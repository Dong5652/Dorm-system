<script setup lang="ts">
/**
 * 宿舍级联选择器（任务 3.9）：楼栋 → 楼层 → 房间 → 床位。
 * 数据来源 GET /api/v1/dorm/tree。供后续入住/异动/费用等模块复用。
 *
 * v-model 出参：{ buildingId, floorId, roomId, bedId }，未选中的层级用 null。
 */
import { computed, onMounted, ref, watch } from 'vue'
import { fetchDormTree, type BuildingTreeNode, type FloorTreeNode, type RoomTreeNode, type BedTreeNode } from '@/api/dorm'

export interface DormSelection {
  buildingId: number | null
  floorId: number | null
  roomId: number | null
  bedId: number | null
}

const props = withDefaults(
  defineProps<{
    modelValue: DormSelection
    /** 是否禁用各层级（用于"只读到楼层"等场景） */
    disableFloor?: boolean
    disableRoom?: boolean
    disableBed?: boolean
    /** 是否只展示到楼层/房间，不展示床位 */
    showBed?: boolean
    placeholder?: string
  }>(),
  { showBed: true, disableFloor: false, disableRoom: false, disableBed: false, placeholder: '请选择' },
)

const emit = defineEmits<{
  'update:modelValue': [DormSelection]
  change: [DormSelection]
}>()

const tree = ref<BuildingTreeNode[]>([])
const loading = ref(false)

const buildings = computed(() => tree.value)
const floors = computed<FloorTreeNode[]>(() => {
  const b = tree.value.find((x) => x.id === props.modelValue.buildingId)
  return b?.floors ?? []
})
const rooms = computed<RoomTreeNode[]>(() => {
  const f = floors.value.find((x) => x.id === props.modelValue.floorId)
  return f?.rooms ?? []
})
const beds = computed<BedTreeNode[]>(() => {
  const r = rooms.value.find((x) => x.id === props.modelValue.roomId)
  return r?.beds ?? []
})

function patch(next: Partial<DormSelection>) {
  const merged = { ...props.modelValue, ...next }
  emit('update:modelValue', merged)
  emit('change', merged)
}

function onBuilding(id: number | null) {
  patch({ buildingId: id, floorId: null, roomId: null, bedId: null })
}
function onFloor(id: number | null) {
  patch({ floorId: id, roomId: null, bedId: null })
}
function onRoom(id: number | null) {
  patch({ roomId: id, bedId: null })
}
function onBed(id: number | null) {
  patch({ bedId: id })
}

// 外部把 modelValue 改了，例如 reset 时同步清空
watch(
  () => props.modelValue,
  (v) => {
    if (!v.buildingId && !v.floorId && !v.roomId && !v.bedId) return
  },
  { deep: true },
)

onMounted(async () => {
  loading.value = true
  try {
    tree.value = await fetchDormTree()
  } catch {
    // 响应拦截器已弹错
  } finally {
    loading.value = false
  }
})
</script>

<template>
  <div class="dorm-selector">
    <el-select
      :model-value="modelValue.buildingId"
      :placeholder="placeholder"
      :loading="loading"
      clearable
      filterable
      style="width: 180px"
      @update:model-value="onBuilding"
    >
      <el-option v-for="b in buildings" :key="b.id" :label="`${b.code} ${b.name}`" :value="b.id" />
    </el-select>

    <el-select
      :model-value="modelValue.floorId"
      :placeholder="disableFloor ? '已禁用' : '楼层'"
      :disabled="disableFloor || !modelValue.buildingId"
      clearable
      filterable
      style="width: 110px"
      @update:model-value="onFloor"
    >
      <el-option v-for="f in floors" :key="f.id" :label="`${f.floorNo} 层`" :value="f.id" />
    </el-select>

    <el-select
      :model-value="modelValue.roomId"
      :placeholder="disableRoom ? '已禁用' : '房间'"
      :disabled="disableRoom || !modelValue.floorId"
      clearable
      filterable
      style="width: 140px"
      @update:model-value="onRoom"
    >
      <el-option v-for="r in rooms" :key="r.id" :label="`${r.roomNo}（${r.occupiedCount}/${r.capacity}）`" :value="r.id" />
    </el-select>

    <el-select
      v-if="showBed"
      :model-value="modelValue.bedId"
      :placeholder="disableBed ? '已禁用' : '床位'"
      :disabled="disableBed || !modelValue.roomId"
      clearable
      filterable
      style="width: 110px"
      @update:model-value="onBed"
    >
      <el-option v-for="b in beds" :key="b.id" :label="`${b.bedNo} 床`" :value="b.id" />
    </el-select>
  </div>
</template>

<style scoped>
.dorm-selector {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  align-items: center;
}
</style>
