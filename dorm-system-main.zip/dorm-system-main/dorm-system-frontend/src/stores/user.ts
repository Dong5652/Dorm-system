import { defineStore } from 'pinia'
import { ref } from 'vue'

const TOKEN_KEY = 'dorm-token'

/**
 * 当前登录用户状态。token 持久化到 localStorage，详情字段每次登录/F5 重新拉 /auth/me 填充。
 */
export const useUserStore = defineStore('user', () => {
  const token = ref<string>(localStorage.getItem(TOKEN_KEY) || '')
  const userId = ref<number | null>(null)
  const username = ref<string>('')
  const realName = ref<string>('')
  const role = ref<string>('')
  const buildingId = ref<number | null>(null)
  const buildingName = ref<string>('')
  const gender = ref<number | null>(null)
  const phone = ref<string>('')
  const fetched = ref<boolean>(false)

  function setToken(value: string) {
    token.value = value
    localStorage.setItem(TOKEN_KEY, value)
  }

  function setUserInfo(info: {
    userId: number
    username: string
    realName: string
    role: string
    buildingId: number | null
    buildingName: string | null
    gender: number
    phone: string
  }) {
    userId.value = info.userId
    username.value = info.username
    realName.value = info.realName
    role.value = info.role
    buildingId.value = info.buildingId
    buildingName.value = info.buildingName ?? ''
    gender.value = info.gender
    phone.value = info.phone
    fetched.value = true
  }

  function clearToken() {
    token.value = ''
    localStorage.removeItem(TOKEN_KEY)
    userId.value = null
    username.value = ''
    realName.value = ''
    role.value = ''
    buildingId.value = null
    buildingName.value = ''
    gender.value = null
    phone.value = ''
    fetched.value = false
  }

  function isLoggedIn() {
    return !!token.value
  }

  return {
    token, userId, username, realName, role,
    buildingId, buildingName, gender, phone, fetched,
    setToken, setUserInfo, clearToken, isLoggedIn,
  }
})
