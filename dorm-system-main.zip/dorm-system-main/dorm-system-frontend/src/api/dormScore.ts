import api from './index'

/**
 * 寝室综合评分接口（API_SPEC §6.3）。
 * 后端响应拦截器已拆 envelope，此处直接拿 data。
 */

// ---- 实体 / DTO ----------------------------------------------------------

export interface DormScoreResponse {
  roomId: number
  buildingId: number | null
  buildingName: string | null
  roomNo: string | null
  yearMonth: string
  hygieneAvg: number
  lateCount: number
  totalScore: number
  level: string
  rank: number
  remark: string | null
}

export interface DormScoreQuery {
  yearMonth?: string
  buildingId?: number
  roomId?: number
}

export interface DormScoreManualRequest {
  roomId: number
  yearMonth: string
  hygieneAvg?: number
  lateCount?: number
  totalScore?: number
  level?: string
  remark?: string
}

export interface DormScoreTriggerRequest {
  yearMonth: string
}

export interface DormScoreTriggerResult {
  yearMonth: string
  affected: number
}

export const LEVEL_LABELS: Record<string, string> = {
  '优秀': '优秀',
  '合格': '合格',
  '待整改': '待整改',
  '不合格': '不合格',
}

export const LEVEL_TYPES: Record<string, '' | 'success' | 'warning' | 'info' | 'danger'> = {
  '优秀': 'success',
  '合格': '',
  '待整改': 'warning',
  '不合格': 'danger',
}

// ---- 接口 ----------------------------------------------------------------

export const listDormScores = (params: DormScoreQuery) =>
  api.get<unknown, { list: DormScoreResponse[] }>('/api/v1/dorm/scores', { params })

export const manualDormScore = (payload: DormScoreManualRequest) =>
  api.post<unknown, unknown>('/api/v1/admin/dorm/scores/manual', payload)

export const triggerDormScore = (payload: DormScoreTriggerRequest) =>
  api.post<unknown, DormScoreTriggerResult>('/api/v1/admin/dorm/scores/trigger', payload)
