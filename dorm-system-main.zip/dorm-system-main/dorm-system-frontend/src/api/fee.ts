import api from './index'

export interface Fee {
  id: number
  studentId: number
  feeType: string
  yearMonth: string
  semester: string
  amount: number
  paidAmount: number
  paidStatus: number
  dueDate: string
  remark: string
  createdAt: string
}

export interface MeterReading {
  id: number
  roomId: number
  meterType: number
  readingValue: number
  previousValue: number
  usageAmount: number
  unitPrice: number
  amount: number
  readingMonth: string
  readerId: number
  remark: string
  createdAt: string
}

export interface PageResult<T> {
  records: T[]
  total: number
}

export const queryFees = (params?: {
  page?: number
  size?: number
  feeType?: string
  yearMonth?: string
  paidStatus?: number
}) => api.get<unknown, PageResult<Fee>>('/api/v1/fee', { params })

export const queryAdminFees = (params?: {
  page?: number
  size?: number
  studentId?: number
  feeType?: string
  yearMonth?: string
  paidStatus?: number
}) => api.get<unknown, PageResult<Fee>>('/api/v1/admin/fee', { params })

export const generateAccommodationFee = (data: {
  semester: string
  amount: number
  dueDate: string
}) => api.post<unknown, void>('/api/v1/admin/fee/accommodation/generate', data)

export const generateUtilityFee = (data: { readingMonth: string }) =>
  api.post<unknown, void>('/api/v1/admin/fee/utility/generate', data)

export const payFee = (id: number, data: { payType: number; amount: number; payNo: string }) =>
  api.post<unknown, void>(`/api/v1/admin/fee/${id}/pay`, data)

export const remindFee = (id: number) =>
  api.post<unknown, void>(`/api/v1/admin/fee/${id}/remind`)

export const queryMeterReadings = (params?: { page?: number; size?: number; roomId?: number }) =>
  api.get<unknown, PageResult<MeterReading>>('/api/v1/dorm/meter', { params })

export const addMeterReading = (data: {
  roomId: number
  meterType: number
  readingValue: number
  readingMonth: string
  remark?: string
}) => api.post<unknown, void>('/api/v1/dorm/meter', data)

export const updateMeterReading = (
  id: number,
  data: { readingValue: number; readingMonth: string; remark?: string },
) => api.put<unknown, void>(`/api/v1/admin/dorm/meter/${id}`, data)

export const deleteMeterReading = (id: number) =>
  api.delete<unknown, void>(`/api/v1/admin/dorm/meter/${id}`)
