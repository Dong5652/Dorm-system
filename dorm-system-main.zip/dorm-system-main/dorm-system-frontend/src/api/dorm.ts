import api from './index'

/**
 * 宿舍基础数据接口（API_SPEC §3）：楼栋 / 楼层 / 房间 / 床位 CRUD + 宿舍树 / 空置统计。
 * 后端响应拦截器已拆 envelope，此处直接拿 data。
 */

// ---- 实体 / DTO ----------------------------------------------------------

export interface Building {
  id: number
  code: string
  name: string
  /** 1男 2女 3混合 */
  gender: number
  floorCount: number
  managerId: number | null
  remark: string | null
  createdAt?: string
}

export interface Floor {
  id: number
  buildingId: number
  floorNo: number
  roomCount: number
  createdAt?: string
}

/** 0空闲 1部分入住 2满员 3维修中 4锁定预留 */
export type RoomStatus = 0 | 1 | 2 | 3 | 4

export interface Room {
  id: number
  buildingId: number
  floorId: number
  roomNo: string
  capacity: number
  occupiedCount: number
  status: RoomStatus
  remark: string | null
  createdAt?: string
}

/** 0空闲 1已占用 2维修中 3预留 */
export type BedStatus = 0 | 1 | 2 | 3

export interface Bed {
  id: number
  roomId: number
  bedNo: string
  studentId: number | null
  status: BedStatus
  checkInTime: string | null
  createdAt?: string
}

export interface BuildingSaveRequest {
  code: string
  name: string
  gender: number
  floorCount: number
  managerId?: number | null
  remark?: string | null
}

export interface FloorSaveRequest {
  buildingId: number
  floorNo: number
  roomCount?: number
}

export interface RoomSaveRequest {
  buildingId: number
  floorId: number
  roomNo: string
  capacity: number
  status?: RoomStatus
  remark?: string | null
}

export interface BedSaveRequest {
  roomId: number
  bedNo: string
  status?: BedStatus
}

export interface Page<T> {
  records: T[]
  total: number
  size: number
  current: number
  pages: number
}

// ---- 树 / 空置统计 --------------------------------------------------------

export interface BedTreeNode {
  id: number
  bedNo: string
  status: BedStatus
  studentId: number | null
  studentName: string | null
}

export interface RoomTreeNode {
  id: number
  roomNo: string
  capacity: number
  occupiedCount: number
  status: RoomStatus
  beds: BedTreeNode[]
}

export interface FloorTreeNode {
  id: number
  floorNo: number
  rooms: RoomTreeNode[]
}

export interface BuildingTreeNode {
  id: number
  code: string
  name: string
  gender: number
  floors: FloorTreeNode[]
}

export interface VacancyStat {
  buildingId: number
  buildingName: string
  totalBeds: number
  occupiedBeds: number
  vacantBeds: number
  occupancyRate: number
}

// ---- 字典 / 通用 ----------------------------------------------------------

export const GENDER_LABELS: Record<number, string> = { 1: '男', 2: '女', 3: '混合' }
export const ROOM_STATUS_LABELS: Record<number, string> = {
  0: '空闲', 1: '部分入住', 2: '满员', 3: '维修中', 4: '锁定预留',
}
export const ROOM_STATUS_TYPES: Record<number, '' | 'success' | 'warning' | 'info' | 'danger'> = {
  0: 'info', 1: '', 2: 'success', 3: 'warning', 4: 'danger',
}
export const BED_STATUS_LABELS: Record<number, string> = {
  0: '空闲', 1: '已占用', 2: '维修中', 3: '预留',
}
export const BED_STATUS_TYPES: Record<number, '' | 'success' | 'warning' | 'info' | 'danger'> = {
  0: 'info', 1: 'success', 2: 'warning', 3: 'danger',
}

// ---- Building -------------------------------------------------------------

export const pageBuildings = (params: {
  pageNum?: number
  pageSize?: number
  keyword?: string
  gender?: number
}) => api.get<unknown, Page<Building>>('/api/v1/admin/buildings', { params })

export interface SysUser {
  id: number
  username: string
  realName: string
  role: string
  gender: number
  phone: string | null
  buildingId: number | null
}

export const listAllBuildings = () =>
  api.get<unknown, Building[]>('/api/v1/admin/buildings/all')

export const listManagers = () =>
  api.get<unknown, SysUser[]>('/api/v1/admin/buildings/managers')

export const getBuilding = (id: number) =>
  api.get<unknown, Building>(`/api/v1/admin/buildings/${id}`)

export const createBuilding = (payload: BuildingSaveRequest) =>
  api.post<unknown, Building>('/api/v1/admin/buildings', payload)

export const updateBuilding = (id: number, payload: BuildingSaveRequest) =>
  api.put<unknown, Building>(`/api/v1/admin/buildings/${id}`, payload)

export const deleteBuilding = (id: number) =>
  api.delete<unknown, void>(`/api/v1/admin/buildings/${id}`)

// ---- Floor ----------------------------------------------------------------

export const pageFloors = (params: {
  pageNum?: number
  pageSize?: number
  buildingId?: number
}) => api.get<unknown, Page<Floor>>('/api/v1/admin/floors', { params })

export const createFloor = (payload: FloorSaveRequest) =>
  api.post<unknown, Floor>('/api/v1/admin/floors', payload)

export const updateFloor = (id: number, payload: FloorSaveRequest) =>
  api.put<unknown, Floor>(`/api/v1/admin/floors/${id}`, payload)

export const deleteFloor = (id: number) =>
  api.delete<unknown, void>(`/api/v1/admin/floors/${id}`)

// ---- Room -----------------------------------------------------------------

export const pageRooms = (params: {
  pageNum?: number
  pageSize?: number
  buildingId?: number
  floorId?: number
}) => api.get<unknown, Page<Room>>('/api/v1/admin/rooms', { params })

export const getRoom = (id: number) =>
  api.get<unknown, Room>(`/api/v1/admin/rooms/${id}`)

export const createRoom = (payload: RoomSaveRequest) =>
  api.post<unknown, Room>('/api/v1/admin/rooms', payload)

export const updateRoom = (id: number, payload: RoomSaveRequest) =>
  api.put<unknown, Room>(`/api/v1/admin/rooms/${id}`, payload)

export const setRoomStatus = (id: number, status: RoomStatus) =>
  api.put<unknown, Room>(`/api/v1/admin/rooms/${id}/status`, { status })

export const deleteRoom = (id: number) =>
  api.delete<unknown, void>(`/api/v1/admin/rooms/${id}`)

// ---- Bed ------------------------------------------------------------------

export const pageBeds = (params: {
  pageNum?: number
  pageSize?: number
  roomId?: number
}) => api.get<unknown, Page<Bed>>('/api/v1/admin/beds', { params })

export const createBed = (payload: BedSaveRequest) =>
  api.post<unknown, Bed>('/api/v1/admin/beds', payload)

export const updateBed = (id: number, payload: BedSaveRequest) =>
  api.put<unknown, Bed>(`/api/v1/admin/beds/${id}`, payload)

export const setBedStatus = (id: number, status: BedStatus) =>
  api.put<unknown, Bed>(`/api/v1/admin/beds/${id}/status`, { status })

export const deleteBed = (id: number) =>
  api.delete<unknown, void>(`/api/v1/admin/beds/${id}`)

// ---- 宿舍树 / 空置统计 ----------------------------------------------------

export const fetchDormTree = () =>
  api.get<unknown, BuildingTreeNode[]>('/api/v1/dorm/tree')

export const fetchVacancy = () =>
  api.get<unknown, VacancyStat[]>('/api/v1/dorm/vacancy')
