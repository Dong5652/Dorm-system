import api from './index'

export interface OperationLog {
  id: number
  operatorId: number
  module: string
  action: string
  targetTable?: string
  targetId?: number
  detail?: string
  ip?: string
  createdAt: string
}

export interface PageResult<T> {
  records: T[]
  total: number
}

export const queryLogs = (params?: {
  page?: number
  size?: number
  operatorId?: number
  module?: string
  action?: string
}) => api.get<unknown, PageResult<OperationLog>>('/api/v1/admin/logs', { params })
