import api from './index'

export interface OccupancyStats {
  dimName: string
  totalBeds: number
  occupiedBeds: number
  vacantBeds: number
  occupancyRate: number
}

export interface DisciplineRecord {
  type: string
  description: string
  time: string
  studentId?: number
  roomId?: number
  score?: number
}

export const getOccupancyStats = (params?: { groupBy?: string; buildingId?: number }) =>
  api.get<unknown, OccupancyStats[]>('/api/v1/stats/occupancy', { params })

export const getDisciplineTimeline = (params?: {
  studentNo?: string
  roomId?: number
  startDate?: string
  endDate?: string
}) => api.get<unknown, DisciplineRecord[]>('/api/v1/stats/discipline', { params })

export const exportReport = (type: string) =>
  api.get<unknown, Blob>('/api/v1/stats/export', {
    params: { type },
    responseType: 'blob',
  })
