import api from './index'

/**
 * 维修师傅账号管理接口（API_SPEC §7.2）。
 * 后端响应拦截器已拆 envelope，此处直接拿 data。
 */

export interface Repairman {
  id: number
  username: string
  realName: string
  gender: number
  phone: string | null
  workType: string | null
  status: number
}

export interface RepairmanSaveRequest {
  username: string
  realName: string
  gender: number
  phone?: string
  workType?: string
  status?: number
}

export const listRepairmen = () =>
  api.get<unknown, Repairman[]>('/api/v1/admin/repairmen')

export const getRepairman = (id: number) =>
  api.get<unknown, Repairman>(`/api/v1/admin/repairmen/${id}`)

export const createRepairman = (payload: RepairmanSaveRequest) =>
  api.post<unknown, Repairman>('/api/v1/admin/repairmen', payload)

export const updateRepairman = (id: number, payload: RepairmanSaveRequest) =>
  api.put<unknown, Repairman>(`/api/v1/admin/repairmen/${id}`, payload)

export const deleteRepairman = (id: number) =>
  api.delete<unknown, void>(`/api/v1/admin/repairmen/${id}`)

export const GENDER_LABELS: Record<number, string> = { 1: '男', 2: '女' }
export const REPAIRMAN_WORK_TYPES = ['水电', '木工', '综合', '油漆', '泥瓦']
