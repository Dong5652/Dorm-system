import api from './index'

export interface Announcement {
  id: number
  title: string
  content: string
  scope: number
  buildingId?: number
  targetRoomId?: number
  targetStudentId?: number
  publishBy: number
  publishTime: string
  isPinned: number
  expireTime: string
  status: number
  createdAt: string
}

export interface NoticeMessage {
  id: number
  toUserId: number
  fromUserId?: number
  msgType: string
  title: string
  content: string
  refId?: number
  isRead: number
  readTime?: string
  createdAt: string
}

export interface PageResult<T> {
  records: T[]
  total: number
  size?: number
  current?: number
}

export const queryAnnouncements = (params?: { page?: number; size?: number }) =>
  api.get<unknown, PageResult<Announcement>>('/api/v1/announcement', { params })

export const getAnnouncementDetail = (id: number) =>
  api.get<unknown, Announcement>(`/api/v1/announcement/${id}`)

export const queryAdminAnnouncements = (params?: { page?: number; size?: number }) =>
  api.get<unknown, PageResult<Announcement>>('/api/v1/admin/announcement', { params })

export const publishAnnouncement = (data: {
  title: string
  content: string
  scope: number
  buildingId?: number
  targetRoomId?: number
  targetStudentId?: number
  isPinned: boolean
  publishTime?: string
  expireTime?: string
}) => api.post<unknown, void>('/api/v1/admin/announcement', data)

export const updateAnnouncement = (id: number, data: Record<string, unknown>) =>
  api.put<unknown, void>(`/api/v1/admin/announcement/${id}`, data)

export const deleteAnnouncement = (id: number) =>
  api.delete<unknown, void>(`/api/v1/admin/announcement/${id}`)

export const pinAnnouncement = (id: number) =>
  api.put<unknown, void>(`/api/v1/admin/announcement/${id}/pin`)

export const offlineAnnouncement = (id: number) =>
  api.put<unknown, void>(`/api/v1/admin/announcement/${id}/offline`)

export const queryNotices = (params?: { page?: number; size?: number }) =>
  api.get<unknown, PageResult<NoticeMessage>>('/api/v1/notice', { params })

export const getUnreadNoticeCount = () =>
  api.get<unknown, number>('/api/v1/notice/unread-count')

export const readNotice = (id: number) =>
  api.put<unknown, void>(`/api/v1/notice/${id}/read`)

export const readAllNotices = () =>
  api.put<unknown, void>('/api/v1/notice/read-all')

export const deleteNotice = (id: number) =>
  api.delete<unknown, void>(`/api/v1/notice/${id}`)
