import axios, {
  type AxiosInstance,
  type AxiosResponse,
  type InternalAxiosRequestConfig,
} from 'axios'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'
import router from '@/router'

export interface ApiEnvelope<T> {
  code: number
  message: string
  data: T
}

const api: AxiosInstance = axios.create({
  // baseURL 留空 → 与 dev server 同源，再由 vite.config proxy /api 转发到 8080
  baseURL: import.meta.env.VITE_API_BASE_URL || '',
  timeout: 15000,
})

// 请求拦截：自动附加 Bearer token
api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = useUserStore().token
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// 响应拦截：按 API_SPEC §1.1 / §13.6 统一拆 code
api.interceptors.response.use(
  (res: AxiosResponse<ApiEnvelope<unknown>>) => {
    const body = res.data
    if (body.code !== 0) {
      ElMessage.error(body.message || '请求失败')
      return Promise.reject(body)
    }
    return body.data as never
  },
  (err) => {
    const status = err.response?.status
    const body = err.response?.data
    const msg = body?.message || err.message
    if (status === 401) {
      // 401 → 清 token + 跳登录页（仅一次）
      const store = useUserStore()
      if (store.token) {
        store.clearToken()
        ElMessage.error('登录已失效，请重新登录')
        const cur = router.currentRoute.value.fullPath
        if (!cur.startsWith('/login')) {
          router.replace({ path: '/login', query: { redirect: cur } })
        }
      }
    } else if (status === 403) {
      ElMessage.error(body?.message || '无权限')
    } else {
      ElMessage.error(msg || '网络错误')
    }
    return Promise.reject(err)
  },
)

// 健康检查（Phase 1 联调用）
export const ping = () => api.get<unknown, string>('/api/v1/ping')

export default api
