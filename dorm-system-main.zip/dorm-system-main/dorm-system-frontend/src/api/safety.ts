import api from './index'

// ==========================================
// 访客管理
// ==========================================
export interface Visitor {
  id: number
  visitorName: string
  idCard: string
  phone: string
  visitTargetId?: number
  buildingId: number
  purpose: string
  enterTime: string
  exitTime?: string
  registerBy: number
  remark?: string
  createdAt: string
}

export interface VisitorRequest {
  visitorName: string
  idCard: string
  phone?: string
  visitTargetId?: number
  buildingId: number
  purpose: string
  enterTime: string
  remark?: string
}

export const queryVisitors = (params?: {
  buildingId?: number
  date?: string
  targetStudentId?: number
}) => api.get<unknown, Visitor[]>('/api/v1/safety/visitor', { params })

export const registerVisitor = (data: VisitorRequest) =>
  api.post<unknown, void>('/api/v1/safety/visitor', data)

export const exitVisitor = (id: number) =>
  api.put<unknown, void>(`/api/v1/safety/visitor/${id}/exit`)

export const deleteVisitor = (id: number) =>
  api.delete<unknown, void>(`/api/v1/admin/safety/visitor/${id}`)

// ==========================================
// 违禁品检查
// ==========================================
export interface SafetyInspection {
  id: number
  roomId: number
  studentId?: number
  inspectDate: string
  inspectorId: number
  itemType: string
  itemDesc: string
  photoUrl?: string
  disposition: string
  noticeSent: number
  remark?: string
  createdAt: string
}

export interface SafetyInspectionRequest {
  roomId: number
  studentId?: number
  inspectDate: string
  itemType: string
  itemDesc: string
  photoUrl?: string
  disposition: string
  noticeSent?: boolean
  remark?: string
}

export const queryInspections = (params?: {
  roomId?: number
  studentId?: number
  startDate?: string
  endDate?: string
}) => api.get<unknown, SafetyInspection[]>('/api/v1/safety/inspection', { params })

export const recordInspection = (data: SafetyInspectionRequest) =>
  api.post<unknown, void>('/api/v1/safety/inspection', data)

export const updateInspection = (id: number, data: SafetyInspectionRequest) =>
  api.put<unknown, void>(`/api/v1/admin/safety/inspection/${id}`, data)

export const deleteInspection = (id: number) =>
  api.delete<unknown, void>(`/api/v1/admin/safety/inspection/${id}`)

// ==========================================
// 安全事件
// ==========================================
export interface SafetyEvent {
  id: number
  buildingId: number
  roomId?: number
  eventType: string
  severity: number
  description: string
  photoUrl?: string
  reportedBy: number
  handled: number
  handleNote?: string
  happenedAt: string
  createdAt: string
}

export interface SafetyEventRequest {
  buildingId: number
  roomId?: number
  eventType: string
  severity: number
  description: string
  photoUrl?: string
  happenedAt: string
}

export const queryEvents = (params?: {
  buildingId?: number
  handled?: number
  severity?: number
  startDate?: string
  endDate?: string
}) => api.get<unknown, SafetyEvent[]>('/api/v1/safety/event', { params })

export const reportEvent = (data: SafetyEventRequest) =>
  api.post<unknown, void>('/api/v1/safety/event', data)

export const handleEvent = (id: number, handleNote: string) =>
  api.put<unknown, void>(`/api/v1/admin/safety/event/${id}/handle`, { handleNote })

export const deleteEvent = (id: number) =>
  api.delete<unknown, void>(`/api/v1/admin/safety/event/${id}`)
