import api from './index'
import type { Page } from './dorm'

/**
 * 晚归考勤接口（API_SPEC §6.2）。
 * 后端响应拦截器已拆 envelope，此处直接拿 data。
 */

// ---- 实体 / DTO ----------------------------------------------------------

export interface Attendance {
  id: number
  studentId: number
  roomId: number
  recordDate: string
  /** 1晚归 2未归 3请假 */
  type: 1 | 2 | 3
  /** ISO LocalDateTime，如 2026-03-16T01:30:00 */
  returnTime: string | null
  inspectorId: number
  remark: string | null
  createdAt?: string
}

export interface AttendanceResponse extends Attendance {
  studentName: string | null
  studentNo: string | null
  roomNo: string | null
  buildingId: number | null
  buildingName: string | null
  inspectorName: string | null
}

export interface AttendanceSaveRequest {
  studentId: number
  recordDate: string
  type: 1 | 2 | 3
  returnTime?: string | null
  remark?: string
}

export interface AttendancePageQuery {
  pageNum?: number
  pageSize?: number
  studentId?: number
  roomId?: number
  buildingId?: number
  type?: number
  startDate?: string
  endDate?: string
}

export const ATTENDANCE_TYPE_LABELS: Record<number, string> = {
  1: '晚归', 2: '未归', 3: '请假',
}
export const ATTENDANCE_TYPE_TYPES: Record<number, '' | 'success' | 'warning' | 'info' | 'danger'> = {
  1: 'warning', 2: 'danger', 3: 'info',
}

export const pageAttendance = (params: AttendancePageQuery) =>
  api.get<unknown, Page<AttendanceResponse>>('/api/v1/dorm/attendance', { params })

export const getAttendance = (id: number) =>
  api.get<unknown, AttendanceResponse>(`/api/v1/dorm/attendance/${id}`)

export const createAttendance = (payload: AttendanceSaveRequest) =>
  api.post<unknown, Attendance>('/api/v1/dorm/attendance', payload)

export const updateAttendance = (id: number, payload: AttendanceSaveRequest) =>
  api.put<unknown, Attendance>(`/api/v1/dorm/attendance/${id}`, payload)

export const deleteAttendance = (id: number) =>
  api.delete<unknown, void>(`/api/v1/dorm/attendance/${id}`)
