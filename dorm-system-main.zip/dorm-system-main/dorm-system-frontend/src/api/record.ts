import api from './index'

/**
 * 入住退宿异动接口（API_SPEC §4 / 阶段5）。
 * 后端响应拦截器已拆 envelope，此处直接拿 data。
 *
 * <ul>
 *   <li>办理入住/退宿/调宿/异动：ADMIN + DORM_MANAGER 均可</li>
 *   <li>自动分配、批量退宿：仅 ADMIN</li>
 *   <li>流水查询：所有登录角色（Service 内部按角色收敛数据范围）</li>
 * </ul>
 */

// ---- 请求 DTO ------------------------------------------------------------

export interface CheckInRequest {
  studentId: number
  bedId: number
  keyIssued?: boolean
  facilityCheck?: string
  remark?: string
}

export interface CheckOutRequest {
  studentId: number
  keyReturned?: boolean
  facilityCheck?: string
  remark?: string
}

export interface ChangeRoomRequest {
  studentId: number
  fromBedId: number
  toBedId: number
  reason?: string
}

/** 异动类型：suspend 休学 / transfer 转专业 / holiday_leave 假期离校 */
export type StudentChangeType = 'suspend' | 'transfer' | 'holiday_leave'

export interface StudentChangeRequest {
  studentId: number
  type: StudentChangeType
  reason?: string
  remark?: string
}

export interface AutoAssignRequest {
  buildingId?: number | null
  preferredFloor?: number | null
}

export interface BatchCheckOutRequest {
  grade: string
  className?: string
  reason?: string
  keyReturned?: boolean
}

// ---- 响应 DTO ------------------------------------------------------------

/** check_in / auto_assign 返回的 Map<String,Object> */
export interface CheckInResultData {
  recordId: number
  bedId: number
}

/** batchCheckOut 返回的 Map<String,Object> */
export interface BatchCheckOutResultData {
  totalCount: number
  successCount: number
  failedCount: number
}

/**
 * 流水查询合并视图。来源由 recordType 区分：
 * check_in_record → recordType='check_in'，type 用 1 入住 / 2 退宿；
 * change_record   → recordType='change'，changeType 用 suspend/transfer/change_room/holiday_leave。
 */
export interface DormRecordResponse {
  id: number
  recordType: 'check_in' | 'change'

  studentId: number
  studentName: string | null
  studentNo: string | null

  /* check_in 来源字段 */
  bedId?: number | null
  bedNo?: string | null
  roomId?: number | null
  roomNo?: string | null
  buildingName?: string | null
  /** 1 入住 2 退宿 */
  type?: number | null
  /** 入住时表示是否已发钥匙；退宿时表示是否已收钥匙（0/1） */
  keyIssued?: number | null
  keyReturned?: number | null
  facilityCheck?: string | null

  /* change 来源字段 */
  changeType?: string | null
  changeTypeLabel?: string | null
  fromBedId?: number | null
  fromBedNo?: string | null
  fromRoomNo?: string | null
  toBedId?: number | null
  toBedNo?: string | null
  toRoomNo?: string | null
  reason?: string | null

  /* 通用 */
  operatorId: number | null
  operatorName: string | null
  /** ISO LocalDateTime，形如 2026-07-18T10:30:00；展示前 replace('T',' ') */
  happenedAt: string
  remark: string | null
}

// ---- 字典 ----------------------------------------------------------------

/** 流水来源大类 */
export const RECORD_TYPE_LABELS: Record<string, string> = {
  check_in: '入住退宿',
  change: '异动登记',
}
export const RECORD_TYPE_TYPES: Record<string, '' | 'success' | 'warning' | 'info' | 'danger'> = {
  check_in: 'success',
  change: 'warning',
}

/** check_in_record.type：1 入住 / 2 退宿 */
export const CHECK_IN_OUT_TYPE_LABELS: Record<number, string> = { 1: '入住', 2: '退宿' }
export const CHECK_IN_OUT_TYPE_TYPES: Record<number, '' | 'success' | 'warning' | 'info' | 'danger'> = {
  1: 'success',
  2: 'info',
}

/** 异动类型（含 change_room，调宿虽走 change_record 但 type='change_room'） */
export const CHANGE_TYPE_LABELS: Record<string, string> = {
  suspend: '休学',
  transfer: '转专业',
  change_room: '调宿',
  holiday_leave: '假期离校',
}
export const CHANGE_TYPE_TYPES: Record<string, '' | 'success' | 'warning' | 'info' | 'danger'> = {
  suspend: 'danger',
  transfer: 'warning',
  change_room: '',
  holiday_leave: 'info',
}

// ---- 接口 ----------------------------------------------------------------

/** 办理入住 */
export const checkIn = (payload: CheckInRequest) =>
  api.post<unknown, CheckInResultData>('/api/v1/dorm/check-in', payload)

/** 自动分配床位（仅 ADMIN） */
export const autoAssign = (studentId: number, payload: AutoAssignRequest) =>
  api.post<unknown, CheckInResultData>(`/api/v1/admin/students/${studentId}/auto-assign`, payload)

/** 办理退宿 */
export const checkOut = (payload: CheckOutRequest) =>
  api.post<unknown, void>('/api/v1/dorm/check-out', payload)

/** 办理调宿 */
export const changeRoom = (payload: ChangeRoomRequest) =>
  api.post<unknown, void>('/api/v1/dorm/change-room', payload)

/** 异动登记（休学/转专业/假期离校） */
export const studentChange = (payload: StudentChangeRequest) =>
  api.post<unknown, void>('/api/v1/dorm/change', payload)

/** 批量退宿（仅 ADMIN） */
export const batchCheckOut = (payload: BatchCheckOutRequest) =>
  api.post<unknown, BatchCheckOutResultData>('/api/v1/admin/check-out/batch', payload)

/** 入住/退宿/异动流水查询；后端 List 不分页，已按 happenedAt desc 排序 */
export const fetchRecords = (params: {
  studentId?: number
  roomId?: number
  type?: number
  changeType?: string
  startDate?: string // ISO yyyy-MM-dd
  endDate?: string // ISO yyyy-MM-dd
}) => api.get<unknown, DormRecordResponse[]>('/api/v1/dorm/records', { params })
