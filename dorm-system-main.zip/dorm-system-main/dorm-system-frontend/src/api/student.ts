import api from './index'
import type { Page } from './dorm'

export interface Student {
  id: number
  userId: number
  studentNo: string
  name: string
  gender: number
  college: string | null
  major: string | null
  className: string | null
  grade: string | null
  currentBedId: number | null
  emergencyContact: string | null
  emergencyPhone: string | null
  enrollDate: string | null
  status: number // 0在籍 1休学 2毕业 3退学
  createdAt?: string
}

export interface StudentSaveRequest {
  studentNo: string
  name: string
  gender: number
  college?: string | null
  major?: string | null
  className?: string | null
  grade?: string | null
  phone?: string | null
  emergencyContact?: string | null
  emergencyPhone?: string | null
  enrollDate?: string | null
  status: number
}

export interface BedDetail {
  bedId: number
  bedNo: string
  roomId: number
  roomNo: string
  buildingId: number
  buildingName: string
  floorId: number
  floorNo: number
}

export interface ChangeRecordDetail {
  id: number
  type: string
  typeLabel: string
  fromBedId: number | null
  fromBedNo: string | null
  fromRoomNo: string | null
  toBedId: number | null
  toBedNo: string | null
  toRoomNo: string | null
  reason: string | null
  operatorId: number
  operatorName: string
  happenedAt: string
  remark: string | null
}

export interface StudentDetailResponse {
  student: Student
  phone: string | null
  bedDetail: BedDetail | null
  changeRecords: ChangeRecordDetail[]
}

export interface ImportResult {
  successCount: number
  errorList: string[]
}

export const STUDENT_STATUS_LABELS: Record<number, string> = {
  0: '在籍',
  1: '休学',
  2: '毕业',
  3: '退学',
}

export const STUDENT_STATUS_TYPES: Record<number, '' | 'success' | 'warning' | 'info' | 'danger'> = {
  0: 'success',
  1: 'warning',
  2: 'info',
  3: 'danger',
}

// ---- API Call Functions ----

export const pageStudents = (params: {
  pageNum?: number
  pageSize?: number
  keyword?: string
  className?: string
  college?: string
  status?: number
}) => api.get<unknown, Page<Student>>('/api/v1/admin/students', { params })

export const getStudentDetail = (id: number) =>
  api.get<unknown, StudentDetailResponse>(`/api/v1/admin/students/${id}`)

export const createStudent = (payload: StudentSaveRequest) =>
  api.post<unknown, Student>('/api/v1/admin/students', payload)

export const updateStudent = (id: number, payload: StudentSaveRequest) =>
  api.put<unknown, Student>(`/api/v1/admin/students/${id}`, payload)

export const deleteStudent = (id: number) =>
  api.delete<unknown, void>(`/api/v1/admin/students/${id}`)

export const importStudents = (file: File) => {
  const formData = new FormData()
  formData.append('file', file)
  return api.post<unknown, ImportResult>('/api/v1/admin/students/import', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  })
}

export const exportStudentsUrl = (params: {
  keyword?: string
  className?: string
  college?: string
  status?: number
}) => {
  const query = new URLSearchParams()
  if (params.keyword) query.append('keyword', params.keyword)
  if (params.className) query.append('className', params.className)
  if (params.college) query.append('college', params.college)
  if (params.status !== undefined && params.status !== null) query.append('status', String(params.status))
  return `/api/v1/admin/students/export?${query.toString()}`
}
