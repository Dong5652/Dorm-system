import api from './index'
import type { Page } from './dorm'

/**
 * 维修工单接口（API_SPEC §7.1）。
 * 后端响应拦截器已拆 envelope，此处直接拿 data。
 */

// ---- 实体 / DTO ----------------------------------------------------------

export interface RepairOrder {
  id: number
  orderNo: string
  roomId: number
  bedId: number | null
  reporterId: number
  title: string
  description: string | null
  photoUrl: string | null
  status: number
  priority: number
  repairmanId: number | null
  assignedAt: string | null
  assignedById: number | null
  startedAt: string | null
  finishedAt: string | null
  completionNote: string | null
  rating: number | null
  ratingComment: string | null
  createdAt?: string
}

export interface RepairResponse extends RepairOrder {
  buildingId: number | null
  buildingName: string | null
  roomNo: string | null
  bedNo: string | null
  reporterName: string | null
  repairmanName: string | null
  repairmanPhone: string | null
  repairmanWorkType: string | null
  assignedByName: string | null
}

export interface RepairCreateRequest {
  roomId: number
  bedId?: number | null
  title: string
  description?: string
  photoUrl?: string
  priority?: number
}

export interface AssignRequest {
  repairmanId: number
}

export interface FinishRequest {
  completionNote: string
}

export interface RateRequest {
  rating: number
  ratingComment?: string
}

export interface RepairPageQuery {
  pageNum?: number
  pageSize?: number
  status?: number
  priority?: number
  repairmanId?: number
  roomId?: number
  buildingId?: number
  reporterId?: number
  startDate?: string
  endDate?: string
}

// ---- 字典 / 通用 ----------------------------------------------------------

/** 0待派单 1已派单 2维修中 3已完成 4已取消 */
export const REPAIR_STATUS_LABELS: Record<number, string> = {
  0: '待派单', 1: '已派单', 2: '维修中', 3: '已完成', 4: '已取消',
}
export const REPAIR_STATUS_TYPES: Record<number, '' | 'success' | 'warning' | 'info' | 'danger'> = {
  0: 'info', 1: '', 2: 'warning', 3: 'success', 4: 'danger',
}
export const PRIORITY_LABELS: Record<number, string> = {
  0: '普通', 1: '紧急', 2: '非常紧急',
}
export const PRIORITY_TYPES: Record<number, '' | 'success' | 'warning' | 'info' | 'danger'> = {
  0: 'info', 1: 'warning', 2: 'danger',
}

// ---- 接口 ----------------------------------------------------------------

export const pageRepairs = (params: RepairPageQuery) =>
  api.get<unknown, Page<RepairResponse>>('/api/v1/repair', { params })

export const getRepair = (id: number) =>
  api.get<unknown, RepairResponse>(`/api/v1/repair/${id}`)

export const createRepair = (payload: RepairCreateRequest) =>
  api.post<unknown, RepairOrder>('/api/v1/repair', payload)

export const assignRepair = (id: number, payload: AssignRequest) =>
  api.post<unknown, RepairOrder>(`/api/v1/admin/repair/${id}/assign`, payload)

export const startRepair = (id: number) =>
  api.put<unknown, RepairOrder>(`/api/v1/repair/${id}/start`)

export const finishRepair = (id: number, payload: FinishRequest) =>
  api.put<unknown, RepairOrder>(`/api/v1/repair/${id}/finish`, payload)

export const rateRepair = (id: number, payload: RateRequest) =>
  api.put<unknown, RepairOrder>(`/api/v1/repair/${id}/rate`, payload)

export const cancelRepair = (id: number) =>
  api.put<unknown, RepairOrder>(`/api/v1/repair/${id}/cancel`)

export const deleteRepair = (id: number) =>
  api.delete<unknown, void>(`/api/v1/admin/repair/${id}`)
