import api from './index'
import type { Page } from './dorm'

/**
 * 卫生检查接口（API_SPEC §6.1）。
 * 后端响应拦截器已拆 envelope，此处直接拿 data。
 */

// ---- 实体 / DTO ----------------------------------------------------------

export interface HygieneCheck {
  id: number
  roomId: number
  checkDate: string
  inspectorId: number
  score: number
  deduction: number
  bonus: number
  photoUrl: string | null
  itemDetail: string | null
  remark: string | null
  createdAt?: string
}

export interface HygieneResponse extends HygieneCheck {
  buildingId: number | null
  buildingName: string | null
  roomNo: string | null
  inspectorName: string | null
}

export interface HygieneSaveRequest {
  roomId: number
  checkDate: string
  score?: number
  deduction?: number
  bonus?: number
  photoUrl?: string
  itemDetail?: string
  remark?: string
}

export interface HygienePageQuery {
  pageNum?: number
  pageSize?: number
  roomId?: number
  buildingId?: number
  startDate?: string
  endDate?: string
}

export const pageHygiene = (params: HygienePageQuery) =>
  api.get<unknown, Page<HygieneResponse>>('/api/v1/dorm/hygiene', { params })

export const getHygiene = (id: number) =>
  api.get<unknown, HygieneResponse>(`/api/v1/dorm/hygiene/${id}`)

export const createHygiene = (payload: HygieneSaveRequest) =>
  api.post<unknown, HygieneCheck>('/api/v1/dorm/hygiene', payload)

export const updateHygiene = (id: number, payload: HygieneSaveRequest) =>
  api.put<unknown, HygieneCheck>(`/api/v1/dorm/hygiene/${id}`, payload)

export const deleteHygiene = (id: number) =>
  api.delete<unknown, void>(`/api/v1/dorm/hygiene/${id}`)
