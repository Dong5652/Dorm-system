import api from './index'

export interface LoginPayload {
  username: string
  password: string
}

export interface LoginResult {
  token: string
  userId: number
  username: string
  realName: string
  role: string
}

export interface CurrentUser {
  userId: number
  username: string
  realName: string
  role: string
  buildingId: number | null
  buildingName: string | null
  gender: number
  phone: string
}

export const login = (payload: LoginPayload) =>
  api.post<unknown, LoginResult>('/api/v1/auth/login', payload)

export const logout = () => api.post<unknown, void>('/api/v1/auth/logout')

export const fetchCurrentUser = () => api.get<unknown, CurrentUser>('/api/v1/auth/me')

export const changePassword = (oldPassword: string, newPassword: string) =>
  api.put<unknown, void>('/api/v1/auth/password', { oldPassword, newPassword })
