<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { fetchCurrentUser, logout } from '@/api/auth'
import { getUnreadNoticeCount } from '@/api/notice'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const store = useUserStore()
const unreadCount = ref(0)
let unreadTimer: number | undefined

const displayName = computed(() => store.realName || store.username || '未登录')
const role = computed(() => store.role || '')
const isAdmin = computed(() => role.value === 'admin')
const isManager = computed(() => role.value === 'admin' || role.value === 'dorm_manager')
const isStudent = computed(() => role.value === 'student')
const isRepairman = computed(() => role.value === 'repairman')
// 学生可读业务（卫生/考勤/评分/费用）
const canStudentBiz = computed(() => isManager.value || isStudent.value)
// 维修全角色
const canRepair = computed(() => isManager.value || isStudent.value || isRepairman.value)

async function loadMe() {
  if (!store.isLoggedIn()) return
  if (store.fetched) return
  try {
    const me = await fetchCurrentUser()
    store.setUserInfo({
      userId: me.userId,
      username: me.username,
      realName: me.realName,
      role: me.role,
      buildingId: me.buildingId,
      buildingName: me.buildingName,
      gender: me.gender,
      phone: me.phone,
    })
  } catch {
    // 拦截器已弹错并清 token；守卫下一次跳 /login
  }
}

async function refreshUnread() {
  if (!store.isLoggedIn()) {
    unreadCount.value = 0
    return
  }
  try {
    const count = await getUnreadNoticeCount()
    unreadCount.value = Number(count) || 0
  } catch {
    // 未登录或接口失败时静默
  }
}

function startUnreadPolling() {
  stopUnreadPolling()
  refreshUnread()
  unreadTimer = window.setInterval(refreshUnread, 30000)
}

function stopUnreadPolling() {
  if (unreadTimer !== undefined) {
    window.clearInterval(unreadTimer)
    unreadTimer = undefined
  }
}

async function handleLogout() {
  await ElMessageBox.confirm('确定要退出登录吗？', '提示', { type: 'warning' })
    .catch(() => 'cancel')
    .then((r) => (r === 'cancel' ? false : true))
  if (!store.isLoggedIn()) return
  try {
    await logout()
  } catch {
    // 即便网络挂，本地清 token 也行
  }
  store.clearToken()
  unreadCount.value = 0
  stopUnreadPolling()
  ElMessage.success('已退出')
  router.replace('/login')
}

watch(
  () => store.token,
  (token) => {
    if (token) startUnreadPolling()
    else {
      unreadCount.value = 0
      stopUnreadPolling()
    }
  },
)

// 从消息页返回时刷新红点
watch(
  () => router.currentRoute.value.path,
  (path) => {
    if (path === '/notice/my' || path === '/') refreshUnread()
  },
)

onMounted(async () => {
  await loadMe()
  if (store.isLoggedIn()) startUnreadPolling()
})

onUnmounted(stopUnreadPolling)
</script>

<template>
  <el-container class="layout">
    <el-header class="header">
      <div class="brand">
        <span class="logo">宿</span>
        <span class="title">学校宿舍管理系统</span>
      </div>
      <div class="right">
        <el-badge :value="unreadCount" :hidden="unreadCount <= 0" :max="99" class="msg-badge">
          <el-button text class="msg-btn" @click="router.push('/notice/my')">
            <el-icon :size="18"><Message /></el-icon>
            <span>消息</span>
          </el-button>
        </el-badge>
        <el-tag v-if="store.role" type="info" effect="plain" size="small">{{ store.role }}</el-tag>
        <el-dropdown @command="(c) => (c === 'logout' ? handleLogout() : null)">
          <span class="user">
            {{ displayName }}<el-icon class="el-icon--right"><ArrowDown /></el-icon>
          </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="logout">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </el-header>
    <el-container class="content-container">
      <el-aside width="220px" class="aside">
        <el-menu :default-active="router.currentRoute.value.path" router class="menu">
          <el-menu-item index="/">
            <el-icon><HomeFilled /></el-icon>
            <span>首页</span>
          </el-menu-item>
          <el-menu-item v-if="isManager" index="/dorm/buildings">
            <el-icon><OfficeBuilding /></el-icon>
            <span>宿舍管理</span>
          </el-menu-item>
          <el-menu-item v-if="isManager" index="/dorm/room-beds">
            <el-icon><Grid /></el-icon>
            <span>床位可视化</span>
          </el-menu-item>
          <el-menu-item v-if="isManager" index="/dorm/check-in-out">
            <el-icon><Key /></el-icon>
            <span>入住退宿</span>
          </el-menu-item>
          <el-menu-item v-if="canStudentBiz" index="/dorm/hygiene">
            <el-icon><Brush /></el-icon>
            <span>卫生检查</span>
          </el-menu-item>
          <el-menu-item v-if="canStudentBiz" index="/dorm/attendance">
            <el-icon><Clock /></el-icon>
            <span>晚归考勤</span>
          </el-menu-item>
          <el-menu-item v-if="canStudentBiz" index="/dorm/scores">
            <el-icon><TrophyBase /></el-icon>
            <span>寝室评分</span>
          </el-menu-item>
          <el-menu-item v-if="canRepair" index="/repair">
            <el-icon><Tools /></el-icon>
            <span>维修工单</span>
          </el-menu-item>
          <el-menu-item v-if="isAdmin" index="/admin/repairmen">
            <el-icon><Avatar /></el-icon>
            <span>师傅管理</span>
          </el-menu-item>
          <el-menu-item v-if="isManager" index="/student/archive">
            <el-icon><User /></el-icon>
            <span>学生档案</span>
          </el-menu-item>
          <el-menu-item v-if="isManager" index="/safety/visitor">
            <el-icon><Lock /></el-icon>
            <span>访客登记</span>
          </el-menu-item>
          <el-menu-item v-if="isManager" index="/safety/inspection">
            <el-icon><Warning /></el-icon>
            <span>违禁品检查</span>
          </el-menu-item>
          <el-menu-item v-if="isManager" index="/safety/event">
            <el-icon><Bell /></el-icon>
            <span>安全事件</span>
          </el-menu-item>
          <el-menu-item v-if="canStudentBiz" index="/fee/list">
            <el-icon><Money /></el-icon>
            <span>费用管理</span>
          </el-menu-item>
          <el-menu-item v-if="isManager" index="/fee/meter">
            <el-icon><Odometer /></el-icon>
            <span>水电抄表</span>
          </el-menu-item>
          <el-menu-item index="/notice/announcement">
            <el-icon><Notification /></el-icon>
            <span>{{ isAdmin ? '公告管理' : '公告' }}</span>
          </el-menu-item>
          <el-menu-item index="/notice/my">
            <el-icon><Message /></el-icon>
            <span>我的消息</span>
            <el-badge
              v-if="unreadCount > 0"
              :value="unreadCount"
              :max="99"
              class="menu-badge"
            />
          </el-menu-item>
          <el-menu-item v-if="isManager" index="/stats/occupancy">
            <el-icon><DataLine /></el-icon>
            <span>入住率统计</span>
          </el-menu-item>
          <el-menu-item v-if="isManager" index="/stats/discipline">
            <el-icon><WarningFilled /></el-icon>
            <span>违纪记录查询</span>
          </el-menu-item>
          <el-menu-item v-if="isAdmin" index="/stats/export">
            <el-icon><Download /></el-icon>
            <span>报表导出</span>
          </el-menu-item>
          <el-menu-item v-if="isAdmin" index="/admin/logs">
            <el-icon><Monitor /></el-icon>
            <span>操作日志</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <el-main class="main">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<style scoped>
.layout {
  min-height: 100vh;
}
.header {
  background: #409eff;
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  height: 60px;
}
.brand {
  display: flex;
  align-items: center;
  gap: 10px;
}
.logo {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: #fff;
  color: #409eff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
}
.title {
  font-size: 18px;
  font-weight: 600;
}
.right {
  display: flex;
  align-items: center;
  gap: 16px;
}
.msg-badge :deep(.el-badge__content) {
  border: none;
}
.msg-btn {
  color: #fff !important;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}
.user {
  cursor: pointer;
  outline: none;
  color: #fff;
}
.content-container {
  min-height: calc(100vh - 60px);
}
.aside {
  background-color: #fff;
  border-right: 1px solid #e6e6e6;
}
.menu {
  border-right: none;
  padding-top: 12px;
}
.menu-badge {
  margin-left: 8px;
}
.main {
  background: #f5f7fa;
  padding: 24px;
}
</style>
