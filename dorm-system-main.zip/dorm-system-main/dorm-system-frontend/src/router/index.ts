import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'

/**
 * meta.roles: 允许访问的角色列表；缺省表示登录即可。
 * 对照 docs/ROLE_PERMISSION_MATRIX.md / FRONTEND_MENU_VISIBILITY.md
 */
const routes: RouteRecordRaw[] = [
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/LoginView.vue'),
    meta: { public: true, title: '登录' },
  },
  {
    path: '/',
    name: 'home',
    component: () => import('@/layouts/MainLayout.vue'),
    children: [
      {
        path: '',
        name: 'home-default',
        component: () => import('@/views/HomeView.vue'),
        meta: { title: '首页' },
      },
      {
        path: 'dorm/buildings',
        name: 'dorm-buildings',
        component: () => import('@/views/BuildingManagerView.vue'),
        meta: { title: '宿舍管理', roles: ['admin', 'dorm_manager'] },
      },
      {
        path: 'student/archive',
        name: 'student-archive',
        component: () => import('@/views/StudentManagerView.vue'),
        meta: { title: '学生档案', roles: ['admin', 'dorm_manager'] },
      },
      {
        path: 'dorm/check-in-out',
        name: 'dorm-check-in-out',
        component: () => import('@/views/CheckInOutView.vue'),
        meta: { title: '入住退宿', roles: ['admin', 'dorm_manager'] },
      },
      {
        path: 'dorm/room-beds',
        name: 'dorm-room-beds',
        component: () => import('@/views/RoomBedView.vue'),
        meta: { title: '床位可视化', roles: ['admin', 'dorm_manager'] },
      },
      {
        path: 'dorm/hygiene',
        name: 'dorm-hygiene',
        component: () => import('@/views/HygieneView.vue'),
        meta: { title: '卫生检查', roles: ['admin', 'dorm_manager', 'student'] },
      },
      {
        path: 'dorm/attendance',
        name: 'dorm-attendance',
        component: () => import('@/views/AttendanceView.vue'),
        meta: { title: '晚归考勤', roles: ['admin', 'dorm_manager', 'student'] },
      },
      {
        path: 'dorm/scores',
        name: 'dorm-scores',
        component: () => import('@/views/DormScoreView.vue'),
        meta: { title: '寝室评分', roles: ['admin', 'dorm_manager', 'student'] },
      },
      {
        path: 'repair',
        name: 'repair-list',
        component: () => import('@/views/RepairListView.vue'),
        meta: { title: '维修工单', roles: ['admin', 'dorm_manager', 'student', 'repairman'] },
      },
      {
        path: 'repair/:id',
        name: 'repair-detail',
        component: () => import('@/views/RepairDetailView.vue'),
        meta: { title: '工单详情', roles: ['admin', 'dorm_manager', 'student', 'repairman'] },
      },
      {
        path: 'admin/repairmen',
        name: 'admin-repairmen',
        component: () => import('@/views/RepairmanManagerView.vue'),
        meta: { title: '师傅管理', roles: ['admin'] },
      },
      {
        path: 'safety/visitor',
        name: 'safety-visitor',
        component: () => import('@/views/VisitorView.vue'),
        meta: { title: '访客登记', roles: ['admin', 'dorm_manager'] },
      },
      {
        path: 'safety/inspection',
        name: 'safety-inspection',
        component: () => import('@/views/SafetyInspectionView.vue'),
        meta: { title: '违禁品检查', roles: ['admin', 'dorm_manager'] },
      },
      {
        path: 'safety/event',
        name: 'safety-event',
        component: () => import('@/views/SafetyEventView.vue'),
        meta: { title: '安全事件', roles: ['admin', 'dorm_manager'] },
      },
      {
        path: 'fee/meter',
        name: 'fee-meter',
        component: () => import('@/views/fee/MeterReadingView.vue'),
        meta: { title: '水电抄表', roles: ['admin', 'dorm_manager'] },
      },
      {
        path: 'fee/list',
        name: 'fee-list',
        component: () => import('@/views/fee/FeeListView.vue'),
        meta: { title: '费用管理', roles: ['admin', 'dorm_manager', 'student'] },
      },
      {
        path: 'notice/announcement',
        name: 'notice-announcement',
        component: () => import('@/views/notice/AnnouncementView.vue'),
        meta: { title: '公告', roles: ['admin', 'dorm_manager', 'student', 'repairman'] },
      },
      {
        path: 'notice/my',
        name: 'notice-my',
        component: () => import('@/views/notice/NoticeView.vue'),
        meta: { title: '我的消息', roles: ['admin', 'dorm_manager', 'student', 'repairman'] },
      },
      {
        path: 'stats/occupancy',
        name: 'stats-occupancy',
        component: () => import('@/views/stats/OccupancyStatsView.vue'),
        meta: { title: '入住率统计', roles: ['admin', 'dorm_manager'] },
      },
      {
        path: 'stats/discipline',
        name: 'stats-discipline',
        component: () => import('@/views/stats/DisciplineTimelineView.vue'),
        meta: { title: '违纪记录查询', roles: ['admin', 'dorm_manager'] },
      },
      {
        path: 'stats/export',
        name: 'stats-export',
        component: () => import('@/views/stats/ExportCenterView.vue'),
        meta: { title: '报表导出', roles: ['admin'] },
      },
      {
        path: 'admin/logs',
        name: 'admin-logs',
        component: () => import('@/views/logs/OperationLogView.vue'),
        meta: { title: '操作日志', roles: ['admin'] },
      },
    ],
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'notFound',
    component: () => import('@/views/NotFoundView.vue'),
    meta: { public: true, title: '404' },
  },
]

export const router = createRouter({
  history: createWebHistory(),
  routes,
})

// 守卫：未登录跳 /login；角色不匹配回首页；登录态访问 /login 回首页
router.beforeEach((to) => {
  const store = useUserStore()
  const requiresAuth = !to.meta?.public

  if (requiresAuth && !store.isLoggedIn()) {
    return {
      path: '/login',
      query: to.fullPath === '/' ? undefined : { redirect: to.fullPath },
    }
  }

  if (to.path === '/login' && store.isLoggedIn()) {
    return { path: '/' }
  }

  const roles = to.meta?.roles as string[] | undefined
  if (requiresAuth && roles && roles.length > 0) {
    const role = store.role || ''
    if (!roles.includes(role)) {
      ElMessage.warning('当前角色无权访问该页面')
      return { path: '/' }
    }
  }

  if (typeof to.meta?.title === 'string') {
    document.title = `${to.meta.title} · 学校宿舍管理系统`
  }
  return true
})

export default router
