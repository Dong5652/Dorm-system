<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useUserStore } from '@/stores/user'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  pageHygiene,
  createHygiene,
  updateHygiene,
  deleteHygiene,
  type HygieneResponse,
  type HygieneSaveRequest,
} from '@/api/hygiene'
import { fetchDormTree, type BuildingTreeNode } from '@/api/dorm'
import DormSelector from '@/components/DormSelector.vue'
import type { DormSelection } from '@/components/DormSelector.vue'

const store = useUserStore()
const isAdmin = computed(() => store.role === 'admin')
const isManager = computed(() => isAdmin.value || store.role === 'dorm_manager')

// ---- 列表 ----------------------------------------------------------------
const list = ref<HygieneResponse[]>([])
const total = ref(0)
const pageNum = ref(1)
const pageSize = ref(10)
const loading = ref(false)

const filter = ref({
  buildingId: undefined as number | undefined,
  roomId: undefined as number | undefined,
  dateRange: null as [string, string] | null,
})

async function loadList() {
  loading.value = true
  try {
    const res = await pageHygiene({
      pageNum: pageNum.value,
      pageSize: pageSize.value,
      buildingId: filter.value.buildingId,
      roomId: filter.value.roomId,
      startDate: filter.value.dateRange?.[0],
      endDate: filter.value.dateRange?.[1],
    })
    list.value = res.records
    total.value = res.total
  } catch {
    // 拦截器弹错
  } finally {
    loading.value = false
  }
}

function resetFilter() {
  filter.value = { buildingId: undefined, roomId: undefined, dateRange: null }
  pageNum.value = 1
  loadList()
}

function handlePageChange(p: number) {
  pageNum.value = p
  loadList()
}

// ---- 录入 / 修改弹窗 -----------------------------------------------------
const dialogVisible = ref(false)
const isEdit = ref(false)
const submitting = ref(false)
const form = ref<HygieneSaveRequest & { id?: number }>({
  id: undefined,
  roomId: 0,
  checkDate: new Date().toISOString().slice(0, 10),
  score: undefined,
  deduction: 0,
  bonus: 0,
  photoUrl: '',
  itemDetail: '',
  remark: '',
})

const dormTree = ref<BuildingTreeNode[]>([])
const dormSelection = ref<DormSelection>({ buildingId: null, floorId: null, roomId: null, bedId: null })

async function loadDormTree() {
  try {
    dormTree.value = await fetchDormTree()
  } catch {
    // 静默
  }
}

function openCreate() {
  isEdit.value = false
  form.value = {
    roomId: 0,
    checkDate: new Date().toISOString().slice(0, 10),
    score: undefined,
    deduction: 0,
    bonus: 0,
    photoUrl: '',
    itemDetail: '',
    remark: '',
  }
  dormSelection.value = { buildingId: null, floorId: null, roomId: null, bedId: null }
  dialogVisible.value = true
}

function openEdit(row: HygieneResponse) {
  isEdit.value = true
  form.value = {
    id: row.id,
    roomId: row.roomId,
    checkDate: row.checkDate,
    score: row.score,
    deduction: row.deduction,
    bonus: row.bonus,
    photoUrl: row.photoUrl || '',
    itemDetail: row.itemDetail || '',
    remark: row.remark || '',
  }
  dormSelection.value = {
    buildingId: row.buildingId,
    floorId: null,
    roomId: row.roomId,
    bedId: null,
  }
  dialogVisible.value = true
}

function onSelectionChange(sel: DormSelection) {
  dormSelection.value = sel
  if (sel.roomId) {
    form.value.roomId = sel.roomId
  }
}

/** 自动按 score = 100 + bonus − deduction 计算（用户未输入 score 时）。 */
const computedScore = computed(() => {
  if (form.value.score !== undefined && form.value.score !== null) return form.value.score
  const base = 100
  const bonus = Number(form.value.bonus) || 0
  const deduction = Number(form.value.deduction) || 0
  return base + bonus - deduction
})

async function submit() {
  if (!form.value.roomId) {
    ElMessage.warning('请选择检查房间')
    return
  }
  if (!form.value.checkDate) {
    ElMessage.warning('请选择检查日期')
    return
  }
  submitting.value = true
  try {
    const payload: HygieneSaveRequest = {
      roomId: form.value.roomId,
      checkDate: form.value.checkDate,
      deduction: Number(form.value.deduction) || 0,
      bonus: Number(form.value.bonus) || 0,
      photoUrl: form.value.photoUrl || undefined,
      itemDetail: form.value.itemDetail || undefined,
      remark: form.value.remark || undefined,
    }
    // score 未填则交给后端按公式算
    if (form.value.score !== undefined && form.value.score !== null) {
      payload.score = Number(form.value.score)
    }
    if (isEdit.value && form.value.id) {
      await updateHygiene(form.value.id, payload)
      ElMessage.success('修改成功')
    } else {
      await createHygiene(payload)
      ElMessage.success('录入成功')
    }
    dialogVisible.value = false
    loadList()
  } catch {
    // 静默
  } finally {
    submitting.value = false
  }
}

async function handleDelete(row: HygieneResponse) {
  try {
    await ElMessageBox.confirm(`确认删除该卫生检查记录吗？`, '提示', { type: 'warning' })
  } catch {
    return
  }
  try {
    await deleteHygiene(row.id)
    ElMessage.success('删除成功')
    loadList()
  } catch {
    // 静默
  }
}

function formatDate(d: string | undefined) {
  return d ? d.replace('T', ' ').slice(0, 16) : '-'
}

onMounted(() => {
  if (isManager.value) loadDormTree()
  loadList()
})
</script>

<template>
  <div class="hygiene-view">
    <div class="page-header">
      <h1 class="page-title">卫生检查</h1>
      <p class="page-subtitle">录入每次卫生检查得分、扣分/加分项，按房间/日期范围查询历史。</p>
    </div>

    <el-card shadow="never">
      <div class="filter-row">
        <el-select
          v-model="filter.buildingId"
          placeholder="按楼栋筛选"
          clearable
          style="width: 180px"
        >
          <el-option
            v-for="b in dormTree"
            :key="b.id"
            :label="b.name"
            :value="b.id"
          />
        </el-select>
        <el-input-number
          v-model="filter.roomId"
          :min="1"
          :controls="false"
          placeholder="房间 ID"
          style="width: 140px"
        />
        <el-date-picker
          v-model="filter.dateRange"
          type="daterange"
          value-format="YYYY-MM-DD"
          range-separator="→"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        />
        <el-button type="primary" @click="pageNum = 1; loadList()">
          <el-icon><Search /></el-icon> 查询
        </el-button>
        <el-button @click="resetFilter">重置</el-button>
        <div class="flex-grow"></div>
        <el-button v-if="isManager" type="primary" @click="openCreate">
          <el-icon><Plus /></el-icon> 录入卫生检查
        </el-button>
      </div>

      <el-table :data="list" v-loading="loading" border stripe empty-text="暂无卫生检查记录">
        <el-table-column label="检查日期" prop="checkDate" width="120" />
        <el-table-column label="楼栋" prop="buildingName" width="120" />
        <el-table-column label="房间" prop="roomNo" width="80" />
        <el-table-column label="得分" width="90" align="center">
          <template #default="{ row }">
            <el-tag
              :type="row.score >= 90 ? 'success' : row.score >= 75 ? '' : row.score >= 60 ? 'warning' : 'danger'"
              effect="dark"
              size="large"
            >
              {{ Number(row.score).toFixed(1) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="扣分" prop="deduction" width="80" align="center">
          <template #default="{ row }">
            <span class="deduct">-{{ Number(row.deduction).toFixed(1) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="加分" prop="bonus" width="80" align="center">
          <template #default="{ row }">
            <span class="bonus">+{{ Number(row.bonus).toFixed(1) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="检查人" prop="inspectorName" width="100" />
        <el-table-column label="备注" prop="remark" min-width="160" show-overflow-tooltip />
        <el-table-column label="录入时间" width="160">
          <template #default="{ row }">
            {{ formatDate(row.createdAt) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button v-if="isManager" size="small" @click="openEdit(row)">修改</el-button>
            <el-button v-if="isAdmin" size="small" type="danger" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pager">
        <el-pagination
          v-model:current-page="pageNum"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next, jumper"
          @current-change="handlePageChange"
          @size-change="loadList"
        />
      </div>
    </el-card>

    <!-- 录入 / 修改弹窗 -->
    <el-dialog
      v-model="dialogVisible"
      :title="isEdit ? '修改卫生检查' : '录入卫生检查'"
      width="600px"
      destroy-on-close
    >
      <el-form :model="form" label-width="100px">
        <el-form-item label="检查房间" required>
          <DormSelector
            :model-value="dormSelection"
            :show-bed="false"
            placeholder="选择楼栋/楼层/房间"
            @change="onSelectionChange"
          />
          <div v-if="form.roomId" class="warn-tip">
            已选房间 ID: {{ form.roomId }}
          </div>
        </el-form-item>

        <el-form-item label="检查日期" required>
          <el-date-picker
            v-model="form.checkDate"
            type="date"
            value-format="YYYY-MM-DD"
            style="width: 100%"
          />
        </el-form-item>

        <el-form-item label="扣分">
          <el-input-number v-model="form.deduction" :min="0" :max="100" :precision="1" />
        </el-form-item>

        <el-form-item label="加分">
          <el-input-number v-model="form.bonus" :min="0" :max="50" :precision="1" />
        </el-form-item>

        <el-form-item label="得分">
          <el-input-number
            v-model="form.score"
            :min="0"
            :max="100"
            :precision="1"
            :placeholder="`留空 = 自动按公式 = ${computedScore.toFixed(1)}`"
            style="width: 100%"
          />
          <div class="hint-tip">留空则按 100 + 加分 − 扣分 自动计算</div>
        </el-form-item>

        <el-form-item label="明细 JSON">
          <el-input
            v-model="form.itemDetail"
            type="textarea"
            :rows="2"
            placeholder='[{"item":"地面有尘","type":"deduct","value":3}]'
          />
        </el-form-item>

        <el-form-item label="照片 URL">
          <el-input v-model="form.photoUrl" placeholder="可选" />
        </el-form-item>

        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" :rows="2" />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="submit">
          {{ isEdit ? '保存' : '录入' }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.hygiene-view {
  max-width: 1400px;
  margin: 0 auto;
}
.page-header {
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: 700;
  color: #303133;
  margin: 0 0 6px 0;
}
.page-subtitle {
  font-size: 14px;
  color: #909399;
  margin: 0;
}
.filter-row {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  margin-bottom: 16px;
}
.flex-grow {
  flex: 1;
}
.deduct {
  color: #f56c6c;
  font-weight: 600;
}
.bonus {
  color: #67c23a;
  font-weight: 600;
}
.pager {
  margin-top: 16px;
  display: flex;
  justify-content: flex-end;
}
.warn-tip {
  margin-top: 6px;
  color: #e6a23c;
  font-size: 12px;
}
.hint-tip {
  margin-top: 4px;
  color: #909399;
  font-size: 12px;
}
</style>
