<script setup lang="ts">
import { computed, nextTick, onMounted, onUnmounted, ref } from 'vue'
import * as echarts from 'echarts'
import { useUserStore } from '@/stores/user'
import { fetchCurrentUser } from '@/api/auth'
import { ping } from '@/api'
import { getOccupancyStats, type OccupancyStats } from '@/api/stats'
import { pageRepairs, type RepairResponse } from '@/api/repair'
import { queryAdminFees, queryFees, type Fee } from '@/api/fee'
import { getUnreadNoticeCount } from '@/api/notice'

const store = useUserStore()
const status = ref<'checking' | 'ok' | 'fail'>('checking')
const pong = ref<string>('')
const loading = ref(false)

const totalBeds = ref(0)
const occupiedBeds = ref(0)
const vacantBeds = ref(0)
const occupancyRate = ref(0)
const pendingRepairCount = ref(0)
const unreadCount = ref(0)
const unpaidFeeCount = ref(0)
const partialFeeCount = ref(0)
const paidFeeCount = ref(0)

const occupancyChartRef = ref<HTMLDivElement | null>(null)
const repairChartRef = ref<HTMLDivElement | null>(null)
const feeChartRef = ref<HTMLDivElement | null>(null)

let occupancyChart: echarts.ECharts | null = null
let repairChart: echarts.ECharts | null = null
let feeChart: echarts.ECharts | null = null

const rateText = computed(() => `${occupancyRate.value.toFixed(1)}%`)

async function callPing() {
  status.value = 'checking'
  try {
    pong.value = (await ping()) as string
    status.value = 'ok'
  } catch {
    status.value = 'fail'
  }
}

async function reloadMe() {
  try {
    const me = await fetchCurrentUser()
    store.setUserInfo({
      userId: me.userId,
      username: me.username,
      realName: me.realName,
      role: me.role,
      buildingId: me.buildingId,
      buildingName: me.buildingName,
      gender: me.gender,
      phone: me.phone,
    })
  } catch {
    // 静默；拦截器会处理
  }
}

function disposeCharts() {
  occupancyChart?.dispose()
  repairChart?.dispose()
  feeChart?.dispose()
  occupancyChart = null
  repairChart = null
  feeChart = null
}

function renderOccupancyChart(rows: OccupancyStats[]) {
  if (!occupancyChartRef.value) return
  if (!occupancyChart) occupancyChart = echarts.init(occupancyChartRef.value)
  occupancyChart.setOption({
    tooltip: { trigger: 'item' },
    legend: { bottom: 0 },
    series: [
      {
        name: '床位',
        type: 'pie',
        radius: ['35%', '65%'],
        data: [
          { name: '已入住', value: occupiedBeds.value },
          { name: '空闲', value: vacantBeds.value },
        ],
      },
    ],
    graphic: rows.length
      ? undefined
      : {
          type: 'text',
          left: 'center',
          top: 'middle',
          style: { text: '暂无数据', fill: '#909399' },
        },
  })
}

function renderRepairChart(list: RepairResponse[]) {
  if (!repairChartRef.value) return
  if (!repairChart) repairChart = echarts.init(repairChartRef.value)
  const statusNames = ['待派单', '已派单', '处理中', '已完成', '已取消']
  const counts = [0, 0, 0, 0, 0]
  for (const item of list) {
    const s = item.status ?? 0
    if (s >= 0 && s < counts.length) counts[s] += 1
  }
  pendingRepairCount.value = counts[0]
  repairChart.setOption({
    tooltip: { trigger: 'axis' },
    xAxis: { type: 'category', data: statusNames },
    yAxis: { type: 'value', minInterval: 1 },
    series: [
      {
        type: 'bar',
        data: counts,
        itemStyle: { color: '#409eff' },
        barWidth: '45%',
      },
    ],
  })
}

function renderFeeChart() {
  if (!feeChartRef.value) return
  if (!feeChart) feeChart = echarts.init(feeChartRef.value)
  feeChart.setOption({
    tooltip: { trigger: 'item' },
    legend: { bottom: 0 },
    series: [
      {
        name: '缴费',
        type: 'pie',
        radius: '65%',
        data: [
          { name: '未缴', value: unpaidFeeCount.value },
          { name: '部分缴纳', value: partialFeeCount.value },
          { name: '已缴清', value: paidFeeCount.value },
        ],
      },
    ],
  })
}

async function loadDashboard() {
  loading.value = true
  try {
    const [occ, repairs, fees, unread] = await Promise.all([
      getOccupancyStats({ groupBy: 'building' }).catch(() => [] as OccupancyStats[]),
      pageRepairs({ pageNum: 1, pageSize: 200 }).catch(() => ({ records: [] as RepairResponse[], total: 0 })),
      (store.role === 'admin' || store.role === 'dorm_manager'
        ? queryAdminFees({ page: 1, size: 200 })
        : queryFees({ page: 1, size: 200 })
      ).catch(() => ({ records: [] as Fee[], total: 0 })),
      getUnreadNoticeCount().catch(() => 0),
    ])

    const occRows = Array.isArray(occ) ? occ : []
    totalBeds.value = occRows.reduce((s, r) => s + (r.totalBeds || 0), 0)
    occupiedBeds.value = occRows.reduce((s, r) => s + (r.occupiedBeds || 0), 0)
    vacantBeds.value = occRows.reduce((s, r) => s + (r.vacantBeds || 0), 0)
    occupancyRate.value = totalBeds.value > 0 ? (occupiedBeds.value / totalBeds.value) * 100 : 0

    const repairList = (repairs as { records?: RepairResponse[] }).records || []
    const feeList = (fees as { records?: Fee[] }).records || []
    unpaidFeeCount.value = feeList.filter((f) => f.paidStatus === 0).length
    partialFeeCount.value = feeList.filter((f) => f.paidStatus === 1).length
    paidFeeCount.value = feeList.filter((f) => f.paidStatus === 2).length
    unreadCount.value = Number(unread) || 0

    await nextTick()
    renderOccupancyChart(occRows)
    renderRepairChart(repairList)
    renderFeeChart()
  } finally {
    loading.value = false
  }
}

function handleResize() {
  occupancyChart?.resize()
  repairChart?.resize()
  feeChart?.resize()
}

onMounted(async () => {
  await callPing()
  if (!store.fetched) await reloadMe()
  await loadDashboard()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
  disposeCharts()
})
</script>

<template>
  <div class="home" v-loading="loading">
    <h1 class="title">欢迎，{{ store.realName || store.username || '同学' }}</h1>
    <p class="subtitle">
      当前角色：
      <el-tag type="primary" size="small">{{ store.role || '-' }}</el-tag>
      <span class="ping">
        后端：
        <el-tag :type="status === 'ok' ? 'success' : status === 'fail' ? 'danger' : 'info'" size="small">
          {{ status === 'ok' ? `正常 (${pong})` : status === 'fail' ? '异常' : '检测中' }}
        </el-tag>
      </span>
    </p>

    <el-row :gutter="16" class="cards">
      <el-col :xs="12" :sm="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-label">总床位</div>
          <div class="stat-value">{{ totalBeds }}</div>
        </el-card>
      </el-col>
      <el-col :xs="12" :sm="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-label">入住率</div>
          <div class="stat-value primary">{{ rateText }}</div>
          <div class="stat-sub">已住 {{ occupiedBeds }} / 空闲 {{ vacantBeds }}</div>
        </el-card>
      </el-col>
      <el-col :xs="12" :sm="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-label">待派单维修</div>
          <div class="stat-value warning">{{ pendingRepairCount }}</div>
        </el-card>
      </el-col>
      <el-col :xs="12" :sm="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-label">未读消息</div>
          <div class="stat-value danger">{{ unreadCount }}</div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="16" class="charts">
      <el-col :xs="24" :md="8">
        <el-card>
          <template #header>入住率（饼图）</template>
          <div ref="occupancyChartRef" class="chart"></div>
        </el-card>
      </el-col>
      <el-col :xs="24" :md="8">
        <el-card>
          <template #header>维修状态（柱状图）</template>
          <div ref="repairChartRef" class="chart"></div>
        </el-card>
      </el-col>
      <el-col :xs="24" :md="8">
        <el-card>
          <template #header>缴费进度（饼图）</template>
          <div ref="feeChartRef" class="chart"></div>
        </el-card>
      </el-col>
    </el-row>

    <div class="actions">
      <el-button type="primary" :loading="loading" @click="loadDashboard">刷新仪表盘</el-button>
      <el-button @click="callPing">重新 Ping</el-button>
    </div>
  </div>
</template>

<style scoped>
.home {
  max-width: 1200px;
  margin: 0 auto;
}
.title {
  font-size: 24px;
  margin: 0 0 8px;
}
.subtitle {
  color: #909399;
  margin: 0 0 20px;
}
.ping {
  margin-left: 12px;
}
.cards {
  margin-bottom: 16px;
}
.stat-card {
  margin-bottom: 12px;
}
.stat-label {
  color: #909399;
  font-size: 13px;
}
.stat-value {
  font-size: 28px;
  font-weight: 700;
  margin-top: 6px;
}
.stat-value.primary {
  color: #409eff;
}
.stat-value.warning {
  color: #e6a23c;
}
.stat-value.danger {
  color: #f56c6c;
}
.stat-sub {
  margin-top: 4px;
  color: #a8abb2;
  font-size: 12px;
}
.charts .el-card {
  margin-bottom: 16px;
}
.chart {
  height: 280px;
  width: 100%;
}
.actions {
  margin-top: 8px;
}
</style>
