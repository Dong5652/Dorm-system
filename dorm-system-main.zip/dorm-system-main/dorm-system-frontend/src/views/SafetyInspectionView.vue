<template>
  <div class="inspection-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>违禁品检查管理</span>
          <el-button type="primary" @click="openAddDialog" v-if="['admin', 'dorm_manager'].includes(authStore.role)">
            录入违禁品
          </el-button>
        </div>
      </template>

      <!-- 搜索栏 -->
      <div class="search-bar">
        <el-form :inline="true" :model="searchForm">
          <el-form-item label="日期范围">
            <el-date-picker
              v-model="searchDateRange"
              type="daterange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              value-format="YYYY-MM-DD"
              clearable
            />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="fetchData">查询</el-button>
          </el-form-item>
        </el-form>
      </div>

      <!-- 数据表格 -->
      <el-table :data="tableData" v-loading="loading" border style="width: 100%">
        <el-table-column prop="roomId" label="房间ID" width="100" />
        <el-table-column prop="inspectDate" label="检查日期" width="120" />
        <el-table-column prop="itemType" label="违禁品类型" width="150" />
        <el-table-column prop="itemDesc" label="物品描述" />
        <el-table-column prop="disposition" label="处理方式" width="150" />
        <el-table-column label="通知下发" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.noticeSent ? 'success' : 'info'">
              {{ scope.row.noticeSent ? '已下发' : '未下发' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="100" fixed="right" v-if="authStore.role === 'admin'">
          <template #default="scope">
            <el-button
              size="small"
              type="danger"
              @click="handleDelete(scope.row.id)"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 录入弹窗 -->
    <el-dialog v-model="dialogVisible" title="录入违禁品检查" width="500px">
      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="房间ID" prop="roomId">
          <el-input-number v-model="form.roomId" :min="1" style="width: 100%" />
        </el-form-item>
        <el-form-item label="相关学生ID" prop="studentId">
          <el-input-number v-model="form.studentId" :min="1" placeholder="选填，若明确责任人" style="width: 100%" />
        </el-form-item>
        <el-form-item label="检查日期" prop="inspectDate">
          <el-date-picker
            v-model="form.inspectDate"
            type="date"
            placeholder="选择日期"
            value-format="YYYY-MM-DD"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="违禁品类型" prop="itemType">
          <el-select v-model="form.itemType" placeholder="选择违禁品类型" style="width: 100%">
            <el-option label="大功率电器" value="大功率电器" />
            <el-option label="管制刀具" value="管制刀具" />
            <el-option label="易燃易爆物" value="易燃易爆物" />
            <el-option label="其他" value="其他" />
          </el-select>
        </el-form-item>
        <el-form-item label="物品描述" prop="itemDesc">
          <el-input v-model="form.itemDesc" type="textarea" placeholder="详细描述物品" />
        </el-form-item>
        <el-form-item label="处理方式" prop="disposition">
          <el-select v-model="form.disposition" placeholder="选择处理方式" style="width: 100%">
            <el-option label="没收保管" value="没收保管" />
            <el-option label="限期带离" value="限期带离" />
            <el-option label="通报批评" value="通报批评" />
          </el-select>
        </el-form-item>
        <el-form-item label="发送整改通知">
          <el-switch v-model="form.noticeSent" />
          <span style="margin-left: 10px; color: #999; font-size: 12px">需指定相关学生ID才能发送</span>
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input v-model="form.remark" type="textarea" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitForm" :loading="submitting">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { FormInstance, FormRules } from 'element-plus'
import { queryInspections, recordInspection, deleteInspection, type SafetyInspection, type SafetyInspectionRequest } from '@/api/safety'
import { useUserStore } from '@/stores/user'

const authStore = useUserStore()

const loading = ref(false)
const tableData = ref<SafetyInspection[]>([])
const searchForm = ref({
  roomId: undefined as number | undefined,
  studentId: undefined as number | undefined
})
const searchDateRange = ref<[string, string] | null>(null)

const dialogVisible = ref(false)
const submitting = ref(false)
const formRef = ref<FormInstance>()
const form = ref<SafetyInspectionRequest>({
  roomId: undefined as any,
  studentId: undefined,
  inspectDate: '',
  itemType: '',
  itemDesc: '',
  disposition: '',
  noticeSent: false,
  remark: ''
})

const rules: FormRules = {
  roomId: [{ required: true, message: '请输入房间ID', trigger: 'blur' }],
  inspectDate: [{ required: true, message: '请选择检查日期', trigger: 'change' }],
  itemType: [{ required: true, message: '请选择违禁品类型', trigger: 'change' }],
  itemDesc: [{ required: true, message: '请输入物品描述', trigger: 'blur' }],
  disposition: [{ required: true, message: '请选择处理方式', trigger: 'change' }]
}

const fetchData = async () => {
  loading.value = true
  try {
    const params: any = {
      roomId: searchForm.value.roomId,
      studentId: searchForm.value.studentId
    }
    if (searchDateRange.value && searchDateRange.value.length === 2) {
      params.startDate = searchDateRange.value[0]
      params.endDate = searchDateRange.value[1]
    }
    const res = await queryInspections(params)
    tableData.value = res || []
  } catch (error) {
    console.error('获取违禁品检查列表失败', error)
  } finally {
    loading.value = false
  }
}

const openAddDialog = () => {
  dialogVisible.value = true
  if (formRef.value) {
    formRef.value.resetFields()
  }
  form.value = {
    roomId: undefined as any,
    studentId: undefined,
    inspectDate: new Date().toISOString().slice(0, 10),
    itemType: '',
    itemDesc: '',
    disposition: '',
    noticeSent: false,
    remark: ''
  }
}

const submitForm = async () => {
  if (!formRef.value) return
  await formRef.value.validate(async (valid) => {
    if (valid) {
      submitting.value = true
      try {
        await recordInspection(form.value)
        ElMessage.success('录入成功')
        dialogVisible.value = false
        fetchData()
      } catch (error) {
        console.error('录入失败', error)
      } finally {
        submitting.value = false
      }
    }
  })
}

const handleDelete = async (id: number) => {
  try {
    await ElMessageBox.confirm('确认删除该违禁品记录吗？', '警告', { type: 'error' })
    await deleteInspection(id)
    ElMessage.success('删除成功')
    fetchData()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除失败', error)
    }
  }
}

onMounted(() => {
  fetchData()
})
</script>

<style scoped>
.inspection-container {
  padding: 20px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.search-bar {
  margin-bottom: 20px;
}
</style>
