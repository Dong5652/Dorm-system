<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useUserStore } from '@/stores/user'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  pageStudents,
  type Student,
} from '@/api/student'
import {
  fetchDormTree,
  type BuildingTreeNode,
  type BedTreeNode,
  type RoomTreeNode,
  type FloorTreeNode,
  BED_STATUS_LABELS,
  BED_STATUS_TYPES,
} from '@/api/dorm'
import {
  checkIn,
  checkOut,
  changeRoom,
  studentChange,
  batchCheckOut,
  fetchRecords,
  RECORD_TYPE_LABELS,
  RECORD_TYPE_TYPES,
  CHECK_IN_OUT_TYPE_LABELS,
  CHECK_IN_OUT_TYPE_TYPES,
  CHANGE_TYPE_LABELS,
  CHANGE_TYPE_TYPES,
  type DormRecordResponse,
  type StudentChangeType,
} from '@/api/record'
import DormSelector from '@/components/DormSelector.vue'
import type { DormSelection } from '@/components/DormSelector.vue'

const store = useUserStore()

// 仅管理员 / 宿管可办理写操作；学生仅可查询流水
const isAdmin = computed(() => store.role === 'admin')
const isManager = computed(() => isAdmin.value || store.role === 'dorm_manager')
const activeTab = ref<'check-in' | 'check-out' | 'change-room' | 'change' | 'batch' | 'records'>('check-in')

// ---- 学生远程搜索 -----------------------------------
const studentOptions = ref<Student[]>([])
const studentLoading = ref(false)
async function searchStudents(keyword: string) {
  studentLoading.value = true
  try {
    const res = await pageStudents({ pageNum: 1, pageSize: 30, keyword })
    studentOptions.value = res.records
  } catch {
    // 拦截器弹错
  } finally {
    studentLoading.value = false
  }
}

function findStudent(id: number | null | undefined): Student | undefined {
  if (!id) return undefined
  return studentOptions.value.find((s) => s.id === id)
}

// ---- 入住表单 -----------------------------------
const checkInForm = ref({
  studentId: null as number | null,
  bedId: null as number | null,
  keyIssued: true,
  facilityCheck: '',
  remark: '',
})
const checkInSelection = ref<DormSelection>({ buildingId: null, floorId: null, roomId: null, bedId: null })
const checkInSubmitting = ref(false)

// 宿舍树（用来过滤出空闲床位）
const dormTree = ref<BuildingTreeNode[]>([])
async function loadDormTree() {
  try {
    dormTree.value = await fetchDormTree()
  } catch {
    // 静默
  }
}

// 当前选中房间下的床位列表（仅空闲可入住）
const checkInAvailableBeds = ref<BedTreeNode[]>([])
function onCheckInSelectionChange(sel: DormSelection) {
  checkInSelection.value = sel
  checkInForm.value.bedId = null
  const room = findRoomInTree(sel.buildingId, sel.floorId, sel.roomId)
  checkInAvailableBeds.value = room?.beds.filter((b) => b.status === 0) ?? []
}

function findRoomInTree(bId: number | null, fId: number | null, rId: number | null): RoomTreeNode | undefined {
  if (!bId || !fId || !rId) return undefined
  const b = dormTree.value.find((x) => x.id === bId)
  const f = b?.floors.find((x) => x.id === fId)
  return f?.rooms.find((x) => x.id === rId)
}

async function submitCheckIn() {
  if (!checkInForm.value.studentId) {
    ElMessage.warning('请选择要入住的学生')
    return
  }
  if (!checkInForm.value.bedId) {
    ElMessage.warning('请选择空闲床位')
    return
  }
  checkInSubmitting.value = true
  try {
    const res = await checkIn({
      studentId: checkInForm.value.studentId,
      bedId: checkInForm.value.bedId,
      keyIssued: checkInForm.value.keyIssued,
      facilityCheck: checkInForm.value.facilityCheck,
      remark: checkInForm.value.remark,
    })
    ElMessage.success(`入住成功，流水号 #${res.recordId}`)
    checkInForm.value = { studentId: null, bedId: null, keyIssued: true, facilityCheck: '', remark: '' }
    checkInSelection.value = { buildingId: null, floorId: null, roomId: null, bedId: null }
    checkInAvailableBeds.value = []
  } catch {
    // 拦截器弹错
  } finally {
    checkInSubmitting.value = false
  }
}

// ---- 退宿表单 -----------------------------------
const checkOutForm = ref({
  studentId: null as number | null,
  keyReturned: true,
  facilityCheck: '',
  remark: '',
})
const checkOutSubmitting = ref(false)

async function submitCheckOut() {
  if (!checkOutForm.value.studentId) {
    ElMessage.warning('请选择要退宿的学生')
    return
  }
  try {
    await ElMessageBox.confirm('确认要为该学生办理退宿吗？将释放其当前床位。', '提示', { type: 'warning' })
  } catch {
    return
  }
  checkOutSubmitting.value = true
  try {
    await checkOut({
      studentId: checkOutForm.value.studentId,
      keyReturned: checkOutForm.value.keyReturned,
      facilityCheck: checkOutForm.value.facilityCheck,
      remark: checkOutForm.value.remark,
    })
    ElMessage.success('退宿成功')
    checkOutForm.value = { studentId: null, keyReturned: true, facilityCheck: '', remark: '' }
  } catch {
    // 静默
  } finally {
    checkOutSubmitting.value = false
  }
}

// ---- 调宿向导 -----------------------------------
const changeRoomForm = ref({
  studentId: null as number | null,
  fromBedId: null as number | null,
  toBedId: null as number | null,
  reason: '',
})
const changeRoomSelection = ref<DormSelection>({ buildingId: null, floorId: null, roomId: null, bedId: null })
const changeRoomAvailableBeds = ref<BedTreeNode[]>([])
const changeRoomSubmitting = ref(false)
const currentStudentBedInfo = ref<string>('')

async function onChangeRoomStudentChange(studentId: number | null) {
  changeRoomForm.value.fromBedId = null
  changeRoomForm.value.toBedId = null
  changeRoomSelection.value = { buildingId: null, floorId: null, roomId: null, bedId: null }
  changeRoomAvailableBeds.value = []
  currentStudentBedInfo.value = ''
  if (!studentId) return
  // 查询学生当前床位（通过流水接口找最近一条入住记录的床位）
  try {
    const records = await fetchRecords({ studentId, type: 1 })
    if (records.length === 0) {
      ElMessage.info('该学生当前未入住任何床位，请先办理入住')
      return
    }
    const latestCheckIn = records[0]
    // 检查后续是否有退宿记录
    const checkOuts = await fetchRecords({ studentId, type: 2 })
    const hasCheckedOut = checkOuts.some((r) => r.happenedAt > latestCheckIn.happenedAt)
    if (hasCheckedOut) {
      ElMessage.info('该学生当前未入住任何床位，请先办理入住')
      return
    }
    changeRoomForm.value.fromBedId = latestCheckIn.bedId ?? null
    currentStudentBedInfo.value = `${latestCheckIn.buildingName || ''} ${latestCheckIn.roomNo || ''} 房 ${latestCheckIn.bedNo || ''} 床`
  } catch {
    // 静默
  }
}

function onChangeRoomSelectionChange(sel: DormSelection) {
  changeRoomSelection.value = sel
  changeRoomForm.value.toBedId = null
  const room = findRoomInTree(sel.buildingId, sel.floorId, sel.roomId)
  changeRoomAvailableBeds.value = room?.beds.filter((b) => b.status === 0) ?? []
}

async function submitChangeRoom() {
  if (!changeRoomForm.value.studentId) {
    ElMessage.warning('请选择学生')
    return
  }
  if (!changeRoomForm.value.fromBedId) {
    ElMessage.warning('该学生当前无床位，无法调宿')
    return
  }
  if (!changeRoomForm.value.toBedId) {
    ElMessage.warning('请选择目标新床位')
    return
  }
  if (changeRoomForm.value.fromBedId === changeRoomForm.value.toBedId) {
    ElMessage.warning('目标床位与原床位相同')
    return
  }
  changeRoomSubmitting.value = true
  try {
    await changeRoom({
      studentId: changeRoomForm.value.studentId,
      fromBedId: changeRoomForm.value.fromBedId,
      toBedId: changeRoomForm.value.toBedId,
      reason: changeRoomForm.value.reason,
    })
    ElMessage.success('调宿成功')
    changeRoomForm.value = { studentId: null, fromBedId: null, toBedId: null, reason: '' }
    changeRoomSelection.value = { buildingId: null, floorId: null, roomId: null, bedId: null }
    changeRoomAvailableBeds.value = []
    currentStudentBedInfo.value = ''
  } catch {
    // 静默
  } finally {
    changeRoomSubmitting.value = false
  }
}

// ---- 异动登记 -----------------------------------
const changeForm = ref({
  studentId: null as number | null,
  type: 'suspend' as StudentChangeType,
  reason: '',
  remark: '',
})
const changeSubmitting = ref(false)

async function submitChange() {
  if (!changeForm.value.studentId) {
    ElMessage.warning('请选择学生')
    return
  }
  if (changeForm.value.type === 'suspend') {
    try {
      await ElMessageBox.confirm('休学登记将自动退宿并置学生状态为休学，确认继续？', '提示', { type: 'warning' })
    } catch {
      return
    }
  }
  changeSubmitting.value = true
  try {
    await studentChange({
      studentId: changeForm.value.studentId,
      type: changeForm.value.type,
      reason: changeForm.value.reason,
      remark: changeForm.value.remark,
    })
    ElMessage.success('异动登记成功')
    changeForm.value = { studentId: null, type: 'suspend', reason: '', remark: '' }
  } catch {
    // 静默
  } finally {
    changeSubmitting.value = false
  }
}

// ---- 批量退宿（仅 ADMIN）-----------------------------------
const batchForm = ref({
  grade: '',
  className: '',
  reason: '毕业退宿',
  keyReturned: true,
})
const batchSubmitting = ref(false)
const batchResult = ref<{ totalCount: number; successCount: number; failedCount: number } | null>(null)

async function submitBatch() {
  if (!batchForm.value.grade) {
    ElMessage.warning('请输入毕业年级')
    return
  }
  try {
    await ElMessageBox.confirm(
      `确认对 ${batchForm.value.grade} 年级${batchForm.value.className ? ' ' + batchForm.value.className + ' 班' : ' 全部班级'}的在宿学生批量退宿？`,
      '批量退宿',
      { type: 'warning' },
    )
  } catch {
    return
  }
  batchSubmitting.value = true
  batchResult.value = null
  try {
    const res = await batchCheckOut({
      grade: batchForm.value.grade,
      className: batchForm.value.className || undefined,
      reason: batchForm.value.reason,
      keyReturned: batchForm.value.keyReturned,
    })
    batchResult.value = res
    ElMessage.success(`批量退宿完成：成功 ${res.successCount} / 失败 ${res.failedCount}`)
  } catch {
    // 静默
  } finally {
    batchSubmitting.value = false
  }
}

// ---- 流水查询 -----------------------------------
const recordsFilter = ref({
  studentId: null as number | null,
  roomId: null as number | null,
  type: undefined as number | undefined,
  changeType: '' as string,
  startDate: '' as string,
  endDate: '' as string,
})
const recordsDateRange = ref<[string, string] | null>(null)
const recordsList = ref<DormRecordResponse[]>([])
const recordsLoading = ref(false)

function onRecordsDateRangeChange(val: [string, string] | null) {
  recordsDateRange.value = val
  recordsFilter.value.startDate = val ? val[0] : ''
  recordsFilter.value.endDate = val ? val[1] : ''
}

async function loadRecords() {
  recordsLoading.value = true
  try {
    const data = await fetchRecords({
      studentId: recordsFilter.value.studentId || undefined,
      roomId: recordsFilter.value.roomId || undefined,
      type: recordsFilter.value.type,
      changeType: recordsFilter.value.changeType || undefined,
      startDate: recordsFilter.value.startDate || undefined,
      endDate: recordsFilter.value.endDate || undefined,
    })
    recordsList.value = data
  } catch {
    // 静默
  } finally {
    recordsLoading.value = false
  }
}

function resetRecordsFilter() {
  recordsFilter.value = {
    studentId: null,
    roomId: null,
    type: undefined,
    changeType: '',
    startDate: '',
    endDate: '',
  }
  recordsDateRange.value = null
  loadRecords()
}

function formatTime(t: string): string {
  return t ? t.replace('T', ' ') : ''
}

function bedSummary(r: DormRecordResponse): string {
  if (r.recordType === 'check_in') {
    return `${r.buildingName || '-'} / ${r.roomNo || '-'} 房 / ${r.bedNo || '-'} 床`
  }
  // change
  return `${r.fromRoomNo || '-'}房${r.fromBedNo || '-'}床 → ${r.toRoomNo || '-'}房${r.toBedNo || '-'}床`
}

onMounted(() => {
  loadDormTree()
  searchStudents('')
  loadRecords()
})
</script>

<template>
  <div class="check-in-out-view">
    <div class="page-header">
      <h1 class="page-title">入住退宿与异动管理</h1>
      <p class="page-subtitle">办理入住、退宿、调宿、异动登记及批量毕业退宿，并提供流水查询与可视化操作入口。</p>
    </div>

    <el-card class="tabs-card" shadow="never">
      <el-tabs v-model="activeTab" type="border-card">
        <!-- ============ 入住 ============ -->
        <el-tab-pane label="办理入住" name="check-in" :disabled="!isManager">
          <div class="form-wrapper">
            <el-form :model="checkInForm" label-width="100px" class="dialog-form">
              <el-form-item label="入住学生" required>
                <el-select
                  v-model="checkInForm.studentId"
                  filterable
                  remote
                  clearable
                  reserve-keyword
                  placeholder="搜索学号 / 姓名"
                  :remote-method="searchStudents"
                  :loading="studentLoading"
                  style="width: 100%"
                >
                  <el-option
                    v-for="s in studentOptions"
                    :key="s.id"
                    :label="`${s.studentNo} · ${s.name}（${s.gender === 1 ? '男' : '女'}）`"
                    :value="s.id"
                  />
                </el-select>
                <div v-if="findStudent(checkInForm.studentId)?.currentBedId" class="warn-tip">
                  <el-icon><Warning /></el-icon> 该学生已分配床位，请先退宿后再办入住
                </div>
              </el-form-item>

              <el-form-item label="目标床位" required>
                <DormSelector
                  :model-value="checkInSelection"
                  :show-bed="false"
                  placeholder="选择楼栋/楼层/房间"
                  @change="onCheckInSelectionChange"
                />
              </el-form-item>

              <el-form-item label="空闲床位" required>
                <el-select
                  v-model="checkInForm.bedId"
                  placeholder="请先选择房间"
                  :disabled="checkInAvailableBeds.length === 0"
                  style="width: 240px"
                >
                  <el-option
                    v-for="b in checkInAvailableBeds"
                    :key="b.id"
                    :label="`${b.bedNo} 床（空闲）`"
                    :value="b.id"
                  />
                </el-select>
                <span v-if="checkInSelection.roomId && checkInAvailableBeds.length === 0" class="warn-tip">
                  <el-icon><Warning /></el-icon> 该房间当前没有空闲床位
                </span>
              </el-form-item>

              <el-form-item label="钥匙发放">
                <el-switch v-model="checkInForm.keyIssued" />
              </el-form-item>

              <el-form-item label="设施检查">
                <el-input v-model="checkInForm.facilityCheck" placeholder="如：桌椅齐全 / 风扇损坏" />
              </el-form-item>

              <el-form-item label="备注">
                <el-input v-model="checkInForm.remark" type="textarea" :rows="2" placeholder="新生入住等" />
              </el-form-item>

              <el-form-item>
                <el-button type="primary" :loading="checkInSubmitting" @click="submitCheckIn">
                  <el-icon style="margin-right: 4px"><Check /></el-icon> 确认入住
                </el-button>
              </el-form-item>
            </el-form>
          </div>
        </el-tab-pane>

        <!-- ============ 退宿 ============ -->
        <el-tab-pane label="办理退宿" name="check-out" :disabled="!isManager">
          <div class="form-wrapper">
            <el-form :model="checkOutForm" label-width="100px" class="dialog-form">
              <el-form-item label="退宿学生" required>
                <el-select
                  v-model="checkOutForm.studentId"
                  filterable
                  remote
                  clearable
                  reserve-keyword
                  placeholder="搜索学号 / 姓名"
                  :remote-method="searchStudents"
                  :loading="studentLoading"
                  style="width: 100%"
                >
                  <el-option
                    v-for="s in studentOptions"
                    :key="s.id"
                    :label="`${s.studentNo} · ${s.name}`"
                    :value="s.id"
                  />
                </el-select>
                <div v-if="checkOutForm.studentId && !findStudent(checkOutForm.studentId)?.currentBedId" class="warn-tip">
                  <el-icon><Warning /></el-icon> 该学生当前未入住任何床位
                </div>
              </el-form-item>

              <el-form-item label="钥匙回收">
                <el-switch v-model="checkOutForm.keyReturned" />
              </el-form-item>

              <el-form-item label="设施检查">
                <el-input v-model="checkOutForm.facilityCheck" placeholder="如：设施完好 / 桌椅损坏" />
              </el-form-item>

              <el-form-item label="备注">
                <el-input v-model="checkOutForm.remark" type="textarea" :rows="2" placeholder="毕业退宿 / 休学退宿等" />
              </el-form-item>

              <el-form-item>
                <el-button type="danger" :loading="checkOutSubmitting" @click="submitCheckOut">
                  <el-icon style="margin-right: 4px"><Close /></el-icon> 确认退宿
                </el-button>
              </el-form-item>
            </el-form>
          </div>
        </el-tab-pane>

        <!-- ============ 调宿 ============ -->
        <el-tab-pane label="调宿向导" name="change-room" :disabled="!isManager">
          <div class="form-wrapper">
            <el-form :model="changeRoomForm" label-width="100px" class="dialog-form">
              <el-form-item label="调宿学生" required>
                <el-select
                  v-model="changeRoomForm.studentId"
                  filterable
                  remote
                  clearable
                  reserve-keyword
                  placeholder="搜索学号 / 姓名"
                  :remote-method="searchStudents"
                  :loading="studentLoading"
                  style="width: 100%"
                  @change="onChangeRoomStudentChange"
                >
                  <el-option
                    v-for="s in studentOptions"
                    :key="s.id"
                    :label="`${s.studentNo} · ${s.name}`"
                    :value="s.id"
                  />
                </el-select>
              </el-form-item>

              <el-form-item label="原床位">
                <el-tag v-if="changeRoomForm.fromBedId" type="info" size="large">
                  {{ currentStudentBedInfo }}
                </el-tag>
                <el-tag v-else type="warning" size="large">无（学生未入住）</el-tag>
              </el-form-item>

              <el-form-item label="目标房间" required>
                <DormSelector
                  :model-value="changeRoomSelection"
                  :show-bed="false"
                  placeholder="选择目标楼栋/楼层/房间"
                  @change="onChangeRoomSelectionChange"
                />
              </el-form-item>

              <el-form-item label="目标床位" required>
                <el-select
                  v-model="changeRoomForm.toBedId"
                  placeholder="请先选择目标房间"
                  :disabled="changeRoomAvailableBeds.length === 0"
                  style="width: 240px"
                >
                  <el-option
                    v-for="b in changeRoomAvailableBeds"
                    :key="b.id"
                    :label="`${b.bedNo} 床（空闲）`"
                    :value="b.id"
                  />
                </el-select>
              </el-form-item>

              <el-form-item label="调宿原因">
                <el-input v-model="changeRoomForm.reason" type="textarea" :rows="2" placeholder="如：同寝矛盾 / 个人偏好" />
              </el-form-item>

              <el-form-item>
                <el-button type="primary" :loading="changeRoomSubmitting" @click="submitChangeRoom">
                  <el-icon style="margin-right: 4px"><Switch /></el-icon> 确认调宿
                </el-button>
              </el-form-item>
            </el-form>
          </div>
        </el-tab-pane>

        <!-- ============ 异动登记 ============ -->
        <el-tab-pane label="异动登记" name="change" :disabled="!isManager">
          <div class="form-wrapper">
            <el-form :model="changeForm" label-width="100px" class="dialog-form">
              <el-form-item label="异动学生" required>
                <el-select
                  v-model="changeForm.studentId"
                  filterable
                  remote
                  clearable
                  reserve-keyword
                  placeholder="搜索学号 / 姓名"
                  :remote-method="searchStudents"
                  :loading="studentLoading"
                  style="width: 100%"
                >
                  <el-option
                    v-for="s in studentOptions"
                    :key="s.id"
                    :label="`${s.studentNo} · ${s.name}`"
                    :value="s.id"
                  />
                </el-select>
              </el-form-item>

              <el-form-item label="异动类型" required>
                <el-radio-group v-model="changeForm.type">
                  <el-radio value="suspend">休学</el-radio>
                  <el-radio value="transfer">转专业</el-radio>
                  <el-radio value="holiday_leave">假期离校</el-radio>
                </el-radio-group>
              </el-form-item>

              <el-form-item label="异动原因">
                <el-input v-model="changeForm.reason" type="textarea" :rows="2" placeholder="如：身体原因休学一年" />
              </el-form-item>

              <el-form-item label="备注">
                <el-input v-model="changeForm.remark" type="textarea" :rows="2" />
              </el-form-item>

              <el-alert
                v-if="changeForm.type === 'suspend'"
                title="休学登记会自动回收学生当前床位并将档案状态置为休学"
                type="warning"
                :closable="false"
                show-icon
                style="margin-bottom: 16px"
              />

              <el-form-item>
                <el-button type="primary" :loading="changeSubmitting" @click="submitChange">
                  <el-icon style="margin-right: 4px"><EditPen /></el-icon> 提交异动登记
                </el-button>
              </el-form-item>
            </el-form>
          </div>
        </el-tab-pane>

        <!-- ============ 批量退宿 ============ -->
        <el-tab-pane v-if="isAdmin" label="批量退宿" name="batch">
          <div class="form-wrapper">
            <el-alert
              title="批量退宿面向毕业季：按年级 + 班级筛选在宿学生并逐条事务退宿，单条失败不影响其他学生。"
              type="info"
              :closable="false"
              show-icon
              style="margin-bottom: 16px"
            />

            <el-form :model="batchForm" label-width="100px" class="dialog-form">
              <el-form-item label="年级" required>
                <el-input v-model="batchForm.grade" placeholder="如：2022" style="width: 200px" />
              </el-form-item>
              <el-form-item label="班级">
                <el-input v-model="batchForm.className" placeholder="留空表示该年级全部班级" style="width: 240px" />
              </el-form-item>
              <el-form-item label="退宿原因">
                <el-input v-model="batchForm.reason" placeholder="毕业退宿 / 其它" />
              </el-form-item>
              <el-form-item label="钥匙回收">
                <el-switch v-model="batchForm.keyReturned" />
              </el-form-item>
              <el-form-item>
                <el-button type="danger" :loading="batchSubmitting" @click="submitBatch">
                  <el-icon style="margin-right: 4px"><Delete /></el-icon> 执行批量退宿
                </el-button>
              </el-form-item>
            </el-form>

            <div v-if="batchResult" class="batch-result">
              <el-descriptions :column="3" border title="批量退宿结果">
                <el-descriptions-item label="命中学生数">{{ batchResult.totalCount }}</el-descriptions-item>
                <el-descriptions-item label="成功">
                  <el-tag type="success">{{ batchResult.successCount }}</el-tag>
                </el-descriptions-item>
                <el-descriptions-item label="失败">
                  <el-tag type="danger">{{ batchResult.failedCount }}</el-tag>
                </el-descriptions-item>
              </el-descriptions>
            </div>
          </div>
        </el-tab-pane>

        <!-- ============ 流水查询 ============ -->
        <el-tab-pane label="流水查询" name="records">
          <div class="records-wrapper">
            <div class="filter-row">
              <el-input-number
                v-model="recordsFilter.studentId"
                :min="1"
                :controls="false"
                placeholder="学生 ID"
                style="width: 140px"
              />
              <el-input-number
                v-model="recordsFilter.roomId"
                :min="1"
                :controls="false"
                placeholder="房间 ID"
                style="width: 140px"
              />
              <el-select v-model="recordsFilter.type" placeholder="入住/退宿" clearable style="width: 140px">
                <el-option :value="1" label="入住" />
                <el-option :value="2" label="退宿" />
              </el-select>
              <el-select v-model="recordsFilter.changeType" placeholder="异动类型" clearable style="width: 160px">
                <el-option value="suspend" label="休学" />
                <el-option value="transfer" label="转专业" />
                <el-option value="change_room" label="调宿" />
                <el-option value="holiday_leave" label="假期离校" />
              </el-select>
              <el-date-picker
                :model-value="recordsDateRange"
                type="daterange"
                value-format="YYYY-MM-DD"
                range-separator="→"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                @update:model-value="onRecordsDateRangeChange"
              />
              <el-button type="primary" @click="loadRecords">
                <el-icon style="margin-right: 4px"><Search /></el-icon> 查询
              </el-button>
              <el-button @click="resetRecordsFilter">重置</el-button>
            </div>

            <el-table :data="recordsList" v-loading="recordsLoading" border stripe style="width: 100%" empty-text="暂无流水记录">
              <el-table-column label="时间" width="160">
                <template #default="{ row }">
                  {{ formatTime(row.happenedAt) }}
                </template>
              </el-table-column>
              <el-table-column label="来源" width="100" align="center">
                <template #default="{ row }">
                  <el-tag :type="RECORD_TYPE_TYPES[row.recordType]" size="small">
                    {{ RECORD_TYPE_LABELS[row.recordType] }}
                  </el-tag>
                </template>
              </el-table-column>
              <el-table-column label="学生" min-width="180">
                <template #default="{ row }">
                  <span class="student-cell">
                    {{ row.studentName || '-' }} <code class="student-no">{{ row.studentNo || '-' }}</code>
                  </span>
                </template>
              </el-table-column>
              <el-table-column label="操作类型" width="120" align="center">
                <template #default="{ row }">
                  <el-tag v-if="row.recordType === 'check_in'" :type="CHECK_IN_OUT_TYPE_TYPES[row.type]" size="small">
                    {{ CHECK_IN_OUT_TYPE_LABELS[row.type] }}
                  </el-tag>
                  <el-tag v-else :type="CHANGE_TYPE_TYPES[row.changeType]" size="small">
                    {{ CHANGE_TYPE_LABELS[row.changeType] || row.changeType }}
                  </el-tag>
                </template>
              </el-table-column>
              <el-table-column label="床位 / 调动" min-width="240">
                <template #default="{ row }">
                  <span class="bed-cell">{{ bedSummary(row) }}</span>
                </template>
              </el-table-column>
              <el-table-column label="钥匙" width="120" align="center">
                <template #default="{ row }">
                  <span v-if="row.recordType === 'check_in'">
                    <el-tag v-if="row.type === 1" :type="row.keyIssued ? 'success' : 'info'" size="small">
                      {{ row.keyIssued ? '已发' : '未发' }}
                    </el-tag>
                    <el-tag v-else :type="row.keyReturned ? 'success' : 'info'" size="small">
                      {{ row.keyReturned ? '已收' : '未收' }}
                    </el-tag>
                  </span>
                  <span v-else>-</span>
                </template>
              </el-table-column>
              <el-table-column label="经办人" width="120">
                <template #default="{ row }">
                  {{ row.operatorName || '-' }}
                </template>
              </el-table-column>
              <el-table-column label="原因 / 备注" min-width="180" show-overflow-tooltip>
                <template #default="{ row }">
                  <span v-if="row.reason">{{ row.reason }}</span>
                  <span v-else-if="row.remark">{{ row.remark }}</span>
                  <span v-else>-</span>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </el-tab-pane>
      </el-tabs>
    </el-card>
  </div>
</template>

<style scoped>
.check-in-out-view {
  max-width: 1200px;
  margin: 0 auto;
}
.page-header {
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: 700;
  color: #303133;
  margin: 0 0 6px 0;
}
.page-subtitle {
  font-size: 14px;
  color: #909399;
  margin: 0;
}
.tabs-card {
  padding: 0;
}
.form-wrapper {
  padding: 24px 32px;
  max-width: 720px;
}
.dialog-form {
  width: 100%;
}
.warn-tip {
  margin-top: 6px;
  color: #e6a23c;
  font-size: 12px;
  display: flex;
  align-items: center;
  gap: 4px;
}
.records-wrapper {
  padding: 16px;
}
.filter-row {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  margin-bottom: 16px;
}
.student-cell {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.student-no {
  background: #f4f4f5;
  color: #909399;
  font-family: monospace;
  padding: 1px 5px;
  border-radius: 3px;
  font-size: 12px;
}
.bed-cell {
  font-size: 13px;
  color: #606266;
}
.batch-result {
  margin-top: 24px;
}
</style>
