<template>
  <div class="export-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>报表导出中心</span>
        </div>
      </template>

      <el-row :gutter="20">
        <el-col :span="6">
          <el-card shadow="hover" class="export-card" @click="handleExport('occupancy', '入住名单')">
            <el-icon class="export-icon"><UserFilled /></el-icon>
            <div class="export-title">入住名单</div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover" class="export-card" @click="handleExport('fee', '缴费统计')">
            <el-icon class="export-icon"><Money /></el-icon>
            <div class="export-title">缴费统计</div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover" class="export-card" @click="handleExport('repair', '维修账单')">
            <el-icon class="export-icon"><Tools /></el-icon>
            <div class="export-title">维修账单</div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover" class="export-card" @click="handleExport('score', '卫生考评')">
            <el-icon class="export-icon"><TrophyBase /></el-icon>
            <div class="export-title">卫生考评</div>
          </el-card>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ElMessage } from 'element-plus'
import { exportReport } from '@/api/stats'

const handleExport = async (type: string, name: string) => {
  try {
    const res = await exportReport(type)
    const blob = new Blob([res as any], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
    const link = document.createElement('a')
    link.href = window.URL.createObjectURL(blob)
    link.download = `${name}.xlsx`
    link.click()
    window.URL.revokeObjectURL(link.href)
    ElMessage.success(`${name} 导出成功`)
  } catch (error) {
    console.error('导出失败', error)
    ElMessage.error('导出失败')
  }
}
</script>

<style scoped>
.export-container { padding: 20px; }
.card-header { font-weight: bold; }
.export-card {
  text-align: center;
  cursor: pointer;
  padding: 20px 0;
  transition: all 0.3s;
}
.export-card:hover {
  transform: translateY(-5px);
  color: #409eff;
}
.export-icon {
  font-size: 48px;
  color: #409eff;
  margin-bottom: 10px;
}
.export-title {
  font-size: 16px;
  font-weight: 500;
}
</style>
