<template>
  <div class="stats-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>入住率统计</span>
          <div class="filters">
            <el-select v-model="groupBy" style="width: 140px" @change="fetchData">
              <el-option label="按楼栋" value="building" />
              <el-option label="按性别" value="gender" />
              <el-option label="按专业" value="major" />
              <el-option label="按年级" value="grade" />
            </el-select>
            <el-button type="primary" :loading="loading" @click="fetchData">刷新</el-button>
          </div>
        </div>
      </template>

      <div ref="chartRef" class="chart"></div>

      <el-table :data="tableData" v-loading="loading" border style="width: 100%; margin-top: 20px">
        <el-table-column prop="dimName" label="维度名称" />
        <el-table-column prop="totalBeds" label="总床位" />
        <el-table-column prop="occupiedBeds" label="已入住床位" />
        <el-table-column prop="vacantBeds" label="空闲床位" />
        <el-table-column label="入住率">
          <template #default="scope">
            <el-progress :percentage="Number(scope.row.occupancyRate?.toFixed?.(2) ?? scope.row.occupancyRate ?? 0)" />
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { nextTick, onMounted, onUnmounted, ref } from 'vue'
import * as echarts from 'echarts'
import { getOccupancyStats, type OccupancyStats } from '@/api/stats'

const loading = ref(false)
const tableData = ref<OccupancyStats[]>([])
const groupBy = ref('building')
const chartRef = ref<HTMLDivElement | null>(null)
let chart: echarts.ECharts | null = null

const fetchData = async () => {
  loading.value = true
  try {
    const res = await getOccupancyStats({ groupBy: groupBy.value })
    tableData.value = Array.isArray(res) ? res : []
    await nextTick()
    renderChart()
  } catch (error) {
    console.error('获取入住率失败', error)
  } finally {
    loading.value = false
  }
}

function renderChart() {
  if (!chartRef.value) return
  if (!chart) chart = echarts.init(chartRef.value)
  chart.setOption({
    tooltip: { trigger: 'axis' },
    legend: { data: ['总床位', '已入住', '空闲'] },
    xAxis: {
      type: 'category',
      data: tableData.value.map((r) => r.dimName),
      axisLabel: { rotate: tableData.value.length > 6 ? 30 : 0 },
    },
    yAxis: { type: 'value', minInterval: 1 },
    series: [
      { name: '总床位', type: 'bar', data: tableData.value.map((r) => r.totalBeds) },
      { name: '已入住', type: 'bar', data: tableData.value.map((r) => r.occupiedBeds) },
      { name: '空闲', type: 'bar', data: tableData.value.map((r) => r.vacantBeds) },
    ],
  })
}

function handleResize() {
  chart?.resize()
}

onMounted(() => {
  fetchData()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
  chart?.dispose()
  chart = null
})
</script>

<style scoped>
.stats-container {
  padding: 20px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-weight: bold;
}
.filters {
  display: flex;
  gap: 8px;
  align-items: center;
}
.chart {
  height: 320px;
  width: 100%;
}
</style>
