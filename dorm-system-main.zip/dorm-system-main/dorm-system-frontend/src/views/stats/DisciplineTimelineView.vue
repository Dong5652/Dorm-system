<template>
  <div class="discipline-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>违纪记录查询</span>
        </div>
      </template>

      <!-- 搜索栏 -->
      <div class="search-bar">
        <el-form :inline="true" :model="searchForm">
          <el-form-item label="学号">
            <el-input v-model="searchForm.studentNo" placeholder="请输入学号" clearable />
          </el-form-item>
          <el-form-item label="房间ID">
            <el-input-number v-model="searchForm.roomId" :min="1" placeholder="房间ID" clearable />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="fetchData">查询</el-button>
          </el-form-item>
        </el-form>
      </div>

      <!-- 时间线 -->
      <el-timeline v-loading="loading" style="margin-top: 20px;">
        <el-timeline-item
          v-for="(record, index) in timelineData"
          :key="index"
          :timestamp="formatTime(record.time)"
          :type="getType(record.type)"
          placement="top"
        >
          <el-card>
            <h4>{{ getTypeName(record.type) }}</h4>
            <p>{{ record.description }}</p>
            <p v-if="record.studentId" class="meta-info">学生ID: {{ record.studentId }}</p>
            <p v-if="record.roomId" class="meta-info">房间ID: {{ record.roomId }}</p>
          </el-card>
        </el-timeline-item>
      </el-timeline>
      <el-empty v-if="!loading && timelineData.length === 0" description="暂无违纪记录" />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { getDisciplineTimeline, type DisciplineRecord } from '@/api/stats'

const loading = ref(false)
const timelineData = ref<DisciplineRecord[]>([])
const searchForm = ref({
  studentNo: '',
  roomId: undefined as number | undefined
})

const fetchData = async () => {
  loading.value = true
  try {
    const params: any = {}
    if (searchForm.value.studentNo) params.studentNo = searchForm.value.studentNo
    if (searchForm.value.roomId) params.roomId = searchForm.value.roomId
    const res = await getDisciplineTimeline(params)
    timelineData.value = res as any
  } catch (error) {
    console.error('查询失败', error)
  } finally {
    loading.value = false
  }
}

const getTypeName = (type: string) => {
  return { hygiene: '卫生问题', attendance: '考勤问题', safety: '安全问题' }[type] || type
}

const getType = (type: string) => {
  return { hygiene: 'warning', attendance: 'danger', safety: 'danger' }[type] || 'primary'
}

const formatTime = (t: string) => t ? t.replace('T', ' ') : ''
</script>

<style scoped>
.discipline-container { padding: 20px; }
.card-header { font-weight: bold; }
.search-bar { margin-bottom: 20px; }
.meta-info { color: #999; font-size: 12px; margin-top: 5px; }
</style>
