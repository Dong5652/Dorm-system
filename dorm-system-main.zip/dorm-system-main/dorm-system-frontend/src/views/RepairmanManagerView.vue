<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  listRepairmen,
  createRepairman,
  updateRepairman,
  deleteRepairman,
  GENDER_LABELS,
  REPAIRMAN_WORK_TYPES,
  type Repairman,
  type RepairmanSaveRequest,
} from '@/api/repairman'

const list = ref<Repairman[]>([])
const loading = ref(false)

async function loadList() {
  loading.value = true
  try {
    list.value = await listRepairmen()
  } catch {
    // 静默
  } finally {
    loading.value = false
  }
}

// ---- 弹窗 --------------------------------------------------------------
const dialogVisible = ref(false)
const isEdit = ref(false)
const submitting = ref(false)
const form = ref<RepairmanSaveRequest & { id?: number }>({
  id: undefined,
  username: '',
  realName: '',
  gender: 1,
  phone: '',
  workType: '',
  status: 1,
})

function openCreate() {
  isEdit.value = false
  form.value = {
    username: '',
    realName: '',
    gender: 1,
    phone: '',
    workType: '水电',
    status: 1,
  }
  dialogVisible.value = true
}

function openEdit(row: Repairman) {
  isEdit.value = true
  form.value = {
    id: row.id,
    username: row.username,
    realName: row.realName,
    gender: row.gender,
    phone: row.phone || '',
    workType: row.workType || '',
    status: row.status,
  }
  dialogVisible.value = true
}

async function submit() {
  if (!form.value.username) {
    ElMessage.warning('请填写登录名')
    return
  }
  if (!form.value.realName) {
    ElMessage.warning('请填写姓名')
    return
  }
  submitting.value = true
  try {
    const payload: RepairmanSaveRequest = {
      username: form.value.username,
      realName: form.value.realName,
      gender: form.value.gender,
      phone: form.value.phone || undefined,
      workType: form.value.workType || undefined,
      status: form.value.status,
    }
    if (isEdit.value && form.value.id) {
      await updateRepairman(form.value.id, payload)
      ElMessage.success('修改成功')
    } else {
      await createRepairman(payload)
      ElMessage.success('新增成功，初始密码 123456')
    }
    dialogVisible.value = false
    loadList()
  } catch {
    // 静默
  } finally {
    submitting.value = false
  }
}

async function handleDelete(row: Repairman) {
  try {
    await ElMessageBox.confirm(`确认删除师傅 ${row.realName} 吗？`, '提示', { type: 'warning' })
  } catch {
    return
  }
  try {
    await deleteRepairman(row.id)
    ElMessage.success('已删除')
    loadList()
  } catch {
    // 静默
  }
}

onMounted(() => {
  loadList()
})
</script>

<template>
  <div class="repairman-view">
    <div class="page-header">
      <h1 class="page-title">维修师傅管理</h1>
      <p class="page-subtitle">
        管理维修师傅账号（sys_user.role=repairman）。新增账号初始密码 123456，BCrypt 加密。
      </p>
    </div>

    <el-card shadow="never">
      <div class="filter-row">
        <div class="flex-grow"></div>
        <el-button type="primary" @click="openCreate">
          <el-icon><Plus /></el-icon> 新增师傅
        </el-button>
      </div>

      <el-table :data="list" v-loading="loading" border stripe empty-text="暂无师傅">
        <el-table-column label="ID" prop="id" width="60" />
        <el-table-column label="登录名" prop="username" width="160" />
        <el-table-column label="姓名" prop="realName" width="120" />
        <el-table-column label="性别" width="80" align="center">
          <template #default="{ row }">{{ GENDER_LABELS[row.gender] || '-' }}</template>
        </el-table-column>
        <el-table-column label="电话" prop="phone" width="140" />
        <el-table-column label="工种" prop="workType" width="100" />
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="row.status === 1 ? 'success' : 'danger'" size="small">
              {{ row.status === 1 ? '启用' : '禁用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="openEdit(row)">修改</el-button>
            <el-button size="small" type="danger" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新增 / 修改弹窗 -->
    <el-dialog
      v-model="dialogVisible"
      :title="isEdit ? '修改师傅' : '新增师傅'"
      width="560px"
      destroy-on-close
    >
      <el-alert
        v-if="!isEdit"
        title="新增师傅初始密码为 123456，请通知本人登录后尽快修改。"
        type="info"
        :closable="false"
        show-icon
        style="margin-bottom: 16px"
      />
      <el-form :model="form" label-width="100px">
        <el-form-item label="登录名" required>
          <el-input
            v-model="form.username"
            :disabled="isEdit"
            placeholder="如 repair003"
          />
          <div v-if="isEdit" class="hint-tip">登录名不可修改</div>
        </el-form-item>
        <el-form-item label="姓名" required>
          <el-input v-model="form.realName" placeholder="如 王师傅" />
        </el-form-item>
        <el-form-item label="性别" required>
          <el-radio-group v-model="form.gender">
            <el-radio :value="1">男</el-radio>
            <el-radio :value="2">女</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="电话">
          <el-input v-model="form.phone" placeholder="如 13800138001" />
        </el-form-item>
        <el-form-item label="工种">
          <el-select v-model="form.workType" placeholder="选择工种" filterable allow-create style="width: 100%">
            <el-option v-for="w in REPAIRMAN_WORK_TYPES" :key="w" :value="w" :label="w" />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-radio-group v-model="form.status">
            <el-radio :value="1">启用</el-radio>
            <el-radio :value="0">禁用</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="submit">
          {{ isEdit ? '保存' : '新增' }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.repairman-view {
  max-width: 1400px;
  margin: 0 auto;
}
.page-header {
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: 700;
  color: #303133;
  margin: 0 0 6px 0;
}
.page-subtitle {
  font-size: 14px;
  color: #909399;
  margin: 0;
}
.filter-row {
  display: flex;
  align-items: center;
  margin-bottom: 16px;
}
.flex-grow {
  flex: 1;
}
.hint-tip {
  margin-top: 4px;
  color: #909399;
  font-size: 12px;
}
</style>
