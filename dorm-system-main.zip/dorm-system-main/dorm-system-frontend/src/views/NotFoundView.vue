<script setup lang="ts">
// 404 占位
</script>

<template>
  <el-result icon="info" title="404" sub-title="页面未找到">
    <template #extra>
      <el-button type="primary" @click="$router.push('/')">回到首页</el-button>
    </template>
  </el-result>
</template>
