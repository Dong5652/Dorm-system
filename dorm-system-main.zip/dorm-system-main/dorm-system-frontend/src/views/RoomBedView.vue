<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { useUserStore } from '@/stores/user'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  pageStudents,
  type Student,
} from '@/api/student'
import {
  fetchDormTree,
  type BuildingTreeNode,
  type FloorTreeNode,
  type RoomTreeNode,
  type BedTreeNode,
  BED_STATUS_LABELS,
  BED_STATUS_TYPES,
  ROOM_STATUS_LABELS,
  ROOM_STATUS_TYPES,
} from '@/api/dorm'
import {
  checkIn,
  checkOut,
  fetchRecords,
} from '@/api/record'

const store = useUserStore()
const isAdmin = computed(() => store.role === 'admin')
const isManager = computed(() => isAdmin.value || store.role === 'dorm_manager')

// --- 宿舍树（楼栋 → 楼层 → 房间 → 床位） ---
const tree = ref<BuildingTreeNode[]>([])
const loading = ref(false)
const selectedBuildingId = ref<number | null>(null)
const selectedFloorId = ref<number | null>(null)
const selectedRoomId = ref<number | null>(null)

const buildings = computed(() => tree.value)
const floors = computed<FloorTreeNode[]>(() => {
  const b = tree.value.find((x) => x.id === selectedBuildingId.value)
  return b?.floors ?? []
})
const rooms = computed<RoomTreeNode[]>(() => {
  const f = floors.value.find((x) => x.id === selectedFloorId.value)
  return f?.rooms ?? []
})
const currentRoom = computed<RoomTreeNode | undefined>(() =>
  rooms.value.find((x) => x.id === selectedRoomId.value),
)

async function loadTree() {
  loading.value = true
  try {
    tree.value = await fetchDormTree()
    // 默认选第一个楼栋 + 第一个楼层
    if (tree.value.length > 0) {
      selectedBuildingId.value = tree.value[0].id
      if (tree.value[0].floors.length > 0) {
        selectedFloorId.value = tree.value[0].floors[0].id
      }
    }
  } catch {
    // 拦截器弹错
  } finally {
    loading.value = false
  }
}

function selectBuilding(id: number) {
  selectedBuildingId.value = id
  const b = tree.value.find((x) => x.id === id)
  selectedFloorId.value = b?.floors[0]?.id ?? null
  selectedRoomId.value = null
}

function selectFloor(id: number) {
  selectedFloorId.value = id
  selectedRoomId.value = null
}

function selectRoom(id: number) {
  selectedRoomId.value = id
}

async function refreshRoom() {
  if (!selectedRoomId.value) return
  await loadTree()
}

// --- 入住弹窗 ---
const checkInDialogVisible = ref(false)
const checkInTargetBed = ref<BedTreeNode | null>(null)
const checkInSubmitting = ref(false)
const studentOptions = ref<Student[]>([])
const studentLoading = ref(false)
const checkInForm = ref({
  studentId: null as number | null,
  keyIssued: true,
  facilityCheck: '',
  remark: '',
})

async function searchStudents(keyword: string) {
  studentLoading.value = true
  try {
    const res = await pageStudents({ pageNum: 1, pageSize: 30, keyword })
    studentOptions.value = res.records
  } catch {
    // 静默
  } finally {
    studentLoading.value = false
  }
}

function openCheckInDialog(bed: BedTreeNode) {
  if (!isManager.value) return
  checkInTargetBed.value = bed
  checkInForm.value = {
    studentId: null,
    keyIssued: true,
    facilityCheck: '',
    remark: '',
  }
  checkInDialogVisible.value = true
  if (studentOptions.value.length === 0) {
    searchStudents('')
  }
}

async function submitCheckIn() {
  if (!checkInTargetBed.value) return
  if (!checkInForm.value.studentId) {
    ElMessage.warning('请选择要入住的学生')
    return
  }
  const target = checkInTargetBed.value
  checkInSubmitting.value = true
  try {
    const res = await checkIn({
      studentId: checkInForm.value.studentId,
      bedId: target.id,
      keyIssued: checkInForm.value.keyIssued,
      facilityCheck: checkInForm.value.facilityCheck,
      remark: checkInForm.value.remark,
    })
    ElMessage.success(`入住成功，流水号 #${res.recordId}`)
    checkInDialogVisible.value = false
    await refreshRoom()
  } catch {
    // 拦截器弹错
  } finally {
    checkInSubmitting.value = false
  }
}

// --- 退宿操作 ---
async function handleCheckOut(bed: BedTreeNode) {
  if (!bed.studentId) return
  try {
    await ElMessageBox.confirm(
      `确认对该床位上的学生办理退宿吗？\n床位号：${bed.bedNo}\n学生：${bed.studentName || '#' + bed.studentId}`,
      '退宿确认',
      { type: 'warning', confirmButtonText: '确认退宿', cancelButtonText: '取消' },
    )
  } catch {
    return
  }
  try {
    await checkOut({
      studentId: bed.studentId,
      keyReturned: true,
      facilityCheck: '',
      remark: '从床位可视化页面退宿',
    })
    ElMessage.success('退宿成功')
    await refreshRoom()
  } catch {
    // 静默
  }
}

// --- 历史流水（按房间） ---
const roomRecords = ref<Awaited<ReturnType<typeof fetchRecords>>>([])
const roomRecordsVisible = ref(false)
const roomRecordsLoading = ref(false)

async function openRoomRecords() {
  if (!selectedRoomId.value) return
  roomRecordsVisible.value = true
  roomRecordsLoading.value = true
  try {
    roomRecords.value = await fetchRecords({ roomId: selectedRoomId.value })
  } catch {
    // 静默
  } finally {
    roomRecordsLoading.value = false
  }
}

function formatTime(t: string): string {
  return t ? t.replace('T', ' ') : ''
}

function bedStatusColor(status: number): string {
  return {
    0: '#67c23a',
    1: '#409eff',
    2: '#e6a23c',
    3: '#f56c6c',
  }[status] || '#909399'
}

onMounted(loadTree)
</script>

<template>
  <div class="room-bed-view">
    <div class="page-header">
      <h1 class="page-title">床位可视化</h1>
      <p class="page-subtitle">按楼栋/楼层/房间浏览床位状态，点击空闲床位可直接办理入住，点击已占用床位可办理退宿。</p>
    </div>

    <div class="main-layout" v-loading="loading">
      <!-- 左侧楼栋 + 楼层 -->
      <div class="sidebar">
        <div class="sidebar-section">
          <div class="sidebar-title">楼栋</div>
          <div class="item-list">
            <div
              v-for="b in buildings"
              :key="b.id"
              :class="['list-item', { active: selectedBuildingId === b.id }]"
              @click="selectBuilding(b.id)"
            >
              <el-tag :type="b.gender === 1 ? 'primary' : b.gender === 2 ? 'danger' : 'warning'" effect="plain" size="small">
                {{ b.gender === 1 ? '男' : b.gender === 2 ? '女' : '混' }}
              </el-tag>
              <span class="item-text">{{ b.code }} {{ b.name }}</span>
            </div>
            <el-empty v-if="buildings.length === 0" description="暂无楼栋" :image-size="40" />
          </div>
        </div>

        <div class="sidebar-section">
          <div class="sidebar-title">楼层</div>
          <div class="item-list">
            <div
              v-for="f in floors"
              :key="f.id"
              :class="['list-item small', { active: selectedFloorId === f.id }]"
              @click="selectFloor(f.id)"
            >
              <span class="item-text">{{ f.floorNo }} 层</span>
              <span class="item-meta">{{ f.rooms.length }} 间</span>
            </div>
            <el-empty v-if="floors.length === 0" description="暂无楼层" :image-size="40" />
          </div>
        </div>
      </div>

      <!-- 右侧房间 + 床位 -->
      <div class="content">
        <template v-if="selectedFloorId">
          <div class="content-header">
            <div class="title-line">
              <span class="floor-label">{{ buildings.find((x) => x.id === selectedBuildingId)?.name || '' }} · {{ floors.find((x) => x.id === selectedFloorId)?.floorNo }} 层</span>
              <span class="room-count">共 {{ rooms.length }} 间房</span>
            </div>
            <el-button size="small" :disabled="!selectedRoomId" @click="openRoomRecords">
              <el-icon style="margin-right: 4px"><Document /></el-icon> 当前房间流水
            </el-button>
          </div>

          <div class="room-grid">
            <div
              v-for="r in rooms"
              :key="r.id"
              :class="['room-card', { selected: selectedRoomId === r.id }]"
              @click="selectRoom(r.id)"
            >
              <div class="room-card-header">
                <span class="room-no">🚪 {{ r.roomNo }}</span>
                <el-tag :type="ROOM_STATUS_TYPES[r.status]" effect="plain" size="small">
                  {{ ROOM_STATUS_LABELS[r.status] }}
                </el-tag>
              </div>
              <div class="room-card-body">
                <div class="room-meta">
                  <span>额定 {{ r.capacity }}</span>
                  <span>已入住 {{ r.occupiedCount }}</span>
                </div>
                <div class="beds-grid">
                  <div
                    v-for="b in r.beds"
                    :key="b.id"
                    :class="['bed-card', `status-${b.status}`]"
                    @click.stop="b.status === 0 ? openCheckInDialog(b) : (b.status === 1 ? handleCheckOut(b) : null)"
                  >
                    <div class="bed-card-header">
                      <span class="bed-no">{{ b.bedNo }} 床</span>
                      <span class="status-dot" :style="{ backgroundColor: bedStatusColor(b.status) }"></span>
                    </div>
                    <div class="bed-status">
                      <el-tag :type="BED_STATUS_TYPES[b.status]" size="small">{{ BED_STATUS_LABELS[b.status] }}</el-tag>
                    </div>
                    <div class="bed-student" v-if="b.status === 1">
                      <el-icon><User /></el-icon>
                      <span>{{ b.studentName || '#' + b.studentId }}</span>
                    </div>
                    <div class="bed-action" v-if="b.status === 0 && isManager">
                      <el-button type="primary" size="small" plain>点击入住</el-button>
                    </div>
                    <div class="bed-action" v-else-if="b.status === 1 && isManager">
                      <el-button type="danger" size="small" plain>点击退宿</el-button>
                    </div>
                  </div>
                  <div v-if="r.beds.length === 0" class="no-beds">该房间暂无床位</div>
                </div>
              </div>
            </div>
            <el-empty v-if="rooms.length === 0" description="当前楼层尚无房间" style="grid-column: span 3" />
          </div>
        </template>

        <el-empty v-else description="请从左侧选择楼栋和楼层" style="padding-top: 120px" />
      </div>
    </div>

    <!-- 入住弹窗 -->
    <el-dialog
      v-model="checkInDialogVisible"
      title="办理入住"
      width="480px"
      destroy-on-close
    >
      <el-form :model="checkInForm" label-width="100px">
        <el-form-item label="目标床位">
          <el-tag type="info" size="large" v-if="checkInTargetBed">{{ checkInTargetBed.bedNo }} 床</el-tag>
        </el-form-item>
        <el-form-item label="入住学生" required>
          <el-select
            v-model="checkInForm.studentId"
            filterable
            remote
            clearable
            reserve-keyword
            placeholder="搜索学号 / 姓名"
            :remote-method="searchStudents"
            :loading="studentLoading"
            style="width: 100%"
          >
            <el-option
              v-for="s in studentOptions"
              :key="s.id"
              :label="`${s.studentNo} · ${s.name}（${s.gender === 1 ? '男' : '女'}）`"
              :value="s.id"
              :disabled="!!s.currentBedId"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="钥匙发放">
          <el-switch v-model="checkInForm.keyIssued" />
        </el-form-item>
        <el-form-item label="设施检查">
          <el-input v-model="checkInForm.facilityCheck" placeholder="如：桌椅齐全 / 风扇损坏" />
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="checkInForm.remark" type="textarea" :rows="2" placeholder="新生入住 / 调宿入住等" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="checkInDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="checkInSubmitting" @click="submitCheckIn">确认入住</el-button>
      </template>
    </el-dialog>

    <!-- 房间流水弹窗 -->
    <el-dialog
      v-model="roomRecordsVisible"
      :title="`房间流水记录 · ${currentRoom?.roomNo || ''}`"
      width="800px"
      destroy-on-close
    >
      <el-table :data="roomRecords" v-loading="roomRecordsLoading" border stripe empty-text="该房间暂无流水记录" max-height="500">
        <el-table-column label="时间" width="160">
          <template #default="{ row }">{{ formatTime(row.happenedAt) }}</template>
        </el-table-column>
        <el-table-column label="学生" min-width="160">
          <template #default="{ row }">
            {{ row.studentName || '-' }} <code class="code-no">{{ row.studentNo || '-' }}</code>
          </template>
        </el-table-column>
        <el-table-column label="类型" width="100" align="center">
          <template #default="{ row }">
            <el-tag v-if="row.recordType === 'check_in'" :type="row.type === 1 ? 'success' : 'info'" size="small">
              {{ row.type === 1 ? '入住' : '退宿' }}
            </el-tag>
            <el-tag v-else type="warning" size="small">
              {{ row.changeTypeLabel || row.changeType }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="床位" width="100">
          <template #default="{ row }">
            <span v-if="row.recordType === 'check_in'">{{ row.bedNo || '-' }} 床</span>
            <span v-else>{{ row.fromBedNo || '-' }} → {{ row.toBedNo || '-' }}</span>
          </template>
        </el-table-column>
        <el-table-column label="备注" min-width="180" show-overflow-tooltip>
          <template #default="{ row }">
            {{ row.reason || row.remark || '-' }}
          </template>
        </el-table-column>
      </el-table>
      <template #footer>
        <el-button @click="roomRecordsVisible = false">关闭</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.room-bed-view {
  max-width: 1400px;
  margin: 0 auto;
}
.page-header {
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: 700;
  color: #303133;
  margin: 0 0 6px 0;
}
.page-subtitle {
  font-size: 14px;
  color: #909399;
  margin: 0;
}

.main-layout {
  display: flex;
  gap: 16px;
  min-height: 600px;
}

/* Sidebar */
.sidebar {
  width: 260px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.sidebar-section {
  background: #fff;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  overflow: hidden;
}
.sidebar-title {
  background: #fafbfd;
  padding: 10px 14px;
  font-weight: 600;
  color: #606266;
  border-bottom: 1px solid #ebeef5;
  font-size: 13px;
}
.item-list {
  max-height: 260px;
  overflow-y: auto;
  padding: 6px;
}
.list-item {
  padding: 8px 10px;
  border-radius: 6px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  color: #606266;
  font-size: 13px;
  transition: all 0.2s;
}
.list-item:hover {
  background-color: #f2f6fc;
}
.list-item.active {
  background-color: #ecf5ff;
  color: #409eff;
  font-weight: 600;
}
.list-item.small {
  padding: 6px 10px;
  font-size: 12px;
}
.item-text {
  flex: 1;
}
.item-meta {
  color: #c0c4cc;
  font-size: 11px;
}

/* Content */
.content {
  flex: 1;
  background: #fff;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  padding: 16px;
  min-width: 0;
}
.content-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  padding-bottom: 10px;
  border-bottom: 1px dashed #ebeef5;
}
.title-line {
  display: flex;
  align-items: baseline;
  gap: 12px;
}
.floor-label {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}
.room-count {
  font-size: 12px;
  color: #909399;
}

/* Room Grid */
.room-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 14px;
}
.room-card {
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  background: #fff;
  cursor: pointer;
  transition: all 0.2s;
  overflow: hidden;
}
.room-card:hover {
  border-color: #409eff;
  box-shadow: 0 4px 12px rgba(64, 158, 255, 0.1);
}
.room-card.selected {
  border-color: #409eff;
  box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.25);
}
.room-card-header {
  padding: 10px 14px;
  background: #fafbfd;
  border-bottom: 1px solid #ebeef5;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.room-no {
  font-weight: 600;
  color: #303133;
  font-size: 14px;
}
.room-card-body {
  padding: 10px 14px;
}
.room-meta {
  display: flex;
  gap: 12px;
  font-size: 12px;
  color: #909399;
  margin-bottom: 10px;
}
.room-meta span {
  background: #f4f4f5;
  padding: 2px 6px;
  border-radius: 4px;
}

/* Bed Grid */
.beds-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 8px;
}
.bed-card {
  border-radius: 6px;
  padding: 8px 10px;
  cursor: pointer;
  border: 2px solid transparent;
  transition: all 0.2s;
  min-height: 88px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.bed-card:hover {
  transform: translateY(-2px);
}
.bed-card.status-0 {
  background: #f0f9eb;
  border-color: #e1f3d8;
}
.bed-card.status-0:hover {
  border-color: #67c23a;
  box-shadow: 0 2px 6px rgba(103, 194, 58, 0.2);
}
.bed-card.status-1 {
  background: #ecf5ff;
  border-color: #d9ecff;
}
.bed-card.status-1:hover {
  border-color: #409eff;
}
.bed-card.status-2 {
  background: #fdf6ec;
  border-color: #faecd8;
  cursor: not-allowed;
}
.bed-card.status-3 {
  background: #fef0f0;
  border-color: #fde2e2;
  cursor: not-allowed;
}
.bed-card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.bed-no {
  font-weight: 600;
  color: #303133;
  font-size: 13px;
}
.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
}
.bed-status {
  display: flex;
  align-items: center;
}
.bed-student {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #409eff;
  font-weight: 600;
}
.bed-action {
  margin-top: auto;
  text-align: center;
}
.no-beds {
  grid-column: span 2;
  text-align: center;
  color: #c0c4cc;
  font-size: 12px;
  padding: 16px 0;
}
.code-no {
  background: #f4f4f5;
  color: #909399;
  font-family: monospace;
  padding: 1px 5px;
  border-radius: 3px;
  font-size: 11px;
}
</style>
