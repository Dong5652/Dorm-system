<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  pageRepairs,
  createRepair,
  cancelRepair,
  deleteRepair,
  REPAIR_STATUS_LABELS,
  REPAIR_STATUS_TYPES,
  PRIORITY_LABELS,
  PRIORITY_TYPES,
  type RepairResponse,
  type RepairCreateRequest,
} from '@/api/repair'
import { listRepairmen, type Repairman } from '@/api/repairman'
import { fetchDormTree, type BuildingTreeNode } from '@/api/dorm'
import DormSelector from '@/components/DormSelector.vue'
import type { DormSelection } from '@/components/DormSelector.vue'

const store = useUserStore()
const router = useRouter()
const isAdmin = computed(() => store.role === 'admin')
const isManager = computed(() => isAdmin.value || store.role === 'dorm_manager')
const isStudent = computed(() => store.role === 'student')
const isRepairman = computed(() => store.role === 'repairman')

// ---- 列表 ----------------------------------------------------------------
const list = ref<RepairResponse[]>([])
const total = ref(0)
const pageNum = ref(1)
const pageSize = ref(10)
const loading = ref(false)

const filter = ref({
  status: undefined as number | undefined,
  priority: undefined as number | undefined,
  buildingId: undefined as number | undefined,
  repairmanId: undefined as number | undefined,
  dateRange: null as [string, string] | null,
})

async function loadList() {
  loading.value = true
  try {
    const res = await pageRepairs({
      pageNum: pageNum.value,
      pageSize: pageSize.value,
      status: filter.value.status,
      priority: filter.value.priority,
      buildingId: filter.value.buildingId,
      repairmanId: filter.value.repairmanId,
      startDate: filter.value.dateRange?.[0],
      endDate: filter.value.dateRange?.[1],
    })
    list.value = res.records
    total.value = res.total
  } catch {
    // 静默
  } finally {
    loading.value = false
  }
}

function resetFilter() {
  filter.value = {
    status: undefined,
    priority: undefined,
    buildingId: undefined,
    repairmanId: undefined,
    dateRange: null,
  }
  pageNum.value = 1
  loadList()
}

function handlePageChange(p: number) {
  pageNum.value = p
  loadList()
}

function viewDetail(row: RepairResponse) {
  router.push(`/repair/${row.id}`)
}

// ---- 创建弹窗 ------------------------------------------------------------
const dialogVisible = ref(false)
const submitting = ref(false)
const form = ref<RepairCreateRequest>({
  roomId: 0,
  bedId: null,
  title: '',
  description: '',
  photoUrl: '',
  priority: 0,
})
const dormSelection = ref<DormSelection>({ buildingId: null, floorId: null, roomId: null, bedId: null })

const dormTree = ref<BuildingTreeNode[]>([])
const repairmen = ref<Repairman[]>([])

async function loadDormTree() {
  try {
    dormTree.value = await fetchDormTree()
  } catch {
    // 静默
  }
}

async function loadRepairmen() {
  if (!isAdmin.value) return
  try {
    repairmen.value = await listRepairmen()
  } catch {
    // 静默
  }
}

function openCreate() {
  form.value = {
    roomId: 0,
    bedId: null,
    title: '',
    description: '',
    photoUrl: '',
    priority: 0,
  }
  dormSelection.value = { buildingId: null, floorId: null, roomId: null, bedId: null }
  dialogVisible.value = true
}

function onSelectionChange(sel: DormSelection) {
  dormSelection.value = sel
  if (sel.roomId) {
    form.value.roomId = sel.roomId
    form.value.bedId = sel.bedId
  }
}

async function submit() {
  if (!form.value.roomId) {
    ElMessage.warning('请选择报修房间')
    return
  }
  if (!form.value.title) {
    ElMessage.warning('请填写报修标题')
    return
  }
  submitting.value = true
  try {
    await createRepair({
      roomId: form.value.roomId,
      bedId: form.value.bedId || undefined,
      title: form.value.title,
      description: form.value.description || undefined,
      photoUrl: form.value.photoUrl || undefined,
      priority: form.value.priority ?? 0,
    })
    ElMessage.success('报修成功')
    dialogVisible.value = false
    loadList()
  } catch {
    // 静默
  } finally {
    submitting.value = false
  }
}

// ---- 取消 / 删除 ---------------------------------------------------------
async function handleCancel(row: RepairResponse) {
  try {
    await ElMessageBox.confirm(`确认取消工单 ${row.orderNo} 吗？`, '提示', { type: 'warning' })
  } catch {
    return
  }
  try {
    await cancelRepair(row.id)
    ElMessage.success('已取消')
    loadList()
  } catch {
    // 静默
  }
}

async function handleDelete(row: RepairResponse) {
  try {
    await ElMessageBox.confirm(`确认删除工单 ${row.orderNo} 吗？此操作不可恢复。`, '提示', { type: 'warning' })
  } catch {
    return
  }
  try {
    await deleteRepair(row.id)
    ElMessage.success('已删除')
    loadList()
  } catch {
    // 静默
  }
}

function formatDateTime(t: string | null) {
  return t ? t.replace('T', ' ').slice(0, 16) : '-'
}

onMounted(() => {
  if (isManager.value) {
    loadDormTree()
    loadRepairmen()
  }
  loadList()
})
</script>

<template>
  <div class="repair-view">
    <div class="page-header">
      <h1 class="page-title">维修工单</h1>
      <p class="page-subtitle">
        学生报修 → 管理员派单 → 师傅维修 → 完工 → 学生评价闭环。各角色仅可见本人权限范围内的工单。
      </p>
    </div>

    <el-card shadow="never">
      <div class="filter-row">
        <el-select v-model="filter.status" placeholder="状态" clearable style="width: 140px">
          <el-option :value="0" label="待派单" />
          <el-option :value="1" label="已派单" />
          <el-option :value="2" label="维修中" />
          <el-option :value="3" label="已完成" />
          <el-option :value="4" label="已取消" />
        </el-select>
        <el-select v-model="filter.priority" placeholder="优先级" clearable style="width: 140px">
          <el-option :value="0" label="普通" />
          <el-option :value="1" label="紧急" />
          <el-option :value="2" label="非常紧急" />
        </el-select>
        <el-select
          v-if="isManager"
          v-model="filter.buildingId"
          placeholder="楼栋"
          clearable
          style="width: 180px"
        >
          <el-option v-for="b in dormTree" :key="b.id" :label="b.name" :value="b.id" />
        </el-select>
        <el-select
          v-if="isAdmin"
          v-model="filter.repairmanId"
          placeholder="维修师傅"
          clearable
          filterable
          style="width: 180px"
        >
          <el-option
            v-for="r in repairmen"
            :key="r.id"
            :label="`${r.realName}（${r.workType || '未设工种'}）`"
            :value="r.id"
          />
        </el-select>
        <el-date-picker
          v-model="filter.dateRange"
          type="daterange"
          value-format="YYYY-MM-DD"
          range-separator="→"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        />
        <el-button type="primary" @click="pageNum = 1; loadList()">
          <el-icon><Search /></el-icon> 查询
        </el-button>
        <el-button @click="resetFilter">重置</el-button>
        <div class="flex-grow"></div>
        <el-button v-if="isManager || isStudent" type="primary" @click="openCreate">
          <el-icon><Plus /></el-icon> 报修
        </el-button>
      </div>

      <el-table :data="list" v-loading="loading" border stripe empty-text="暂无工单">
        <el-table-column label="单号" prop="orderNo" width="160" />
        <el-table-column label="标题" prop="title" min-width="180" show-overflow-tooltip />
        <el-table-column label="楼栋" prop="buildingName" width="120" />
        <el-table-column label="房间" prop="roomNo" width="80" />
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="REPAIR_STATUS_TYPES[row.status]" size="small">
              {{ REPAIR_STATUS_LABELS[row.status] }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="优先级" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="PRIORITY_TYPES[row.priority]" size="small" effect="plain">
              {{ PRIORITY_LABELS[row.priority] }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="维修师傅" width="120">
          <template #default="{ row }">
            <span v-if="row.repairmanName">{{ row.repairmanName }}</span>
            <span v-else class="muted">未派单</span>
          </template>
        </el-table-column>
        <el-table-column label="评分" width="80" align="center">
          <template #default="{ row }">
            <span v-if="row.rating" class="rating">{{ '★'.repeat(row.rating) }}</span>
            <span v-else class="muted">-</span>
          </template>
        </el-table-column>
        <el-table-column label="创建时间" width="150">
          <template #default="{ row }">
            {{ formatDateTime(row.createdAt) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="viewDetail(row)">详情</el-button>
            <el-button
              v-if="(isStudent || isAdmin) && [0, 1, 2].includes(row.status)"
              size="small"
              type="warning"
              @click="handleCancel(row)"
            >取消</el-button>
            <el-button v-if="isAdmin" size="small" type="danger" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pager">
        <el-pagination
          v-model:current-page="pageNum"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next, jumper"
          @current-change="handlePageChange"
          @size-change="loadList"
        />
      </div>
    </el-card>

    <!-- 报修弹窗 -->
    <el-dialog v-model="dialogVisible" title="发起报修" width="560px" destroy-on-close>
      <el-form :model="form" label-width="100px">
        <el-form-item label="房间" required>
          <DormSelector
            v-model="dormSelection"
            :show-bed="true"
            placeholder="选择报修房间"
            @change="onSelectionChange"
          />
        </el-form-item>
        <el-form-item label="标题" required>
          <el-input v-model="form.title" placeholder="如：水龙头漏水" maxlength="100" show-word-limit />
        </el-form-item>
        <el-form-item label="描述">
          <el-input
            v-model="form.description"
            type="textarea"
            :rows="3"
            placeholder="详细描述故障现象"
          />
        </el-form-item>
        <el-form-item label="照片 URL">
          <el-input v-model="form.photoUrl" placeholder="可选，如 /upload/repair/xxx.jpg" />
        </el-form-item>
        <el-form-item label="优先级">
          <el-radio-group v-model="form.priority">
            <el-radio :value="0">普通</el-radio>
            <el-radio :value="1">紧急</el-radio>
            <el-radio :value="2">非常紧急</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="submit">提交报修</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.repair-view {
  max-width: 1400px;
  margin: 0 auto;
}
.page-header {
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: 700;
  color: #303133;
  margin: 0 0 6px 0;
}
.page-subtitle {
  font-size: 14px;
  color: #909399;
  margin: 0;
}
.filter-row {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  margin-bottom: 16px;
}
.flex-grow {
  flex: 1;
}
.pager {
  margin-top: 16px;
  display: flex;
  justify-content: flex-end;
}
.muted {
  color: #c0c4cc;
}
.rating {
  color: #f56c6c;
  letter-spacing: 1px;
}
</style>
