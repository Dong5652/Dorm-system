<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  getRepair,
  assignRepair,
  startRepair,
  finishRepair,
  rateRepair,
  cancelRepair,
  REPAIR_STATUS_LABELS,
  REPAIR_STATUS_TYPES,
  PRIORITY_LABELS,
  PRIORITY_TYPES,
  type RepairResponse,
} from '@/api/repair'
import { listRepairmen, type Repairman } from '@/api/repairman'

const route = useRoute()
const router = useRouter()
const store = useUserStore()

const isAdmin = computed(() => store.role === 'admin')
const isStudent = computed(() => store.role === 'student')
const isRepairman = computed(() => store.role === 'repairman')

const detail = ref<RepairResponse | null>(null)
const loading = ref(false)

async function load() {
  const id = Number(route.params.id)
  if (!id) return
  loading.value = true
  try {
    detail.value = await getRepair(id)
  } catch {
    // 静默
  } finally {
    loading.value = false
  }
}

// ---- 派单 --------------------------------------------------------------
const repairmen = ref<Repairman[]>([])
const assignDialogVisible = ref(false)
const assignForm = ref<{ repairmanId: number | undefined }>({ repairmanId: undefined })
const assignSubmitting = ref(false)

async function loadRepairmen() {
  try {
    repairmen.value = await listRepairmen()
  } catch {
    // 静默
  }
}

function openAssignDialog() {
  assignForm.value = { repairmanId: undefined }
  assignDialogVisible.value = true
}

async function submitAssign() {
  if (!detail.value) return
  if (!assignForm.value.repairmanId) {
    ElMessage.warning('请选择维修师傅')
    return
  }
  assignSubmitting.value = true
  try {
    await assignRepair(detail.value.id, { repairmanId: assignForm.value.repairmanId })
    ElMessage.success('派单成功')
    assignDialogVisible.value = false
    load()
  } catch {
    // 静默
  } finally {
    assignSubmitting.value = false
  }
}

// ---- 接单 / 完工 / 评价 / 取消 ------------------------------------------
async function handleStart() {
  if (!detail.value) return
  try {
    await ElMessageBox.confirm('确认接单开始维修？', '提示', { type: 'warning' })
  } catch {
    return
  }
  try {
    await startRepair(detail.value.id)
    ElMessage.success('已接单')
    load()
  } catch {
    // 静默
  }
}

const finishDialogVisible = ref(false)
const finishForm = ref<{ completionNote: string }>({ completionNote: '' })
const finishSubmitting = ref(false)

function openFinishDialog() {
  finishForm.value = { completionNote: '' }
  finishDialogVisible.value = true
}

async function submitFinish() {
  if (!detail.value) return
  if (!finishForm.value.completionNote) {
    ElMessage.warning('请填写维修说明')
    return
  }
  finishSubmitting.value = true
  try {
    await finishRepair(detail.value.id, { completionNote: finishForm.value.completionNote })
    ElMessage.success('已完工')
    finishDialogVisible.value = false
    load()
  } catch {
    // 静默
  } finally {
    finishSubmitting.value = false
  }
}

const rateDialogVisible = ref(false)
const rateForm = ref<{ rating: number; ratingComment: string }>({ rating: 5, ratingComment: '' })
const rateSubmitting = ref(false)

function openRateDialog() {
  rateForm.value = { rating: 5, ratingComment: '' }
  rateDialogVisible.value = true
}

async function submitRate() {
  if (!detail.value) return
  rateSubmitting.value = true
  try {
    await rateRepair(detail.value.id, {
      rating: rateForm.value.rating,
      ratingComment: rateForm.value.ratingComment || undefined,
    })
    ElMessage.success('已评价')
    rateDialogVisible.value = false
    load()
  } catch {
    // 静默
  } finally {
    rateSubmitting.value = false
  }
}

async function handleCancel() {
  if (!detail.value) return
  try {
    await ElMessageBox.confirm(`确认取消工单 ${detail.value.orderNo}？`, '提示', { type: 'warning' })
  } catch {
    return
  }
  try {
    await cancelRepair(detail.value.id)
    ElMessage.success('已取消')
    load()
  } catch {
    // 静默
  }
}

function formatDateTime(t: string | null) {
  return t ? t.replace('T', ' ').slice(0, 16) : '-'
}

onMounted(() => {
  load()
  if (isAdmin.value) loadRepairmen()
})
</script>

<template>
  <div class="repair-detail-view" v-loading="loading">
    <div class="page-header">
      <el-button @click="router.back()" link>
        <el-icon><ArrowLeft /></el-icon> 返回
      </el-button>
      <h1 class="page-title">
        工单详情
        <span v-if="detail" class="order-no">{{ detail.orderNo }}</span>
      </h1>
    </div>

    <el-card v-if="detail" shadow="never">
      <el-descriptions :column="3" border>
        <el-descriptions-item label="单号">{{ detail.orderNo }}</el-descriptions-item>
        <el-descriptions-item label="状态">
          <el-tag :type="REPAIR_STATUS_TYPES[detail.status]">
            {{ REPAIR_STATUS_LABELS[detail.status] }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="优先级">
          <el-tag :type="PRIORITY_TYPES[detail.priority]" effect="plain">
            {{ PRIORITY_LABELS[detail.priority] }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="标题" :span="2">{{ detail.title }}</el-descriptions-item>
        <el-descriptions-item label="报修人">{{ detail.reporterName || '-' }}</el-descriptions-item>
        <el-descriptions-item label="楼栋">{{ detail.buildingName || '-' }}</el-descriptions-item>
        <el-descriptions-item label="房间">{{ detail.roomNo || '-' }}</el-descriptions-item>
        <el-descriptions-item label="床位">{{ detail.bedNo || '-' }}</el-descriptions-item>
        <el-descriptions-item label="维修师傅">
          {{ detail.repairmanName || '-' }}
          <span v-if="detail.repairmanWorkType" class="muted">({{ detail.repairmanWorkType }})</span>
        </el-descriptions-item>
        <el-descriptions-item label="师傅电话">{{ detail.repairmanPhone || '-' }}</el-descriptions-item>
        <el-descriptions-item label="派单人">{{ detail.assignedByName || '-' }}</el-descriptions-item>
        <el-descriptions-item label="派单时间">{{ formatDateTime(detail.assignedAt) }}</el-descriptions-item>
        <el-descriptions-item label="开始时间">{{ formatDateTime(detail.startedAt) }}</el-descriptions-item>
        <el-descriptions-item label="完工时间">{{ formatDateTime(detail.finishedAt) }}</el-descriptions-item>
        <el-descriptions-item label="创建时间">{{ formatDateTime(detail.createdAt) }}</el-descriptions-item>
        <el-descriptions-item label="故障描述" :span="3">{{ detail.description || '-' }}</el-descriptions-item>
        <el-descriptions-item label="维修说明" :span="3">{{ detail.completionNote || '-' }}</el-descriptions-item>
        <el-descriptions-item label="评价">
          <span v-if="detail.rating" class="rating">{{ '★'.repeat(detail.rating) }} ({{ detail.rating }} 星)</span>
          <span v-else class="muted">未评价</span>
        </el-descriptions-item>
        <el-descriptions-item label="评价内容" :span="2">{{ detail.ratingComment || '-' }}</el-descriptions-item>
      </el-descriptions>

      <div v-if="detail.photoUrl" class="photo-block">
        <h3>现场照片</h3>
        <el-image :src="detail.photoUrl" fit="cover" style="width: 240px; height: 180px" />
      </div>

      <!-- 状态流转按钮 -->
      <div class="actions">
        <!-- 管理员派单：status=0 -->
        <el-button v-if="isAdmin && detail.status === 0" type="primary" @click="openAssignDialog">
          <el-icon><Pointer /></el-icon> 派单
        </el-button>

        <!-- 师傅接单：status=1 -->
        <el-button v-if="isRepairman && detail.status === 1" type="primary" @click="handleStart">
          <el-icon><VideoPlay /></el-icon> 接单
        </el-button>

        <!-- 师傅完工：status=2 -->
        <el-button v-if="isRepairman && detail.status === 2" type="success" @click="openFinishDialog">
          <el-icon><CircleCheck /></el-icon> 完工
        </el-button>

        <!-- 学生评价：status=3 且未评价 -->
        <el-button
          v-if="isStudent && detail.status === 3 && !detail.rating"
          type="warning"
          @click="openRateDialog"
        >
          <el-icon><Star /></el-icon> 评价
        </el-button>

        <!-- 取消：学生/管理员，status∈{0,1,2} -->
        <el-button
          v-if="(isStudent || isAdmin) && [0, 1, 2].includes(detail.status)"
          type="danger"
          @click="handleCancel"
        >
          <el-icon><Close /></el-icon> 取消工单
        </el-button>
      </div>
    </el-card>

    <!-- 派单弹窗 -->
    <el-dialog v-model="assignDialogVisible" title="派单" width="480px" destroy-on-close>
      <el-form :model="assignForm" label-width="100px">
        <el-form-item label="维修师傅" required>
          <el-select
            v-model="assignForm.repairmanId"
            placeholder="选择师傅"
            filterable
            style="width: 100%"
          >
            <el-option
              v-for="r in repairmen"
              :key="r.id"
              :label="`${r.realName}（${r.workType || '未设工种'}）`"
              :value="r.id"
              :disabled="r.status === 0"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="assignDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="assignSubmitting" @click="submitAssign">派单</el-button>
      </template>
    </el-dialog>

    <!-- 完工弹窗 -->
    <el-dialog v-model="finishDialogVisible" title="完工登记" width="560px" destroy-on-close>
      <el-form :model="finishForm" label-width="100px">
        <el-form-item label="维修说明" required>
          <el-input
            v-model="finishForm.completionNote"
            type="textarea"
            :rows="4"
            placeholder="如：更换水龙头芯，已正常使用"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="finishDialogVisible = false">取消</el-button>
        <el-button type="success" :loading="finishSubmitting" @click="submitFinish">完工</el-button>
      </template>
    </el-dialog>

    <!-- 评价弹窗 -->
    <el-dialog v-model="rateDialogVisible" title="工单评价" width="480px" destroy-on-close>
      <el-form :model="rateForm" label-width="100px">
        <el-form-item label="评分" required>
          <el-rate v-model="rateForm.rating" :max="5" />
        </el-form-item>
        <el-form-item label="评价内容">
          <el-input
            v-model="rateForm.ratingComment"
            type="textarea"
            :rows="3"
            placeholder="如：响应及时，维修到位"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="rateDialogVisible = false">取消</el-button>
        <el-button type="warning" :loading="rateSubmitting" @click="submitRate">提交评价</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.repair-detail-view {
  max-width: 1400px;
  margin: 0 auto;
}
.page-header {
  margin-bottom: 16px;
}
.page-title {
  font-size: 22px;
  font-weight: 700;
  color: #303133;
  margin: 8px 0 0 0;
  display: flex;
  align-items: center;
  gap: 12px;
}
.order-no {
  font-size: 14px;
  color: #606266;
  font-weight: 400;
  background: #f4f4f5;
  padding: 2px 8px;
  border-radius: 4px;
  font-family: monospace;
}
.actions {
  margin-top: 24px;
  display: flex;
  gap: 12px;
  justify-content: flex-end;
  border-top: 1px solid #ebeef5;
  padding-top: 16px;
}
.photo-block {
  margin-top: 24px;
}
.photo-block h3 {
  font-size: 14px;
  color: #606266;
  margin: 0 0 8px 0;
}
.muted {
  color: #909399;
}
.rating {
  color: #f56c6c;
  font-weight: 600;
}
</style>
