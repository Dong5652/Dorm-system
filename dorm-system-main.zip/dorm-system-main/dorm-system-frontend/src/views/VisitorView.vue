<template>
  <div class="visitor-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>访客登记管理</span>
          <el-button type="primary" @click="openAddDialog" v-if="['admin', 'dorm_manager'].includes(authStore.role)">
            登记访客
          </el-button>
        </div>
      </template>

      <!-- 搜索栏 -->
      <div class="search-bar">
        <el-form :inline="true" :model="searchForm">
          <el-form-item label="楼栋">
            <el-select v-model="searchForm.buildingId" placeholder="选择楼栋" clearable>
              <el-option
                v-for="b in buildingList"
                :key="b.id"
                :label="b.name"
                :value="b.id"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="日期">
            <el-date-picker
              v-model="searchForm.date"
              type="date"
              placeholder="选择日期"
              value-format="YYYY-MM-DD"
              clearable
            />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="fetchData">查询</el-button>
          </el-form-item>
        </el-form>
      </div>

      <!-- 数据表格 -->
      <el-table :data="tableData" v-loading="loading" border style="width: 100%">
        <el-table-column prop="visitorName" label="访客姓名" width="120" />
        <el-table-column prop="idCard" label="身份证号" width="180" />
        <el-table-column prop="phone" label="联系电话" width="120" />
        <el-table-column prop="purpose" label="来访目的" />
        <el-table-column label="进入时间" width="180">
          <template #default="scope">
            {{ formatDateTime(scope.row.enterTime) }}
          </template>
        </el-table-column>
        <el-table-column label="离开时间" width="180">
          <template #default="scope">
            <span v-if="scope.row.exitTime">{{ formatDateTime(scope.row.exitTime) }}</span>
            <el-tag v-else type="danger">未离开</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="remark" label="备注" />
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="scope">
            <el-button
              v-if="!scope.row.exitTime"
              size="small"
              type="success"
              @click="handleExit(scope.row.id)"
            >
              登记离开
            </el-button>
            <el-button
              v-if="authStore.role === 'admin'"
              size="small"
              type="danger"
              @click="handleDelete(scope.row.id)"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 登记弹窗 -->
    <el-dialog v-model="dialogVisible" title="访客登记" width="500px">
      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="访客姓名" prop="visitorName">
          <el-input v-model="form.visitorName" placeholder="请输入访客姓名" />
        </el-form-item>
        <el-form-item label="身份证号" prop="idCard">
          <el-input v-model="form.idCard" placeholder="请输入身份证号" />
        </el-form-item>
        <el-form-item label="联系电话" prop="phone">
          <el-input v-model="form.phone" placeholder="请输入联系电话" />
        </el-form-item>
        <el-form-item label="访问楼栋" prop="buildingId">
          <el-select v-model="form.buildingId" placeholder="选择楼栋" style="width: 100%">
            <el-option
              v-for="b in buildingList"
              :key="b.id"
              :label="b.name"
              :value="b.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="来访目的" prop="purpose">
          <el-input v-model="form.purpose" type="textarea" placeholder="请输入来访目的" />
        </el-form-item>
        <el-form-item label="进入时间" prop="enterTime">
          <el-date-picker
            v-model="form.enterTime"
            type="datetime"
            placeholder="选择进入时间"
            value-format="YYYY-MM-DDTHH:mm:ss"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input v-model="form.remark" type="textarea" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitForm" :loading="submitting">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { FormInstance, FormRules } from 'element-plus'
import { queryVisitors, registerVisitor, exitVisitor, deleteVisitor, type Visitor, type VisitorRequest } from '@/api/safety'
import { listAllBuildings } from '@/api/dorm'
import { useUserStore } from '@/stores/user'

const authStore = useUserStore()

const loading = ref(false)
const tableData = ref<Visitor[]>([])
const buildingList = ref<any[]>([])
const searchForm = ref({
  buildingId: undefined as number | undefined,
  date: ''
})

const dialogVisible = ref(false)
const submitting = ref(false)
const formRef = ref<FormInstance>()
const form = ref<VisitorRequest>({
  visitorName: '',
  idCard: '',
  phone: '',
  buildingId: undefined as any,
  purpose: '',
  enterTime: '',
  remark: ''
})

const rules: FormRules = {
  visitorName: [{ required: true, message: '请输入访客姓名', trigger: 'blur' }],
  idCard: [{ required: true, message: '请输入身份证号', trigger: 'blur' }],
  buildingId: [{ required: true, message: '请选择楼栋', trigger: 'change' }],
  purpose: [{ required: true, message: '请输入来访目的', trigger: 'blur' }],
  enterTime: [{ required: true, message: '请选择进入时间', trigger: 'change' }]
}

const fetchBuildings = async () => {
  try {
    const res = await listAllBuildings()
    buildingList.value = (res as any) || []
  } catch (error) {
    console.error('获取楼栋列表失败', error)
  }
}

const fetchData = async () => {
  loading.value = true
  try {
    const res = await queryVisitors({
      buildingId: searchForm.value.buildingId,
      date: searchForm.value.date || undefined
    })
    tableData.value = res || []
  } catch (error) {
    console.error('获取访客列表失败', error)
  } finally {
    loading.value = false
  }
}

const openAddDialog = () => {
  dialogVisible.value = true
  // Reset form
  if (formRef.value) {
    formRef.value.resetFields()
  }
  form.value = {
    visitorName: '',
    idCard: '',
    phone: '',
    buildingId: authStore.user?.buildingId || undefined as any,
    purpose: '',
    enterTime: new Date().toISOString().slice(0, 19),
    remark: ''
  }
}

const submitForm = async () => {
  if (!formRef.value) return
  await formRef.value.validate(async (valid) => {
    if (valid) {
      submitting.value = true
      try {
        await registerVisitor(form.value)
        ElMessage.success('登记成功')
        dialogVisible.value = false
        fetchData()
      } catch (error) {
        console.error('登记失败', error)
      } finally {
        submitting.value = false
      }
    }
  })
}

const handleExit = async (id: number) => {
  try {
    await ElMessageBox.confirm('确认登记该访客离开吗？', '提示', { type: 'warning' })
    await exitVisitor(id)
    ElMessage.success('登记离开成功')
    fetchData()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('登记离开失败', error)
    }
  }
}

const handleDelete = async (id: number) => {
  try {
    await ElMessageBox.confirm('确认删除该访客记录吗？', '警告', { type: 'error' })
    await deleteVisitor(id)
    ElMessage.success('删除成功')
    fetchData()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除失败', error)
    }
  }
}

const formatDateTime = (val: string) => {
  if (!val) return ''
  return val.replace('T', ' ')
}

onMounted(() => {
  fetchBuildings()
  fetchData()
})
</script>

<style scoped>
.visitor-container {
  padding: 20px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.search-bar {
  margin-bottom: 20px;
}
</style>
