<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useUserStore } from '@/stores/user'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  listDormScores,
  manualDormScore,
  triggerDormScore,
  LEVEL_TYPES,
  type DormScoreResponse,
  type DormScoreManualRequest,
} from '@/api/dormScore'
import { fetchDormTree, type BuildingTreeNode } from '@/api/dorm'

const store = useUserStore()
const isAdmin = computed(() => store.role === 'admin')

// ---- 列表 ----------------------------------------------------------------
const list = ref<DormScoreResponse[]>([])
const loading = ref(false)
const filter = ref({
  yearMonth: '',
  buildingId: undefined as number | undefined,
})

const dormTree = ref<BuildingTreeNode[]>([])

async function loadList() {
  loading.value = true
  try {
    const res = await listDormScores({
      yearMonth: filter.value.yearMonth || undefined,
      buildingId: filter.value.buildingId,
    })
    list.value = res.list || []
  } catch {
    // 静默
  } finally {
    loading.value = false
  }
}

function resetFilter() {
  filter.value = { yearMonth: '', buildingId: undefined }
  loadList()
}

// ---- 触发月度评分任务 ----------------------------------------------------
const triggerDialogVisible = ref(false)
const triggerForm = ref({ yearMonth: '' })
const triggerSubmitting = ref(false)
const triggerResult = ref<{ yearMonth: string; affected: number } | null>(null)

function openTriggerDialog() {
  // 默认上月
  const now = new Date()
  const last = new Date(now.getFullYear(), now.getMonth() - 1, 1)
  const ym = `${last.getFullYear()}-${String(last.getMonth() + 1).padStart(2, '0')}`
  triggerForm.value = { yearMonth: ym }
  triggerResult.value = null
  triggerDialogVisible.value = true
}

async function submitTrigger() {
  if (!triggerForm.value.yearMonth) {
    ElMessage.warning('请输入评分月份')
    return
  }
  if (!/^\d{4}-\d{2}$/.test(triggerForm.value.yearMonth)) {
    ElMessage.warning('月份格式应为 yyyy-MM，如 2026-03')
    return
  }
  try {
    await ElMessageBox.confirm(
      `确认对 ${triggerForm.value.yearMonth} 重新生成评分？将覆盖该月所有已存在的评分记录。`,
      '触发月度评分',
      { type: 'warning' },
    )
  } catch {
    return
  }
  triggerSubmitting.value = true
  triggerResult.value = null
  try {
    const res = await triggerDormScore({ yearMonth: triggerForm.value.yearMonth })
    triggerResult.value = res
    ElMessage.success(`生成完成，共 ${res.affected} 条评分`)
    // 同步刷新列表
    filter.value.yearMonth = triggerForm.value.yearMonth
    loadList()
  } catch {
    // 静默
  } finally {
    triggerSubmitting.value = false
  }
}

// ---- 手动补录弹窗 --------------------------------------------------------
const manualDialogVisible = ref(false)
const manualSubmitting = ref(false)
const manualForm = ref<DormScoreManualRequest>({
  roomId: 0,
  yearMonth: '',
  hygieneAvg: undefined,
  lateCount: undefined,
  totalScore: undefined,
  level: '',
  remark: '',
})

function openManualDialog(row?: DormScoreResponse) {
  manualForm.value = {
    roomId: row?.roomId || 0,
    yearMonth: row?.yearMonth || filter.value.yearMonth || '',
    hygieneAvg: row?.hygieneAvg,
    lateCount: row?.lateCount,
    totalScore: row?.totalScore,
    level: row?.level || '',
    remark: '',
  }
  manualDialogVisible.value = true
}

/** 自动按公式重算 total_score，给前端预览参考。 */
const computedTotal = computed(() => {
  const avg = Number(manualForm.value.hygieneAvg) || 0
  const late = Number(manualForm.value.lateCount) || 0
  const attendance = Math.max(0, 100 - late * 5)
  return Number((avg * 0.6 + attendance * 0.4).toFixed(2))
})

const computedLevel = computed(() => {
  const v = manualForm.value.totalScore !== undefined
    ? Number(manualForm.value.totalScore)
    : computedTotal.value
  if (v >= 90) return '优秀'
  if (v >= 75) return '合格'
  if (v >= 60) return '待整改'
  return '不合格'
})

async function submitManual() {
  if (!manualForm.value.roomId) {
    ElMessage.warning('请输入房间 ID')
    return
  }
  if (!manualForm.value.yearMonth) {
    ElMessage.warning('请输入评分月份')
    return
  }
  manualSubmitting.value = true
  try {
    await manualDormScore({
      roomId: manualForm.value.roomId,
      yearMonth: manualForm.value.yearMonth,
      hygieneAvg: manualForm.value.hygieneAvg,
      lateCount: manualForm.value.lateCount,
      totalScore: manualForm.value.totalScore,
      level: manualForm.value.level,
      remark: manualForm.value.remark,
    })
    ElMessage.success('补录成功')
    manualDialogVisible.value = false
    loadList()
  } catch {
    // 静默
  } finally {
    manualSubmitting.value = false
  }
}

function rankColor(rank: number): string {
  if (rank === 1) return '#f56c6c'
  if (rank === 2) return '#e6a23c'
  if (rank === 3) return '#409eff'
  return '#909399'
}

onMounted(() => {
  if (isAdmin.value) fetchDormTree().then((t) => (dormTree.value = t)).catch(() => {})
  loadList()
})
</script>

<template>
  <div class="dorm-score-view">
    <div class="page-header">
      <h1 class="page-title">寝室评分排行</h1>
      <p class="page-subtitle">
        月度寝室综合评分排行：total_score = hygiene_avg × 0.6 + (100 − late_count × 5) × 0.4
      </p>
    </div>

    <el-card shadow="never">
      <div class="filter-row">
        <el-input
          v-model="filter.yearMonth"
          placeholder="月份 yyyy-MM"
          style="width: 160px"
        />
        <el-select
          v-model="filter.buildingId"
          placeholder="按楼栋筛选"
          clearable
          style="width: 180px"
        >
          <el-option
            v-for="b in dormTree"
            :key="b.id"
            :label="b.name"
            :value="b.id"
          />
        </el-select>
        <el-button type="primary" @click="loadList()">
          <el-icon><Search /></el-icon> 查询
        </el-button>
        <el-button @click="resetFilter">重置</el-button>
        <div class="flex-grow"></div>
        <el-button v-if="isAdmin" type="warning" @click="openTriggerDialog">
          <el-icon><Refresh /></el-icon> 触发月度评分
        </el-button>
        <el-button v-if="isAdmin" type="primary" @click="openManualDialog()">
          <el-icon><EditPen /></el-icon> 手动补录
        </el-button>
      </div>

      <el-table :data="list" v-loading="loading" border stripe empty-text="暂无评分记录">
        <el-table-column label="排名" width="80" align="center">
          <template #default="{ row }">
            <span class="rank-badge" :style="{ backgroundColor: rankColor(row.rank) }">
              {{ row.rank }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="月份" prop="yearMonth" width="100" />
        <el-table-column label="楼栋" prop="buildingName" width="120" />
        <el-table-column label="房间" prop="roomNo" width="80" />
        <el-table-column label="卫生均分" prop="hygieneAvg" width="110" align="center">
          <template #default="{ row }">
            {{ Number(row.hygieneAvg).toFixed(2) }}
          </template>
        </el-table-column>
        <el-table-column label="晚归次数" prop="lateCount" width="100" align="center" />
        <el-table-column label="综合得分" width="120" align="center">
          <template #default="{ row }">
            <el-tag effect="dark" size="large">{{ Number(row.totalScore).toFixed(2) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="等级" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="LEVEL_TYPES[row.level] || 'info'" effect="plain">
              {{ row.level }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="评语" prop="remark" min-width="160" show-overflow-tooltip />
        <el-table-column v-if="isAdmin" label="操作" width="100" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="openManualDialog(row)">补录</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 触发月度评分任务弹窗 -->
    <el-dialog v-model="triggerDialogVisible" title="触发月度评分任务" width="480px" destroy-on-close>
      <el-alert
        title="将重新生成指定月份的评分（覆盖已有记录）。每月 1 号凌晨 1 点会自动跑，这里仅用于补跑或开发联调。"
        type="info"
        :closable="false"
        show-icon
        style="margin-bottom: 16px"
      />
      <el-form :model="triggerForm" label-width="100px">
        <el-form-item label="评分月份" required>
          <el-input v-model="triggerForm.yearMonth" placeholder="如 2026-03" />
        </el-form-item>
      </el-form>
      <div v-if="triggerResult" class="trigger-result">
        <el-descriptions :column="2" border title="任务结果">
          <el-descriptions-item label="月份">{{ triggerResult.yearMonth }}</el-descriptions-item>
          <el-descriptions-item label="生成评分数">
            <el-tag type="success">{{ triggerResult.affected }}</el-tag>
          </el-descriptions-item>
        </el-descriptions>
      </div>
      <template #footer>
        <el-button @click="triggerDialogVisible = false">关闭</el-button>
        <el-button type="primary" :loading="triggerSubmitting" @click="submitTrigger">执行</el-button>
      </template>
    </el-dialog>

    <!-- 手动补录弹窗 -->
    <el-dialog v-model="manualDialogVisible" title="手动补录 / 修正评分" width="560px" destroy-on-close>
      <el-alert
        title="补录会覆盖该房间该月的评分（写一条 operation_log）。未填字段按公式重算。"
        type="warning"
        :closable="false"
        show-icon
        style="margin-bottom: 16px"
      />
      <el-form :model="manualForm" label-width="100px">
        <el-form-item label="房间 ID" required>
          <el-input-number v-model="manualForm.roomId" :min="1" :controls="false" style="width: 100%" />
        </el-form-item>
        <el-form-item label="评分月份" required>
          <el-input v-model="manualForm.yearMonth" placeholder="如 2026-03" />
        </el-form-item>
        <el-form-item label="卫生均分">
          <el-input-number v-model="manualForm.hygieneAvg" :min="0" :max="100" :precision="2" />
        </el-form-item>
        <el-form-item label="晚归次数">
          <el-input-number v-model="manualForm.lateCount" :min="0" />
        </el-form-item>
        <el-form-item label="综合得分">
          <el-input-number v-model="manualForm.totalScore" :min="0" :max="100" :precision="2" :placeholder="`留空 = 公式 = ${computedTotal.toFixed(2)}`" />
          <div class="hint-tip">留空则按公式 = {{ computedTotal.toFixed(2) }}（{{ computedLevel }}）</div>
        </el-form-item>
        <el-form-item label="等级">
          <el-select v-model="manualForm.level" clearable placeholder="留空按公式自动判定">
            <el-option value="优秀" label="优秀" />
            <el-option value="合格" label="合格" />
            <el-option value="待整改" label="待整改" />
            <el-option value="不合格" label="不合格" />
          </el-select>
        </el-form-item>
        <el-form-item label="评语">
          <el-input v-model="manualForm.remark" type="textarea" :rows="2" placeholder="如：管理员修正" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="manualDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="manualSubmitting" @click="submitManual">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.dorm-score-view {
  max-width: 1400px;
  margin: 0 auto;
}
.page-header {
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: 700;
  color: #303133;
  margin: 0 0 6px 0;
}
.page-subtitle {
  font-size: 14px;
  color: #909399;
  margin: 0;
}
.filter-row {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  margin-bottom: 16px;
}
.flex-grow {
  flex: 1;
}
.rank-badge {
  display: inline-block;
  width: 28px;
  height: 28px;
  line-height: 28px;
  border-radius: 50%;
  color: #fff;
  font-weight: 700;
  font-size: 13px;
}
.trigger-result {
  margin-top: 16px;
}
.hint-tip {
  margin-top: 4px;
  color: #909399;
  font-size: 12px;
}
</style>
