<template>
  <div class="meter-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>水电抄表管理</span>
          <el-button type="primary" @click="openAddDialog" v-if="['admin', 'dorm_manager'].includes(authStore.role)">
            录入读数
          </el-button>
        </div>
      </template>

      <!-- 搜索栏 -->
      <div class="search-bar">
        <el-form :inline="true" :model="searchForm">
          <el-form-item label="房间ID">
            <el-input-number v-model="searchForm.roomId" :min="1" placeholder="房间ID" clearable style="width: 150px" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="fetchData">查询</el-button>
          </el-form-item>
        </el-form>
      </div>

      <!-- 数据表格 -->
      <el-table :data="tableData" v-loading="loading" border style="width: 100%">
        <el-table-column prop="roomId" label="房间ID" width="100" />
        <el-table-column prop="readingMonth" label="抄表月份" width="100" />
        <el-table-column label="表类型" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.meterType === 1 ? 'info' : 'warning'">
              {{ scope.row.meterType === 1 ? '水表' : '电表' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="previousValue" label="上次读数" width="120" />
        <el-table-column prop="readingValue" label="本次读数" width="120" />
        <el-table-column prop="usageAmount" label="使用量" width="100" />
        <el-table-column prop="amount" label="生成费用" width="120" />
        <el-table-column prop="remark" label="备注" />
        <el-table-column label="操作" width="150" fixed="right" v-if="authStore.role === 'admin'">
          <template #default="scope">
            <el-button size="small" type="primary" @click="openEditDialog(scope.row)">
              修改
            </el-button>
            <el-button size="small" type="danger" @click="handleDelete(scope.row.id)">
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 录入/修改弹窗 -->
    <el-dialog v-model="dialogVisible" :title="isEdit ? '修改读数' : '录入读数'" width="500px">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
        <el-form-item label="房间ID" prop="roomId">
          <el-input-number v-model="form.roomId" :min="1" :disabled="isEdit" style="width: 100%" />
        </el-form-item>
        <el-form-item label="表类型" prop="meterType">
          <el-select v-model="form.meterType" :disabled="isEdit" style="width: 100%">
            <el-option label="水表" :value="1" />
            <el-option label="电表" :value="2" />
          </el-select>
        </el-form-item>
        <el-form-item label="本次读数" prop="readingValue">
          <el-input-number v-model="form.readingValue" :precision="2" :step="0.1" style="width: 100%" />
        </el-form-item>
        <el-form-item label="抄表月份" prop="readingMonth">
          <el-date-picker
            v-model="form.readingMonth"
            type="month"
            placeholder="选择月份"
            value-format="YYYY-MM"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input v-model="form.remark" type="textarea" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitForm" :loading="submitting">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { FormInstance, FormRules } from 'element-plus'
import { queryMeterReadings, addMeterReading, updateMeterReading, deleteMeterReading, type MeterReading } from '@/api/fee'
import { useUserStore } from '@/stores/user'

const authStore = useUserStore()

const loading = ref(false)
const tableData = ref<MeterReading[]>([])
const searchForm = ref({
  roomId: undefined as number | undefined
})

const dialogVisible = ref(false)
const isEdit = ref(false)
const submitting = ref(false)
const formRef = ref<FormInstance>()
const form = ref({
  id: 0,
  roomId: undefined as any,
  meterType: 1,
  readingValue: 0,
  readingMonth: '',
  remark: ''
})

const rules: FormRules = {
  roomId: [{ required: true, message: '请输入房间ID', trigger: 'blur' }],
  meterType: [{ required: true, message: '请选择表类型', trigger: 'change' }],
  readingValue: [{ required: true, message: '请输入本次读数', trigger: 'blur' }],
  readingMonth: [{ required: true, message: '请选择抄表月份', trigger: 'change' }]
}

const fetchData = async () => {
  loading.value = true
  try {
    const res = await queryMeterReadings({
      roomId: searchForm.value.roomId
    })
    tableData.value = res?.records || []
  } catch (error) {
    console.error('获取抄表记录失败', error)
  } finally {
    loading.value = false
  }
}

const openAddDialog = () => {
  isEdit.value = false
  dialogVisible.value = true
  if (formRef.value) formRef.value.resetFields()
  form.value = {
    id: 0,
    roomId: undefined as any,
    meterType: 1,
    readingValue: 0,
    readingMonth: new Date().toISOString().slice(0, 7),
    remark: ''
  }
}

const openEditDialog = (row: MeterReading) => {
  isEdit.value = true
  dialogVisible.value = true
  if (formRef.value) formRef.value.resetFields()
  form.value = {
    id: row.id,
    roomId: row.roomId,
    meterType: row.meterType,
    readingValue: row.readingValue,
    readingMonth: row.readingMonth,
    remark: row.remark || ''
  }
}

const submitForm = async () => {
  if (!formRef.value) return
  await formRef.value.validate(async (valid) => {
    if (valid) {
      submitting.value = true
      try {
        if (isEdit.value) {
          await updateMeterReading(form.value.id, form.value)
          ElMessage.success('修改成功')
        } else {
          await addMeterReading(form.value)
          ElMessage.success('录入成功')
        }
        dialogVisible.value = false
        fetchData()
      } catch (error) {
        console.error('保存失败', error)
      } finally {
        submitting.value = false
      }
    }
  })
}

const handleDelete = async (id: number) => {
  try {
    await ElMessageBox.confirm('确认删除该抄表记录吗？', '警告', { type: 'error' })
    await deleteMeterReading(id)
    ElMessage.success('删除成功')
    fetchData()
  } catch (error) {
    if (error !== 'cancel') console.error('删除失败', error)
  }
}

onMounted(() => {
  fetchData()
})
</script>

<style scoped>
.meter-container { padding: 20px; }
.card-header { display: flex; justify-content: space-between; align-items: center; }
.search-bar { margin-bottom: 20px; }
</style>
