<template>
  <div class="fee-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>费用管理</span>
          <div class="actions" v-if="authStore.role === 'admin'">
            <el-button type="warning" @click="openUtilityDialog">按月出水电费</el-button>
            <el-button type="success" @click="openAccommodationDialog">批量出住宿费</el-button>
          </div>
        </div>
      </template>

      <!-- 搜索栏 -->
      <div class="search-bar">
        <el-form :inline="true" :model="searchForm">
          <el-form-item label="账单类型">
            <el-select v-model="searchForm.feeType" placeholder="选择类型" clearable style="width: 120px">
              <el-option label="住宿费" value="accommodation" />
              <el-option label="水电费" value="utility" />
            </el-select>
          </el-form-item>
          <el-form-item label="缴费状态">
            <el-select v-model="searchForm.paidStatus" placeholder="选择状态" clearable style="width: 120px">
              <el-option label="未缴" :value="0" />
              <el-option label="部分缴费" :value="1" />
              <el-option label="已结清" :value="2" />
            </el-select>
          </el-form-item>
          <el-form-item label="账期">
            <el-input v-model="searchForm.yearMonth" placeholder="例: 2026-03" clearable style="width: 120px" />
          </el-form-item>
          <el-form-item label="学生ID" v-if="authStore.role === 'admin'">
            <el-input-number v-model="searchForm.studentId" :min="1" placeholder="学生ID" clearable style="width: 120px" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="fetchData">查询</el-button>
          </el-form-item>
        </el-form>
      </div>

      <!-- 数据表格 -->
      <el-table :data="tableData" v-loading="loading" border style="width: 100%">
        <el-table-column prop="studentId" label="学生ID" width="100" />
        <el-table-column label="费用类型" width="100">
          <template #default="scope">
            {{ scope.row.feeType === 'accommodation' ? '住宿费' : '水电费' }}
          </template>
        </el-table-column>
        <el-table-column prop="yearMonth" label="账期" width="120" />
        <el-table-column prop="amount" label="应缴金额" width="100" />
        <el-table-column prop="paidAmount" label="已缴金额" width="100" />
        <el-table-column label="缴费状态" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.paidStatus)">
              {{ getStatusLabel(scope.row.paidStatus) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="dueDate" label="截止日期" width="120" />
        <el-table-column label="操作" width="180" fixed="right" v-if="authStore.role === 'admin'">
          <template #default="scope">
            <el-button 
              size="small" 
              type="primary" 
              @click="openPayDialog(scope.row)"
              v-if="scope.row.paidStatus !== 2"
            >
              缴费
            </el-button>
            <el-button 
              size="small" 
              type="warning" 
              @click="handleRemind(scope.row.id)"
              v-if="scope.row.paidStatus !== 2"
            >
              催缴
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 水电费出账弹窗 -->
    <el-dialog v-model="utilityDialogVisible" title="水电费出账" width="400px">
      <el-form ref="utilityFormRef" :model="utilityForm" label-width="100px">
        <el-form-item label="抄表月份" prop="readingMonth" :rules="[{required: true, message: '请选择月份'}]">
          <el-date-picker
            v-model="utilityForm.readingMonth"
            type="month"
            placeholder="选择月份"
            value-format="YYYY-MM"
            style="width: 100%"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="utilityDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitUtility" :loading="submitting">确认生成</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 住宿费出账弹窗 -->
    <el-dialog v-model="accommodationDialogVisible" title="住宿费批量出账" width="400px">
      <el-form ref="accFormRef" :model="accForm" label-width="100px">
        <el-form-item label="学期" prop="semester" :rules="[{required: true, message: '请输入学期'}]">
          <el-input v-model="accForm.semester" placeholder="如 2026-2027-1" />
        </el-form-item>
        <el-form-item label="费用金额" prop="amount" :rules="[{required: true, message: '请输入金额'}]">
          <el-input-number v-model="accForm.amount" :min="0" :precision="2" :step="100" style="width: 100%" />
        </el-form-item>
        <el-form-item label="截止日期" prop="dueDate" :rules="[{required: true, message: '请选择截止日期'}]">
          <el-date-picker v-model="accForm.dueDate" type="date" value-format="YYYY-MM-DD" style="width: 100%" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="accommodationDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitAccommodation" :loading="submitting">确认生成</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 缴费弹窗 -->
    <el-dialog v-model="payDialogVisible" title="缴纳费用" width="400px">
      <el-form ref="payFormRef" :model="payForm" label-width="100px">
        <el-form-item label="缴费金额" prop="amount" :rules="[{required: true, message: '请输入金额'}]">
          <el-input-number v-model="payForm.amount" :min="0.01" :precision="2" :step="10" style="width: 100%" />
        </el-form-item>
        <el-form-item label="支付方式" prop="payType" :rules="[{required: true, message: '请选择支付方式'}]">
          <el-select v-model="payForm.payType" style="width: 100%">
            <el-option label="现金" :value="1" />
            <el-option label="微信/支付宝" :value="2" />
            <el-option label="银行转账" :value="3" />
          </el-select>
        </el-form-item>
        <el-form-item label="交易流水号" prop="payNo" :rules="[{required: true, message: '请输入流水号'}]">
          <el-input v-model="payForm.payNo" placeholder="请输入交易流水号" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="payDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitPay" :loading="submitting">确认缴费</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { FormInstance } from 'element-plus'
import { queryFees, queryAdminFees, generateAccommodationFee, generateUtilityFee, payFee, remindFee, type Fee } from '@/api/fee'
import { useUserStore } from '@/stores/user'

const authStore = useUserStore()

const loading = ref(false)
const tableData = ref<Fee[]>([])
const searchForm = ref({
  feeType: '',
  yearMonth: '',
  paidStatus: undefined as number | undefined,
  studentId: undefined as number | undefined
})

const submitting = ref(false)

const utilityDialogVisible = ref(false)
const utilityFormRef = ref<FormInstance>()
const utilityForm = ref({ readingMonth: '' })

const accommodationDialogVisible = ref(false)
const accFormRef = ref<FormInstance>()
const accForm = ref({ semester: '', amount: 1200, dueDate: '' })

const payDialogVisible = ref(false)
const payFormRef = ref<FormInstance>()
const payForm = ref({ feeId: 0, amount: 0, payType: 2, payNo: '' })

const fetchData = async () => {
  loading.value = true
  try {
    const params: any = {
      feeType: searchForm.value.feeType || undefined,
      yearMonth: searchForm.value.yearMonth || undefined,
      paidStatus: searchForm.value.paidStatus
    }
    let res
    if (authStore.role === 'admin') {
      params.studentId = searchForm.value.studentId
      res = await queryAdminFees(params)
    } else {
      res = await queryFees(params)
    }
    tableData.value = res?.records || []
  } catch (error) {
    console.error('获取费用列表失败', error)
  } finally {
    loading.value = false
  }
}

const openUtilityDialog = () => {
  utilityDialogVisible.value = true
  if (utilityFormRef.value) utilityFormRef.value.resetFields()
  utilityForm.value.readingMonth = new Date().toISOString().slice(0, 7)
}

const submitUtility = async () => {
  if (!utilityFormRef.value) return
  await utilityFormRef.value.validate(async (valid) => {
    if (valid) {
      submitting.value = true
      try {
        await generateUtilityFee(utilityForm.value)
        ElMessage.success('出账成功')
        utilityDialogVisible.value = false
        fetchData()
      } catch (error) {
        console.error('出账失败', error)
      } finally {
        submitting.value = false
      }
    }
  })
}

const openAccommodationDialog = () => {
  accommodationDialogVisible.value = true
  if (accFormRef.value) accFormRef.value.resetFields()
  accForm.value = { semester: '2026-2027-1', amount: 1200, dueDate: '' }
}

const submitAccommodation = async () => {
  if (!accFormRef.value) return
  await accFormRef.value.validate(async (valid) => {
    if (valid) {
      submitting.value = true
      try {
        await generateAccommodationFee(accForm.value)
        ElMessage.success('生成成功')
        accommodationDialogVisible.value = false
        fetchData()
      } catch (error) {
        console.error('生成失败', error)
      } finally {
        submitting.value = false
      }
    }
  })
}

const openPayDialog = (row: Fee) => {
  payDialogVisible.value = true
  if (payFormRef.value) payFormRef.value.resetFields()
  payForm.value = {
    feeId: row.id,
    amount: row.amount - row.paidAmount,
    payType: 2,
    payNo: ''
  }
}

const submitPay = async () => {
  if (!payFormRef.value) return
  await payFormRef.value.validate(async (valid) => {
    if (valid) {
      submitting.value = true
      try {
        await payFee(payForm.value.feeId, payForm.value)
        ElMessage.success('缴费成功')
        payDialogVisible.value = false
        fetchData()
      } catch (error) {
        console.error('缴费失败', error)
      } finally {
        submitting.value = false
      }
    }
  })
}

const handleRemind = async (id: number) => {
  try {
    await ElMessageBox.confirm('确认向该学生发送催缴消息吗？', '提示', { type: 'warning' })
    await remindFee(id)
    ElMessage.success('发送成功')
  } catch (error) {
    if (error !== 'cancel') console.error('发送失败', error)
  }
}

const getStatusLabel = (status: number) => {
  return { 0: '未缴', 1: '部分缴费', 2: '已结清' }[status] || '未知'
}

const getStatusType = (status: number) => {
  return { 0: 'danger', 1: 'warning', 2: 'success' }[status] || 'info'
}

onMounted(() => {
  fetchData()
})
</script>

<style scoped>
.fee-container { padding: 20px; }
.card-header { display: flex; justify-content: space-between; align-items: center; }
.search-bar { margin-bottom: 20px; }
.actions { display: flex; gap: 10px; }
</style>
