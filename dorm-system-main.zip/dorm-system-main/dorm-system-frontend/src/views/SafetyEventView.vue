<template>
  <div class="event-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>安全事件管理</span>
          <el-button type="primary" @click="openAddDialog" v-if="['admin', 'dorm_manager'].includes(authStore.role)">
            上报事件
          </el-button>
        </div>
      </template>

      <!-- 搜索栏 -->
      <div class="search-bar">
        <el-form :inline="true" :model="searchForm">
          <el-form-item label="楼栋">
            <el-select v-model="searchForm.buildingId" placeholder="选择楼栋" clearable>
              <el-option
                v-for="b in buildingList"
                :key="b.id"
                :label="b.name"
                :value="b.id"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="处理状态">
            <el-select v-model="searchForm.handled" placeholder="选择状态" clearable style="width: 120px">
              <el-option label="待处理" :value="0" />
              <el-option label="已处理" :value="1" />
            </el-select>
          </el-form-item>
          <el-form-item label="严重程度">
            <el-select v-model="searchForm.severity" placeholder="选择程度" clearable style="width: 120px">
              <el-option label="一般" :value="0" />
              <el-option label="较重" :value="1" />
              <el-option label="严重" :value="2" />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="fetchData">查询</el-button>
          </el-form-item>
        </el-form>
      </div>

      <!-- 数据表格 -->
      <el-table :data="tableData" v-loading="loading" border style="width: 100%">
        <el-table-column prop="buildingId" label="楼栋ID" width="80" />
        <el-table-column prop="roomId" label="房间ID" width="80" />
        <el-table-column prop="eventType" label="事件类型" width="100" />
        <el-table-column label="严重程度" width="100">
          <template #default="scope">
            <el-tag :type="getSeverityType(scope.row.severity)">
              {{ getSeverityLabel(scope.row.severity) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="description" label="事件描述" />
        <el-table-column label="发生时间" width="160">
          <template #default="scope">
            {{ formatDateTime(scope.row.happenedAt) }}
          </template>
        </el-table-column>
        <el-table-column label="处理状态" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.handled === 1 ? 'success' : 'danger'">
              {{ scope.row.handled === 1 ? '已处理' : '待处理' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="handleNote" label="处置说明" />
        <el-table-column label="操作" width="150" fixed="right" v-if="authStore.role === 'admin'">
          <template #default="scope">
            <el-button
              v-if="scope.row.handled === 0"
              size="small"
              type="success"
              @click="openHandleDialog(scope.row)"
            >
              处理
            </el-button>
            <el-button
              size="small"
              type="danger"
              @click="handleDelete(scope.row.id)"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 上报弹窗 -->
    <el-dialog v-model="dialogVisible" title="上报安全事件" width="500px">
      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="所属楼栋" prop="buildingId">
          <el-select v-model="form.buildingId" placeholder="选择楼栋" style="width: 100%">
            <el-option
              v-for="b in buildingList"
              :key="b.id"
              :label="b.name"
              :value="b.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="涉及房间" prop="roomId">
          <el-input-number v-model="form.roomId" :min="1" placeholder="选填，公共区域留空" style="width: 100%" />
        </el-form-item>
        <el-form-item label="事件类型" prop="eventType">
          <el-select v-model="form.eventType" placeholder="选择事件类型" style="width: 100%">
            <el-option label="火情" value="火情" />
            <el-option label="设施失控" value="设施失控" />
            <el-option label="人员异常" value="人员异常" />
            <el-option label="其它" value="其它" />
          </el-select>
        </el-form-item>
        <el-form-item label="严重程度" prop="severity">
          <el-select v-model="form.severity" placeholder="选择严重程度" style="width: 100%">
            <el-option label="一般" :value="0" />
            <el-option label="较重" :value="1" />
            <el-option label="严重" :value="2" />
          </el-select>
        </el-form-item>
        <el-form-item label="发生时间" prop="happenedAt">
          <el-date-picker
            v-model="form.happenedAt"
            type="datetime"
            placeholder="选择发生时间"
            value-format="YYYY-MM-DDTHH:mm:ss"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="事件描述" prop="description">
          <el-input v-model="form.description" type="textarea" placeholder="详细描述事件经过及影响" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitForm" :loading="submitting">确认</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 处理弹窗 -->
    <el-dialog v-model="handleDialogVisible" title="事件处理" width="400px">
      <el-form
        ref="handleFormRef"
        :model="handleForm"
        label-width="80px"
      >
        <el-form-item label="处置说明" prop="handleNote" :rules="[{ required: true, message: '请输入处置说明', trigger: 'blur' }]">
          <el-input v-model="handleForm.handleNote" type="textarea" rows="3" placeholder="描述处理结果" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitHandle" :loading="handleSubmitting">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { FormInstance, FormRules } from 'element-plus'
import { queryEvents, reportEvent, handleEvent, deleteEvent, type SafetyEvent, type SafetyEventRequest } from '@/api/safety'
import { listAllBuildings } from '@/api/dorm'
import { useUserStore } from '@/stores/user'

const authStore = useUserStore()

const loading = ref(false)
const tableData = ref<SafetyEvent[]>([])
const buildingList = ref<any[]>([])
const searchForm = ref({
  buildingId: undefined as number | undefined,
  handled: undefined as number | undefined,
  severity: undefined as number | undefined
})

const dialogVisible = ref(false)
const submitting = ref(false)
const formRef = ref<FormInstance>()
const form = ref<SafetyEventRequest>({
  buildingId: undefined as any,
  roomId: undefined,
  eventType: '',
  severity: 0,
  description: '',
  happenedAt: ''
})

const handleDialogVisible = ref(false)
const handleSubmitting = ref(false)
const handleFormRef = ref<FormInstance>()
const handleForm = ref({
  id: 0,
  handleNote: ''
})

const rules: FormRules = {
  buildingId: [{ required: true, message: '请选择楼栋', trigger: 'change' }],
  eventType: [{ required: true, message: '请选择事件类型', trigger: 'change' }],
  severity: [{ required: true, message: '请选择严重程度', trigger: 'change' }],
  happenedAt: [{ required: true, message: '请选择发生时间', trigger: 'change' }],
  description: [{ required: true, message: '请输入事件描述', trigger: 'blur' }]
}

const fetchBuildings = async () => {
  try {
    const res = await listAllBuildings()
    buildingList.value = (res as any) || []
  } catch (error) {
    console.error('获取楼栋列表失败', error)
  }
}

const fetchData = async () => {
  loading.value = true
  try {
    const res = await queryEvents({
      buildingId: searchForm.value.buildingId,
      handled: searchForm.value.handled,
      severity: searchForm.value.severity
    })
    tableData.value = res || []
  } catch (error) {
    console.error('获取安全事件列表失败', error)
  } finally {
    loading.value = false
  }
}

const openAddDialog = () => {
  dialogVisible.value = true
  if (formRef.value) {
    formRef.value.resetFields()
  }
  form.value = {
    buildingId: authStore.user?.buildingId || undefined as any,
    roomId: undefined,
    eventType: '',
    severity: 0,
    description: '',
    happenedAt: new Date().toISOString().slice(0, 19)
  }
}

const submitForm = async () => {
  if (!formRef.value) return
  await formRef.value.validate(async (valid) => {
    if (valid) {
      submitting.value = true
      try {
        await reportEvent(form.value)
        ElMessage.success('上报成功')
        dialogVisible.value = false
        fetchData()
      } catch (error) {
        console.error('上报失败', error)
      } finally {
        submitting.value = false
      }
    }
  })
}

const openHandleDialog = (row: SafetyEvent) => {
  handleDialogVisible.value = true
  if (handleFormRef.value) {
    handleFormRef.value.resetFields()
  }
  handleForm.value = {
    id: row.id,
    handleNote: ''
  }
}

const submitHandle = async () => {
  if (!handleFormRef.value) return
  await handleFormRef.value.validate(async (valid) => {
    if (valid) {
      handleSubmitting.value = true
      try {
        await handleEvent(handleForm.value.id, handleForm.value.handleNote)
        ElMessage.success('处理成功')
        handleDialogVisible.value = false
        fetchData()
      } catch (error) {
        console.error('处理失败', error)
      } finally {
        handleSubmitting.value = false
      }
    }
  })
}

const handleDelete = async (id: number) => {
  try {
    await ElMessageBox.confirm('确认删除该事件记录吗？', '警告', { type: 'error' })
    await deleteEvent(id)
    ElMessage.success('删除成功')
    fetchData()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除失败', error)
    }
  }
}

const formatDateTime = (val: string) => {
  if (!val) return ''
  return val.replace('T', ' ')
}

const getSeverityLabel = (severity: number) => {
  const map: Record<number, string> = {
    0: '一般',
    1: '较重',
    2: '严重'
  }
  return map[severity] || '未知'
}

const getSeverityType = (severity: number) => {
  const map: Record<number, string> = {
    0: 'info',
    1: 'warning',
    2: 'danger'
  }
  return map[severity] || 'info'
}

onMounted(() => {
  fetchBuildings()
  fetchData()
})
</script>

<style scoped>
.event-container {
  padding: 20px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.search-bar {
  margin-bottom: 20px;
}
</style>
