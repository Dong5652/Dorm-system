<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useUserStore } from '@/stores/user'
import { ElMessage, ElMessageBox } from 'element-plus'
import axios from 'axios'
import {
  pageStudents,
  getStudentDetail,
  createStudent,
  updateStudent,
  deleteStudent,
  importStudents,
  STUDENT_STATUS_LABELS,
  STUDENT_STATUS_TYPES,
  type Student,
  type StudentDetailResponse
} from '@/api/student'
import { GENDER_LABELS } from '@/api/dorm'

const store = useUserStore()

// 权限：仅管理员（ADMIN）允许修改、新增、删除、导入学生档案
const isAdmin = computed(() => store.role === 'admin')

// --- 学生列表数据 ---
const students = ref<Student[]>([])
const totalStudents = ref(0)
const pageNum = ref(1)
const pageSize = ref(10)
const searchKeyword = ref('')
const searchClassName = ref('')
const searchCollege = ref('')
const searchStatus = ref<number | undefined>(undefined)
const loadingList = ref(false)

// --- 新增/编辑弹窗 ---
const formDialogVisible = ref(false)
const isEdit = ref(false)
const studentFormRef = ref()
const studentForm = ref({
  id: 0,
  studentNo: '',
  name: '',
  gender: 1,
  college: '',
  major: '',
  className: '',
  grade: '',
  phone: '',
  emergencyContact: '',
  emergencyPhone: '',
  enrollDate: '',
  status: 0
})

const studentRules = {
  studentNo: [{ required: true, message: '请输入学号/工号', trigger: 'blur' }],
  name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
  gender: [{ required: true, message: '请选择性别', trigger: 'change' }],
  status: [{ required: true, message: '请选择在籍状态', trigger: 'change' }]
}

// --- 详情弹窗 ---
const detailDialogVisible = ref(false)
const detailData = ref<StudentDetailResponse | null>(null)
const loadingDetail = ref(false)

// --- 批量导入弹窗 ---
const importDialogVisible = ref(false)
const importFile = ref<File | null>(null)
const importing = ref(false)
const importResult = ref<{ successCount: number; errorList: string[] } | null>(null)

// --- 方法：加载列表 ---
async function loadStudents() {
  loadingList.value = true
  try {
    const res = await pageStudents({
      pageNum: pageNum.value,
      pageSize: pageSize.value,
      keyword: searchKeyword.value,
      className: searchClassName.value,
      college: searchCollege.value,
      status: searchStatus.value
    })
    students.value = res.records
    totalStudents.value = res.total
  } catch {
    // 拦截器弹错
  } finally {
    loadingList.value = false
  }
}

function handleReset() {
  searchKeyword.value = ''
  searchClassName.value = ''
  searchCollege.value = ''
  searchStatus.value = undefined
  pageNum.value = 1
  loadStudents()
}

// --- CRUD 操作 ---
function handleAdd() {
  isEdit.value = false
  studentForm.value = {
    id: 0,
    studentNo: '',
    name: '',
    gender: 1,
    college: '',
    major: '',
    className: '',
    grade: new Date().getFullYear().toString(),
    phone: '',
    emergencyContact: '',
    emergencyPhone: '',
    enrollDate: new Date().toISOString().split('T')[0],
    status: 0
  }
  formDialogVisible.value = true
}

async function handleEdit(row: Student) {
  isEdit.value = true
  loadingDetail.value = true
  try {
    const detail = await getStudentDetail(row.id)
    studentForm.value = {
      id: detail.student.id,
      studentNo: detail.student.studentNo,
      name: detail.student.name,
      gender: detail.student.gender,
      college: detail.student.college || '',
      major: detail.student.major || '',
      className: detail.student.className || '',
      grade: detail.student.grade || '',
      phone: detail.phone || '',
      emergencyContact: detail.student.emergencyContact || '',
      emergencyPhone: detail.student.emergencyPhone || '',
      enrollDate: detail.student.enrollDate || '',
      status: detail.student.status
    }
    formDialogVisible.value = true
  } catch {
    // 忽略
  } finally {
    loadingDetail.value = false
  }
}

async function saveStudent() {
  if (!studentFormRef.value) return
  await studentFormRef.value.validate(async (valid: boolean) => {
    if (!valid) return
    try {
      if (isEdit.value) {
        await updateStudent(studentForm.value.id, studentForm.value)
        ElMessage.success('修改学生档案成功')
      } else {
        await createStudent(studentForm.value)
        ElMessage.success('新增学生档案并创建系统账号成功')
      }
      formDialogVisible.value = false
      loadStudents()
    } catch {
      // 忽略
    }
  })
}

async function handleDelete(row: Student) {
  try {
    await ElMessageBox.confirm(`确认删除学号为 [${row.studentNo}] 的学生 [${row.name}] 吗？将联动软删除其系统登录账号。`, '警告', {
      type: 'warning',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await deleteStudent(row.id)
    ElMessage.success('软删除学生档案及关联系统账号成功')
    loadStudents()
  } catch (e) {
    if (e !== 'cancel') {
      ElMessage.error('删除失败，可能该学生已分配床位，请先退宿')
    }
  }
}

// --- 学生详情 ---
async function openDetail(row: Student) {
  loadingDetail.value = true
  detailDialogVisible.value = true
  detailData.value = null
  try {
    detailData.value = await getStudentDetail(row.id)
  } catch {
    detailDialogVisible.value = false
  } finally {
    loadingDetail.value = false
  }
}

// --- Excel 导入逻辑 ---
function openImport() {
  importFile.value = null
  importResult.value = null
  importDialogVisible.value = true
}

function handleFileChange(event: Event) {
  const target = event.target as HTMLInputElement
  if (target.files && target.files.length > 0) {
    importFile.value = target.files[0]
  }
}

async function triggerImport() {
  if (!importFile.value) {
    ElMessage.warning('请先选择要上传的 Excel 文件')
    return
  }
  importing.value = true
  importResult.value = null
  try {
    const res = await importStudents(importFile.value)
    importResult.value = res
    ElMessage.success(`导入完成，成功 ${res.successCount} 条记录`)
    loadStudents()
  } catch (e) {
    // 报错处理
  } finally {
    importing.value = false
  }
}

// --- Excel 导出逻辑 ---
async function handleExport() {
  try {
    ElMessage.info('正在生成 Excel 报表，请稍候...')
    const res = await axios.get('/api/v1/admin/students/export', {
      params: {
        keyword: searchKeyword.value,
        className: searchClassName.value,
        college: searchCollege.value,
        status: searchStatus.value
      },
      headers: {
        Authorization: `Bearer ${store.token}`
      },
      responseType: 'blob'
    })

    const blob = new Blob([res.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `学生档案列表_${new Date().toISOString().split('T')[0]}.xlsx`
    link.click()
    window.URL.revokeObjectURL(url)
    ElMessage.success('导出 Excel 成功')
  } catch (err) {
    ElMessage.error('导出 Excel 发生错误，请重试')
  }
}

onMounted(loadStudents)
</script>

<template>
  <div class="student-manager">
    <div class="page-header">
      <h1 class="page-title">学生学籍档案管理</h1>
      <p class="page-subtitle">维护校区学生的基本学籍档案，自动同步新建/销毁系统登录账号，支持批量导入导出 Excel。</p>
    </div>

    <!-- 过滤器 Card -->
    <el-card class="filter-card" shadow="never">
      <div class="filter-container">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索学号 / 姓名"
          clearable
          style="width: 200px"
          @keyup.enter="loadStudents"
        >
          <template #prefix>
            <el-icon><Search /></el-icon>
          </template>
        </el-input>
        <el-input
          v-model="searchCollege"
          placeholder="输入学院名称"
          clearable
          style="width: 160px"
          @keyup.enter="loadStudents"
        />
        <el-input
          v-model="searchClassName"
          placeholder="输入班级名称"
          clearable
          style="width: 160px"
          @keyup.enter="loadStudents"
        />
        <el-select
          v-model="searchStatus"
          placeholder="在籍状态"
          clearable
          style="width: 120px"
          @change="loadStudents"
        >
          <el-option :value="0" label="在籍" />
          <el-option :value="1" label="休学" />
          <el-option :value="2" label="毕业" />
          <el-option :value="3" label="退学" />
        </el-select>
        <el-button type="primary" @click="loadStudents">查询</el-button>
        <el-button @click="handleReset">重置</el-button>
      </div>

      <div class="action-bar">
        <div class="left-actions">
          <el-button v-if="isAdmin" type="success" @click="handleAdd">
            <el-icon style="margin-right: 4px"><Plus /></el-icon> 新增学生
          </el-button>
          <el-button v-if="isAdmin" type="warning" @click="openImport">
            <el-icon style="margin-right: 4px"><Upload /></el-icon> 批量导入
          </el-button>
          <el-button type="info" @click="handleExport">
            <el-icon style="margin-right: 4px"><Download /></el-icon> 导出 Excel
          </el-button>
        </div>
      </div>
    </el-card>

    <!-- 学生表格 Card -->
    <el-card class="table-card" shadow="never" v-loading="loadingList">
      <el-table :data="students" style="width: 100%" border stripe>
        <el-table-column prop="studentNo" label="学号" width="130" align="center">
          <template #default="{ row }">
            <span class="code-badge">{{ row.studentNo }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="name" label="姓名" min-width="120" />
        <el-table-column prop="gender" label="性别" width="80" align="center">
          <template #default="{ row }">
            <el-tag :type="row.gender === 1 ? 'primary' : 'danger'" effect="plain" size="small">
              {{ GENDER_LABELS[row.gender] }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="college" label="学院" min-width="150" show-overflow-tooltip />
        <el-table-column prop="major" label="专业" min-width="150" show-overflow-tooltip />
        <el-table-column prop="className" label="班级" min-width="130" show-overflow-tooltip />
        <el-table-column prop="grade" label="年级" width="100" align="center" />
        <el-table-column prop="status" label="在籍状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="STUDENT_STATUS_TYPES[row.status]" effect="dark" size="small">
              {{ STUDENT_STATUS_LABELS[row.status] }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right" align="center">
          <template #default="{ row }">
            <el-button type="primary" size="small" link @click="openDetail(row)">
              <el-icon style="margin-right: 2px"><Document /></el-icon> 详情
            </el-button>
            <el-button v-if="isAdmin" type="warning" size="small" link @click="handleEdit(row)">
              编辑
            </el-button>
            <el-button v-if="isAdmin" type="danger" size="small" link @click="handleDelete(row)">
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="pageNum"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="totalStudents"
          @size-change="loadStudents"
          @current-change="loadStudents"
        />
      </div>
    </el-card>

    <!-- 学生新增/编辑表单 Dialog -->
    <el-dialog
      v-model="formDialogVisible"
      :title="isEdit ? '编辑学生档案' : '新增学生档案'"
      width="600px"
      destroy-on-close
    >
      <el-form :model="studentForm" :rules="studentRules" ref="studentFormRef" label-width="110px" style="padding-right: 20px">
        <div class="form-grid">
          <el-form-item label="学号/工号" prop="studentNo">
            <el-input v-model="studentForm.studentNo" placeholder="例如：20240101" :disabled="isEdit" />
          </el-form-item>
          <el-form-item label="姓名" prop="name">
            <el-input v-model="studentForm.name" placeholder="姓名" />
          </el-form-item>
          <el-form-item label="性别" prop="gender">
            <el-radio-group v-model="studentForm.gender">
              <el-radio :value="1">男</el-radio>
              <el-radio :value="2">女</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="在籍状态" prop="status">
            <el-select v-model="studentForm.status" placeholder="选择状态" style="width: 100%">
              <el-option :value="0" label="在籍" />
              <el-option :value="1" label="休学" />
              <el-option :value="2" label="毕业" />
              <el-option :value="3" label="退学" />
            </el-select>
          </el-form-item>
          <el-form-item label="学院" prop="college">
            <el-input v-model="studentForm.college" placeholder="学院名称" />
          </el-form-item>
          <el-form-item label="专业" prop="major">
            <el-input v-model="studentForm.major" placeholder="专业名称" />
          </el-form-item>
          <el-form-item label="班级" prop="className">
            <el-input v-model="studentForm.className" placeholder="班级名称，例如：软件2401" />
          </el-form-item>
          <el-form-item label="年级" prop="grade">
            <el-input v-model="studentForm.grade" placeholder="例如：2024" />
          </el-form-item>
          <el-form-item label="个人电话" prop="phone">
            <el-input v-model="studentForm.phone" placeholder="电话（关联登录账号电话）" />
          </el-form-item>
          <el-form-item label="入学日期" prop="enrollDate">
            <el-date-picker v-model="studentForm.enrollDate" type="date" value-format="YYYY-MM-DD" placeholder="入学日期" style="width: 100%" />
          </el-form-item>
          <el-form-item label="紧急联系人" prop="emergencyContact">
            <el-input v-model="studentForm.emergencyContact" placeholder="家长或监护人姓名" />
          </el-form-item>
          <el-form-item label="紧急联系电话" prop="emergencyPhone">
            <el-input v-model="studentForm.emergencyPhone" placeholder="紧急电话" />
          </el-form-item>
        </div>
      </el-form>
      <template #footer>
        <el-button @click="formDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveStudent">保存</el-button>
      </template>
    </el-dialog>

    <!-- 批量导入 Dialog -->
    <el-dialog
      v-model="importDialogVisible"
      title="批量导入学生数据"
      width="500px"
      destroy-on-close
    >
      <div class="import-layout">
        <p class="import-tip">
          请选择要上传的 Excel 文件。支持扩展名为 <code>.xlsx</code> 的工作簿。<br/>
          系统将自动读取 Excel 第一张工作表并为每个新学号创建 <code>sys_user</code> 账户，默认密码为 <code>123456</code>。
        </p>
        
        <div class="file-upload-box">
          <input type="file" id="excelFile" accept=".xlsx" @change="handleFileChange" style="display: none;" />
          <label for="excelFile" class="upload-label">
            <el-icon size="40" color="#909399"><DocumentAdd /></el-icon>
            <span class="upload-text">{{ importFile ? importFile.name : '点击此处选择 Excel 文件' }}</span>
          </label>
        </div>

        <div v-if="importResult" class="import-result-box">
          <el-alert :title="`成功导入 ${importResult.successCount} 条记录`" type="success" :closable="false" show-icon />
          <div v-if="importResult.errorList.length > 0" class="error-list-container">
            <p class="error-list-title">异常/忽略条目清单：</p>
            <ul class="error-list">
              <li v-for="(err, i) in importResult.errorList" :key="i" class="error-item">⚠️ {{ err }}</li>
            </ul>
          </div>
        </div>
      </div>
      <template #footer>
        <el-button @click="importDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="importing" @click="triggerImport">开始导入</el-button>
      </template>
    </el-dialog>

    <!-- 档案详情 Dialog -->
    <el-dialog
      v-model="detailDialogVisible"
      title="学生电子档案详情"
      width="700px"
      destroy-on-close
    >
      <div class="detail-container" v-loading="loadingDetail">
        <template v-if="detailData">
          <!-- 基本信息区 -->
          <h3 class="section-title">📂 学籍基本档案</h3>
          <div class="info-grid">
            <div class="info-item"><span class="label">学号</span><span class="value">{{ detailData.student.studentNo }}</span></div>
            <div class="info-item"><span class="label">姓名</span><span class="value">{{ detailData.student.name }}</span></div>
            <div class="info-item"><span class="label">性别</span><span class="value">{{ GENDER_LABELS[detailData.student.gender] }}</span></div>
            <div class="info-item">
              <span class="label">在籍状态</span>
              <el-tag :type="STUDENT_STATUS_TYPES[detailData.student.status]" size="small" effect="dark">
                {{ STUDENT_STATUS_LABELS[detailData.student.status] }}
              </el-tag>
            </div>
            <div class="info-item"><span class="label">学院</span><span class="value">{{ detailData.student.college || '-' }}</span></div>
            <div class="info-item"><span class="label">专业</span><span class="value">{{ detailData.student.major || '-' }}</span></div>
            <div class="info-item"><span class="label">班级</span><span class="value">{{ detailData.student.className || '-' }}</span></div>
            <div class="info-item"><span class="label">年级</span><span class="value">{{ detailData.student.grade || '-' }}</span></div>
            <div class="info-item"><span class="label">入学日期</span><span class="value">{{ detailData.student.enrollDate || '-' }}</span></div>
            <div class="info-item"><span class="label">个人电话</span><span class="value">{{ detailData.phone || '-' }}</span></div>
            <div class="info-item"><span class="label">紧急联系人</span><span class="value">{{ detailData.student.emergencyContact || '-' }}</span></div>
            <div class="info-item"><span class="label">紧急电话</span><span class="value">{{ detailData.student.emergencyPhone || '-' }}</span></div>
          </div>

          <!-- 当前入住寝室 -->
          <h3 class="section-title" style="margin-top: 24px;">🏢 入住宿舍床位</h3>
          <div v-if="detailData.bedDetail" class="residence-box">
            <el-icon size="20" color="#409eff" style="margin-right: 6px;"><OfficeBuilding /></el-icon>
            <span class="residence-text">
              分配宿舍：
              <span class="highlight">{{ detailData.bedDetail.buildingName }}</span> — 
              <span class="highlight">{{ detailData.bedDetail.floorNo }} 层</span> — 
              <span class="highlight">{{ detailData.bedDetail.roomNo }} 房间</span> — 
              <span class="highlight">{{ detailData.bedDetail.bedNo }} 号床</span>
            </span>
          </div>
          <div v-else class="residence-empty">
            <el-tag type="info" size="large">未分配宿舍（无当前入住床位）</el-tag>
          </div>

          <!-- 历史异动 -->
          <h3 class="section-title" style="margin-top: 24px;">⏳ 历史异动流水</h3>
          <div class="timeline-box">
            <el-timeline>
              <el-timeline-item
                v-for="log in detailData.changeRecords"
                :key="log.id"
                :timestamp="log.happenedAt ? log.happenedAt.replace('T', ' ') : ''"
                placement="top"
                type="primary"
              >
                <el-card shadow="never" class="log-card">
                  <div class="log-header">
                    <span class="log-type-tag">{{ log.typeLabel }}</span>
                    <span class="operator">经办人：{{ log.operatorName }}</span>
                  </div>
                  <p class="log-desc" v-if="log.type === 'change_room'">
                    床位变动：从 <code>{{ log.fromRoomNo || '-' }}房 ({{ log.fromBedNo || '-' }}床)</code> 调整为 <code>{{ log.toRoomNo || '-' }}房 ({{ log.toBedNo || '-' }}床)</code>
                  </p>
                  <p class="log-desc" v-else>
                    档案异动状态说明
                  </p>
                  <div class="log-reason" v-if="log.reason"><strong>异动原因：</strong>{{ log.reason }}</div>
                  <div class="log-remark" v-if="log.remark"><strong>备注：</strong>{{ log.remark }}</div>
                </el-card>
              </el-timeline-item>
            </el-timeline>
            <el-empty v-if="detailData.changeRecords.length === 0" description="暂无任何历史异动记录" :image-size="60" style="padding: 10px 0" />
          </div>
        </template>
      </div>
    </el-dialog>
  </div>
</template>

<style scoped>
.student-manager {
  max-width: 1200px;
  margin: 0 auto;
}
.page-header {
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: 700;
  color: #303133;
  margin: 0 0 6px 0;
}
.page-subtitle {
  font-size: 14px;
  color: #909399;
  margin: 0;
}
.filter-card {
  margin-bottom: 16px;
}
.filter-container {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 14px;
}
.action-bar {
  display: flex;
  justify-content: space-between;
  border-top: 1px dashed #ebeef5;
  padding-top: 14px;
}
.code-badge {
  background: #f4f4f5;
  color: #909399;
  font-family: monospace;
  padding: 2px 6px;
  border-radius: 4px;
  font-weight: bold;
}
.table-card {
  padding: 4px;
}
.pagination-container {
  margin-top: 18px;
  display: flex;
  justify-content: flex-end;
}

/* Form Styles */
.form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px 20px;
}

/* Import dialog styles */
.import-layout {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.import-tip {
  font-size: 13px;
  color: #606266;
  line-height: 1.6;
  background-color: #fdf6ec;
  padding: 10px 14px;
  border-left: 4px solid #e6a23c;
  border-radius: 4px;
  margin: 0;
}
.file-upload-box {
  border: 2px dashed #dcdfe6;
  border-radius: 8px;
  padding: 24px;
  text-align: center;
  cursor: pointer;
  background-color: #fafbfc;
  transition: all 0.25s;
}
.file-upload-box:hover {
  border-color: #409eff;
  background-color: #f2f6fc;
}
.upload-label {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}
.upload-text {
  font-size: 14px;
  color: #606266;
  font-weight: 500;
}
.import-result-box {
  border-top: 1px dashed #dcdfe6;
  padding-top: 14px;
}
.error-list-container {
  margin-top: 10px;
}
.error-list-title {
  font-size: 13px;
  font-weight: 600;
  color: #f56c6c;
  margin: 0 0 6px 0;
}
.error-list {
  max-height: 150px;
  overflow-y: auto;
  padding-left: 14px;
  margin: 0;
  font-size: 12px;
  color: #606266;
  background: #fef0f0;
  border: 1px solid #fde2e2;
  border-radius: 4px;
  padding: 10px;
}
.error-item {
  margin-bottom: 6px;
  list-style: none;
}

/* Detail info CSS */
.section-title {
  font-size: 15px;
  font-weight: 700;
  color: #303133;
  margin: 0 0 12px 0;
  border-left: 4px solid #409eff;
  padding-left: 8px;
}
.info-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
  background-color: #f8fafc;
  padding: 16px;
  border-radius: 8px;
  border: 1px solid #ebeef5;
}
.info-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.info-item .label {
  font-size: 12px;
  color: #909399;
}
.info-item .value {
  font-size: 14px;
  color: #303133;
  font-weight: 500;
}
.residence-box {
  display: flex;
  align-items: center;
  background: #ecf5ff;
  border: 1px solid #d9ecff;
  padding: 12px 16px;
  border-radius: 8px;
}
.residence-text {
  font-size: 14px;
  color: #409eff;
  font-weight: 500;
}
.highlight {
  font-weight: bold;
}
.residence-empty {
  text-align: center;
  padding: 12px 0;
}
.timeline-box {
  max-height: 250px;
  overflow-y: auto;
  padding: 10px;
  background: #fafbfc;
  border-radius: 8px;
  border: 1px solid #f0f2f5;
}
.log-card {
  padding: 0;
  border: none;
  background: transparent;
}
.log-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}
.log-type-tag {
  background: #e1f3d8;
  color: #67c23a;
  padding: 2px 8px;
  font-size: 11px;
  border-radius: 4px;
  font-weight: bold;
}
.operator {
  font-size: 12px;
  color: #909399;
}
.log-desc {
  margin: 0 0 6px 0;
  font-size: 13px;
  color: #303133;
  line-height: 1.4;
}
.log-desc code {
  background-color: #f4f4f5;
  color: #909399;
  padding: 2px 4px;
  border-radius: 4px;
  font-family: monospace;
}
.log-reason, .log-remark {
  font-size: 12px;
  color: #606266;
  margin-top: 4px;
}
</style>
