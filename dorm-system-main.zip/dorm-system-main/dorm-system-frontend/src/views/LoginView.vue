<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, type FormInstance, type FormRules } from 'element-plus'
import { login, type LoginPayload } from '@/api/auth'
import { useUserStore } from '@/stores/user'

const route = useRoute()
const router = useRouter()
const store = useUserStore()

const formRef = ref<FormInstance>()
const loading = ref(false)
const form = reactive<LoginPayload>({ username: 'admin', password: '' })

const rules: FormRules<LoginPayload> = {
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 32, message: '密码长度需在 6–32 之间', trigger: 'blur' },
  ],
}

async function handleLogin() {
  const v = await formRef.value?.validate().catch(() => null)
  if (!v) return
  loading.value = true
  try {
    const res = await login({ ...form })
    store.setToken(res.token)
    ElMessage.success(`欢迎，${res.realName}`)
    const redirect = typeof route.query.redirect === 'string' ? route.query.redirect : '/'
    router.replace(redirect)
  } catch (e) {
    // 响应拦截器已弹 toast，这里仅吞错
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="login-page">
    <el-card class="login-card" shadow="always">
      <h1 class="title">学校宿舍管理系统</h1>
      <p class="subtitle">请使用账号登录</p>

      <el-form ref="formRef" :model="form" :rules="rules" label-width="0" @submit.prevent="handleLogin">
        <el-form-item prop="username">
          <el-input v-model="form.username" placeholder="账号" prefix-icon="User" size="large" clearable />
        </el-form-item>
        <el-form-item prop="password">
          <el-input
            v-model="form.password"
            type="password"
            placeholder="密码"
            prefix-icon="Lock"
            size="large"
            show-password
            @keyup.enter="handleLogin"
          />
        </el-form-item>
        <el-button type="primary" size="large" style="width: 100%" :loading="loading" @click="handleLogin">
          登录
        </el-button>
      </el-form>

      <p class="hint">
        默认账号：<code>admin / 123456</code> · <code>dm001 / 123456</code> · <code>repair001 / dorm123</code>
      </p>
    </el-card>
  </div>
</template>

<style scoped>
.login-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #409eff 0%, #6e8ef9 100%);
}
.login-card {
  width: 380px;
  padding: 24px;
  border-radius: 12px;
}
.title {
  margin: 0 0 6px;
  font-size: 22px;
  text-align: center;
  color: #303133;
}
.subtitle {
  margin: 0 0 24px;
  font-size: 13px;
  color: #909399;
  text-align: center;
}
.hint {
  margin-top: 18px;
  font-size: 12px;
  color: #909399;
  text-align: center;
}
.hint code {
  background: #f4f4f5;
  padding: 1px 4px;
  border-radius: 4px;
}
</style>
