<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { useUserStore } from '@/stores/user'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  pageBuildings,
  listManagers,
  createBuilding,
  updateBuilding,
  deleteBuilding,
  pageFloors,
  createFloor,
  updateFloor,
  deleteFloor,
  pageRooms,
  createRoom,
  updateRoom,
  setRoomStatus,
  deleteRoom,
  pageBeds,
  createBed,
  updateBed,
  setBedStatus,
  deleteBed,
  getRoom,
  type Building,
  type Floor,
  type Room,
  type Bed,
  type SysUser,
  type RoomStatus,
  type BedStatus,
  GENDER_LABELS,
  ROOM_STATUS_LABELS,
  ROOM_STATUS_TYPES,
  BED_STATUS_LABELS,
  BED_STATUS_TYPES
} from '@/api/dorm'

const store = useUserStore()

// 权限判断：仅管理员能做写操作
const isAdmin = computed(() => store.role === 'admin')

// --- 楼栋列表状态 ---
const buildings = ref<Building[]>([])
const totalBuildings = ref(0)
const pageNum = ref(1)
const pageSize = ref(10)
const searchKeyword = ref('')
const searchGender = ref<number | undefined>(undefined)
const loadingBuildings = ref(false)

// 宿管列表缓存
const managers = ref<SysUser[]>([])

// --- 楼栋表单弹窗 ---
const buildingDialogVisible = ref(false)
const isBuildingEdit = ref(false)
const buildingFormRef = ref()
const buildingForm = ref({
  id: 0,
  code: '',
  name: '',
  gender: 1,
  floorCount: 6,
  managerId: null as number | null,
  remark: ''
})

const buildingRules = {
  code: [{ required: true, message: '请输入楼栋编号', trigger: 'blur' }],
  name: [{ required: true, message: '请输入楼栋名称', trigger: 'blur' }],
  gender: [{ required: true, message: '请选择性别类型', trigger: 'change' }],
  floorCount: [{ required: true, message: '请输入楼层数', trigger: 'blur' }]
}

// --- 级联管理 Drawer 状态 ---
const drawerVisible = ref(false)
const currentBuilding = ref<Building | null>(null)
const floors = ref<Floor[]>([])
const loadingFloors = ref(false)
const selectedFloorId = ref<number | null>(null)

const rooms = ref<Room[]>([])
const loadingRooms = ref(false)
const roomBedsMap = ref<Record<number, Bed[]>>({})

// --- 楼层弹窗 ---
const floorDialogVisible = ref(false)
const isFloorEdit = ref(false)
const floorForm = ref({
  id: 0,
  buildingId: 0,
  floorNo: 1,
  roomCount: 0
})

// --- 房间弹窗 ---
const roomDialogVisible = ref(false)
const isRoomEdit = ref(false)
const roomFormRef = ref()
const roomForm = ref({
  id: 0,
  buildingId: 0,
  floorId: 0,
  roomNo: '',
  capacity: 4,
  remark: ''
})
const roomRules = {
  roomNo: [{ required: true, message: '请输入房间号', trigger: 'blur' }],
  capacity: [{ required: true, message: '请输入额定床位数', trigger: 'blur' }]
}

// --- 床位弹窗 ---
const bedDialogVisible = ref(false)
const bedForm = ref({
  roomId: 0,
  bedNo: '',
  status: 0 as BedStatus
})

// --- 加载方法 ---
async function loadBuildings() {
  loadingBuildings.value = true
  try {
    const res = await pageBuildings({
      pageNum: pageNum.value,
      pageSize: pageSize.value,
      keyword: searchKeyword.value,
      gender: searchGender.value
    })
    buildings.value = res.records
    totalBuildings.value = res.total
  } catch (err) {
    // 拦截器已处理错误
  } finally {
    loadingBuildings.value = false
  }
}

async function loadManagers() {
  if (!isAdmin.value) return
  try {
    managers.value = await listManagers()
  } catch {
    // 忽略
  }
}

function getManagerName(id: number | null) {
  if (!id) return '-'
  const m = managers.value.find((x) => x.id === id)
  return m ? `${m.realName}（${m.username}）` : `#${id}`
}

// --- 楼栋 CRUD 动作 ---
function handleAddBuilding() {
  isBuildingEdit.value = false
  buildingForm.value = {
    id: 0,
    code: '',
    name: '',
    gender: 1,
    floorCount: 6,
    managerId: null,
    remark: ''
  }
  buildingDialogVisible.value = true
}

function handleEditBuilding(row: Building) {
  isBuildingEdit.value = true
  buildingForm.value = {
    id: row.id,
    code: row.code,
    name: row.name,
    gender: row.gender,
    floorCount: row.floorCount,
    managerId: row.managerId,
    remark: row.remark || ''
  }
  buildingDialogVisible.value = true
}

async function saveBuilding() {
  if (!buildingFormRef.value) return
  await buildingFormRef.value.validate(async (valid: boolean) => {
    if (!valid) return
    try {
      if (isBuildingEdit.value) {
        await updateBuilding(buildingForm.value.id, buildingForm.value)
        ElMessage.success('修改楼栋成功')
      } else {
        await createBuilding(buildingForm.value)
        ElMessage.success('新增楼栋成功')
      }
      buildingDialogVisible.value = false
      loadBuildings()
    } catch {
      // 忽略
    }
  })
}

async function handleDeleteBuilding(row: Building) {
  try {
    await ElMessageBox.confirm(`确定要删除楼栋 "${row.name}" 吗？如果楼栋内有房间，可能会报错。`, '警告', {
      type: 'warning',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
    await deleteBuilding(row.id)
    ElMessage.success('删除成功')
    loadBuildings()
  } catch (e) {
    if (e !== 'cancel') {
      ElMessage.error('删除失败，可能该楼栋内仍有房间存在')
    }
  }
}

// --- 级联管理 Drawer 核心逻辑 ---
async function openDormDrawer(building: Building) {
  currentBuilding.value = building
  drawerVisible.value = true
  selectedFloorId.value = null
  rooms.value = []
  roomBedsMap.value = {}
  await loadFloors()
}

async function loadFloors() {
  if (!currentBuilding.value) return
  loadingFloors.value = true
  try {
    const res = await pageFloors({
      pageNum: 1,
      pageSize: 200,
      buildingId: currentBuilding.value.id
    })
    floors.value = res.records.sort((a, b) => a.floorNo - b.floorNo)
    if (floors.value.length > 0 && !selectedFloorId.value) {
      // 默认选择第一层
      selectFloor(floors.value[0].id)
    }
  } catch {
    // 忽略
  } finally {
    loadingFloors.value = false
  }
}

function selectFloor(floorId: number) {
  selectedFloorId.value = floorId
  loadRooms()
}

async function loadRooms() {
  if (!selectedFloorId.value || !currentBuilding.value) return
  loadingRooms.value = true
  try {
    const res = await pageRooms({
      pageNum: 1,
      pageSize: 200,
      buildingId: currentBuilding.value.id,
      floorId: selectedFloorId.value
    })
    rooms.value = res.records.sort((a, b) => a.roomNo.localeCompare(b.roomNo))
    // 加载各个房间的床位
    for (const r of rooms.value) {
      loadBeds(r.id)
    }
  } catch {
    // 忽略
  } finally {
    loadingRooms.value = false
  }
}

async function loadBeds(roomId: number) {
  try {
    const res = await pageBeds({ pageNum: 1, pageSize: 50, roomId })
    roomBedsMap.value[roomId] = res.records.sort((a, b) => a.bedNo.localeCompare(b.bedNo))
  } catch {
    // 忽略
  }
}

// --- 楼层 CRUD ---
function handleAddFloor() {
  if (!currentBuilding.value) return
  isFloorEdit.value = false
  // 推荐下一层号
  const nextNo = floors.value.length > 0 ? Math.max(...floors.value.map((x) => x.floorNo)) + 1 : 1
  floorForm.value = {
    id: 0,
    buildingId: currentBuilding.value.id,
    floorNo: nextNo,
    roomCount: 0
  }
  floorDialogVisible.value = true
}

function handleEditFloor(f: Floor) {
  isFloorEdit.value = true
  floorForm.value = {
    id: f.id,
    buildingId: f.buildingId,
    floorNo: f.floorNo,
    roomCount: f.roomCount
  }
  floorDialogVisible.value = true
}

async function saveFloor() {
  try {
    if (isFloorEdit.value) {
      await updateFloor(floorForm.value.id, floorForm.value)
      ElMessage.success('修改成功')
    } else {
      await createFloor(floorForm.value)
      ElMessage.success('新增成功')
    }
    floorDialogVisible.value = false
    await loadFloors()
  } catch {
    // 忽略
  }
}

async function handleDeleteFloor(f: Floor) {
  try {
    await ElMessageBox.confirm(`确定要删除 ${f.floorNo} 层吗？`, '提示', { type: 'warning' })
    await deleteFloor(f.id)
    ElMessage.success('删除成功')
    if (selectedFloorId.value === f.id) {
      selectedFloorId.value = null
    }
    await loadFloors()
  } catch (e) {
    if (e !== 'cancel') {
      ElMessage.error('删除失败，可能该楼层下仍有房间')
    }
  }
}

// --- 房间 CRUD ---
function handleAddRoom() {
  if (!currentBuilding.value || !selectedFloorId.value) return
  isRoomEdit.value = false
  roomForm.value = {
    id: 0,
    buildingId: currentBuilding.value.id,
    floorId: selectedFloorId.value,
    roomNo: '',
    capacity: 4,
    remark: ''
  }
  roomDialogVisible.value = true
}

function handleEditRoom(r: Room) {
  isRoomEdit.value = true
  roomForm.value = {
    id: r.id,
    buildingId: r.buildingId,
    floorId: r.floorId,
    roomNo: r.roomNo,
    capacity: r.capacity,
    remark: r.remark || ''
  }
  roomDialogVisible.value = true
}

async function saveRoom() {
  if (!roomFormRef.value) return
  await roomFormRef.value.validate(async (valid: boolean) => {
    if (!valid) return
    try {
      if (isRoomEdit.value) {
        await updateRoom(roomForm.value.id, roomForm.value)
        ElMessage.success('修改房间成功')
      } else {
        await createRoom(roomForm.value)
        ElMessage.success('新增房间成功')
      }
      roomDialogVisible.value = false
      loadRooms()
    } catch {
      // 忽略
    }
  })
}

async function handleSetRoomStatus(r: Room, status: RoomStatus) {
  try {
    await setRoomStatus(r.id, status)
    ElMessage.success('房间状态修改成功')
    // 联动刷新该房间
    const detail = await getRoom(r.id)
    const idx = rooms.value.findIndex((x) => x.id === r.id)
    if (idx !== -1) {
      rooms.value[idx] = detail
    }
    loadBeds(r.id)
  } catch {
    // 忽略
  }
}

async function handleDeleteRoom(r: Room) {
  try {
    await ElMessageBox.confirm(`确定要删除房间 ${r.roomNo} 吗？将同时软删除房间内的床位。`, '警告', { type: 'warning' })
    await deleteRoom(r.id)
    ElMessage.success('删除房间成功')
    loadRooms()
  } catch (e) {
    if (e !== 'cancel') {
      ElMessage.error('删除失败，可能有学生正在入住此房间')
    }
  }
}

// --- 床位 CRUD 与状态 ---
function handleAddBed(roomId: number) {
  bedForm.value = {
    roomId,
    bedNo: '',
    status: 0
  }
  bedDialogVisible.value = true
}

async function saveBed() {
  if (!bedForm.value.bedNo) {
    ElMessage.warning('请输入床位号')
    return
  }
  try {
    await createBed(bedForm.value)
    ElMessage.success('新增床位成功')
    bedDialogVisible.value = false
    // 重新拉取床位和房间信息
    loadBeds(bedForm.value.roomId)
    const idx = rooms.value.findIndex((x) => x.id === bedForm.value.roomId)
    if (idx !== -1) {
      const detail = await getRoom(bedForm.value.roomId)
      rooms.value[idx] = detail
    }
  } catch {
    // 忽略
  }
}

async function handleSetBedStatus(b: Bed, status: BedStatus) {
  try {
    await setBedStatus(b.id, status)
    ElMessage.success('床位状态修改成功')
    loadBeds(b.roomId)
    const idx = rooms.value.findIndex((x) => x.id === b.roomId)
    if (idx !== -1) {
      const detail = await getRoom(b.roomId)
      rooms.value[idx] = detail
    }
  } catch {
    // 忽略
  }
}

async function handleDeleteBed(b: Bed) {
  try {
    await ElMessageBox.confirm(`确定要删除床位 ${b.bedNo} 吗？`, '提示', { type: 'warning' })
    await deleteBed(b.id)
    ElMessage.success('删除成功')
    loadBeds(b.roomId)
    const idx = rooms.value.findIndex((x) => x.id === b.roomId)
    if (idx !== -1) {
      const detail = await getRoom(b.roomId)
      rooms.value[idx] = detail
    }
  } catch (e) {
    if (e !== 'cancel') {
      ElMessage.error('删除失败，可能该床位已被占用')
    }
  }
}

onMounted(() => {
  loadBuildings()
  loadManagers()
})
</script>

<template>
  <div class="building-manager">
    <div class="page-header">
      <h1 class="page-title">宿舍基础数据管理</h1>
      <p class="page-subtitle">在这里维护校区的楼栋、楼层、房间及床位数据，联动维护入住状态和维修标志。</p>
    </div>

    <!-- 搜索过滤与新增 -->
    <el-card class="filter-card" shadow="never">
      <div class="filter-container">
        <div class="left-filters">
          <el-input
            v-model="searchKeyword"
            placeholder="搜索楼栋名称/编号"
            clearable
            style="width: 240px"
            @keyup.enter="loadBuildings"
            @clear="loadBuildings"
          >
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
          </el-input>
          <el-select
            v-model="searchGender"
            placeholder="按性别类型筛选"
            clearable
            style="width: 180px"
            @change="loadBuildings"
          >
            <el-option :value="1" label="男生楼" />
            <el-option :value="2" label="女生楼" />
            <el-option :value="3" label="混合楼" />
          </el-select>
          <el-button type="primary" @click="loadBuildings">查询</el-button>
        </div>
        <div v-if="isAdmin" class="right-actions">
          <el-button type="success" @click="handleAddBuilding">
            <el-icon style="margin-right: 4px"><Plus /></el-icon> 新增楼栋
          </el-button>
        </div>
      </div>
    </el-card>

    <!-- 楼栋表格 -->
    <el-card class="table-card" shadow="never" v-loading="loadingBuildings">
      <el-table :data="buildings" style="width: 100%" border stripe>
        <el-table-column prop="code" label="楼栋编号" width="120" align="center">
          <template #default="{ row }">
            <span class="code-badge">{{ row.code }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="name" label="楼栋名称" min-width="150" />
        <el-table-column prop="gender" label="性别类型" width="120" align="center">
          <template #default="{ row }">
            <el-tag
              :type="row.gender === 1 ? 'primary' : row.gender === 2 ? 'danger' : 'warning'"
              effect="dark"
              size="small"
            >
              {{ GENDER_LABELS[row.gender] }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="floorCount" label="楼层总数" width="120" align="center" />
        <el-table-column label="直属宿管" min-width="180">
          <template #default="{ row }">
            {{ getManagerName(row.managerId) }}
          </template>
        </el-table-column>
        <el-table-column prop="remark" label="备注" show-overflow-tooltip />
        <el-table-column label="操作" width="280" fixed="right" align="center">
          <template #default="{ row }">
            <el-button type="primary" size="small" link @click="openDormDrawer(row)">
              <el-icon style="margin-right: 2px"><Menu /></el-icon> 房间管理
            </el-button>
            <el-button v-if="isAdmin" type="warning" size="small" link @click="handleEditBuilding(row)">
              编辑
            </el-button>
            <el-button v-if="isAdmin" type="danger" size="small" link @click="handleDeleteBuilding(row)">
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="pageNum"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="totalBuildings"
          @size-change="loadBuildings"
          @current-change="loadBuildings"
        />
      </div>
    </el-card>

    <!-- 楼栋表单 Dialog -->
    <el-dialog
      v-model="buildingDialogVisible"
      :title="isBuildingEdit ? '编辑楼栋' : '新增楼栋'"
      width="500px"
      destroy-on-close
    >
      <el-form :model="buildingForm" :rules="buildingRules" ref="buildingFormRef" label-width="100px" style="padding-right: 20px">
        <el-form-item label="楼栋编号" prop="code">
          <el-input v-model="buildingForm.code" placeholder="例如：7B" :disabled="isBuildingEdit" />
        </el-form-item>
        <el-form-item label="楼栋名称" prop="name">
          <el-input v-model="buildingForm.name" placeholder="例如：7号A楼" />
        </el-form-item>
        <el-form-item label="性别限制" prop="gender">
          <el-radio-group v-model="buildingForm.gender">
            <el-radio :value="1">男生楼</el-radio>
            <el-radio :value="2">女生楼</el-radio>
            <el-radio :value="3">混合楼</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="楼层总数" prop="floorCount">
          <el-input-number v-model="buildingForm.floorCount" :min="1" :max="30" />
        </el-form-item>
        <el-form-item label="绑定宿管" prop="managerId">
          <el-select v-model="buildingForm.managerId" placeholder="选择直属宿管" clearable style="width: 100%">
            <el-option v-for="m in managers" :key="m.id" :label="`${m.realName} (${m.username})`" :value="m.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input v-model="buildingForm.remark" type="textarea" placeholder="备注信息..." />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="buildingDialogVisible.value = false">取消</el-button>
        <el-button type="primary" @click="saveBuilding">保存</el-button>
      </template>
    </el-dialog>

    <!-- 级联管理 Drawer -->
    <el-drawer
      v-model="drawerVisible"
      :title="`房间与床位管理 · ${currentBuilding?.name || ''}`"
      size="80%"
      destroy-on-close
    >
      <div class="drawer-layout">
        <!-- 左侧楼层选择 -->
        <div class="drawer-sidebar" v-loading="loadingFloors">
          <div class="sidebar-header">
            <span>楼层列表</span>
            <el-button v-if="isAdmin" type="primary" size="small" circle @click="handleAddFloor">
              <el-icon><Plus /></el-icon>
            </el-button>
          </div>
          <div class="floor-list">
            <div
              v-for="f in floors"
              :key="f.id"
              :class="['floor-item', { active: selectedFloorId === f.id }]"
              @click="selectFloor(f.id)"
            >
              <span class="floor-no">{{ f.floorNo }} 层</span>
              <div v-if="isAdmin" class="floor-actions" @click.stop>
                <el-button type="primary" size="small" link @click="handleEditFloor(f)"><el-icon><Edit /></el-icon></el-button>
                <el-button type="danger" size="small" link @click="handleDeleteFloor(f)"><el-icon><Delete /></el-icon></el-button>
              </div>
            </div>
            <el-empty v-if="floors.length === 0" description="暂无楼层" :image-size="60" />
          </div>
        </div>

        <!-- 右侧房间 & 床位展示 -->
        <div class="drawer-main" v-loading="loadingRooms">
          <template v-if="selectedFloorId">
            <div class="main-header">
              <div class="current-info">
                当前楼层：<span class="highlight">{{ floors.find((x) => x.id === selectedFloorId)?.floorNo || '' }} 层</span>
              </div>
              <el-button v-if="isAdmin" type="success" size="small" @click="handleAddRoom">
                <el-icon style="margin-right: 4px"><Plus /></el-icon> 新增房间
              </el-button>
            </div>

            <!-- 房间 Grid -->
            <div class="room-grid">
              <div v-for="r in rooms" :key="r.id" class="room-card">
                <div class="room-card-header">
                  <span class="room-no">🚪 {{ r.roomNo }}</span>
                  <el-tag :type="ROOM_STATUS_TYPES[r.status]" effect="plain" size="small">
                    {{ ROOM_STATUS_LABELS[r.status] }}
                  </el-tag>
                </div>
                <div class="room-card-body">
                  <div class="room-stats">
                    <span class="stat-item">额定床位: {{ r.capacity }}</span>
                    <span class="stat-item">已入住: {{ r.occupiedCount }}</span>
                  </div>
                  
                  <!-- 房间状态更改 -->
                  <div v-if="isAdmin" class="room-status-change">
                    <span class="label">快捷状态：</span>
                    <el-dropdown trigger="click" @command="(s: RoomStatus) => handleSetRoomStatus(r, s)">
                      <span class="el-dropdown-link">
                        切换状态 <el-icon class="el-icon--right"><arrow-down /></el-icon>
                      </span>
                      <template #dropdown>
                        <el-dropdown-menu>
                          <el-dropdown-item :command="0">空闲 (自适应)</el-dropdown-item>
                          <el-dropdown-item :command="3">维修中</el-dropdown-item>
                          <el-dropdown-item :command="4">锁定预留</el-dropdown-item>
                        </el-dropdown-menu>
                      </template>
                    </el-dropdown>
                  </div>

                  <!-- 床位列表 -->
                  <div class="beds-section">
                    <div class="beds-header">
                      <span>床位明细</span>
                      <el-button v-if="isAdmin && (roomBedsMap[r.id]?.length || 0) < r.capacity" type="primary" size="small" link @click="handleAddBed(r.id)">
                        + 添加床位
                      </el-button>
                    </div>
                    <div class="beds-list">
                      <div v-for="b in roomBedsMap[r.id]" :key="b.id" class="bed-item">
                        <div class="bed-info">
                          <span class="bed-no">🛏️ {{ b.bedNo }}床</span>
                          <el-tag :type="BED_STATUS_TYPES[b.status]" size="small" style="margin-left: 6px">
                            {{ BED_STATUS_LABELS[b.status] }}
                          </el-tag>
                          <span v-if="b.studentId" class="student-name">
                            ({{ b.studentName || `学号:${b.studentId}` }})
                          </span>
                        </div>
                        
                        <div class="bed-actions">
                          <!-- 只有非占用床位才能快捷修改状态 -->
                          <el-dropdown v-if="isAdmin && b.status !== 1" trigger="click" @command="(s: BedStatus) => handleSetBedStatus(b, s)">
                            <el-button size="small" circle style="padding: 3px"><el-icon><Setting /></el-icon></el-button>
                            <template #dropdown>
                              <el-dropdown-menu>
                                <el-dropdown-item :command="0">空闲</el-dropdown-item>
                                <el-dropdown-item :command="2">维修</el-dropdown-item>
                                <el-dropdown-item :command="3">预留</el-dropdown-item>
                              </el-dropdown-menu>
                            </template>
                          </el-dropdown>
                          <el-button v-if="isAdmin && b.status !== 1" type="danger" size="small" circle style="padding: 3px; margin-left: 4px" @click="handleDeleteBed(b)">
                            <el-icon><Delete /></el-icon>
                          </el-button>
                        </div>
                      </div>
                      <div v-if="!roomBedsMap[r.id] || roomBedsMap[r.id].length === 0" class="no-beds">
                        暂无床位
                      </div>
                    </div>
                  </div>
                </div>
                <div v-if="isAdmin" class="room-card-footer">
                  <el-button type="primary" size="small" link @click="handleEditRoom(r)">编辑</el-button>
                  <el-button type="danger" size="small" link @click="handleDeleteRoom(r)">删除</el-button>
                </div>
              </div>
              <el-empty v-if="rooms.length === 0" description="当前楼层尚无房间" style="grid-column: span 3" />
            </div>
          </template>
          <el-empty v-else description="请从左侧选择一个楼层" style="padding-top: 100px" />
        </div>
      </div>
    </el-drawer>

    <!-- 楼层表单 Dialog -->
    <el-dialog
      v-model="floorDialogVisible"
      :title="isFloorEdit ? '编辑楼层' : '新增楼层'"
      width="400px"
    >
      <el-form :model="floorForm" label-width="80px">
        <el-form-item label="楼层号">
          <el-input-number v-model="floorForm.floorNo" :min="-2" :max="30" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="floorDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveFloor">确定</el-button>
      </template>
    </el-dialog>

    <!-- 房间表单 Dialog -->
    <el-dialog
      v-model="roomDialogVisible"
      :title="isRoomEdit ? '编辑房间' : '新增房间'"
      width="450px"
      destroy-on-close
    >
      <el-form :model="roomForm" :rules="roomRules" ref="roomFormRef" label-width="100px">
        <el-form-item label="房间号" prop="roomNo">
          <el-input v-model="roomForm.roomNo" placeholder="例如：302" />
        </el-form-item>
        <el-form-item label="额定床位" prop="capacity">
          <el-input-number v-model="roomForm.capacity" :min="1" :max="12" />
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input v-model="roomForm.remark" type="textarea" placeholder="备注信息..." />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="roomDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveRoom">确定</el-button>
      </template>
    </el-dialog>

    <!-- 床位新增 Dialog -->
    <el-dialog
      v-model="bedDialogVisible"
      title="添加床位"
      width="400px"
    >
      <el-form :model="bedForm" label-width="80px">
        <el-form-item label="床位号" required>
          <el-input v-model="bedForm.bedNo" placeholder="例如：1号床 或 1" />
        </el-form-item>
        <el-form-item label="初始状态">
          <el-select v-model="bedForm.status" placeholder="状态">
            <el-option :value="0" label="空闲" />
            <el-option :value="2" label="维修中" />
            <el-option :value="3" label="预留" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="bedDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveBed">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.building-manager {
  max-width: 1200px;
  margin: 0 auto;
}
.page-header {
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: 700;
  color: #303133;
  margin: 0 0 6px 0;
}
.page-subtitle {
  font-size: 14px;
  color: #909399;
  margin: 0;
}
.filter-card {
  margin-bottom: 16px;
}
.filter-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
}
.left-filters {
  display: flex;
  align-items: center;
  gap: 10px;
}
.code-badge {
  background: #f4f4f5;
  color: #909399;
  font-family: monospace;
  padding: 2px 6px;
  border-radius: 4px;
  font-weight: bold;
}
.table-card {
  padding: 4px;
}
.pagination-container {
  margin-top: 18px;
  display: flex;
  justify-content: flex-end;
}

/* Drawer CSS Layout */
.drawer-layout {
  display: flex;
  height: 100%;
  margin: -20px; /* 消除 el-drawer 的默认 padding */
  border-top: 1px solid #ebeef5;
}
.drawer-sidebar {
  width: 220px;
  border-right: 1px solid #ebeef5;
  background-color: #fcfcfd;
  display: flex;
  flex-direction: column;
}
.sidebar-header {
  padding: 14px 18px;
  font-weight: bold;
  border-bottom: 1px solid #ebeef5;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: #606266;
}
.floor-list {
  flex: 1;
  overflow-y: auto;
  padding: 10px;
}
.floor-item {
  padding: 12px 14px;
  border-radius: 6px;
  cursor: pointer;
  margin-bottom: 6px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  transition: all 0.2s;
  color: #606266;
}
.floor-item:hover {
  background-color: #f2f6fc;
}
.floor-item.active {
  background-color: #ecf5ff;
  color: #409eff;
  font-weight: 600;
}
.floor-actions {
  display: none;
}
.floor-item:hover .floor-actions {
  display: flex;
  gap: 4px;
}

.drawer-main {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
  background-color: #fff;
  display: flex;
  flex-direction: column;
}
.main-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding-bottom: 12px;
  border-bottom: 1px dashed #ebeef5;
}
.current-info {
  font-size: 16px;
  font-weight: 600;
  color: #606266;
}
.highlight {
  color: #409eff;
}

.room-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 16px;
}
.room-card {
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  background: #fff;
  display: flex;
  flex-direction: column;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.02);
  transition: all 0.25s;
}
.room-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 16px 0 rgba(0, 0, 0, 0.08);
}
.room-card-header {
  padding: 12px 16px;
  background-color: #fafbfd;
  border-bottom: 1px solid #ebeef5;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-radius: 8px 8px 0 0;
}
.room-no {
  font-weight: bold;
  color: #303133;
}
.room-card-body {
  padding: 14px 16px;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.room-stats {
  font-size: 13px;
  color: #606266;
  display: flex;
  gap: 12px;
}
.stat-item {
  background: #f0f2f5;
  padding: 2px 6px;
  border-radius: 4px;
}
.room-status-change {
  display: flex;
  align-items: center;
  font-size: 12px;
  color: #909399;
}
.room-status-change .el-dropdown-link {
  color: #409eff;
  cursor: pointer;
}
.beds-section {
  border-top: 1px dashed #ebeef5;
  padding-top: 10px;
}
.beds-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 8px;
}
.beds-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.bed-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #f9fafc;
  padding: 6px 10px;
  border-radius: 4px;
  font-size: 12px;
}
.bed-info {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
}
.bed-no {
  font-weight: 600;
  color: #606266;
}
.student-name {
  color: #67c23a;
  margin-left: 6px;
  font-weight: bold;
}
.bed-actions {
  display: flex;
  align-items: center;
}
.no-beds {
  text-align: center;
  font-size: 12px;
  color: #c0c4cc;
  padding: 8px 0;
}
.room-card-footer {
  padding: 10px 16px;
  border-top: 1px solid #ebeef5;
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}
</style>
