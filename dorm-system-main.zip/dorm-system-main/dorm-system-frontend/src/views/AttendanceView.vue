<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useUserStore } from '@/stores/user'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  pageAttendance,
  createAttendance,
  updateAttendance,
  deleteAttendance,
  ATTENDANCE_TYPE_LABELS,
  ATTENDANCE_TYPE_TYPES,
  type AttendanceResponse,
  type AttendanceSaveRequest,
} from '@/api/attendance'
import { fetchDormTree, type BuildingTreeNode } from '@/api/dorm'
import { pageStudents, type Student } from '@/api/student'

const store = useUserStore()
const isAdmin = computed(() => store.role === 'admin')
const isManager = computed(() => isAdmin.value || store.role === 'dorm_manager')

// ---- 列表 ----------------------------------------------------------------
const list = ref<AttendanceResponse[]>([])
const total = ref(0)
const pageNum = ref(1)
const pageSize = ref(10)
const loading = ref(false)

const filter = ref({
  buildingId: undefined as number | undefined,
  studentId: undefined as number | undefined,
  roomId: undefined as number | undefined,
  type: undefined as number | undefined,
  dateRange: null as [string, string] | null,
})

async function loadList() {
  loading.value = true
  try {
    const res = await pageAttendance({
      pageNum: pageNum.value,
      pageSize: pageSize.value,
      buildingId: filter.value.buildingId,
      studentId: filter.value.studentId,
      roomId: filter.value.roomId,
      type: filter.value.type,
      startDate: filter.value.dateRange?.[0],
      endDate: filter.value.dateRange?.[1],
    })
    list.value = res.records
    total.value = res.total
  } catch {
    // 静默
  } finally {
    loading.value = false
  }
}

function resetFilter() {
  filter.value = {
    buildingId: undefined,
    studentId: undefined,
    roomId: undefined,
    type: undefined,
    dateRange: null,
  }
  pageNum.value = 1
  loadList()
}

function handlePageChange(p: number) {
  pageNum.value = p
  loadList()
}

// ---- 登记弹窗 ------------------------------------------------------------
const dialogVisible = ref(false)
const isEdit = ref(false)
const submitting = ref(false)
const form = ref<AttendanceSaveRequest & { id?: number }>({
  id: undefined,
  studentId: 0,
  recordDate: new Date().toISOString().slice(0, 10),
  type: 1,
  returnTime: null,
  remark: '',
})

const studentOptions = ref<Student[]>([])
const studentLoading = ref(false)

async function searchStudents(keyword: string) {
  studentLoading.value = true
  try {
    const res = await pageStudents({ pageNum: 1, pageSize: 30, keyword })
    studentOptions.value = res.records
  } catch {
    // 静默
  } finally {
    studentLoading.value = false
  }
}

const dormTree = ref<BuildingTreeNode[]>([])
async function loadDormTree() {
  try {
    dormTree.value = await fetchDormTree()
  } catch {
    // 静默
  }
}

function openCreate() {
  isEdit.value = false
  form.value = {
    studentId: 0,
    recordDate: new Date().toISOString().slice(0, 10),
    type: 1,
    returnTime: null,
    remark: '',
  }
  dialogVisible.value = true
  if (studentOptions.value.length === 0) searchStudents('')
}

function openEdit(row: AttendanceResponse) {
  isEdit.value = true
  form.value = {
    id: row.id,
    studentId: row.studentId,
    recordDate: row.recordDate,
    type: row.type,
    returnTime: row.returnTime,
    remark: row.remark || '',
  }
  // 把当前学生塞进 options 以便下拉显示
  if (!studentOptions.value.find((s) => s.id === row.studentId)) {
    studentOptions.value = [
      {
        id: row.studentId,
        userId: 0,
        studentNo: row.studentNo || '',
        name: row.studentName || '',
        gender: 0,
        college: null,
        major: null,
        className: null,
        grade: null,
        currentBedId: null,
        emergencyContact: null,
        emergencyPhone: null,
        enrollDate: null,
        status: 0,
      } as Student,
      ...studentOptions.value,
    ]
  }
  dialogVisible.value = true
}

async function submit() {
  if (!form.value.studentId) {
    ElMessage.warning('请选择学生')
    return
  }
  if (!form.value.recordDate) {
    ElMessage.warning('请选择记录日期')
    return
  }
  submitting.value = true
  try {
    const payload: AttendanceSaveRequest = {
      studentId: form.value.studentId,
      recordDate: form.value.recordDate,
      type: form.value.type,
      returnTime: form.value.returnTime || undefined,
      remark: form.value.remark || undefined,
    }
    if (isEdit.value && form.value.id) {
      await updateAttendance(form.value.id, payload)
      ElMessage.success('修改成功')
    } else {
      await createAttendance(payload)
      ElMessage.success('登记成功')
    }
    dialogVisible.value = false
    loadList()
  } catch {
    // 静默
  } finally {
    submitting.value = false
  }
}

async function handleDelete(row: AttendanceResponse) {
  try {
    await ElMessageBox.confirm('确认删除该考勤记录吗？', '提示', { type: 'warning' })
  } catch {
    return
  }
  try {
    await deleteAttendance(row.id)
    ElMessage.success('删除成功')
    loadList()
  } catch {
    // 静默
  }
}

function formatDateTime(t: string | null) {
  return t ? t.replace('T', ' ').slice(0, 16) : '-'
}

onMounted(() => {
  if (isManager.value) {
    loadDormTree()
    searchStudents('')
  }
  loadList()
})
</script>

<template>
  <div class="attendance-view">
    <div class="page-header">
      <h1 class="page-title">晚归考勤</h1>
      <p class="page-subtitle">登记晚归/未归/请假记录，按学生/房间/楼栋/日期范围查询。</p>
    </div>

    <el-card shadow="never">
      <div class="filter-row">
        <el-select
          v-model="filter.buildingId"
          placeholder="按楼栋筛选"
          clearable
          style="width: 180px"
        >
          <el-option
            v-for="b in dormTree"
            :key="b.id"
            :label="b.name"
            :value="b.id"
          />
        </el-select>
        <el-input-number
          v-model="filter.studentId"
          :min="1"
          :controls="false"
          placeholder="学生 ID"
          style="width: 140px"
        />
        <el-input-number
          v-model="filter.roomId"
          :min="1"
          :controls="false"
          placeholder="房间 ID"
          style="width: 140px"
        />
        <el-select v-model="filter.type" placeholder="类型" clearable style="width: 120px">
          <el-option :value="1" label="晚归" />
          <el-option :value="2" label="未归" />
          <el-option :value="3" label="请假" />
        </el-select>
        <el-date-picker
          v-model="filter.dateRange"
          type="daterange"
          value-format="YYYY-MM-DD"
          range-separator="→"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        />
        <el-button type="primary" @click="pageNum = 1; loadList()">
          <el-icon><Search /></el-icon> 查询
        </el-button>
        <el-button @click="resetFilter">重置</el-button>
        <div class="flex-grow"></div>
        <el-button v-if="isManager" type="primary" @click="openCreate">
          <el-icon><Plus /></el-icon> 登记考勤
        </el-button>
      </div>

      <el-table :data="list" v-loading="loading" border stripe empty-text="暂无考勤记录">
        <el-table-column label="日期" prop="recordDate" width="120" />
        <el-table-column label="学生" min-width="180">
          <template #default="{ row }">
            <span class="student-cell">
              {{ row.studentName || '-' }}
              <code class="student-no">{{ row.studentNo || '-' }}</code>
            </span>
          </template>
        </el-table-column>
        <el-table-column label="楼栋" prop="buildingName" width="120" />
        <el-table-column label="房间" prop="roomNo" width="80" />
        <el-table-column label="类型" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="ATTENDANCE_TYPE_TYPES[row.type]" size="small">
              {{ ATTENDANCE_TYPE_LABELS[row.type] }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="归寝时间" width="160">
          <template #default="{ row }">
            {{ formatDateTime(row.returnTime) }}
          </template>
        </el-table-column>
        <el-table-column label="记录人" prop="inspectorName" width="100" />
        <el-table-column label="备注" prop="remark" min-width="160" show-overflow-tooltip />
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button v-if="isManager" size="small" @click="openEdit(row)">修改</el-button>
            <el-button v-if="isAdmin" size="small" type="danger" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pager">
        <el-pagination
          v-model:current-page="pageNum"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next, jumper"
          @current-change="handlePageChange"
          @size-change="loadList"
        />
      </div>
    </el-card>

    <!-- 登记 / 修改弹窗 -->
    <el-dialog
      v-model="dialogVisible"
      :title="isEdit ? '修改考勤记录' : '登记考勤'"
      width="560px"
      destroy-on-close
    >
      <el-form :model="form" label-width="100px">
        <el-form-item label="学生" required>
          <el-select
            v-model="form.studentId"
            filterable
            remote
            clearable
            reserve-keyword
            placeholder="搜索学号 / 姓名"
            :remote-method="searchStudents"
            :loading="studentLoading"
            style="width: 100%"
          >
            <el-option
              v-for="s in studentOptions"
              :key="s.id"
              :label="`${s.studentNo} · ${s.name}`"
              :value="s.id"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="日期" required>
          <el-date-picker
            v-model="form.recordDate"
            type="date"
            value-format="YYYY-MM-DD"
            style="width: 100%"
          />
        </el-form-item>

        <el-form-item label="类型" required>
          <el-radio-group v-model="form.type">
            <el-radio :value="1">晚归</el-radio>
            <el-radio :value="2">未归</el-radio>
            <el-radio :value="3">请假</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item v-if="form.type === 1" label="归寝时间">
          <el-date-picker
            v-model="form.returnTime"
            type="datetime"
            value-format="YYYY-MM-DDTHH:mm:ss"
            placeholder="实际归寝时间"
            style="width: 100%"
          />
        </el-form-item>

        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" :rows="2" placeholder="如：校外兼职晚归" />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="submit">
          {{ isEdit ? '保存' : '登记' }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.attendance-view {
  max-width: 1400px;
  margin: 0 auto;
}
.page-header {
  margin-bottom: 24px;
}
.page-title {
  font-size: 24px;
  font-weight: 700;
  color: #303133;
  margin: 0 0 6px 0;
}
.page-subtitle {
  font-size: 14px;
  color: #909399;
  margin: 0;
}
.filter-row {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  margin-bottom: 16px;
}
.flex-grow {
  flex: 1;
}
.student-cell {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.student-no {
  background: #f4f4f5;
  color: #909399;
  font-family: monospace;
  padding: 1px 5px;
  border-radius: 3px;
  font-size: 12px;
}
.pager {
  margin-top: 16px;
  display: flex;
  justify-content: flex-end;
}
</style>
