<template>
  <div class="notice-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>我的消息</span>
          <el-button type="primary" plain @click="handleReadAll" :disabled="!tableData.some((n) => n.isRead === 0)">
            全部标为已读
          </el-button>
        </div>
      </template>

      <el-table :data="tableData" v-loading="loading" border style="width: 100%">
        <el-table-column label="状态" width="90">
          <template #default="scope">
            <el-badge is-dot v-if="scope.row.isRead === 0" class="unread-dot" />
            <el-tag :type="scope.row.isRead === 1 ? 'info' : 'danger'" size="small">
              {{ scope.row.isRead === 1 ? '已读' : '未读' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="类型" width="120">
          <template #default="scope">
            <el-tag :type="msgTypeTag(scope.row.msgType)">
              {{ msgTypeLabel(scope.row.msgType) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="title" label="标题" min-width="150" />
        <el-table-column prop="content" label="内容摘要" min-width="250" show-overflow-tooltip />
        <el-table-column label="时间" width="170">
          <template #default="scope">
            {{ formatTime(scope.row.createdAt) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="scope">
            <el-button size="small" type="primary" @click="viewDetail(scope.row)">查看</el-button>
            <el-button size="small" type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="detailVisible" :title="currentDetail?.title" width="500px">
      <div style="margin-bottom: 10px; color: #999; font-size: 12px">
        时间：{{ formatTime(currentDetail?.createdAt || '') }}
      </div>
      <div style="white-space: pre-wrap; line-height: 1.6">
        {{ currentDetail?.content }}
      </div>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  queryNotices,
  readNotice,
  readAllNotices,
  deleteNotice,
  type NoticeMessage,
} from '@/api/notice'

const loading = ref(false)
const tableData = ref<NoticeMessage[]>([])
const detailVisible = ref(false)
const currentDetail = ref<NoticeMessage | null>(null)

const fetchData = async () => {
  loading.value = true
  try {
    // axios 拦截器已拆 envelope，直接拿 data
    const res = await queryNotices({ page: 1, size: 50 })
    tableData.value = res?.records || []
  } catch (error) {
    console.error('获取消息列表失败', error)
  } finally {
    loading.value = false
  }
}

const viewDetail = async (row: NoticeMessage) => {
  currentDetail.value = row
  detailVisible.value = true
  if (row.isRead === 0) {
    try {
      await readNotice(row.id)
      row.isRead = 1
    } catch (e) {
      console.error('标记已读失败', e)
    }
  }
}

const handleReadAll = async () => {
  try {
    await readAllNotices()
    ElMessage.success('已全部标记为已读')
    fetchData()
  } catch (error) {
    console.error('操作失败', error)
  }
}

const handleDelete = async (id: number) => {
  try {
    await ElMessageBox.confirm('确认删除该消息吗？', '提示', { type: 'warning' })
    await deleteNotice(id)
    ElMessage.success('删除成功')
    fetchData()
  } catch (error) {
    if (error !== 'cancel') console.error('删除失败', error)
  }
}

const formatTime = (t: string) => (t ? t.replace('T', ' ') : '')

const msgTypeLabel = (t: string) => {
  const map: Record<string, string> = {
    system: '系统通知',
    fee: '催缴',
    FEE_REMIND: '催缴',
    rectify: '整改',
    notice: '通知',
  }
  return map[t] || t || '消息'
}

const msgTypeTag = (t: string) => {
  if (t === 'fee' || t === 'FEE_REMIND') return 'warning'
  if (t === 'rectify') return 'danger'
  if (t === 'system') return 'info'
  return 'primary'
}

onMounted(() => {
  fetchData()
})
</script>

<style scoped>
.notice-container {
  padding: 20px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.unread-dot {
  margin-right: 8px;
}
</style>
