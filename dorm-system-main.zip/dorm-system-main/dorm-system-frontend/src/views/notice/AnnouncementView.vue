<template>
  <div class="announcement-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>公告管理</span>
          <el-button type="primary" @click="openAddDialog" v-if="authStore.role === 'admin'">
            发布公告
          </el-button>
        </div>
      </template>

      <!-- 数据表格 -->
      <el-table :data="tableData" v-loading="loading" border style="width: 100%">
        <el-table-column prop="title" label="标题" min-width="200">
          <template #default="scope">
            <el-tag v-if="scope.row.isPinned" type="danger" size="small" style="margin-right: 5px">置顶</el-tag>
            <el-link type="primary" @click="viewDetail(scope.row)">{{ scope.row.title }}</el-link>
          </template>
        </el-table-column>
        <el-table-column label="可见范围" width="120">
          <template #default="scope">
            <el-tag :type="scope.row.scope === 0 ? 'success' : 'warning'">
              {{ scope.row.scope === 0 ? '全校' : '特定楼栋' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="发布时间" width="160">
          <template #default="scope">
            {{ formatTime(scope.row.publishTime) }}
          </template>
        </el-table-column>
        <el-table-column label="状态" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.status === 1 ? 'success' : 'info'">
              {{ scope.row.status === 1 ? '已发布' : '已下线' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right" v-if="authStore.role === 'admin'">
          <template #default="scope">
            <el-button size="small" @click="handlePin(scope.row)">
              {{ scope.row.isPinned ? '取消置顶' : '置顶' }}
            </el-button>
            <el-button 
              size="small" 
              type="warning" 
              @click="handleOffline(scope.row.id)"
              v-if="scope.row.status === 1"
            >
              下线
            </el-button>
            <el-button size="small" type="danger" @click="handleDelete(scope.row.id)">
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 发布公告弹窗 -->
    <el-dialog v-model="dialogVisible" title="发布公告" width="600px">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
        <el-form-item label="标题" prop="title">
          <el-input v-model="form.title" placeholder="请输入标题" />
        </el-form-item>
        <el-form-item label="可见范围" prop="scope">
          <el-radio-group v-model="form.scope">
            <el-radio :value="0">全校可见</el-radio>
            <el-radio :value="1">特定楼栋</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="楼栋ID" prop="buildingId" v-if="form.scope === 1" :rules="[{required: true, message: '请输入楼栋ID'}]">
          <el-input-number v-model="form.buildingId" :min="1" />
        </el-form-item>
        <el-form-item label="内容" prop="content">
          <el-input v-model="form.content" type="textarea" rows="5" placeholder="请输入正文" />
        </el-form-item>
        <el-form-item label="是否置顶">
          <el-switch v-model="form.isPinned" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitForm" :loading="submitting">发布</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 公告详情弹窗 -->
    <el-dialog v-model="detailVisible" :title="currentDetail?.title" width="600px">
      <div style="margin-bottom: 10px; color: #999; font-size: 12px;">
        发布时间：{{ formatTime(currentDetail?.publishTime || '') }}
      </div>
      <div style="white-space: pre-wrap; line-height: 1.6;">
        {{ currentDetail?.content }}
      </div>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { FormInstance, FormRules } from 'element-plus'
import { queryAnnouncements, queryAdminAnnouncements, publishAnnouncement, deleteAnnouncement, pinAnnouncement, offlineAnnouncement, type Announcement } from '@/api/notice'
import { useUserStore } from '@/stores/user'

const authStore = useUserStore()

const loading = ref(false)
const tableData = ref<Announcement[]>([])

const dialogVisible = ref(false)
const submitting = ref(false)
const formRef = ref<FormInstance>()
const form = ref({
  title: '',
  content: '',
  scope: 0,
  buildingId: undefined as number | undefined,
  isPinned: false
})

const rules: FormRules = {
  title: [{ required: true, message: '请输入标题', trigger: 'blur' }],
  content: [{ required: true, message: '请输入内容', trigger: 'blur' }]
}

const detailVisible = ref(false)
const currentDetail = ref<Announcement | null>(null)

const fetchData = async () => {
  loading.value = true
  try {
    const res = authStore.role === 'admin' 
      ? await queryAdminAnnouncements() 
      : await queryAnnouncements()
    tableData.value = res?.records || []
  } catch (error) {
    console.error('获取公告列表失败', error)
  } finally {
    loading.value = false
  }
}

const openAddDialog = () => {
  dialogVisible.value = true
  if (formRef.value) formRef.value.resetFields()
  form.value = { title: '', content: '', scope: 0, buildingId: undefined, isPinned: false }
}

const submitForm = async () => {
  if (!formRef.value) return
  await formRef.value.validate(async (valid) => {
    if (valid) {
      submitting.value = true
      try {
        await publishAnnouncement(form.value)
        ElMessage.success('发布成功')
        dialogVisible.value = false
        fetchData()
      } catch (error) {
        console.error('发布失败', error)
      } finally {
        submitting.value = false
      }
    }
  })
}

const viewDetail = (row: Announcement) => {
  currentDetail.value = row
  detailVisible.value = true
}

const handlePin = async (row: Announcement) => {
  try {
    await pinAnnouncement(row.id)
    ElMessage.success(row.isPinned ? '已取消置顶' : '已置顶')
    fetchData()
  } catch (error) {
    console.error('操作失败', error)
  }
}

const handleOffline = async (id: number) => {
  try {
    await ElMessageBox.confirm('确认下线该公告吗？', '提示', { type: 'warning' })
    await offlineAnnouncement(id)
    ElMessage.success('已下线')
    fetchData()
  } catch (error) {
    if (error !== 'cancel') console.error('下线失败', error)
  }
}

const handleDelete = async (id: number) => {
  try {
    await ElMessageBox.confirm('确认删除该公告吗？', '警告', { type: 'error' })
    await deleteAnnouncement(id)
    ElMessage.success('删除成功')
    fetchData()
  } catch (error) {
    if (error !== 'cancel') console.error('删除失败', error)
  }
}

const formatTime = (t: string) => t ? t.replace('T', ' ') : ''

onMounted(() => {
  fetchData()
})
</script>

<style scoped>
.announcement-container { padding: 20px; }
.card-header { display: flex; justify-content: space-between; align-items: center; }
</style>
