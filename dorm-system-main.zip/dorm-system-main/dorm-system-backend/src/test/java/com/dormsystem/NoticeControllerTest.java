package com.dormsystem;

import com.dormsystem.dto.notice.AnnouncementRequest;
import com.dormsystem.entity.SysUser;
import com.dormsystem.mapper.AnnouncementMapper;
import com.dormsystem.mapper.SysUserMapper;
import com.dormsystem.security.JwtAuthenticationToken;
import com.dormsystem.security.LoginUser;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.RequestPostProcessor;
import org.springframework.transaction.annotation.Transactional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("local")
@Transactional
public class NoticeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private SysUserMapper sysUserMapper;

    @Autowired
    private AnnouncementMapper announcementMapper;

    private LoginUser adminLoginUser;

    @BeforeEach
    public void setUp() {
        announcementMapper.delete(null);

        SysUser adminUser = sysUserMapper.selectById(1L);
        if (adminUser == null) {
            adminUser = new SysUser();
            adminUser.setUsername("admin_notice_test");
            adminUser.setPassword("123456");
            adminUser.setRealName("公告测试管理员");
            adminUser.setRole("admin");
            adminUser.setStatus(1);
            sysUserMapper.insert(adminUser);
        }
        adminLoginUser = new LoginUser(adminUser);
        SecurityContextHolder.getContext().setAuthentication(
                new JwtAuthenticationToken(adminLoginUser, null, adminLoginUser.getAuthorities()));
    }

    private RequestPostProcessor auth() {
        return SecurityMockMvcRequestPostProcessors.user(adminLoginUser);
    }

    @Test
    public void testPublishAndGetAnnouncement() throws Exception {
        AnnouncementRequest req = new AnnouncementRequest();
        req.setTitle("测试公告");
        req.setContent("这是一条测试公告");
        req.setScope(0); // All students

        mockMvc.perform(post("/api/v1/admin/announcement")
                        .with(auth())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk());

        mockMvc.perform(get("/api/v1/announcement").with(auth()))
                .andExpect(status().isOk());
    }
}
