package com.dormsystem;

import com.alibaba.excel.EasyExcel;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.dormsystem.dto.student.StudentExcelModel;
import com.dormsystem.dto.student.StudentSaveRequest;
import com.dormsystem.entity.Student;
import com.dormsystem.entity.SysUser;
import com.dormsystem.mapper.StudentMapper;
import com.dormsystem.mapper.SysUserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("local")
@Transactional
public class StudentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private StudentMapper studentMapper;

    @Autowired
    private SysUserMapper sysUserMapper;

    @Test
    @WithMockUser(roles = "ADMIN")
    public void testCreateStudentWithDate() throws Exception {
        StudentSaveRequest req = new StudentSaveRequest();
        req.setStudentNo("TEST_STUDENT_001");
        req.setName("测试学生");
        req.setGender(1);
        req.setCollege("测试学院");
        req.setMajor("测试专业");
        req.setClassName("测试班级");
        req.setGrade("2024");
        req.setPhone("13999999999");
        req.setEmergencyContact("紧急联系人");
        req.setEmergencyPhone("13988888888");
        req.setEnrollDate(LocalDate.of(2024, 9, 1));
        req.setStatus(0);

        String json = objectMapper.writeValueAsString(req);

        // 发送 POST 请求并验证反序列化及响应结果
        mockMvc.perform(post("/api/v1/admin/students")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.studentNo").value("TEST_STUDENT_001"));

        // 验证 sys_user 表中的联动创建
        SysUser user = sysUserMapper.selectOne(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<SysUser>()
                        .eq(SysUser::getUsername, "TEST_STUDENT_001"));
        assertNotNull(user);
        assertEquals("测试学生", user.getRealName());
        assertEquals("student", user.getRole());
        assertEquals(1, user.getGender());
        assertEquals("13999999999", user.getPhone());
        assertEquals(1, user.getStatus());

        // 验证 student 表中的联动创建与 LocalDate 反序列化结果
        Student student = studentMapper.selectOne(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<Student>()
                        .eq(Student::getStudentNo, "TEST_STUDENT_001"));
        assertNotNull(student);
        assertEquals(user.getId(), student.getUserId());
        assertEquals(LocalDate.of(2024, 9, 1), student.getEnrollDate());
        assertEquals(0, student.getStatus());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    public void testDeleteStudentCascadeSoftDeletesUser() throws Exception {
        // 1. 先建立一个测试学生
        SysUser user = new SysUser();
        user.setUsername("DEL_STUDENT_001");
        user.setPassword("123456");
        user.setRealName("待删学生");
        user.setRole("student");
        user.setGender(2);
        user.setStatus(1);
        sysUserMapper.insert(user);

        Student student = new Student();
        student.setUserId(user.getId());
        student.setStudentNo(user.getUsername());
        student.setName(user.getRealName());
        student.setGender(user.getGender());
        student.setStatus(0);
        studentMapper.insert(student);

        // 2. 调用删除接口
        mockMvc.perform(delete("/api/v1/admin/students/" + student.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0));

        // 3. 校验软删除效果（MyBatis-Plus 的 selectById 默认会过滤掉 is_deleted=1 的记录，返回 null）
        Student deletedStudent = studentMapper.selectById(student.getId());
        assertNull(deletedStudent);

        SysUser deletedUser = sysUserMapper.selectById(user.getId());
        assertNull(deletedUser);
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    public void testDeleteStudentWithBedRejects() throws Exception {
        // 1. 建立测试学生并绑定 mock 床位
        SysUser user = new SysUser();
        user.setUsername("BED_STUDENT_001");
        user.setPassword("123456");
        user.setRealName("床位学生");
        user.setRole("student");
        user.setGender(1);
        user.setStatus(1);
        sysUserMapper.insert(user);

        Student student = new Student();
        student.setUserId(user.getId());
        student.setStudentNo(user.getUsername());
        student.setName(user.getRealName());
        student.setGender(user.getGender());
        student.setStatus(0);
        student.setCurrentBedId(999L); // Mock 已绑定床位
        studentMapper.insert(student);

        // 2. 调用删除接口，验证拒绝并返回 409
        mockMvc.perform(delete("/api/v1/admin/students/" + student.getId()))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value(40901))
                .andExpect(jsonPath("$.message").value("该学生目前已分配床位，请先办理退宿再删除档案"));

        // 3. 校验数据库记录依然存在
        Student checkStudent = studentMapper.selectById(student.getId());
        assertNotNull(checkStudent);
        SysUser checkUser = sysUserMapper.selectById(user.getId());
        assertNotNull(checkUser);
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    public void testImportExcel() throws Exception {
        // 1. 动态生成包含正常、格式错误、及重复学号数据的 Excel
        List<StudentExcelModel> excelList = new ArrayList<>();
        
        // 正常行
        StudentExcelModel m1 = new StudentExcelModel();
        m1.setStudentNo("IMPORT_001");
        m1.setName("正常导入一");
        m1.setGender("男");
        m1.setCollege("信息学院");
        m1.setMajor("软件工程");
        m1.setClassName("软件2401");
        m1.setGrade("2024");
        m1.setPhone("13911112222");
        m1.setEmergencyContact("紧急一");
        m1.setEmergencyPhone("13922223333");
        m1.setEnrollDate("2024-09-01");
        excelList.add(m1);

        // 性别非法行
        StudentExcelModel m2 = new StudentExcelModel();
        m2.setStudentNo("IMPORT_002");
        m2.setName("性别错误二");
        m2.setGender("未知");
        excelList.add(m2);

        // 学号重复行 (重复学号 IMPORT_001)
        StudentExcelModel m3 = new StudentExcelModel();
        m3.setStudentNo("IMPORT_001");
        m3.setName("重复学号三");
        m3.setGender("女");
        excelList.add(m3);

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        EasyExcel.write(bos, StudentExcelModel.class).sheet("学生数据").doWrite(excelList);
        byte[] excelBytes = bos.toByteArray();

        MockMultipartFile mockFile = new MockMultipartFile(
                "file",
                "students_import.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                excelBytes
        );

        // 2. 调用批量导入接口并验证响应结果
        mockMvc.perform(multipart("/api/v1/admin/students/import")
                .file(mockFile))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.successCount").value(1))
                .andExpect(jsonPath("$.data.errorList").isArray())
                .andExpect(jsonPath("$.data.errorList[0]").value("第 3 行：性别必须为'男'或'女'，已忽略"))
                .andExpect(jsonPath("$.data.errorList[1]").value("第 4 行：文件中存在重复学号 [IMPORT_001]，已忽略"));

        // 3. 校验正常的一行是否成功录入
        SysUser user = sysUserMapper.selectOne(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<SysUser>()
                        .eq(SysUser::getUsername, "IMPORT_001"));
        assertNotNull(user);
        assertEquals("正常导入一", user.getRealName());
        assertEquals("student", user.getRole());
        assertEquals(1, user.getGender());
        assertEquals("13911112222", user.getPhone());

        Student student = studentMapper.selectOne(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<Student>()
                        .eq(Student::getStudentNo, "IMPORT_001"));
        assertNotNull(student);
        assertEquals(user.getId(), student.getUserId());
        assertEquals(LocalDate.of(2024, 9, 1), student.getEnrollDate());

        // 校验非法行未录入
        Student studentErr = studentMapper.selectOne(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<Student>()
                        .eq(Student::getStudentNo, "IMPORT_002"));
        assertNull(studentErr);
    }
}
