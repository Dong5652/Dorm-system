package com.dormsystem;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.dormsystem.dto.attendance.AttendanceSaveRequest;
import com.dormsystem.dto.hygiene.HygieneSaveRequest;
import com.dormsystem.dto.score.DormScoreManualRequest;
import com.dormsystem.dto.score.DormScoreTriggerRequest;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.*;
import com.dormsystem.security.JwtAuthenticationToken;
import com.dormsystem.security.LoginUser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * 阶段六集成测试：卫生检查 / 考勤 / 月度评分 全链路。
 *
 * <p>核心校验：</p>
 * <ul>
 *   <li>卫生 score 自动按 100 + bonus − deduction 计算</li>
 *   <li>宿管跨楼栋操作被拒绝（FORBIDDEN）</li>
 *   <li>评分公式：total_score = hygiene_avg × 0.6 + (100 − late_count × 5) × 0.4</li>
 *   <li>level 映射：≥90 优秀 / 75–89 合格 / 60–74 待整改 / &lt;60 不合格</li>
 *   <li>手动触发评分任务后 dorm_score 表写入记录</li>
 *   <li>管理员手动补录后写入新值</li>
 * </ul>
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("local")
@Transactional
public class HygieneAttendanceScoreTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private ObjectMapper objectMapper;
    @Autowired private SysUserMapper sysUserMapper;
    @Autowired private BuildingMapper buildingMapper;
    @Autowired private FloorMapper floorMapper;
    @Autowired private RoomMapper roomMapper;
    @Autowired private BedMapper bedMapper;
    @Autowired private StudentMapper studentMapper;
    @Autowired private HygieneCheckMapper hygieneCheckMapper;
    @Autowired private AttendanceMapper attendanceMapper;
    @Autowired private DormScoreMapper dormScoreMapper;

    private SysUser adminUser;
    private SysUser dormManagerA;
    private SysUser dormManagerB;
    private Building buildingA;
    private Building buildingB;
    private Room roomA1;
    private Room roomA2;
    private Room roomB1;
    private Student studentInA;
    private Bed bedInA;

    @BeforeEach
    public void setUp() {
        // 1. 管理员
        adminUser = new SysUser();
        adminUser.setUsername("admin_phase6");
        adminUser.setPassword("123456");
        adminUser.setRealName("管理员6");
        adminUser.setRole("admin");
        adminUser.setGender(1);
        adminUser.setStatus(1);
        sysUserMapper.insert(adminUser);

        // 2. 宿管 A 管 building A，宿管 B 管 building B
        dormManagerA = new SysUser();
        dormManagerA.setUsername("dm_a_phase6");
        dormManagerA.setPassword("123456");
        dormManagerA.setRealName("宿管A");
        dormManagerA.setRole("dorm_manager");
        dormManagerA.setGender(1);
        dormManagerA.setStatus(1);
        sysUserMapper.insert(dormManagerA);

        dormManagerB = new SysUser();
        dormManagerB.setUsername("dm_b_phase6");
        dormManagerB.setPassword("123456");
        dormManagerB.setRealName("宿管B");
        dormManagerB.setRole("dorm_manager");
        dormManagerB.setGender(2);
        dormManagerB.setStatus(1);
        sysUserMapper.insert(dormManagerB);

        buildingA = new Building();
        buildingA.setCode("PHA_A");
        buildingA.setName("A栋");
        buildingA.setGender(1);
        buildingA.setFloorCount(1);
        buildingA.setManagerId(dormManagerA.getId());
        buildingMapper.insert(buildingA);
        dormManagerA.setBuildingId(buildingA.getId());
        sysUserMapper.updateById(dormManagerA);

        buildingB = new Building();
        buildingB.setCode("PHA_B");
        buildingB.setName("B栋");
        buildingB.setGender(2);
        buildingB.setFloorCount(1);
        buildingB.setManagerId(dormManagerB.getId());
        buildingMapper.insert(buildingB);
        dormManagerB.setBuildingId(buildingB.getId());
        sysUserMapper.updateById(dormManagerB);

        Floor fA = new Floor();
        fA.setBuildingId(buildingA.getId());
        fA.setFloorNo(1);
        fA.setRoomCount(2);
        floorMapper.insert(fA);

        Floor fB = new Floor();
        fB.setBuildingId(buildingB.getId());
        fB.setFloorNo(1);
        fB.setRoomCount(1);
        floorMapper.insert(fB);

        roomA1 = new Room();
        roomA1.setBuildingId(buildingA.getId());
        roomA1.setFloorId(fA.getId());
        roomA1.setRoomNo("101");
        roomA1.setCapacity(4);
        roomA1.setOccupiedCount(0);
        roomA1.setStatus(0);
        roomMapper.insert(roomA1);

        roomA2 = new Room();
        roomA2.setBuildingId(buildingA.getId());
        roomA2.setFloorId(fA.getId());
        roomA2.setRoomNo("102");
        roomA2.setCapacity(4);
        roomA2.setOccupiedCount(0);
        roomA2.setStatus(0);
        roomMapper.insert(roomA2);

        roomB1 = new Room();
        roomB1.setBuildingId(buildingB.getId());
        roomB1.setFloorId(fB.getId());
        roomB1.setRoomNo("101");
        roomB1.setCapacity(4);
        roomB1.setOccupiedCount(0);
        roomB1.setStatus(0);
        roomMapper.insert(roomB1);

        bedInA = new Bed();
        bedInA.setRoomId(roomA1.getId());
        bedInA.setBedNo("1");
        bedInA.setStatus(0);
        bedMapper.insert(bedInA);

        // 3. 学生 + 入住房间
        SysUser su = new SysUser();
        su.setUsername("stu_phase6");
        su.setPassword("123456");
        su.setRealName("学生A");
        su.setRole("student");
        su.setGender(1);
        su.setStatus(1);
        sysUserMapper.insert(su);

        studentInA = new Student();
        studentInA.setUserId(su.getId());
        studentInA.setStudentNo("stu_phase6");
        studentInA.setName("学生A");
        studentInA.setGender(1);
        studentInA.setStatus(0);
        studentInA.setGrade("2024");
        studentInA.setCurrentBedId(bedInA.getId());
        studentMapper.insert(studentInA);

        bedInA.setStudentId(studentInA.getId());
        bedInA.setStatus(1);
        bedMapper.updateById(bedInA);

        // 默认以 admin 身份调用
        loginAs(adminUser);
    }

    private void loginAs(SysUser user) {
        LoginUser loginUser = new LoginUser(user);
        JwtAuthenticationToken auth = new JwtAuthenticationToken(loginUser, null, loginUser.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(auth);
    }

    @Test
    public void testHygieneCreateWithAutoScore() throws Exception {
        HygieneSaveRequest req = new HygieneSaveRequest();
        req.setRoomId(roomA1.getId());
        req.setCheckDate(LocalDate.of(2026, 3, 15));
        req.setDeduction(new BigDecimal("8.0"));
        req.setBonus(new BigDecimal("2.0"));
        req.setItemDetail("[{\"item\":\"地面\",\"type\":\"deduct\",\"value\":8}]");
        req.setRemark("整体尚可");

        mockMvc.perform(post("/api/v1/dorm/hygiene")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.score").value(94.0));

        // 校验 DB
        HygieneCheck saved = hygieneCheckMapper.selectList(null).get(0);
        assertEquals(new BigDecimal("94.00"), saved.getScore());
        assertEquals(new BigDecimal("8.00"), saved.getDeduction());
        assertEquals(new BigDecimal("2.00"), saved.getBonus());
        assertEquals(adminUser.getId(), saved.getInspectorId());
    }

    @Test
    public void testHygieneDormManagerCrossBuildingRejected() throws Exception {
        loginAs(dormManagerB);
        HygieneSaveRequest req = new HygieneSaveRequest();
        req.setRoomId(roomA1.getId()); // A 栋房间
        req.setCheckDate(LocalDate.of(2026, 3, 15));
        req.setDeduction(new BigDecimal("5.0"));

        mockMvc.perform(post("/api/v1/dorm/hygiene")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value(40301));
    }

    @Test
    public void testHygieneDormManagerOwnBuildingOk() throws Exception {
        loginAs(dormManagerA);
        HygieneSaveRequest req = new HygieneSaveRequest();
        req.setRoomId(roomA1.getId());
        req.setCheckDate(LocalDate.of(2026, 3, 15));
        req.setDeduction(new BigDecimal("5.0"));

        mockMvc.perform(post("/api/v1/dorm/hygiene")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.score").value(95.0));
    }

    @Test
    public void testStudentCanOnlySeeOwnRoomHygiene() throws Exception {
        // 在 A1 房间和B1房间都插入卫生记录
        HygieneCheck hA = new HygieneCheck();
        hA.setRoomId(roomA1.getId());
        hA.setCheckDate(LocalDate.of(2026, 3, 10));
        hA.setInspectorId(adminUser.getId());
        hA.setScore(new BigDecimal("90.00"));
        hA.setDeduction(new BigDecimal("10.00"));
        hA.setBonus(BigDecimal.ZERO);
        hygieneCheckMapper.insert(hA);

        HygieneCheck hB = new HygieneCheck();
        hB.setRoomId(roomB1.getId());
        hB.setCheckDate(LocalDate.of(2026, 3, 10));
        hB.setInspectorId(adminUser.getId());
        hB.setScore(new BigDecimal("80.00"));
        hB.setDeduction(new BigDecimal("20.00"));
        hB.setBonus(BigDecimal.ZERO);
        hygieneCheckMapper.insert(hB);

        // 学生登录：只能看到自己房间的 1 条
        SysUser stu = sysUserMapper.selectList(null).stream()
                .filter(u -> "stu_phase6".equals(u.getUsername())).findFirst().orElseThrow();
        loginAs(stu);

        mockMvc.perform(get("/api/v1/dorm/hygiene")
                .param("pageNum", "1")
                .param("pageSize", "20"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.records.size()").value(1))
                .andExpect(jsonPath("$.data.records[0].roomId").value(roomA1.getId()));
    }

    @Test
    public void testAttendanceCreateAndQuery() throws Exception {
        AttendanceSaveRequest req = new AttendanceSaveRequest();
        req.setStudentId(studentInA.getId());
        req.setRecordDate(LocalDate.of(2026, 3, 15));
        req.setType(1);
        req.setReturnTime(LocalDateTime.of(2026, 3, 16, 1, 30, 0));
        req.setRemark("校外兼职晚归");

        mockMvc.perform(post("/api/v1/dorm/attendance")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.roomId").value(roomA1.getId()));

        // 查询考勤列表 - 应能找到
        mockMvc.perform(get("/api/v1/dorm/attendance")
                .param("studentId", String.valueOf(studentInA.getId())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.records[0].type").value(1))
                .andExpect(jsonPath("$.data.records[0].studentNo").value("stu_phase6"));
    }

    @Test
    public void testDormScoreTriggerAndFormula() throws Exception {
        // 1. 给 A1 房间插入 2 次卫生检查：90 + 95 → avg 92.5
        HygieneCheck h1 = new HygieneCheck();
        h1.setRoomId(roomA1.getId());
        h1.setCheckDate(LocalDate.of(2026, 3, 10));
        h1.setInspectorId(adminUser.getId());
        h1.setScore(new BigDecimal("90.00"));
        h1.setDeduction(new BigDecimal("10.00"));
        h1.setBonus(BigDecimal.ZERO);
        hygieneCheckMapper.insert(h1);

        HygieneCheck h2 = new HygieneCheck();
        h2.setRoomId(roomA1.getId());
        h2.setCheckDate(LocalDate.of(2026, 3, 20));
        h2.setInspectorId(adminUser.getId());
        h2.setScore(new BigDecimal("95.00"));
        h2.setDeduction(new BigDecimal("5.00"));
        h2.setBonus(BigDecimal.ZERO);
        hygieneCheckMapper.insert(h2);

        // 2. 给 A1 房间 2 次晚归记录
        Attendance a1 = new Attendance();
        a1.setStudentId(studentInA.getId());
        a1.setRoomId(roomA1.getId());
        a1.setRecordDate(LocalDate.of(2026, 3, 5));
        a1.setType(1);
        a1.setInspectorId(adminUser.getId());
        attendanceMapper.insert(a1);

        Attendance a2 = new Attendance();
        a2.setStudentId(studentInA.getId());
        a2.setRoomId(roomA1.getId());
        a2.setRecordDate(LocalDate.of(2026, 3, 8));
        a2.setType(2);
        a2.setInspectorId(adminUser.getId());
        attendanceMapper.insert(a2);

        // 3. 手动触发评分
        DormScoreTriggerRequest trig = new DormScoreTriggerRequest();
        trig.setYearMonth("2026-03");
        mockMvc.perform(post("/api/v1/admin/dorm/scores/trigger")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(trig)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.yearMonth").value("2026-03"))
                .andExpect(jsonPath("$.data.affected").exists());

        // 4. 校验 DB：A1 房间评分应符合公式
        DormScore a1Score = dormScoreMapper.selectList(null).stream()
                .filter(s -> s.getRoomId().equals(roomA1.getId()))
                .findFirst().orElseThrow();
        // hygiene_avg = (90+95)/2 = 92.5
        // late_count = 2
        // total = 92.5*0.6 + (100 - 2*5)*0.4 = 55.5 + 36 = 91.5
        assertEquals(new BigDecimal("92.50"), a1Score.getHygieneAvg());
        assertEquals(2, a1Score.getLateCount());
        assertEquals(new BigDecimal("91.50"), a1Score.getTotalScore());
        assertEquals("优秀", a1Score.getLevel()); // ≥90 优秀
    }

    @Test
    public void testDormScoreLevelMapping() throws Exception {
        // 测试 4 个 level 阈值
        BigDecimal[] scores = {
                new BigDecimal("90.00"),  // 优秀
                new BigDecimal("89.99"),  // 合格
                new BigDecimal("75.00"),  // 合格
                new BigDecimal("74.99"),  // 待整改
                new BigDecimal("60.00"),  // 待整改
                new BigDecimal("59.99"),  // 不合格
        };
        String[] expectedLevels = {"优秀", "合格", "合格", "待整改", "待整改", "不合格"};
        for (int i = 0; i < scores.length; i++) {
            assertEquals(expectedLevels[i], com.dormsystem.service.DormScoreService.calcLevel(scores[i]),
                    "score=" + scores[i]);
        }
    }

    @Test
    public void testDormScoreManualOverride() throws Exception {
        // 1. 先触发一次评分生成基线
        DormScoreTriggerRequest trig = new DormScoreTriggerRequest();
        trig.setYearMonth("2026-03");
        mockMvc.perform(post("/api/v1/admin/dorm/scores/trigger")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(trig)))
                .andExpect(status().isOk());

        // 2. 手动补录：把 A1 房间改为 95 分
        DormScoreManualRequest manual = new DormScoreManualRequest();
        manual.setRoomId(roomA1.getId());
        manual.setYearMonth("2026-03");
        manual.setHygieneAvg(new BigDecimal("95.00"));
        manual.setLateCount(0);
        manual.setTotalScore(new BigDecimal("95.00"));
        manual.setLevel("优秀");
        manual.setRemark("管理员修正");

        mockMvc.perform(post("/api/v1/admin/dorm/scores/manual")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(manual)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.totalScore").value(95.00));

        // 3. 校验 DB
        DormScore updated = dormScoreMapper.selectList(null).stream()
                .filter(s -> s.getRoomId().equals(roomA1.getId()))
                .findFirst().orElseThrow();
        assertEquals(new BigDecimal("95.00"), updated.getTotalScore());
        assertEquals("优秀", updated.getLevel());
        assertEquals("管理员修正", updated.getRemark());
    }

    @Test
    public void testDormScoreRankingSortedDesc() throws Exception {
        // A1 房间 90 分，A2 房间 80 分
        HygieneCheck h1 = new HygieneCheck();
        h1.setRoomId(roomA1.getId());
        h1.setCheckDate(LocalDate.of(2026, 3, 10));
        h1.setInspectorId(adminUser.getId());
        h1.setScore(new BigDecimal("90.00"));
        h1.setDeduction(new BigDecimal("10.00"));
        h1.setBonus(BigDecimal.ZERO);
        hygieneCheckMapper.insert(h1);

        HygieneCheck h2 = new HygieneCheck();
        h2.setRoomId(roomA2.getId());
        h2.setCheckDate(LocalDate.of(2026, 3, 10));
        h2.setInspectorId(adminUser.getId());
        h2.setScore(new BigDecimal("80.00"));
        h2.setDeduction(new BigDecimal("20.00"));
        h2.setBonus(BigDecimal.ZERO);
        hygieneCheckMapper.insert(h2);

        DormScoreTriggerRequest trig = new DormScoreTriggerRequest();
        trig.setYearMonth("2026-03");
        mockMvc.perform(post("/api/v1/admin/dorm/scores/trigger")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(trig)))
                .andExpect(status().isOk());

        // 查询 A 栋范围 - A1 应该排第一
        mockMvc.perform(get("/api/v1/dorm/scores")
                .param("yearMonth", "2026-03")
                .param("buildingId", String.valueOf(buildingA.getId())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.list[0].rank").value(1))
                .andExpect(jsonPath("$.data.list[0].totalScore").value(94.00)) // 90*0.6 + 100*0.4
                .andExpect(jsonPath("$.data.list[0].level").value("优秀"));
    }
}
