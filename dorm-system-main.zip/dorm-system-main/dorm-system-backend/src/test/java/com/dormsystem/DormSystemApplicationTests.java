package com.dormsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * 上下文加载测试，确保 Spring 配置能正常启动（Phase 1 起的最小验证）。
 */
@SpringBootTest
class DormSystemApplicationTests {

    @Test
    void contextLoads() {
        // 仅验证应用上下文能装配完成
    }
}
