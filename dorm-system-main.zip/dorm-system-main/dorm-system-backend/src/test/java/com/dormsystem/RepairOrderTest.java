package com.dormsystem;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.dormsystem.dto.repair.AssignRequest;
import com.dormsystem.dto.repair.FinishRequest;
import com.dormsystem.dto.repair.RateRequest;
import com.dormsystem.dto.repair.RepairCreateRequest;
import com.dormsystem.dto.repair.RepairmanSaveRequest;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.*;
import com.dormsystem.security.LoginUser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.RequestPostProcessor;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * 阶段七集成测试：维修工单流转 + 维修师傅账号管理。
 *
 * <p>核心校验：</p>
 * <ul>
 *   <li>学生报修后看到自己工单 status=0</li>
 *   <li>管理员派单后工单流转到 status=1，assigned_at 写入</li>
 *   <li>维修师傅只能看到分配给自己的工单</li>
 *   <li>师傅接单后 status=2，完工后 status=3 + finished_at</li>
 *   <li>学生评价后 rating 写入，重复评分被拒绝</li>
 *   <li>各角色看到的列表范围符合权限规则</li>
 * </ul>
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("local")
@Transactional
public class RepairOrderTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private ObjectMapper objectMapper;
    @Autowired private SysUserMapper sysUserMapper;
    @Autowired private BuildingMapper buildingMapper;
    @Autowired private FloorMapper floorMapper;
    @Autowired private RoomMapper roomMapper;
    @Autowired private BedMapper bedMapper;
    @Autowired private StudentMapper studentMapper;
    @Autowired private RepairOrderMapper repairOrderMapper;

    private SysUser adminUser;
    private SysUser dormManagerA;
    private SysUser dormManagerB;
    private SysUser repairman1;
    private SysUser repairman2;
    private SysUser studentUser;
    private Student studentInA;
    private Building buildingA;
    private Building buildingB;
    private Room roomA1;
    private Room roomB1;
    private Bed bedInA;

    /** 当前登录用户（供 perform().with(auth()) 注入 SecurityContext）。 */
    private LoginUser currentLoginUser;

    @BeforeEach
    public void setUp() {
        // 1. 管理员
        adminUser = new SysUser();
        adminUser.setUsername("admin_phase7");
        adminUser.setPassword("123456");
        adminUser.setRealName("管理员7");
        adminUser.setRole("admin");
        adminUser.setGender(1);
        adminUser.setStatus(1);
        sysUserMapper.insert(adminUser);

        // 2. 宿管 A 管 building A，宿管 B 管 building B
        dormManagerA = new SysUser();
        dormManagerA.setUsername("dm_a_phase7");
        dormManagerA.setPassword("123456");
        dormManagerA.setRealName("宿管A7");
        dormManagerA.setRole("dorm_manager");
        dormManagerA.setGender(1);
        dormManagerA.setStatus(1);
        sysUserMapper.insert(dormManagerA);

        dormManagerB = new SysUser();
        dormManagerB.setUsername("dm_b_phase7");
        dormManagerB.setPassword("123456");
        dormManagerB.setRealName("宿管B7");
        dormManagerB.setRole("dorm_manager");
        dormManagerB.setGender(2);
        dormManagerB.setStatus(1);
        sysUserMapper.insert(dormManagerB);

        buildingA = new Building();
        buildingA.setCode("PH7_A");
        buildingA.setName("A栋7");
        buildingA.setGender(1);
        buildingA.setFloorCount(1);
        buildingA.setManagerId(dormManagerA.getId());
        buildingMapper.insert(buildingA);
        dormManagerA.setBuildingId(buildingA.getId());
        sysUserMapper.updateById(dormManagerA);

        buildingB = new Building();
        buildingB.setCode("PH7_B");
        buildingB.setName("B栋7");
        buildingB.setGender(2);
        buildingB.setFloorCount(1);
        buildingB.setManagerId(dormManagerB.getId());
        buildingMapper.insert(buildingB);
        dormManagerB.setBuildingId(buildingB.getId());
        sysUserMapper.updateById(dormManagerB);

        Floor fA = new Floor();
        fA.setBuildingId(buildingA.getId());
        fA.setFloorNo(1);
        fA.setRoomCount(1);
        floorMapper.insert(fA);

        Floor fB = new Floor();
        fB.setBuildingId(buildingB.getId());
        fB.setFloorNo(1);
        fB.setRoomCount(1);
        floorMapper.insert(fB);

        roomA1 = new Room();
        roomA1.setBuildingId(buildingA.getId());
        roomA1.setFloorId(fA.getId());
        roomA1.setRoomNo("101");
        roomA1.setCapacity(4);
        roomA1.setOccupiedCount(0);
        roomA1.setStatus(0);
        roomMapper.insert(roomA1);

        roomB1 = new Room();
        roomB1.setBuildingId(buildingB.getId());
        roomB1.setFloorId(fB.getId());
        roomB1.setRoomNo("101");
        roomB1.setCapacity(4);
        roomB1.setOccupiedCount(0);
        roomB1.setStatus(0);
        roomMapper.insert(roomB1);

        bedInA = new Bed();
        bedInA.setRoomId(roomA1.getId());
        bedInA.setBedNo("1");
        bedInA.setStatus(0);
        bedMapper.insert(bedInA);

        // 3. 学生 + 入住房间 A1
        studentUser = new SysUser();
        studentUser.setUsername("stu_phase7");
        studentUser.setPassword("123456");
        studentUser.setRealName("学生A7");
        studentUser.setRole("student");
        studentUser.setGender(1);
        studentUser.setStatus(1);
        sysUserMapper.insert(studentUser);

        studentInA = new Student();
        studentInA.setUserId(studentUser.getId());
        studentInA.setStudentNo("stu_phase7");
        studentInA.setName("学生A7");
        studentInA.setGender(1);
        studentInA.setStatus(0);
        studentInA.setGrade("2024");
        studentInA.setCurrentBedId(bedInA.getId());
        studentMapper.insert(studentInA);

        bedInA.setStudentId(studentInA.getId());
        bedInA.setStatus(1);
        bedMapper.updateById(bedInA);

        // 4. 两个维修师傅
        repairman1 = new SysUser();
        repairman1.setUsername("repair_p7_1");
        repairman1.setPassword("123456");
        repairman1.setRealName("张师傅7");
        repairman1.setRole("repairman");
        repairman1.setGender(1);
        repairman1.setPhone("13800138007");
        repairman1.setWorkType("水电");
        repairman1.setStatus(1);
        sysUserMapper.insert(repairman1);

        repairman2 = new SysUser();
        repairman2.setUsername("repair_p7_2");
        repairman2.setPassword("123456");
        repairman2.setRealName("刘师傅7");
        repairman2.setRole("repairman");
        repairman2.setGender(1);
        repairman2.setPhone("13800138008");
        repairman2.setWorkType("综合");
        repairman2.setStatus(1);
        sysUserMapper.insert(repairman2);

        // 默认以 admin 身份调用
        loginAs(adminUser);
    }

    private void loginAs(SysUser user) {
        currentLoginUser = new LoginUser(user);
    }

    /**
     * 把 currentLoginUser 注入到当前 MockMvc 请求中。
     * <p>使用 SecurityMockMvcRequestPostProcessors.user() 而非直接操作 SecurityContextHolder，
     * 因为 Spring Security 6 的 SecurityContextHolderFilter 会在每次请求之间重置上下文，
     * 直接 setAuthentication 无法在同一测试方法内连续切换用户。</p>
     */
    private RequestPostProcessor auth() {
        return SecurityMockMvcRequestPostProcessors.user(currentLoginUser);
    }

    /**
     * 包装 mockMvc.perform，自动注入当前登录用户。
     * 所有请求都通过它发起，避免每次都写 .with(auth())。
     */
    private org.springframework.test.web.servlet.ResultActions perform(
            org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder builder) throws Exception {
        return mockMvc.perform(builder.with(auth()));
    }

    // ---- 工单流转测试 ----------------------------------------------------

    @Test
    public void testStudentCreateRepairOrderStatusZero() throws Exception {
        loginAs(studentUser);
        RepairCreateRequest req = new RepairCreateRequest();
        req.setRoomId(roomA1.getId());
        req.setBedId(bedInA.getId());
        req.setTitle("水龙头漏水");
        req.setDescription("302房1号床水龙头持续滴水");
        req.setPriority(1);

        perform(post("/api/v1/repair")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.status").value(0))
                .andExpect(jsonPath("$.data.reporterId").value(studentUser.getId()))
                .andExpect(jsonPath("$.data.orderNo").isNotEmpty());

        // 学生能看到自己工单
        perform(get("/api/v1/repair"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.records.size()").value(1))
                .andExpect(jsonPath("$.data.records[0].status").value(0));

        // 校验 DB
        RepairOrder saved = repairOrderMapper.selectList(null).get(0);
        assertEquals(0, saved.getStatus());
        assertEquals(studentUser.getId(), saved.getReporterId());
        assertTrue(saved.getOrderNo().startsWith("RP"));
    }

    @Test
    public void testAdminAssignTransitionsToStatusOne() throws Exception {
        // 1. 学生先报修
        loginAs(studentUser);
        RepairCreateRequest createReq = new RepairCreateRequest();
        createReq.setRoomId(roomA1.getId());
        createReq.setBedId(bedInA.getId());
        createReq.setTitle("空调不制冷");
        createReq.setPriority(0);
        String body = perform(post("/api/v1/repair")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(createReq)))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        Long orderId = objectMapper.readTree(body).at("/data/id").asLong();

        // 2. 管理员派单
        loginAs(adminUser);
        AssignRequest assignReq = new AssignRequest();
        assignReq.setRepairmanId(repairman1.getId());

        perform(post("/api/v1/admin/repair/" + orderId + "/assign")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(assignReq)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value(1))
                .andExpect(jsonPath("$.data.repairmanId").value(repairman1.getId()))
                .andExpect(jsonPath("$.data.assignedAt").isNotEmpty())
                .andExpect(jsonPath("$.data.assignedBy").value(adminUser.getId()));

        // 校验 DB
        RepairOrder saved = repairOrderMapper.selectById(orderId);
        assertEquals(1, saved.getStatus());
        assertEquals(repairman1.getId(), saved.getRepairmanId());
        assertNotNull(saved.getAssignedAt());
        assertEquals(adminUser.getId(), saved.getAssignedBy());
    }

    @Test
    public void testRepairmanCanOnlySeeOwnOrders() throws Exception {
        // 1. 创建两个工单，分别派给 repairman1 和 repairman2
        loginAs(studentUser);
        RepairCreateRequest req1 = new RepairCreateRequest();
        req1.setRoomId(roomA1.getId());
        req1.setBedId(bedInA.getId());
        req1.setTitle("灯坏");
        String body1 = perform(post("/api/v1/repair")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req1)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        Long orderId1 = objectMapper.readTree(body1).at("/data/id").asLong();

        RepairCreateRequest req2 = new RepairCreateRequest();
        req2.setRoomId(roomA1.getId());
        req2.setBedId(bedInA.getId());
        req2.setTitle("马桶堵");
        String body2 = perform(post("/api/v1/repair")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req2)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        Long orderId2 = objectMapper.readTree(body2).at("/data/id").asLong();

        // 2. 派单给不同师傅
        loginAs(adminUser);
        AssignRequest a1 = new AssignRequest();
        a1.setRepairmanId(repairman1.getId());
        perform(post("/api/v1/admin/repair/" + orderId1 + "/assign")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(a1)))
                .andExpect(status().isOk());

        AssignRequest a2 = new AssignRequest();
        a2.setRepairmanId(repairman2.getId());
        perform(post("/api/v1/admin/repair/" + orderId2 + "/assign")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(a2)))
                .andExpect(status().isOk());

        // 3. repairman1 查询：只能看到派给自己的 1 个
        loginAs(repairman1);
        perform(get("/api/v1/repair"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.records.size()").value(1))
                .andExpect(jsonPath("$.data.records[0].id").value(orderId1))
                .andExpect(jsonPath("$.data.records[0].repairmanId").value(repairman1.getId()));

        // 4. repairman2 查询：只能看到自己的 1 个
        loginAs(repairman2);
        perform(get("/api/v1/repair"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.records.size()").value(1))
                .andExpect(jsonPath("$.data.records[0].id").value(orderId2));

        // 5. repairman1 不能查看 repairman2 的工单详情
        loginAs(repairman1);
        perform(get("/api/v1/repair/" + orderId2))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value(40301));
    }

    @Test
    public void testRepairmanStartAndFinishFlow() throws Exception {
        // 1. 报修 + 派单
        loginAs(studentUser);
        RepairCreateRequest req = new RepairCreateRequest();
        req.setRoomId(roomA1.getId());
        req.setBedId(bedInA.getId());
        req.setTitle("水管漏水");
        String body = perform(post("/api/v1/repair")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        Long orderId = objectMapper.readTree(body).at("/data/id").asLong();

        loginAs(adminUser);
        AssignRequest a = new AssignRequest();
        a.setRepairmanId(repairman1.getId());
        perform(post("/api/v1/admin/repair/" + orderId + "/assign")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(a)))
                .andExpect(status().isOk());

        // 2. 师傅接单 → status=2
        loginAs(repairman1);
        perform(put("/api/v1/repair/" + orderId + "/start"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value(2))
                .andExpect(jsonPath("$.data.startedAt").isNotEmpty());

        // 3. 师傅完工 → status=3 + finished_at + completion_note
        FinishRequest f = new FinishRequest();
        f.setCompletionNote("更换水龙头芯，已正常使用");
        perform(put("/api/v1/repair/" + orderId + "/finish")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(f)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value(3))
                .andExpect(jsonPath("$.data.finishedAt").isNotEmpty())
                .andExpect(jsonPath("$.data.completionNote").value("更换水龙头芯，已正常使用"));

        // 校验 DB
        RepairOrder saved = repairOrderMapper.selectById(orderId);
        assertEquals(3, saved.getStatus());
        assertNotNull(saved.getStartedAt());
        assertNotNull(saved.getFinishedAt());
    }

    @Test
    public void testStudentRateAndRejectRepeatedRating() throws Exception {
        // 1. 走完整流程到 status=3
        loginAs(studentUser);
        RepairCreateRequest req = new RepairCreateRequest();
        req.setRoomId(roomA1.getId());
        req.setBedId(bedInA.getId());
        req.setTitle("门锁坏");
        String body = perform(post("/api/v1/repair")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        Long orderId = objectMapper.readTree(body).at("/data/id").asLong();

        loginAs(adminUser);
        AssignRequest a = new AssignRequest();
        a.setRepairmanId(repairman1.getId());
        perform(post("/api/v1/admin/repair/" + orderId + "/assign")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(a)))
                .andExpect(status().isOk());

        loginAs(repairman1);
        perform(put("/api/v1/repair/" + orderId + "/start"))
                .andExpect(status().isOk());
        FinishRequest f = new FinishRequest();
        f.setCompletionNote("换锁完成");
        perform(put("/api/v1/repair/" + orderId + "/finish")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(f)))
                .andExpect(status().isOk());

        // 2. 学生评价
        loginAs(studentUser);
        RateRequest r = new RateRequest();
        r.setRating(5);
        r.setRatingComment("响应及时");
        perform(put("/api/v1/repair/" + orderId + "/rate")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(r)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.rating").value(5))
                .andExpect(jsonPath("$.data.ratingComment").value("响应及时"));

        // 校验 DB
        RepairOrder saved = repairOrderMapper.selectById(orderId);
        assertEquals(5, saved.getRating());

        // 3. 重复评分被拒绝
        RateRequest r2 = new RateRequest();
        r2.setRating(3);
        r2.setRatingComment("改主意了");
        perform(put("/api/v1/repair/" + orderId + "/rate")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(r2)))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value(40901));

        // 校验 DB 仍是 5
        RepairOrder still = repairOrderMapper.selectById(orderId);
        assertEquals(5, still.getRating());
        assertEquals("响应及时", still.getRatingComment());
    }

    @Test
    public void testRoleBasedListScope() throws Exception {
        // 1. 学生在 A 楼报修 1 个
        loginAs(studentUser);
        RepairCreateRequest req1 = new RepairCreateRequest();
        req1.setRoomId(roomA1.getId());
        req1.setBedId(bedInA.getId());
        req1.setTitle("A栋学生报修");
        perform(post("/api/v1/repair")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req1)))
                .andExpect(status().isOk());

        // 2. 宿管 A 在 A 楼代学生报修 1 个
        loginAs(dormManagerA);
        RepairCreateRequest req2 = new RepairCreateRequest();
        req2.setRoomId(roomA1.getId());
        req2.setBedId(bedInA.getId());
        req2.setTitle("宿管A代报修");
        perform(post("/api/v1/repair")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req2)))
                .andExpect(status().isOk());

        // 3. 宿管 B 在 B 楼报修 1 个
        loginAs(dormManagerB);
        RepairCreateRequest req3 = new RepairCreateRequest();
        req3.setRoomId(roomB1.getId());
        req3.setTitle("B栋报修");
        perform(post("/api/v1/repair")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req3)))
                .andExpect(status().isOk());

        // 4. 管理员看 → 3 个
        loginAs(adminUser);
        perform(get("/api/v1/repair"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.records.size()").value(3));

        // 5. 宿管 A 看 → 只有 A 楼的 2 个
        loginAs(dormManagerA);
        perform(get("/api/v1/repair"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.records.size()").value(2));
        // 所有记录都属于 building A
        perform(get("/api/v1/repair"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.records[*].buildingId").value(
                        org.hamcrest.Matchers.everyItem(org.hamcrest.Matchers.equalTo(buildingA.getId().intValue()))));

        // 6. 宿管 B 看 → 只有 B 楼的 1 个
        loginAs(dormManagerB);
        perform(get("/api/v1/repair"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.records.size()").value(1))
                .andExpect(jsonPath("$.data.records[0].buildingId").value(buildingB.getId()));

        // 7. 学生看 → 只能看到自己发起的 1 个
        loginAs(studentUser);
        perform(get("/api/v1/repair"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.records.size()").value(1))
                .andExpect(jsonPath("$.data.records[0].title").value("A栋学生报修"));

        // 8. 师傅看 → 还没派单，0 个
        loginAs(repairman1);
        perform(get("/api/v1/repair"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.records.size()").value(0));
    }

    @Test
    public void testCancelOrderAndStatusFlowConstraint() throws Exception {
        // 学生报修
        loginAs(studentUser);
        RepairCreateRequest req = new RepairCreateRequest();
        req.setRoomId(roomA1.getId());
        req.setBedId(bedInA.getId());
        req.setTitle("窗帘坏");
        String body = perform(post("/api/v1/repair")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        Long orderId = objectMapper.readTree(body).at("/data/id").asLong();

        // 学生取消
        perform(put("/api/v1/repair/" + orderId + "/cancel"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value(4));

        // 已取消的工单不可再派单
        loginAs(adminUser);
        AssignRequest a = new AssignRequest();
        a.setRepairmanId(repairman1.getId());
        perform(post("/api/v1/admin/repair/" + orderId + "/assign")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(a)))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value(40901));
    }

    @Test
    public void testStudentCannotReportForOtherRoom() throws Exception {
        loginAs(studentUser);
        RepairCreateRequest req = new RepairCreateRequest();
        req.setRoomId(roomB1.getId()); // 学生住在 A 楼，无权报修 B 楼
        req.setTitle("越权报修");
        perform(post("/api/v1/repair")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value(40301));
    }

    @Test
    public void testAssignToNonRepairmanRejected() throws Exception {
        loginAs(studentUser);
        RepairCreateRequest req = new RepairCreateRequest();
        req.setRoomId(roomA1.getId());
        req.setBedId(bedInA.getId());
        req.setTitle("测试派单给非师傅");
        String body = perform(post("/api/v1/repair")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        Long orderId = objectMapper.readTree(body).at("/data/id").asLong();

        loginAs(adminUser);
        AssignRequest a = new AssignRequest();
        a.setRepairmanId(dormManagerA.getId()); // 宿管不是维修师傅
        perform(post("/api/v1/admin/repair/" + orderId + "/assign")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(a)))
                .andExpect(status().is4xxClientError())
                .andExpect(jsonPath("$.code").value(40001));
    }

    // ---- 维修师傅账号管理测试 ---------------------------------------------

    @Test
    public void testRepairmanCRUD() throws Exception {
        // 1. 列表：种子 2 个（repair001 / repair002） + 测试 setUp 创建 2 个（repair_p7_1 / repair_p7_2）
        loginAs(adminUser);
        perform(get("/api/v1/admin/repairmen"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.size()").value(4));

        // 2. 新增师傅
        RepairmanSaveRequest create = new RepairmanSaveRequest();
        create.setUsername("repair_new_p7");
        create.setRealName("新师傅");
        create.setGender(1);
        create.setPhone("13900139000");
        create.setWorkType("木工");
        create.setStatus(1);
        String body = perform(post("/api/v1/admin/repairmen")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(create)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.id").isNotEmpty())
                .andExpect(jsonPath("$.data.workType").value("木工"))
                .andReturn().getResponse().getContentAsString();
        Long newId = objectMapper.readTree(body).at("/data/id").asLong();

        // 3. 修改
        RepairmanSaveRequest upd = new RepairmanSaveRequest();
        upd.setUsername("repair_new_p7"); // username 传相同值
        upd.setRealName("新师傅改名");
        upd.setGender(1);
        upd.setPhone("13900139001");
        upd.setWorkType("综合");
        upd.setStatus(1);
        perform(put("/api/v1/admin/repairmen/" + newId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(upd)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.realName").value("新师傅改名"))
                .andExpect(jsonPath("$.data.workType").value("综合"));

        // 4. 删除（无未完结工单，应允许）
        perform(delete("/api/v1/admin/repairmen/" + newId))
                .andExpect(status().isOk());

        // 5. 删除后查不到
        perform(get("/api/v1/admin/repairmen/" + newId))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value(40401));
    }

    @Test
    public void testRepairmanDeleteBlockedIfPendingOrder() throws Exception {
        // 1. 给 repairman1 派一个工单
        loginAs(studentUser);
        RepairCreateRequest req = new RepairCreateRequest();
        req.setRoomId(roomA1.getId());
        req.setBedId(bedInA.getId());
        req.setTitle("pending block test");
        String body = perform(post("/api/v1/repair")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        Long orderId = objectMapper.readTree(body).at("/data/id").asLong();

        loginAs(adminUser);
        AssignRequest a = new AssignRequest();
        a.setRepairmanId(repairman1.getId());
        perform(post("/api/v1/admin/repair/" + orderId + "/assign")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(a)))
                .andExpect(status().isOk());

        // 2. 删除师傅应被拒绝
        perform(delete("/api/v1/admin/repairmen/" + repairman1.getId()))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value(40901));
    }
}
