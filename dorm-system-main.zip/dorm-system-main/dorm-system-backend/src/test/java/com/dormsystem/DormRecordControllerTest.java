package com.dormsystem;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.dormsystem.dto.record.CheckInRequest;
import com.dormsystem.dto.record.CheckOutRequest;
import com.dormsystem.dto.record.ChangeRoomRequest;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.*;
import com.dormsystem.security.LoginUser;
import com.dormsystem.security.JwtAuthenticationToken;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("local")
@Transactional
public class DormRecordControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private StudentMapper studentMapper;

    @Autowired
    private BedMapper bedMapper;

    @Autowired
    private RoomMapper roomMapper;

    @Autowired
    private BuildingMapper buildingMapper;

    @Autowired
    private FloorMapper floorMapper;

    @Autowired
    private SysUserMapper sysUserMapper;

    private Student maleStudent;
    private Student femaleStudent;
    private Building maleBuilding;
    private Building femaleBuilding;
    private Room maleRoom;
    private Room femaleRoom;
    private Bed maleBed;
    private Bed femaleBed;

    @BeforeEach
    public void setUp() {
        // 1. 初始化系统账户
        SysUser u1 = new SysUser();
        u1.setUsername("MALE_ST_001");
        u1.setPassword("123456");
        u1.setRealName("男生一");
        u1.setRole("student");
        u1.setGender(1);
        u1.setStatus(1);
        sysUserMapper.insert(u1);

        SysUser u2 = new SysUser();
        u2.setUsername("FEMALE_ST_001");
        u2.setPassword("123456");
        u2.setRealName("女生一");
        u2.setRole("student");
        u2.setGender(2);
        u2.setStatus(1);
        sysUserMapper.insert(u2);

        // 2. 初始化学生档案
        maleStudent = new Student();
        maleStudent.setUserId(u1.getId());
        maleStudent.setStudentNo("MALE_ST_001");
        maleStudent.setName("男生一");
        maleStudent.setGender(1);
        maleStudent.setStatus(0);
        maleStudent.setGrade("2024");
        studentMapper.insert(maleStudent);

        femaleStudent = new Student();
        femaleStudent.setUserId(u2.getId());
        femaleStudent.setStudentNo("FEMALE_ST_001");
        femaleStudent.setName("女生一");
        femaleStudent.setGender(2);
        femaleStudent.setStatus(0);
        femaleStudent.setGrade("2024");
        studentMapper.insert(femaleStudent);

        // 3. 初始化男生楼栋 + 楼层 + 房间 + 床位
        maleBuilding = new Building();
        maleBuilding.setCode("BUILD_M");
        maleBuilding.setName("男生楼栋");
        maleBuilding.setGender(1); // 男生楼
        maleBuilding.setFloorCount(1);
        buildingMapper.insert(maleBuilding);

        Floor f1 = new Floor();
        f1.setBuildingId(maleBuilding.getId());
        f1.setFloorNo(1);
        f1.setRoomCount(1);
        floorMapper.insert(f1);

        maleRoom = new Room();
        maleRoom.setBuildingId(maleBuilding.getId());
        maleRoom.setFloorId(f1.getId());
        maleRoom.setRoomNo("101");
        maleRoom.setCapacity(4);
        maleRoom.setOccupiedCount(0);
        maleRoom.setStatus(0);
        roomMapper.insert(maleRoom);

        maleBed = new Bed();
        maleBed.setRoomId(maleRoom.getId());
        maleBed.setBedNo("1");
        maleBed.setStatus(0);
        bedMapper.insert(maleBed);

        // 4. 初始化女生楼栋 + 楼层 + 房间 + 床位
        femaleBuilding = new Building();
        femaleBuilding.setCode("BUILD_F");
        femaleBuilding.setName("女生楼栋");
        femaleBuilding.setGender(2); // 女生楼
        femaleBuilding.setFloorCount(1);
        buildingMapper.insert(femaleBuilding);

        Floor f2 = new Floor();
        f2.setBuildingId(femaleBuilding.getId());
        f2.setFloorNo(1);
        f2.setRoomCount(1);
        floorMapper.insert(f2);

        femaleRoom = new Room();
        femaleRoom.setBuildingId(femaleBuilding.getId());
        femaleRoom.setFloorId(f2.getId());
        femaleRoom.setRoomNo("101");
        femaleRoom.setCapacity(4);
        femaleRoom.setOccupiedCount(0);
        femaleRoom.setStatus(0);
        roomMapper.insert(femaleRoom);

        femaleBed = new Bed();
        femaleBed.setRoomId(femaleRoom.getId());
        femaleBed.setBedNo("1");
        femaleBed.setStatus(0);
        bedMapper.insert(femaleBed);

        // 5. 初始化 mock 认证管理员用户
        SysUser operator = new SysUser();
        operator.setUsername("admin_op");
        operator.setPassword("123456");
        operator.setRealName("管理员");
        operator.setRole("admin");
        operator.setStatus(1);
        sysUserMapper.insert(operator);

        LoginUser loginUser = new LoginUser(operator);
        JwtAuthenticationToken auth = new JwtAuthenticationToken(loginUser, null, loginUser.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(auth);
    }

    @Test
    public void testCheckInSuccess() throws Exception {
        CheckInRequest req = new CheckInRequest();
        req.setStudentId(maleStudent.getId());
        req.setBedId(maleBed.getId());
        req.setKeyIssued(true);
        req.setFacilityCheck("无破损");
        req.setRemark("正常入住");

        mockMvc.perform(post("/api/v1/dorm/check-in")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0))
                .andExpect(jsonPath("$.data.bedId").value(maleBed.getId()));

        // 校验床位、房间和学生状态
        Bed b = bedMapper.selectById(maleBed.getId());
        assertEquals(1, b.getStatus());
        assertEquals(maleStudent.getId(), b.getStudentId());

        Room r = roomMapper.selectById(maleRoom.getId());
        assertEquals(1, r.getOccupiedCount());
        assertEquals(1, r.getStatus()); // 0空闲 1部分入住

        Student s = studentMapper.selectById(maleStudent.getId());
        assertEquals(maleBed.getId(), s.getCurrentBedId());
    }

    @Test
    public void testCheckInGenderMismatchRejected() throws Exception {
        // 尝试把男生分到女生寝室床位
        CheckInRequest req = new CheckInRequest();
        req.setStudentId(maleStudent.getId());
        req.setBedId(femaleBed.getId());
        req.setKeyIssued(true);

        mockMvc.perform(post("/api/v1/dorm/check-in")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.code").value(40901))
                .andExpect(jsonPath("$.message").value("性别不匹配，不能将男生分配到女生楼栋"));
    }

    @Test
    public void testCheckOutSuccess() throws Exception {
        // 1. 先人工入住
        maleStudent.setCurrentBedId(maleBed.getId());
        studentMapper.updateById(maleStudent);
        maleBed.setStatus(1);
        maleBed.setStudentId(maleStudent.getId());
        bedMapper.updateById(maleBed);
        maleRoom.setOccupiedCount(1);
        maleRoom.setStatus(1);
        roomMapper.updateById(maleRoom);

        // 2. 调用退宿
        CheckOutRequest req = new CheckOutRequest();
        req.setStudentId(maleStudent.getId());
        req.setKeyReturned(true);
        req.setFacilityCheck("良好");

        mockMvc.perform(post("/api/v1/dorm/check-out")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(0));

        // 3. 校验状态还原
        Bed b = bedMapper.selectById(maleBed.getId());
        assertEquals(0, b.getStatus());
        assertNull(b.getStudentId());

        Room r = roomMapper.selectById(maleRoom.getId());
        assertEquals(0, r.getOccupiedCount());
        assertEquals(0, r.getStatus());

        Student s = studentMapper.selectById(maleStudent.getId());
        assertNull(s.getCurrentBedId());
    }

    @Test
    public void testChangeRoomSuccess() throws Exception {
        // 1. 创建另一个空闲床位
        Bed targetBed = new Bed();
        targetBed.setRoomId(maleRoom.getId());
        targetBed.setBedNo("2");
        targetBed.setStatus(0);
        bedMapper.insert(targetBed);

        // 2. 学生先入住床位 1
        maleStudent.setCurrentBedId(maleBed.getId());
        studentMapper.updateById(maleStudent);
        maleBed.setStatus(1);
        maleBed.setStudentId(maleStudent.getId());
        bedMapper.updateById(maleBed);
        maleRoom.setOccupiedCount(1);
        maleRoom.setStatus(1);
        roomMapper.updateById(maleRoom);

        // 3. 申请调宿到床位 2
        ChangeRoomRequest req = new ChangeRoomRequest();
        req.setStudentId(maleStudent.getId());
        req.setFromBedId(maleBed.getId());
        req.setToBedId(targetBed.getId());
        req.setReason("正常调宿测试");

        mockMvc.perform(post("/api/v1/dorm/change-room")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk());

        // 4. 校验状态变化
        Bed bOld = bedMapper.selectById(maleBed.getId());
        assertEquals(0, bOld.getStatus());
        assertNull(bOld.getStudentId());

        Bed bNew = bedMapper.selectById(targetBed.getId());
        assertEquals(1, bNew.getStatus());
        assertEquals(maleStudent.getId(), bNew.getStudentId());

        Student s = studentMapper.selectById(maleStudent.getId());
        assertEquals(targetBed.getId(), s.getCurrentBedId());
    }
}
