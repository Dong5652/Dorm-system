package com.dormsystem;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.dormsystem.dto.safety.SafetyEventHandleRequest;
import com.dormsystem.dto.safety.SafetyEventRequest;
import com.dormsystem.dto.safety.SafetyInspectionRequest;
import com.dormsystem.dto.safety.VisitorRequest;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.*;
import com.dormsystem.security.JwtAuthenticationToken;
import com.dormsystem.security.LoginUser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("local")
@Transactional
public class SafetyControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private VisitorMapper visitorMapper;
    
    @Autowired
    private SafetyInspectionMapper safetyInspectionMapper;
    
    @Autowired
    private SafetyEventMapper safetyEventMapper;
    
    @Autowired
    private NoticeMessageMapper noticeMessageMapper;

    @Autowired
    private BuildingMapper buildingMapper;

    @Autowired
    private StudentMapper studentMapper;
    
    @Autowired
    private SysUserMapper sysUserMapper;

    private Building testBuilding;
    private Student testStudent;
    private SysUser testAdmin;

    @BeforeEach
    public void setUp() {
        testAdmin = new SysUser();
        testAdmin.setUsername("admin_safety");
        testAdmin.setPassword("123456");
        testAdmin.setRealName("安全管理员");
        testAdmin.setRole("admin");
        testAdmin.setStatus(1);
        sysUserMapper.insert(testAdmin);

        testBuilding = new Building();
        testBuilding.setCode("B_SAFETY");
        testBuilding.setName("安全测试楼");
        testBuilding.setGender(3);
        testBuilding.setFloorCount(5);
        buildingMapper.insert(testBuilding);

        SysUser studentUser = new SysUser();
        studentUser.setUsername("ST_SAFETY");
        studentUser.setPassword("123456");
        studentUser.setRealName("测试学生");
        studentUser.setRole("student");
        studentUser.setStatus(1);
        sysUserMapper.insert(studentUser);

        testStudent = new Student();
        testStudent.setUserId(studentUser.getId());
        testStudent.setStudentNo("ST_SAFETY");
        testStudent.setName("测试学生");
        testStudent.setGender(1);
        studentMapper.insert(testStudent);

        LoginUser loginUser = new LoginUser(testAdmin);
        JwtAuthenticationToken auth = new JwtAuthenticationToken(loginUser, null, loginUser.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(auth);
    }

    @Test
    public void testVisitorFlow() throws Exception {
        VisitorRequest req = new VisitorRequest();
        req.setVisitorName("张三");
        req.setIdCard("110105199001011234");
        req.setBuildingId(testBuilding.getId());
        req.setPurpose("探访");
        req.setEnterTime(LocalDateTime.now());

        mockMvc.perform(post("/api/v1/safety/visitor")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk());

        Visitor v = visitorMapper.selectList(null).get(0);
        assertEquals("张三", v.getVisitorName());
        assertNull(v.getExitTime());

        mockMvc.perform(put("/api/v1/safety/visitor/" + v.getId() + "/exit"))
                .andExpect(status().isOk());

        Visitor v2 = visitorMapper.selectById(v.getId());
        assertNotNull(v2.getExitTime());
    }

    @Test
    public void testInspectionNotice() throws Exception {
        SafetyInspectionRequest req = new SafetyInspectionRequest();
        req.setRoomId(1L); // Mock room ID
        req.setStudentId(testStudent.getId());
        req.setInspectDate(LocalDate.now());
        req.setItemType("大功率电器");
        req.setItemDesc("热得快");
        req.setDisposition("没收");
        req.setNoticeSent(true);

        mockMvc.perform(post("/api/v1/safety/inspection")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk());

        SafetyInspection si = safetyInspectionMapper.selectList(null).get(0);
        assertEquals("大功率电器", si.getItemType());
        
        NoticeMessage msg = noticeMessageMapper.selectList(null).get(0);
        assertEquals("rectify", msg.getMsgType());
        assertEquals(testStudent.getUserId(), msg.getToUserId());
        assertTrue(msg.getContent().contains("大功率电器"));
    }

    @Test
    public void testSafetyEventHandle() throws Exception {
        SafetyEventRequest req = new SafetyEventRequest();
        req.setBuildingId(testBuilding.getId());
        req.setEventType("火情");
        req.setSeverity(2);
        req.setDescription("测试火情");
        req.setHappenedAt(LocalDateTime.now());

        mockMvc.perform(post("/api/v1/safety/event")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk());

        SafetyEvent event = safetyEventMapper.selectList(null).get(0);
        assertEquals(0, event.getHandled());

        SafetyEventHandleRequest handleReq = new SafetyEventHandleRequest();
        handleReq.setHandleNote("已扑灭");

        mockMvc.perform(put("/api/v1/admin/safety/event/" + event.getId() + "/handle")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(handleReq)))
                .andExpect(status().isOk());

        SafetyEvent event2 = safetyEventMapper.selectById(event.getId());
        assertEquals(1, event2.getHandled());
        assertEquals("已扑灭", event2.getHandleNote());
    }
}
