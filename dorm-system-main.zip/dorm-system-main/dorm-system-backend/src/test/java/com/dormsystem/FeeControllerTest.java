package com.dormsystem;

import com.dormsystem.dto.fee.MeterReadingRequest;
import com.dormsystem.entity.SysUser;
import com.dormsystem.mapper.FeeMapper;
import com.dormsystem.mapper.MeterReadingMapper;
import com.dormsystem.mapper.SysUserMapper;
import com.dormsystem.security.JwtAuthenticationToken;
import com.dormsystem.security.LoginUser;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.RequestPostProcessor;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("local")
@Transactional
public class FeeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private SysUserMapper sysUserMapper;

    @Autowired
    private MeterReadingMapper meterReadingMapper;

    @Autowired
    private FeeMapper feeMapper;

    private LoginUser adminLoginUser;

    @BeforeEach
    public void setUp() {
        feeMapper.delete(null);
        meterReadingMapper.delete(null);

        SysUser adminUser = sysUserMapper.selectById(1L);
        if (adminUser == null) {
            adminUser = new SysUser();
            adminUser.setUsername("admin_fee_test");
            adminUser.setPassword("123456");
            adminUser.setRealName("费用测试管理员");
            adminUser.setRole("admin");
            adminUser.setStatus(1);
            sysUserMapper.insert(adminUser);
        }
        adminLoginUser = new LoginUser(adminUser);
        // 同步写入 SecurityContext，便于 Service 层 SecurityUtils 读取
        SecurityContextHolder.getContext().setAuthentication(
                new JwtAuthenticationToken(adminLoginUser, null, adminLoginUser.getAuthorities()));
    }

    private RequestPostProcessor auth() {
        return SecurityMockMvcRequestPostProcessors.user(adminLoginUser);
    }

    @Test
    public void testRecordMeterReadingAndGenerateFee() throws Exception {
        // 使用唯一月份，避免软删除后唯一键 uk_meter_room_type_month 冲突
        String month = "2099-12";
        MeterReadingRequest req = new MeterReadingRequest();
        req.setRoomId(1L);
        req.setMeterType(1); // Water
        req.setReadingValue(new BigDecimal("100.5"));
        req.setReadingMonth(month);

        mockMvc.perform(post("/api/v1/dorm/meter")
                        .with(auth())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk());

        String req2 = "{\"readingMonth\":\"" + month + "\"}";
        mockMvc.perform(post("/api/v1/admin/fee/utility/generate")
                        .with(auth())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(req2))
                .andExpect(status().isOk());
    }
}
