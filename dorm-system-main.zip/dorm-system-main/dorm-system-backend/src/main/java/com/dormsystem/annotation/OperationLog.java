package com.dormsystem.annotation;

import java.lang.annotation.*;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface OperationLog {
    String module() default "";
    String action() default "";
    /** 目标表名；为空时回退为 module */
    String targetTable() default "";
}
