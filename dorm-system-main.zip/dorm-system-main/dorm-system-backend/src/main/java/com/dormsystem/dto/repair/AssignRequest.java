package com.dormsystem.dto.repair;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/** 派单请求：指定维修师傅 user_id。 */
@Data
public class AssignRequest {

    @NotNull(message = "维修师傅ID不能为空")
    private Long repairmanId;
}
