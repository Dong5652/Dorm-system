package com.dormsystem.aspect;

import com.dormsystem.annotation.OperationLog;
import com.dormsystem.mapper.OperationLogMapper;
import com.dormsystem.security.LoginUser;
import com.dormsystem.security.SecurityUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.time.LocalDateTime;

@Aspect
@Component
@Slf4j
@RequiredArgsConstructor
public class OperationLogAspect {

    private final OperationLogMapper operationLogMapper;
    private final ObjectMapper objectMapper;

    @Around("@annotation(com.dormsystem.annotation.OperationLog)")
    public Object around(ProceedingJoinPoint point) throws Throwable {
        long beginTime = System.currentTimeMillis();
        try {
            return point.proceed();
        } finally {
            long time = System.currentTimeMillis() - beginTime;
            saveLog(point, time);
        }
    }

    private void saveLog(ProceedingJoinPoint joinPoint, long time) {
        try {
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            Method method = signature.getMethod();
            OperationLog annotation = method.getAnnotation(OperationLog.class);

            com.dormsystem.entity.OperationLog logEntity = new com.dormsystem.entity.OperationLog();
            String module = annotation != null && annotation.module() != null && !annotation.module().isBlank()
                    ? annotation.module() : "unknown";
            String action = annotation != null && annotation.action() != null && !annotation.action().isBlank()
                    ? annotation.action() : method.getName();
            logEntity.setModule(module);
            logEntity.setAction(action);
            // DDL: target_table NOT NULL —— 优先注解 targetTable，否则回退 module
            String targetTable = annotation != null && annotation.targetTable() != null && !annotation.targetTable().isBlank()
                    ? annotation.targetTable() : module;
            logEntity.setTargetTable(targetTable);

            Object[] args = joinPoint.getArgs();
            // 尝试从路径参数提取 targetId（常见第一个 Long 参数）
            if (args != null) {
                for (Object arg : args) {
                    if (arg instanceof Long id) {
                        logEntity.setTargetId(id);
                        break;
                    }
                }
            }

            // 仅记录摘要，避免把完整请求体（可能含 PII）写入审计日志
            StringBuilder summary = new StringBuilder();
            summary.append(signature.getDeclaringType().getSimpleName())
                    .append('.').append(method.getName())
                    .append(" | costMs=").append(time);
            if (args != null) {
                summary.append(" | argTypes=");
                for (int i = 0; i < args.length; i++) {
                    if (i > 0) summary.append(',');
                    Object arg = args[i];
                    summary.append(arg == null ? "null" : arg.getClass().getSimpleName());
                    if (arg instanceof Long id) {
                        summary.append('(').append(id).append(')');
                    }
                }
            }
            String detail = summary.toString();
            if (detail.length() > 500) {
                detail = detail.substring(0, 500);
            }
            logEntity.setDetail(detail);

            ServletRequestAttributes attrs = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attrs != null) {
                HttpServletRequest request = attrs.getRequest();
                logEntity.setIp(request.getRemoteAddr());
            }

            // JWT 注入的 principal 是 LoginUser，不是 SysUser
            try {
                logEntity.setOperatorId(SecurityUtils.currentUserId());
            } catch (Exception ex) {
                Object principal = null;
                if (org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication() != null) {
                    principal = org.springframework.security.core.context.SecurityContextHolder
                            .getContext().getAuthentication().getPrincipal();
                }
                if (principal instanceof LoginUser loginUser) {
                    logEntity.setOperatorId(loginUser.getUserId());
                } else {
                    // 无法识别操作人时不写日志，避免 NOT NULL 约束失败
                    log.warn("Skip operation log: operator not resolved for {}.{}",
                            joinPoint.getTarget().getClass().getSimpleName(), signature.getName());
                    return;
                }
            }

            logEntity.setCreatedAt(LocalDateTime.now());
            operationLogMapper.insert(logEntity);
        } catch (Exception e) {
            log.error("Failed to save operation log", e);
        }
    }
}
