package com.dormsystem;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * 学校宿舍管理系统后端入口。
 *
 * <p>Phase 1：脚手架 + /api/v1/ping 联调。</p>
 *
 * <p>Phase 6：开启 {@link EnableScheduling}，供 {@code DormScoreScheduler} 月度评分任务使用。</p>
 */
@SpringBootApplication
@MapperScan("com.dormsystem.mapper")
@EnableScheduling
public class DormSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(DormSystemApplication.class, args);
    }
}
