package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.dorm.FloorSaveRequest;
import com.dormsystem.entity.Building;
import com.dormsystem.entity.Floor;
import com.dormsystem.mapper.FloorMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/** 楼层服务。 */
@Service
@RequiredArgsConstructor
public class FloorService {

    private final FloorMapper floorMapper;
    private final BuildingService buildingService;

    public Page<Floor> page(int pageNum, int pageSize, Long buildingId) {
        // 宿管 scope 收敛:forcing buildingId 为本人楼栋;admin 传 null 不限
        Long scope = BuildingService.scopeBuildingId();
        Long effectiveBuildingId = scope != null ? scope : buildingId;
        if (scope != null && buildingId != null && !scope.equals(buildingId)) {
            throw new BusinessException(ResultCode.FORBIDDEN, "无权查看非本人楼栋的楼层");
        }
        Page<Floor> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Floor> w = new LambdaQueryWrapper<>();
        if (effectiveBuildingId != null) w.eq(Floor::getBuildingId, effectiveBuildingId);
        w.orderByAsc(Floor::getFloorNo);
        return floorMapper.selectPage(page, w);
    }

    public List<Floor> listByBuilding(Long buildingId) {
        Long scope = BuildingService.scopeBuildingId();
        if (scope != null && !scope.equals(buildingId)) {
            throw new BusinessException(ResultCode.FORBIDDEN, "无权查看非本人楼栋的楼层");
        }
        return floorMapper.selectList(
                new LambdaQueryWrapper<Floor>()
                        .eq(Floor::getBuildingId, buildingId)
                        .orderByAsc(Floor::getFloorNo));
    }

    public Floor get(Long id) {
        Floor f = floorMapper.selectById(id);
        if (f == null) throw new BusinessException(ResultCode.NOT_FOUND, "楼层不存在");
        Long scope = BuildingService.scopeBuildingId();
        if (scope != null && !scope.equals(f.getBuildingId())) {
            throw new BusinessException(ResultCode.FORBIDDEN, "无权访问该楼层");
        }
        return f;
    }

    public Floor create(FloorSaveRequest req) {
        Building b = buildingService.get(req.getBuildingId());
        ensureFloorNoUnique(b.getId(), req.getFloorNo(), null);
        Floor f = new Floor();
        f.setBuildingId(b.getId());
        f.setFloorNo(req.getFloorNo());
        f.setRoomCount(req.getRoomCount() == null ? 0 : req.getRoomCount());
        floorMapper.insert(f);
        return f;
    }

    public Floor update(Long id, FloorSaveRequest req) {
        Floor f = get(id);
        if (!f.getBuildingId().equals(req.getBuildingId())) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "不允许修改楼层所属楼栋");
        }
        if (!f.getFloorNo().equals(req.getFloorNo())) {
            ensureFloorNoUnique(req.getBuildingId(), req.getFloorNo(), id);
        }
        f.setFloorNo(req.getFloorNo());
        f.setRoomCount(req.getRoomCount());
        floorMapper.updateById(f);
        return f;
    }

    public void delete(Long id) {
        get(id);
        floorMapper.deleteById(id);
    }

    private void ensureFloorNoUnique(Long buildingId, Integer floorNo, Long excludeId) {
        LambdaQueryWrapper<Floor> w = new LambdaQueryWrapper<Floor>()
                .eq(Floor::getBuildingId, buildingId)
                .eq(Floor::getFloorNo, floorNo);
        if (excludeId != null) w.ne(Floor::getId, excludeId);
        Long cnt = floorMapper.selectCount(w);
        if (cnt != null && cnt > 0) {
            throw new BusinessException(ResultCode.CONFLICT, "该楼栋已存在此楼层号: " + floorNo);
        }
    }
}
