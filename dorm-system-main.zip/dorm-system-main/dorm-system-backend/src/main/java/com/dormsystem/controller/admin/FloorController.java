package com.dormsystem.controller.admin;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.Result;
import com.dormsystem.dto.dorm.FloorSaveRequest;
import com.dormsystem.entity.Floor;
import com.dormsystem.service.FloorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/** 楼层管理（API_SPEC §3.2）。 */
@Tag(name = "Admin · Floor", description = "楼层 CRUD（管理员）")
@RestController
@RequestMapping("/api/v1/admin/floors")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class FloorController {

    private final FloorService floorService;

    @Operation(summary = "楼层分页列表(按 building_id)")
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<Page<Floor>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) Long buildingId) {
        return Result.success(floorService.page(pageNum, pageSize, buildingId));
    }

    @Operation(summary = "新增楼层")
    @PostMapping
    public Result<Floor> create(@Valid @RequestBody FloorSaveRequest req) {
        return Result.success(floorService.create(req));
    }

    @Operation(summary = "修改楼层")
    @PutMapping("/{id}")
    public Result<Floor> update(@PathVariable Long id, @Valid @RequestBody FloorSaveRequest req) {
        return Result.success(floorService.update(id, req));
    }

    @Operation(summary = "删除楼层")
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        floorService.delete(id);
        return Result.success();
    }
}
