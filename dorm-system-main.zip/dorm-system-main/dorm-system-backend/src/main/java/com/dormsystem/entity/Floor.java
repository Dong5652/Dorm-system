package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/** 楼层表（{@code floor}，DATABASE.md §2.1）。 */
@Data
@TableName("floor")
public class Floor {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long buildingId;

    private Integer floorNo;

    private Integer roomCount;

    private LocalDateTime createdAt;

    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
