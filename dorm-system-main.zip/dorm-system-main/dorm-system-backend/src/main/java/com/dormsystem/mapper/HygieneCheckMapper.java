package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.HygieneCheck;
import org.apache.ibatis.annotations.Mapper;

/** HygieneCheck 通用 Mapper。 */
@Mapper
public interface HygieneCheckMapper extends BaseMapper<HygieneCheck> {
}
