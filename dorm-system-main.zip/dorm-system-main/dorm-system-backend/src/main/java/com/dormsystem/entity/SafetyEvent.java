package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 安全事件表
 */
@Data
@TableName("safety_event")
public class SafetyEvent {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long buildingId;
    private Long roomId;
    private String eventType;
    private Integer severity;
    private String description;
    private String photoUrl;
    private Long reportedBy;
    private Integer handled;
    private String handleNote;
    private LocalDateTime happenedAt;
    private LocalDateTime createdAt;
    
    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
