package com.dormsystem.dto.repair;

import lombok.Data;

/** 维修师傅账号响应（脱敏：不返回 password / is_deleted）。 */
@Data
public class RepairmanResponse {

    private Long id;
    private String username;
    private String realName;
    private Integer gender;
    private String phone;
    private String workType;
    private Integer status;
}
