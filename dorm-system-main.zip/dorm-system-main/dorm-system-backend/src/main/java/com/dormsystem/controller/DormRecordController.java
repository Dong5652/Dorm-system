package com.dormsystem.controller;

import com.dormsystem.annotation.OperationLog;
import com.dormsystem.common.Result;
import com.dormsystem.dto.record.*;
import com.dormsystem.service.DormRecordService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 入住退宿与异动控制层接口（API_SPEC §5）。
 */
@Tag(name = "Dorm Record", description = "入住/退宿/自动分配/异动流水记录接口")
@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class DormRecordController {

    private final DormRecordService dormRecordService;

    @Operation(summary = "办理入住登记")
    @PostMapping("/dorm/check-in")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<Map<String, Object>> checkIn(@Valid @RequestBody CheckInRequest req) {
        return Result.success(dormRecordService.checkIn(req));
    }

    @Operation(summary = "自动分配床位")
    @PostMapping("/admin/students/{id}/auto-assign")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Map<String, Object>> autoAssign(@PathVariable Long id, @RequestBody AutoAssignRequest req) {
        return Result.success(dormRecordService.autoAssign(id, req));
    }

    @Operation(summary = "办理退宿登记")
    @PostMapping("/dorm/check-out")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<Void> checkOut(@Valid @RequestBody CheckOutRequest req) {
        dormRecordService.checkOut(req);
        return Result.success();
    }

    @Operation(summary = "办理调宿登记")
    @PostMapping("/dorm/change-room")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<Void> changeRoom(@Valid @RequestBody ChangeRoomRequest req) {
        dormRecordService.changeRoom(req);
        return Result.success();
    }

    @Operation(summary = "登记异动（休学/转专业/假期离校）")
    @PostMapping("/dorm/change")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<Void> change(@Valid @RequestBody StudentChangeRequest req) {
        dormRecordService.change(req);
        return Result.success();
    }

    @Operation(summary = "批量退宿（根据年级与班级）")
    @PostMapping("/admin/check-out/batch")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "dorm", action = "batch_check_out", targetTable = "dorm_record")
    public Result<Map<String, Object>> batchCheckOut(@Valid @RequestBody BatchCheckOutRequest req) {
        return Result.success(dormRecordService.batchCheckOut(req));
    }

    @Operation(summary = "入住/退宿/异动流水日志列表查询")
    @GetMapping("/dorm/records")
    @PreAuthorize("isAuthenticated()")
    public Result<List<DormRecordResponse>> records(
            @RequestParam(required = false) Long studentId,
            @RequestParam(required = false) Long roomId,
            @RequestParam(required = false) Integer type,
            @RequestParam(required = false) String changeType,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return Result.success(dormRecordService.queryRecords(studentId, roomId, type, changeType, startDate, endDate));
    }
}
