package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@TableName("fee")
public class Fee {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long studentId;
    private String feeType;
    /** MySQL 保留词 year_month，必须反引号映射 */
    @TableField("`year_month`")
    private String yearMonth;
    private String semester;
    private BigDecimal amount;
    private BigDecimal paidAmount;
    private Integer paidStatus;
    private LocalDate dueDate;
    private String remark;
    private LocalDateTime createdAt;
    
    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
