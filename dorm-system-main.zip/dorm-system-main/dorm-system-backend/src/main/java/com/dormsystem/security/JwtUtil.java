package com.dormsystem.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Date;

/**
 * JWT 工具：HMAC-SHA256 签发、解析、校验。
 *
 * <p>密钥来自 {@code jwt.secret}（建议由 application-local.yml 注入，勿入 git）。
 * 标准 claim：subject 为 user_id，role 作为自定义 claim {@code role}。</p>
 */
@Slf4j
@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secret;

    @Value("${jwt.issuer:dorm-system}")
    private String issuer;

    @Value("${jwt.expire-minutes:720}")
    private long expireMinutes;

    private SecretKey key;

    @PostConstruct
    void init() {
        if (secret == null || secret.getBytes(StandardCharsets.UTF_8).length < 32) {
            throw new IllegalStateException("jwt.secret 至少需 32 字节（256bit）");
        }
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    /** 生成 token；subject 为用户 id，自定义 claim 含 username/role。 */
    public String generate(Long userId, String username, String role) {
        Date now = new Date();
        Date exp = new Date(now.getTime() + Duration.ofMinutes(expireMinutes).toMillis());
        return Jwts.builder()
                .issuer(issuer)
                .subject(String.valueOf(userId))
                .claim("username", username)
                .claim("role", role)
                .issuedAt(now)
                .expiration(exp)
                .signWith(key)
                .compact();
    }

    /** 解析并校验签名 + 过期；返回的 Jws 包含 Claims。 */
    public Jws<Claims> parse(String token) {
        return Jwts.parser()
                .verifyWith(key)
                .requireIssuer(issuer)
                .build()
                .parseSignedClaims(token);
    }

    /** 从 token 中读取 user_id（subject）。 */
    public Long getUserId(Claims claims) {
        return Long.valueOf(claims.getSubject());
    }
}
