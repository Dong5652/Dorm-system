package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 晚归考勤表（{@code attendance}，DATABASE.md §2.4）。
 * type: 1晚归 2未归 3请假。
 */
@Data
@TableName("attendance")
public class Attendance {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long studentId;

    private Long roomId;

    private LocalDate recordDate;

    /** 1晚归 2未归 3请假。 */
    private Integer type;

    /** 实际归寝时间（晚归时填）。 */
    private LocalDateTime returnTime;

    private Long inspectorId;

    private String remark;

    private LocalDateTime createdAt;

    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
