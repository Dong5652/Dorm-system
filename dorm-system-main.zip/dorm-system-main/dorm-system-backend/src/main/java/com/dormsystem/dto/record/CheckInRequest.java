package com.dormsystem.dto.record;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 办理入住请求。
 */
@Data
public class CheckInRequest {

    @NotNull(message = "学生ID不能为空")
    private Long studentId;

    @NotNull(message = "床位ID不能为空")
    private Long bedId;

    private Boolean keyIssued;

    private String facilityCheck;

    private String remark;
}
