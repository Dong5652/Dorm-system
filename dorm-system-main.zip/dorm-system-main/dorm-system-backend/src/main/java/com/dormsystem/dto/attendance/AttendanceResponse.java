package com.dormsystem.dto.attendance;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 考勤列表 / 详情响应（API_SPEC §6.2）。
 *
 * <p>冗余 studentName / studentNo / roomNo / buildingName / inspectorName 便于前端直接展示。</p>
 */
@Data
public class AttendanceResponse {

    private Long id;
    private Long studentId;
    private String studentName;
    private String studentNo;
    private Long roomId;
    private String roomNo;
    private Long buildingId;
    private String buildingName;
    private LocalDate recordDate;
    /** 1晚归 2未归 3请假 */
    private Integer type;
    private LocalDateTime returnTime;
    private Long inspectorId;
    private String inspectorName;
    private String remark;
    private LocalDateTime createdAt;
}
