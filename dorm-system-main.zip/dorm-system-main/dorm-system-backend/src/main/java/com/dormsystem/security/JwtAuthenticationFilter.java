package com.dormsystem.security;

import com.dormsystem.service.SysUserDetailsService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.NonNull;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * JWT 认证过滤器：解析 {@code Authorization: Bearer <token>}，校验通过后注入
 * {@link org.springframework.security.core.context.SecurityContext}，并按 user_id 反查账号做禁用校验。
 *
 * <p>token 缺失/非法时不抛错，留给后续 AuthorizationFilter 按权限决定是否放行（403）。</p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private static final String BEARER = "Bearer ";

    private final JwtUtil jwtUtil;
    private final SysUserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain chain) throws ServletException, IOException {
        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith(BEARER)) {
            String token = header.substring(BEARER.length()).trim();
            try {
                Jws<Claims> jws = jwtUtil.parse(token);
                Claims claims = jws.getPayload();
                Long userId = jwtUtil.getUserId(claims);
                if (SecurityContextHolder.getContext().getAuthentication() == null) {
                    LoginUser user = (LoginUser) userDetailsService.loadUserByUserId(userId);
                    if (user.isEnabled()) {
                        JwtAuthenticationToken auth = new JwtAuthenticationToken(user, null, user.getAuthorities());
                        auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                        SecurityContextHolder.getContext().setAuthentication(auth);
                    }
                }
            } catch (Exception ex) {
                // 无效 token 不立即拒绝；AuthorizationFilter 会按权限处理。
                log.debug("JWT 解析失败：{}", ex.getMessage());
                SecurityContextHolder.clearContext();
            }
        }
        chain.doFilter(request, response);
    }
}
