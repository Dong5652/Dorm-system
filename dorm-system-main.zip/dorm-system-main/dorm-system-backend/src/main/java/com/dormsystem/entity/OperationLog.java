package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 操作日志表（{@code operation_log}，DATABASE.md §2.7）。
 * 不带 is_deleted 软删除字段（操作日志不允许删除）。
 */
@Data
@TableName("operation_log")
public class OperationLog {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long operatorId;

    private String module;

    private String action;

    private String targetTable;

    private Long targetId;

    private String detail;

    private String ip;

    private LocalDateTime createdAt;
}
