package com.dormsystem.dto.dorm.tree;

import lombok.Data;

import java.util.List;

/** 宿舍树的一层节点。 */
@Data
public class FloorTreeNode {
    private Long id;
    private Integer floorNo;
    private List<RoomTreeNode> rooms;
}
