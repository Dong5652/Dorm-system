package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 寝室综合评分表（{@code dorm_score}，DATABASE.md §2.4）。
 *
 * <p>每月 1 凌晨 1 点由 {@code DormScoreScheduler} 跑出上一月评分：</p>
 * <pre>
 *   total_score = hygiene_avg × 0.6 + (100 − late_count × 5) × 0.4
 *   level: ≥90 优秀 / 75-89 合格 / 60-74 待整改 / &lt;60 不合格
 * </pre>
 *
 * <p>重新生成时通过 {@link com.dormsystem.mapper.DormScoreMapper#physicalDeleteByMonth} 物理删除旧记录，
 * 以避免软删除行命中 {@code uk_dorm_score_room_month} 唯一约束。</p>
 */
@Data
@TableName("dorm_score")
public class DormScore {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long roomId;

    /** 评分月份，如 2026-03。 */
    @TableField("`year_month`")
    private String yearMonth;

    private BigDecimal hygieneAvg;

    private Integer lateCount;

    private BigDecimal totalScore;

    /** 优秀 / 合格 / 待整改 / 不合格。 */
    private String level;

    private String remark;

    private LocalDateTime createdAt;

    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
