package com.dormsystem.dto.score;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 手动触发月度评分任务请求（API_SPEC §6.3.3）。
 */
@Data
public class DormScoreTriggerRequest {

    @NotBlank(message = "评分月份不能为空")
    private String yearMonth;
}
