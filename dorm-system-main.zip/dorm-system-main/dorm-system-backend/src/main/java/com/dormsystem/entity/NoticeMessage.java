package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 站内消息表
 */
@Data
@TableName("notice_message")
public class NoticeMessage {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long toUserId;
    private Long fromUserId;
    private String title;
    private String content;
    private String msgType;
    private Long refId;
    private Integer isRead;
    private LocalDateTime readTime;
    private LocalDateTime createdAt;
    
    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
