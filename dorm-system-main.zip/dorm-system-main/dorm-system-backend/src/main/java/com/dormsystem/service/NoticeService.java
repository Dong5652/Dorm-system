package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.notice.AnnouncementRequest;
import com.dormsystem.entity.Announcement;
import com.dormsystem.entity.Bed;
import com.dormsystem.entity.NoticeMessage;
import com.dormsystem.entity.Room;
import com.dormsystem.entity.Student;
import com.dormsystem.mapper.AnnouncementMapper;
import com.dormsystem.mapper.BedMapper;
import com.dormsystem.mapper.NoticeMessageMapper;
import com.dormsystem.mapper.RoomMapper;
import com.dormsystem.mapper.StudentMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class NoticeService {
    private final AnnouncementMapper announcementMapper;
    private final NoticeMessageMapper noticeMessageMapper;
    private final StudentMapper studentMapper;
    private final BedMapper bedMapper;
    private final RoomMapper roomMapper;

    /**
     * 学生/宿管可见公告：
     * - scope=0 全校
     * - scope=1 自己楼栋
     * - scope=2 自己寝室
     * - scope=3 指定学生
     * 管理员可见全部已发布公告。
     */
    public IPage<Announcement> pageAnnouncements(int page, int size,
                                                 Long userId,
                                                 Long buildingId,
                                                 String role) {
        LambdaQueryWrapper<Announcement> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Announcement::getStatus, 1);
        // 未过期或未设置过期
        wrapper.and(w -> w.isNull(Announcement::getExpireTime)
                .or()
                .gt(Announcement::getExpireTime, LocalDateTime.now()));

        if (!"admin".equalsIgnoreCase(role)) {
            Long studentId = null;
            Long roomId = null;
            Long resolvedBuildingId = buildingId;

            Student student = studentMapper.selectOne(new LambdaQueryWrapper<Student>()
                    .eq(Student::getUserId, userId)
                    .last("LIMIT 1"));
            if (student != null) {
                studentId = student.getId();
                if (student.getCurrentBedId() != null) {
                    Bed bed = bedMapper.selectById(student.getCurrentBedId());
                    if (bed != null) {
                        roomId = bed.getRoomId();
                        Room room = roomMapper.selectById(bed.getRoomId());
                        if (room != null) {
                            resolvedBuildingId = room.getBuildingId();
                        }
                    }
                }
            }

            final Long fBuildingId = resolvedBuildingId;
            final Long fRoomId = roomId;
            final Long fStudentId = studentId;

            wrapper.and(w -> {
                w.eq(Announcement::getScope, 0);
                if (fBuildingId != null) {
                    w.or(x -> x.eq(Announcement::getScope, 1)
                            .eq(Announcement::getBuildingId, fBuildingId));
                }
                if (fRoomId != null) {
                    w.or(x -> x.eq(Announcement::getScope, 2)
                            .eq(Announcement::getTargetRoomId, fRoomId));
                }
                if (fStudentId != null) {
                    w.or(x -> x.eq(Announcement::getScope, 3)
                            .eq(Announcement::getTargetStudentId, fStudentId));
                }
            });
        }

        wrapper.orderByDesc(Announcement::getIsPinned)
               .orderByDesc(Announcement::getPublishTime);
        return announcementMapper.selectPage(new Page<>(page, size), wrapper);
    }

    public IPage<Announcement> pageAdminAnnouncements(int page, int size) {
        LambdaQueryWrapper<Announcement> wrapper = new LambdaQueryWrapper<>();
        wrapper.orderByDesc(Announcement::getIsPinned)
               .orderByDesc(Announcement::getCreatedAt);
        return announcementMapper.selectPage(new Page<>(page, size), wrapper);
    }

    /**
     * 详情查询也做 scope 可见性校验，避免通过 id 直达越权读取。
     */
    public Announcement getVisibleAnnouncement(Long id, Long userId, Long buildingId, String role) {
        Announcement ann = announcementMapper.selectById(id);
        if (ann == null || ann.getStatus() == null || ann.getStatus() != 1) {
            throw new BusinessException(ResultCode.NOT_FOUND, "公告不存在或未发布");
        }
        if (ann.getExpireTime() != null && !ann.getExpireTime().isAfter(LocalDateTime.now())) {
            throw new BusinessException(ResultCode.NOT_FOUND, "公告已过期");
        }
        if ("admin".equalsIgnoreCase(role)) {
            return ann;
        }

        Integer scope = ann.getScope() == null ? 0 : ann.getScope();
        if (scope == 0) {
            return ann;
        }

        Long studentId = null;
        Long roomId = null;
        Long resolvedBuildingId = buildingId;
        Student student = studentMapper.selectOne(new LambdaQueryWrapper<Student>()
                .eq(Student::getUserId, userId)
                .last("LIMIT 1"));
        if (student != null) {
            studentId = student.getId();
            if (student.getCurrentBedId() != null) {
                Bed bed = bedMapper.selectById(student.getCurrentBedId());
                if (bed != null) {
                    roomId = bed.getRoomId();
                    Room room = roomMapper.selectById(bed.getRoomId());
                    if (room != null) {
                        resolvedBuildingId = room.getBuildingId();
                    }
                }
            }
        }

        boolean visible = switch (scope) {
            case 1 -> resolvedBuildingId != null && resolvedBuildingId.equals(ann.getBuildingId());
            case 2 -> roomId != null && roomId.equals(ann.getTargetRoomId());
            case 3 -> studentId != null && studentId.equals(ann.getTargetStudentId());
            default -> false;
        };
        if (!visible) {
            throw new BusinessException(ResultCode.FORBIDDEN, "无权查看该公告");
        }
        return ann;
    }

    public void publishAnnouncement(AnnouncementRequest req, Long operatorId) {
        validateScopeTargets(req);
        Announcement ann = new Announcement();
        applyAnnouncementFields(ann, req);
        ann.setPublishBy(operatorId);
        ann.setPublishTime(req.getPublishTime() != null ? req.getPublishTime() : LocalDateTime.now());
        ann.setStatus(1); // Published
        ann.setCreatedAt(LocalDateTime.now());
        announcementMapper.insert(ann);
    }

    public void updateAnnouncement(Long id, AnnouncementRequest req) {
        Announcement ann = announcementMapper.selectById(id);
        if (ann == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "公告不存在");
        }
        validateScopeTargets(req);
        applyAnnouncementFields(ann, req);
        if (req.getPublishTime() != null) {
            ann.setPublishTime(req.getPublishTime());
        }
        announcementMapper.updateById(ann);
    }

    public void deleteAnnouncement(Long id) {
        announcementMapper.deleteById(id);
    }

    public void pinAnnouncement(Long id) {
        Announcement ann = announcementMapper.selectById(id);
        if (ann == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "公告不存在");
        }
        ann.setIsPinned(ann.getIsPinned() != null && ann.getIsPinned() == 1 ? 0 : 1);
        announcementMapper.updateById(ann);
    }

    public void offlineAnnouncement(Long id) {
        Announcement ann = announcementMapper.selectById(id);
        if (ann == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "公告不存在");
        }
        ann.setStatus(2); // 已下架
        announcementMapper.updateById(ann);
    }

    /**
     * 按接收用户查询站内消息。
     * @param toUserId sys_user.id（不是 student.id）
     */
    public IPage<NoticeMessage> pageNotices(int page, int size, Long toUserId) {
        LambdaQueryWrapper<NoticeMessage> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(NoticeMessage::getToUserId, toUserId);
        wrapper.orderByAsc(NoticeMessage::getIsRead)
               .orderByDesc(NoticeMessage::getCreatedAt);
        return noticeMessageMapper.selectPage(new Page<>(page, size), wrapper);
    }

    public long countUnreadNotices(Long toUserId) {
        LambdaQueryWrapper<NoticeMessage> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(NoticeMessage::getToUserId, toUserId);
        wrapper.eq(NoticeMessage::getIsRead, 0);
        return noticeMessageMapper.selectCount(wrapper);
    }

    public void readNotice(Long id, Long toUserId) {
        NoticeMessage notice = noticeMessageMapper.selectById(id);
        if (notice != null && toUserId != null && toUserId.equals(notice.getToUserId())) {
            notice.setIsRead(1);
            notice.setReadTime(LocalDateTime.now());
            noticeMessageMapper.updateById(notice);
        }
    }

    @Transactional
    public void readAllNotices(Long toUserId) {
        NoticeMessage updateNotice = new NoticeMessage();
        updateNotice.setIsRead(1);
        updateNotice.setReadTime(LocalDateTime.now());
        LambdaQueryWrapper<NoticeMessage> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(NoticeMessage::getToUserId, toUserId);
        wrapper.eq(NoticeMessage::getIsRead, 0);
        noticeMessageMapper.update(updateNotice, wrapper);
    }

    public void deleteNotice(Long id, Long toUserId) {
        NoticeMessage notice = noticeMessageMapper.selectById(id);
        if (notice != null && toUserId != null && toUserId.equals(notice.getToUserId())) {
            noticeMessageMapper.deleteById(id);
        }
    }

    private void applyAnnouncementFields(Announcement ann, AnnouncementRequest req) {
        ann.setTitle(req.getTitle());
        ann.setContent(req.getContent());
        ann.setScope(req.getScope() == null ? 0 : req.getScope());
        ann.setBuildingId(req.getBuildingId());
        ann.setTargetRoomId(req.getTargetRoomId());
        ann.setTargetStudentId(req.getTargetStudentId());
        ann.setIsPinned(req.getIsPinned() != null && req.getIsPinned() ? 1 : 0);
        ann.setExpireTime(req.getExpireTime());
    }

    private void validateScopeTargets(AnnouncementRequest req) {
        Integer scope = req.getScope() == null ? 0 : req.getScope();
        if (scope < 0 || scope > 3) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "scope 取值 0/1/2/3");
        }
        if (scope == 1 && req.getBuildingId() == null) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "楼栋公告必须指定 buildingId");
        }
        if (scope == 2 && req.getTargetRoomId() == null) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "寝室公告必须指定 targetRoomId");
        }
        if (scope == 3 && req.getTargetStudentId() == null) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "个人公告必须指定 targetStudentId");
        }
    }
}
