package com.dormsystem.dto.record;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 登记学生异动（如休学/转专业/假期离校）请求。
 */
@Data
public class StudentChangeRequest {

    @NotNull(message = "学生ID不能为空")
    private Long studentId;

    @NotBlank(message = "异动类型不能为空")
    private String type; // suspend/transfer/holiday_leave

    private String reason;

    private String remark;
}
