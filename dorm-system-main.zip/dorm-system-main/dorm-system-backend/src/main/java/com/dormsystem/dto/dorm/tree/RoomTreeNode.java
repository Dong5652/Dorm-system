package com.dormsystem.dto.dorm.tree;

import lombok.Data;

import java.util.List;

/** 宿舍树的一个房间节点。 */
@Data
public class RoomTreeNode {
    private Long id;
    private String roomNo;
    private Integer capacity;
    private Integer occupiedCount;
    private Integer status;
    private List<BedTreeNode> beds;
}
