package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 房间表（{@code room}，DATABASE.md §2.1）。
 * status: 0空闲 1部分入住 2满员 3维修中 4锁定预留。
 */
@Data
@TableName("room")
public class Room {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long buildingId;

    private Long floorId;

    private String roomNo;

    private Integer capacity;

    private Integer occupiedCount;

    /** 0空闲 1部分入住 2满员 3维修中 4锁定预留。 */
    private Integer status;

    private String remark;

    private LocalDateTime createdAt;

    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
