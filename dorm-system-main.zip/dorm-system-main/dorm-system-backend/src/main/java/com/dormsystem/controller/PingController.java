package com.dormsystem.controller;

import com.dormsystem.common.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 健康检查接口，用于 Phase 1 前后端联调。
 *
 * <p>验收约定（{@code DEVELOPMENT_PLAN.md §阶段1}）：
 * <pre>curl http://localhost:8080/api/v1/ping 返回 {"code":0,"data":"pong"}</pre>
 */
@Tag(name = "Ping", description = "健康检查 / 联调")
@RestController
@RequestMapping("/api/v1")
public class PingController {

    @Operation(summary = "Ping", description = "返回 pong，验证前后端联通（Phase 1 验收）")
    @GetMapping("/ping")
    public Result<String> ping() {
        return Result.success("pong");
    }
}
