package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.CheckInRecord;
import org.apache.ibatis.annotations.Mapper;

/**
 * 入住退宿记录 Mapper。
 */
@Mapper
public interface CheckInRecordMapper extends BaseMapper<CheckInRecord> {
}
