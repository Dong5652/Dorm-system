package com.dormsystem.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dormsystem.annotation.OperationLog;
import com.dormsystem.common.Result;
import com.dormsystem.dto.repair.*;
import com.dormsystem.entity.RepairOrder;
import com.dormsystem.security.SecurityUtils;
import com.dormsystem.service.RepairService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

/**
 * 维修工单控制层（API_SPEC §7.1）。
 *
 * <ul>
 *   <li>GET    /api/v1/repair                  分页列表（按角色过滤）</li>
 *   <li>GET    /api/v1/repair/{id}              详情</li>
 *   <li>POST   /api/v1/repair                   学生 / 宿管报修</li>
 *   <li>POST   /api/v1/admin/repair/{id}/assign 管理员派单</li>
 *   <li>PUT    /api/v1/repair/{id}/start        师傅接单</li>
 *   <li>PUT    /api/v1/repair/{id}/finish       师傅完工</li>
 *   <li>PUT    /api/v1/repair/{id}/rate         学生评价</li>
 *   <li>PUT    /api/v1/repair/{id}/cancel       取消工单</li>
 *   <li>DELETE /api/v1/admin/repair/{id}        管理员删除工单</li>
 * </ul>
 */
@Tag(name = "Repair", description = "维修工单接口")
@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class RepairController {

    private final RepairService repairService;

    @Operation(summary = "工单分页列表（按角色过滤）")
    @GetMapping("/repair")
    @PreAuthorize("isAuthenticated()")
    public Result<IPage<RepairResponse>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) Integer status,
            @RequestParam(required = false) Integer priority,
            @RequestParam(required = false) Long repairmanId,
            @RequestParam(required = false) Long roomId,
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Long reporterId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return Result.success(repairService.page(
                pageNum, pageSize, status, priority, repairmanId,
                roomId, buildingId, reporterId, startDate, endDate));
    }

    @Operation(summary = "工单详情")
    @GetMapping("/repair/{id}")
    @PreAuthorize("isAuthenticated()")
    public Result<RepairResponse> get(@PathVariable Long id) {
        return Result.success(repairService.get(id));
    }

    @Operation(summary = "学生 / 宿管报修")
    @PostMapping("/repair")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER','STUDENT')")
    public Result<RepairOrder> create(@Valid @RequestBody RepairCreateRequest req) {
        return Result.success(repairService.create(req));
    }

    @Operation(summary = "管理员派单")
    @PostMapping("/admin/repair/{id}/assign")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<RepairOrder> assign(@PathVariable Long id, @Valid @RequestBody AssignRequest req) {
        return Result.success(repairService.assign(id, req, SecurityUtils.currentUserId()));
    }

    @Operation(summary = "师傅接单")
    @PutMapping("/repair/{id}/start")
    @PreAuthorize("hasRole('REPAIRMAN')")
    public Result<RepairOrder> start(@PathVariable Long id) {
        return Result.success(repairService.start(id, SecurityUtils.currentUserId()));
    }

    @Operation(summary = "师傅完工")
    @PutMapping("/repair/{id}/finish")
    @PreAuthorize("hasRole('REPAIRMAN')")
    public Result<RepairOrder> finish(@PathVariable Long id, @Valid @RequestBody FinishRequest req) {
        return Result.success(repairService.finish(id, req, SecurityUtils.currentUserId()));
    }

    @Operation(summary = "学生评价")
    @PutMapping("/repair/{id}/rate")
    @PreAuthorize("hasRole('STUDENT')")
    public Result<RepairOrder> rate(@PathVariable Long id, @Valid @RequestBody RateRequest req) {
        return Result.success(repairService.rate(id, req, SecurityUtils.currentUserId()));
    }

    @Operation(summary = "取消工单（学生 / 管理员）")
    @PutMapping("/repair/{id}/cancel")
    @PreAuthorize("hasAnyRole('ADMIN','STUDENT')")
    public Result<RepairOrder> cancel(@PathVariable Long id) {
        return Result.success(repairService.cancel(id, SecurityUtils.currentUserId(), SecurityUtils.currentRole()));
    }

    @Operation(summary = "管理员删除工单")
    @DeleteMapping("/admin/repair/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "repair", action = "delete", targetTable = "repair_order")
    public Result<Void> delete(@PathVariable Long id) {
        repairService.delete(id);
        return Result.success();
    }
}
