package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.Fee;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FeeMapper extends BaseMapper<Fee> {
}
