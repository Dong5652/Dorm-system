package com.dormsystem.security;

import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.entity.SysUser;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * 取当前登录用户的静态工具。controller / service 都可以从这里拿。
 */
public final class SecurityUtils {

    private SecurityUtils() {}

    public static LoginUser current() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Object principal = auth != null ? auth.getPrincipal() : null;
        if (principal instanceof LoginUser loginUser) {
            return loginUser;
        }
        throw new BusinessException(ResultCode.UNAUTHORIZED, "未登录");
    }

    public static SysUser currentUser() {
        return current().getUser();
    }

    public static Long currentUserId() {
        return current().getUserId();
    }

    public static String currentRole() {
        return current().getRole();
    }
}
