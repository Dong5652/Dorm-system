package com.dormsystem.dto.repair;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** 完工请求：师傅填写维修说明。 */
@Data
public class FinishRequest {

    @NotBlank(message = "维修说明不能为空")
    private String completionNote;
}
