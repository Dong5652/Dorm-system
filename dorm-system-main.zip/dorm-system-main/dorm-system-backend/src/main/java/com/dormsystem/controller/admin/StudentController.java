package com.dormsystem.controller.admin;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.annotation.OperationLog;
import com.dormsystem.common.Result;
import com.dormsystem.dto.student.StudentDetailResponse;
import com.dormsystem.dto.student.StudentSaveRequest;
import com.dormsystem.entity.Student;
import com.dormsystem.service.StudentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

/**
 * 学生档案管理控制器（API_SPEC §4）。
 * 权限控制：仅管理员（ADMIN）及有权限的宿管（DORM_MANAGER）可查询；写操作仅管理员。
 */
@Tag(name = "Admin · Student", description = "学生档案 CRUD 与批量导入导出")
@RestController
@RequestMapping("/api/v1/admin/students")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
public class StudentController {

    private final StudentService studentService;

    @Operation(summary = "学生档案分页查询")
    @GetMapping
    public Result<Page<Student>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String className,
            @RequestParam(required = false) String college,
            @RequestParam(required = false) Integer status) {
        return Result.success(studentService.page(pageNum, pageSize, keyword, className, college, status));
    }

    @Operation(summary = "学生详情（包含档案+宿舍+异动流水）")
    @GetMapping("/{id}")
    public Result<StudentDetailResponse> getDetail(@PathVariable Long id) {
        return Result.success(studentService.getDetail(id));
    }

    @Operation(summary = "新增学生档案（同步建立 sys_user 账户）")
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Student> create(@Valid @RequestBody StudentSaveRequest req) {
        return Result.success(studentService.create(req));
    }

    @Operation(summary = "修改学生档案（同步更新 sys_user 账户）")
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "student", action = "update", targetTable = "student")
    public Result<Student> update(@PathVariable Long id, @Valid @RequestBody StudentSaveRequest req) {
        return Result.success(studentService.update(id, req));
    }

    @Operation(summary = "删除学生档案（同步删除 sys_user 账户）")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "student", action = "delete", targetTable = "student")
    public Result<Void> delete(@PathVariable Long id) {
        studentService.delete(id);
        return Result.success();
    }

    @Operation(summary = "批量导入学生档案（上传 Excel，Alibaba EasyExcel 实现）")
    @PostMapping("/import")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Map<String, Object>> importExcel(@RequestParam("file") MultipartFile file) {
        return Result.success(studentService.importExcel(file));
    }

    @Operation(summary = "批量导出学生档案（下载 Excel）")
    @GetMapping("/export")
    public void exportExcel(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String className,
            @RequestParam(required = false) String college,
            @RequestParam(required = false) Integer status,
            HttpServletResponse response) throws IOException {
        studentService.exportExcel(keyword, className, college, status, response);
    }
}
