package com.dormsystem.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 登录成功响应（API_SPEC §2.1）。
 */
@Data
@AllArgsConstructor
public class LoginResponse {
    private String token;
    private Long userId;
    private String username;
    private String realName;
    private String role;
}
