package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 楼栋表（{@code building}，DATABASE.md §2.1）。
 * gender: 1男 2女 3混合；manager_id 关联 sys_user（宿管）。
 */
@Data
@TableName("building")
public class Building {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 楼栋编号，唯一。 */
    private String code;

    private String name;

    /** 1男 2女 3混合。 */
    private Integer gender;

    private Integer floorCount;

    private Long managerId;

    private String remark;

    private LocalDateTime createdAt;

    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
