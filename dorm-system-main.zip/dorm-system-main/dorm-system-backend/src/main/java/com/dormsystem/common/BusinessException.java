package com.dormsystem.common;

import lombok.Getter;

/**
 * 业务异常：Service 层抛出后由 {@link GlobalExceptionHandler} 统一翻译为 {@link Result}。
 */
@Getter
public class BusinessException extends RuntimeException {

    private final ResultCode code;

    public BusinessException(ResultCode code) {
        super(code.getMessage());
        this.code = code;
    }

    public BusinessException(ResultCode code, String message) {
        super(message);
        this.code = code;
    }
}
