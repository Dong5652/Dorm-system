package com.dormsystem.dto.dorm.tree;

import lombok.Data;

import java.util.List;

/** 宿舍树（{@code GET /api/v1/dorm/tree}）的一栋楼节点。 */
@Data
public class BuildingTreeNode {
    private Long id;
    private String code;
    private String name;
    private Integer gender;
    private List<FloorTreeNode> floors;
}
