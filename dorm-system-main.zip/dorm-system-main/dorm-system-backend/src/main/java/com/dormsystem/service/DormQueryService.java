package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.dormsystem.dto.dorm.tree.*;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 宿舍树 + 空置统计查询。返回级联 building → floor → room → bed 的树(含 studentName 关联)。
 *
 * <p>studentName 暂走 SysUser.real_name 反查(学生档案 Phase 4 后可改 student.name 冗余)。</p>
 *
 * <p>数据范围:宿管(DORM_MANAGER)只看本人管辖楼栋一棵子树,ADMIN 全部楼栋;
 * 非授权角色由 {@link BuildingService#scopeBuildingId()} 抛 FORBIDDEN 拦住。</p>
 */
@Service
@RequiredArgsConstructor
public class DormQueryService {

    private final BuildingMapper buildingMapper;
    private final FloorMapper floorMapper;
    private final RoomMapper roomMapper;
    private final BedMapper bedMapper;
    private final SysUserMapper sysUserMapper;
    private final StudentMapper studentMapper;

    public List<BuildingTreeNode> tree() {
        // 宿管 scope 收敛:只能看到本人管辖楼栋一棵子树;admin 不限
        Long scope = BuildingService.scopeBuildingId();
        LambdaQueryWrapper<Building> bw = new LambdaQueryWrapper<Building>().orderByAsc(Building::getCode);
        if (scope != null) bw.eq(Building::getId, scope);
        List<Building> buildings = buildingMapper.selectList(bw);
        if (buildings.isEmpty()) return List.of();

        List<Long> buildingIds = buildings.stream().map(Building::getId).toList();
        List<Floor> floors = floorMapper.selectList(
                new LambdaQueryWrapper<Floor>()
                        .in(Floor::getBuildingId, buildingIds)
                        .orderByAsc(Floor::getFloorNo));
        List<Long> floorIds = floors.stream().map(Floor::getId).toList();
        List<Long> floorIdsSafe = floorIds.isEmpty() ? List.of(-1L) : floorIds;

        List<Room> rooms = roomMapper.selectList(
                new LambdaQueryWrapper<Room>()
                        .in(Room::getFloorId, floorIdsSafe)
                        .orderByAsc(Room::getRoomNo));
        List<Long> roomIds = rooms.stream().map(Room::getId).toList();
        List<Long> roomIdsSafe = roomIds.isEmpty() ? List.of(-1L) : roomIds;

        List<Bed> beds = bedMapper.selectList(
                new LambdaQueryWrapper<Bed>()
                        .in(Bed::getRoomId, roomIdsSafe)
                        .orderByAsc(Bed::getBedNo));

        // 学生姓名:从 student.name 查询
        Set<Long> studentIds = beds.stream()
                .map(Bed::getStudentId).filter(Objects::nonNull).collect(Collectors.toSet());
        Map<Long, String> studentNameMap = new HashMap<>();
        if (!studentIds.isEmpty()) {
            List<Student> students = studentMapper.selectList(
                    new LambdaQueryWrapper<Student>().in(Student::getId, studentIds));
            for (Student s : students) studentNameMap.put(s.getId(), s.getName());
        }

        Map<Long, List<Bed>> bedByRoom = beds.stream().collect(Collectors.groupingBy(Bed::getRoomId));
        Map<Long, List<Room>> roomByFloor = rooms.stream().collect(Collectors.groupingBy(Room::getFloorId));
        Map<Long, List<Floor>> floorByBuilding = floors.stream().collect(Collectors.groupingBy(Floor::getBuildingId));

        List<BuildingTreeNode> tree = new ArrayList<>(buildings.size());
        for (Building b : buildings) {
            BuildingTreeNode bt = new BuildingTreeNode();
            bt.setId(b.getId());
            bt.setCode(b.getCode());
            bt.setName(b.getName());
            bt.setGender(b.getGender());

            List<Floor> bf = floorByBuilding.getOrDefault(b.getId(), List.of());
            List<FloorTreeNode> floorNodes = new ArrayList<>(bf.size());
            for (Floor f : bf) {
                FloorTreeNode ft = new FloorTreeNode();
                ft.setId(f.getId());
                ft.setFloorNo(f.getFloorNo());

                List<Room> fr = roomByFloor.getOrDefault(f.getId(), List.of());
                List<RoomTreeNode> roomNodes = new ArrayList<>(fr.size());
                for (Room r : fr) {
                    RoomTreeNode rt = new RoomTreeNode();
                    rt.setId(r.getId());
                    rt.setRoomNo(r.getRoomNo());
                    rt.setCapacity(r.getCapacity());
                    rt.setOccupiedCount(r.getOccupiedCount());
                    rt.setStatus(r.getStatus());

                    List<Bed> rb = bedByRoom.getOrDefault(r.getId(), List.of());
                    List<BedTreeNode> bedNodes = new ArrayList<>(rb.size());
                    for (Bed bed : rb) {
                        BedTreeNode bt2 = new BedTreeNode();
                        bt2.setId(bed.getId());
                        bt2.setBedNo(bed.getBedNo());
                        bt2.setStatus(bed.getStatus());
                        bt2.setStudentId(bed.getStudentId());
                        bt2.setStudentName(bed.getStudentId() == null ? null
                                : studentNameMap.get(bed.getStudentId()));
                        bedNodes.add(bt2);
                    }
                    rt.setBeds(bedNodes);
                    roomNodes.add(rt);
                }
                ft.setRooms(roomNodes);
                floorNodes.add(ft);
            }
            bt.setFloors(floorNodes);
            tree.add(bt);
        }
        return tree;
    }

    public List<VacancyStat> vacancy() {
        Long scope = BuildingService.scopeBuildingId();
        LambdaQueryWrapper<Building> bw = new LambdaQueryWrapper<Building>().orderByAsc(Building::getCode);
        if (scope != null) bw.eq(Building::getId, scope);
        List<Building> buildings = buildingMapper.selectList(bw);
        List<Long> buildingIds = buildings.stream().map(Building::getId).toList();
        List<Long> buildingIdsSafe = buildingIds.isEmpty() ? List.of(-1L) : buildingIds;
        List<Room> rooms = roomMapper.selectList(
                new LambdaQueryWrapper<Room>().in(Room::getBuildingId, buildingIdsSafe));
        List<Long> roomIds = rooms.stream().map(Room::getId).toList();
        List<Long> roomIdsSafe = roomIds.isEmpty() ? List.of(-1L) : roomIds;
        List<Bed> beds = bedMapper.selectList(
                new LambdaQueryWrapper<Bed>().in(Bed::getRoomId, roomIdsSafe));

        Map<Long, List<Room>> roomByBuilding = rooms.stream()
                .collect(Collectors.groupingBy(Room::getBuildingId));
        Map<Long, List<Bed>> bedByRoom = beds.stream()
                .collect(Collectors.groupingBy(Bed::getRoomId));

        List<VacancyStat> out = new ArrayList<>(buildings.size());
        for (Building b : buildings) {
            VacancyStat s = new VacancyStat();
            s.setBuildingId(b.getId());
            s.setBuildingName(b.getName());
            List<Room> roomsOfB = roomByBuilding.getOrDefault(b.getId(), List.of());
            Set<Long> roomIdsOfB = roomsOfB.stream().map(Room::getId).collect(Collectors.toSet());
            int total = 0, occupied = 0;
            for (Long rid : roomIdsOfB) {
                List<Bed> rb = bedByRoom.getOrDefault(rid, List.of());
                for (Bed bed : rb) {
                    total++;
                    if (BedService.BED_OCCUPIED == bed.getStatus()) occupied++;
                }
            }
            s.setTotalBeds(total);
            s.setOccupiedBeds(occupied);
            s.setVacantBeds(total - occupied);
            s.setOccupancyRate(total == 0 ? 0.0 : Math.round(100.0 * occupied / total * 100) / 100.0);
            out.add(s);
        }
        return out;
    }
}
