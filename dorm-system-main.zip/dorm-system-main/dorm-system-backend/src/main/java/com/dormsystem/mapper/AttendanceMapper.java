package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.Attendance;
import org.apache.ibatis.annotations.Mapper;

/** Attendance 通用 Mapper。 */
@Mapper
public interface AttendanceMapper extends BaseMapper<Attendance> {
}
