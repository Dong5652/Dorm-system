package com.dormsystem.controller;

import com.dormsystem.common.Result;
import com.dormsystem.service.StatsService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
@RequestMapping("/api/v1/stats")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
public class StatsController {
    
    private final StatsService statsService;

    @GetMapping("/occupancy")
    public Result<?> getOccupancyStats(
            @RequestParam(required = false) String groupBy,
            @RequestParam(required = false) Long buildingId) {
        return Result.success(statsService.getOccupancyStats(groupBy, buildingId));
    }

    @GetMapping("/discipline")
    public Result<?> getDisciplineTimeline(
            @RequestParam(required = false) String studentNo,
            @RequestParam(required = false) Long roomId,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate) {
        return Result.success(statsService.getDisciplineTimeline(studentNo, roomId, startDate, endDate));
    }

    @GetMapping("/export")
    @PreAuthorize("hasRole('ADMIN')")
    public void exportReport(
            @RequestParam String type,
            HttpServletResponse response) throws IOException {
        statsService.exportReport(type, response);
    }
}
