package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.Floor;
import org.apache.ibatis.annotations.Mapper;

/** Floor 通用 Mapper。 */
@Mapper
public interface FloorMapper extends BaseMapper<Floor> {
}
