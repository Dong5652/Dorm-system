package com.dormsystem.dto.notice;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class AnnouncementRequest {
    private String title;
    private String content;
    private Integer scope;
    private Long buildingId;
    /** scope=2 时生效 */
    private Long targetRoomId;
    /** scope=3 时生效 */
    private Long targetStudentId;
    private Boolean isPinned;
    private LocalDateTime publishTime;
    private LocalDateTime expireTime;
}
