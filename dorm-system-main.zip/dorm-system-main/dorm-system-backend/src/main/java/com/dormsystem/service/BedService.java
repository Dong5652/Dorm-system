package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.dorm.BedSaveRequest;
import com.dormsystem.entity.Bed;
import com.dormsystem.entity.Room;
import com.dormsystem.mapper.BedMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Set;

/**
 * 床位服务。床位状态变化后立即触发 {@link RoomService#recalcRoomState} 刷 room 状态。
 *
 * <p>床位占用 / 释放的业务闭环(分配学生 → status=1)在 Phase 5 入住退宿模块接续,
 * 这里只覆盖管理员视角的「直接维护床位」:新增床位、状态手工变更(空闲/维修/预留)、删除。
 * 释放/占用由 Phase 5 的入住退宿接口直接写 bed.student_id + status 后再调 refreshRoom。</p>
 */
@Service
@RequiredArgsConstructor
public class BedService {

    /** 床位状态:0空闲 1已占用 2维修中 3预留。 */
    public static final Integer BED_FREE = 0;
    public static final Integer BED_OCCUPIED = 1;
    public static final Integer BED_REPAIR = 2;
    public static final Integer BED_RESERVED = 3;

    private final BedMapper bedMapper;
    private final RoomService roomService;

    public Page<Bed> page(int pageNum, int pageSize, Long roomId) {
        Long scope = BuildingService.scopeBuildingId();
        if (scope != null && roomId != null) {
            // 宿管:校验该 roomId 所在楼栋为自己管辖
            Room r = roomService.get(roomId);
            if (!scope.equals(r.getBuildingId())) {
                throw new BusinessException(ResultCode.FORBIDDEN, "无权查看非本人楼栋的床位");
            }
        }
        Page<Bed> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Bed> w = new LambdaQueryWrapper<>();
        if (roomId != null) w.eq(Bed::getRoomId, roomId);
        w.orderByAsc(Bed::getBedNo);
        return bedMapper.selectPage(page, w);
    }

    /**
     * 床位状态变更(管理员直接维护或 Phase 5 调用)。
     *
     * @param id       bed id
     * @param newStatus 0空闲 2维修中 3预留;1已占用 仅 Phase 5 内部允许
     */
    @Transactional
    public Bed setStatus(Long id, int newStatus) {
        if (!Set.of(BED_FREE, BED_OCCUPIED, BED_REPAIR, BED_RESERVED).contains(newStatus)) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "床位状态取值 0/1/2/3");
        }
        Bed b = get(id);
        if (newStatus == BED_OCCUPIED && b.getStudentId() == null) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "床位无当前占用人,不可直接置为已占用");
        }
        if (newStatus != BED_OCCUPIED) {
            b.setStudentId(null);
            if (newStatus == BED_FREE) {
                b.setCheckInTime(null);
            }
        }
        b.setStatus(newStatus);
        bedMapper.updateById(b);
        roomService.recalcRoomState(b.getRoomId());
        return get(id);
    }

    /** Phase 5 内部调用:占用床位入 student_id,置 status=1,记录入住时间,然后刷 room 状态。 */
    @Transactional
    public Bed occupy(Long bedId, Long studentId) {
        Bed b = get(bedId);
        if (!BED_FREE.equals(b.getStatus())) {
            throw new BusinessException(ResultCode.CONFLICT, "床位当前不可被占用, status=" + b.getStatus());
        }
        b.setStudentId(studentId);
        b.setStatus(BED_OCCUPIED);
        b.setCheckInTime(LocalDateTime.now());
        bedMapper.updateById(b);
        roomService.recalcRoomState(b.getRoomId());
        return get(bedId);
    }

    /** Phase 5 内部调用:释放床位 occupied → free。 */
    @Transactional
    public Bed release(Long bedId) {
        Bed b = get(bedId);
        if (!BED_OCCUPIED.equals(b.getStatus())) {
            throw new BusinessException(ResultCode.CONFLICT, "床位非占用态,无需释放");
        }
        b.setStudentId(null);
        b.setStatus(BED_FREE);
        b.setCheckInTime(null);
        bedMapper.updateById(b);
        roomService.recalcRoomState(b.getRoomId());
        return get(bedId);
    }

    public Bed get(Long id) {
        Bed b = bedMapper.selectById(id);
        if (b == null) throw new BusinessException(ResultCode.NOT_FOUND, "床位不存在");
        return b;
    }

    public Bed create(BedSaveRequest req) {
        Room r = roomService.get(req.getRoomId());
        ensureBedNoUnique(r.getId(), req.getBedNo(), null);
        Bed b = new Bed();
        b.setRoomId(r.getId());
        b.setBedNo(req.getBedNo());
        b.setStatus(req.getStatus() == null ? BED_FREE : req.getStatus());
        bedMapper.insert(b);
        roomService.recalcRoomState(r.getId());
        return b;
    }

    public Bed update(Long id, BedSaveRequest req) {
        Bed b = get(id);
        if (!b.getRoomId().equals(req.getRoomId())) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "不允许修改床位所属房间");
        }
        if (!b.getBedNo().equals(req.getBedNo())) {
            ensureBedNoUnique(req.getRoomId(), req.getBedNo(), id);
        }
        b.setBedNo(req.getBedNo());
        if (req.getStatus() != null && !req.getStatus().equals(b.getStatus())) {
            return setStatus(id, req.getStatus());
        }
        bedMapper.updateById(b);
        roomService.recalcRoomState(b.getRoomId());
        return b;
    }

    public void delete(Long id) {
        Bed b = get(id);
        if (BED_OCCUPIED.equals(b.getStatus())) {
            throw new BusinessException(ResultCode.CONFLICT, "床位占用中,禁止删除");
        }
        bedMapper.deleteById(id);
        roomService.recalcRoomState(b.getRoomId());
    }

    /** Phase 5 调宿内部调用:把旧床位释放 + 占用新床位,房间的状态机两边都重算。 */
    @Transactional
    public void swap(Long fromBedId, Long toBedId, Long studentId) {
        release(fromBedId);
        occupy(toBedId, studentId);
    }

    /** Phase 5 内部调用:刷一下 room 状态。 */
    public void refreshRoom(Long roomId) {
        roomService.recalcRoomState(roomId);
    }

    private void ensureBedNoUnique(Long roomId, String bedNo, Long excludeId) {
        LambdaQueryWrapper<Bed> w = new LambdaQueryWrapper<Bed>()
                .eq(Bed::getRoomId, roomId)
                .eq(Bed::getBedNo, bedNo);
        if (excludeId != null) w.ne(Bed::getId, excludeId);
        Long cnt = bedMapper.selectCount(w);
        if (cnt != null && cnt > 0) {
            throw new BusinessException(ResultCode.CONFLICT, "该房间已存在此床位号: " + bedNo);
        }
    }
}
