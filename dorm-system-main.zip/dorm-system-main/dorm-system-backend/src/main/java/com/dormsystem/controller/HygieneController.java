package com.dormsystem.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dormsystem.common.Result;
import com.dormsystem.dto.hygiene.HygieneResponse;
import com.dormsystem.dto.hygiene.HygieneSaveRequest;
import com.dormsystem.entity.HygieneCheck;
import com.dormsystem.service.HygieneService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

/**
 * 卫生检查控制层（API_SPEC §6.1）。
 *
 * <ul>
 *   <li>GET    /api/v1/dorm/hygiene         分页列表</li>
 *   <li>GET    /api/v1/dorm/hygiene/{id}    详情</li>
 *   <li>POST   /api/v1/dorm/hygiene         录入</li>
 *   <li>PUT    /api/v1/dorm/hygiene/{id}    修改</li>
 *   <li>DELETE /api/v1/dorm/hygiene/{id}    删除（仅 ADMIN）</li>
 * </ul>
 */
@Tag(name = "Hygiene", description = "卫生检查接口")
@RestController
@RequestMapping("/api/v1/dorm/hygiene")
@RequiredArgsConstructor
public class HygieneController {

    private final HygieneService hygieneService;

    @Operation(summary = "卫生检查分页列表")
    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public Result<IPage<HygieneResponse>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) Long roomId,
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return Result.success(
                hygieneService.page(pageNum, pageSize, roomId, buildingId, startDate, endDate));
    }

    @Operation(summary = "卫生检查详情")
    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public Result<HygieneResponse> get(@PathVariable Long id) {
        return Result.success(hygieneService.get(id));
    }

    @Operation(summary = "录入卫生检查")
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<HygieneCheck> create(@Valid @RequestBody HygieneSaveRequest req) {
        return Result.success(hygieneService.create(req));
    }

    @Operation(summary = "修改卫生检查")
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<HygieneCheck> update(@PathVariable Long id, @Valid @RequestBody HygieneSaveRequest req) {
        return Result.success(hygieneService.update(id, req));
    }

    @Operation(summary = "删除卫生检查（仅 ADMIN）")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> delete(@PathVariable Long id) {
        hygieneService.delete(id);
        return Result.success();
    }
}
