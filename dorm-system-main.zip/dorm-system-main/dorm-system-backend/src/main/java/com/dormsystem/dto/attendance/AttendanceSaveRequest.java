package com.dormsystem.dto.attendance;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 晚归考勤登记 / 修改请求（API_SPEC §6.2）。
 * type: 1晚归 2未归 3请假。
 */
@Data
public class AttendanceSaveRequest {

    @NotNull(message = "学生ID不能为空")
    private Long studentId;

    @NotNull(message = "记录日期不能为空")
    private LocalDate recordDate;

    @NotNull(message = "考勤类型不能为空")
    private Integer type;

    /** 实际归寝时间（晚归时填）。 */
    private LocalDateTime returnTime;

    private String remark;
}
