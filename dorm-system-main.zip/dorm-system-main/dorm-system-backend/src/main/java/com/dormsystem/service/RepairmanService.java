package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.repair.RepairmanResponse;
import com.dormsystem.dto.repair.RepairmanSaveRequest;
import com.dormsystem.entity.SysUser;
import com.dormsystem.mapper.RepairOrderMapper;
import com.dormsystem.mapper.SysUserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 维修师傅账号服务（API_SPEC §7.2）。
 *
 * <p>本质就是 sys_user 表 role='repairman' 的 CRUD：</p>
 * <ul>
 *   <li>新增：role 自动设为 {@code repairman}，初始密码 {@code 123456}（BCrypt 加密）。</li>
 *   <li>修改：username 不可改；realName / phone / workType / gender 可改。</li>
 *   <li>删除：软删；删除前校验是否仍有未完结工单。</li>
 * </ul>
 */
@Service
@RequiredArgsConstructor
public class RepairmanService {

    public static final String ROLE_REPAIRMAN = "repairman";
    public static final String DEFAULT_PASSWORD = "123456";

    private final SysUserMapper sysUserMapper;
    private final RepairOrderMapper repairOrderMapper;
    private final PasswordEncoder passwordEncoder;

    public List<RepairmanResponse> list() {
        List<SysUser> users = sysUserMapper.selectList(
                new LambdaQueryWrapper<SysUser>()
                        .eq(SysUser::getRole, ROLE_REPAIRMAN)
                        .orderByAsc(SysUser::getUsername));
        return users.stream().map(this::toResponse).collect(Collectors.toList());
    }

    public RepairmanResponse get(Long id) {
        SysUser user = mustGet(id);
        return toResponse(user);
    }

    @Transactional
    public RepairmanResponse create(RepairmanSaveRequest req) {
        // 校验 username 唯一
        Long cnt = sysUserMapper.selectCount(
                new LambdaQueryWrapper<SysUser>().eq(SysUser::getUsername, req.getUsername()));
        if (cnt != null && cnt > 0) {
            throw new BusinessException(ResultCode.CONFLICT, "登录名已存在: " + req.getUsername());
        }
        if (req.getGender() == null || (req.getGender() != 1 && req.getGender() != 2)) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "gender 取值 1男 2女");
        }
        SysUser u = new SysUser();
        u.setUsername(req.getUsername());
        u.setPassword(passwordEncoder.encode(DEFAULT_PASSWORD));
        u.setRealName(req.getRealName());
        u.setRole(ROLE_REPAIRMAN);
        u.setGender(req.getGender());
        u.setPhone(req.getPhone());
        u.setWorkType(req.getWorkType());
        u.setStatus(req.getStatus() == null ? 1 : req.getStatus());
        sysUserMapper.insert(u);
        return toResponse(u);
    }

    @Transactional
    public RepairmanResponse update(Long id, RepairmanSaveRequest req) {
        SysUser existed = mustGet(id);
        if (req.getGender() == null || (req.getGender() != 1 && req.getGender() != 2)) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "gender 取值 1男 2女");
        }
        // username 不允许修改
        existed.setRealName(req.getRealName());
        existed.setGender(req.getGender());
        existed.setPhone(req.getPhone());
        existed.setWorkType(req.getWorkType());
        if (req.getStatus() != null) {
            existed.setStatus(req.getStatus());
        }
        sysUserMapper.updateById(existed);
        return toResponse(existed);
    }

    @Transactional
    public void delete(Long id) {
        SysUser existed = mustGet(id);
        // 校验：若仍有未完结工单（0/1/2），禁止删除
        Long pendingCnt = repairOrderMapper.selectCount(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<com.dormsystem.entity.RepairOrder>()
                        .eq(com.dormsystem.entity.RepairOrder::getRepairmanId, id)
                        .in(com.dormsystem.entity.RepairOrder::getStatus, 0, 1, 2));
        if (pendingCnt != null && pendingCnt > 0) {
            throw new BusinessException(ResultCode.CONFLICT, "该师傅仍有未完结工单，禁止删除");
        }
        sysUserMapper.deleteById(id);
    }

    private SysUser mustGet(Long id) {
        SysUser u = sysUserMapper.selectById(id);
        if (u == null || !ROLE_REPAIRMAN.equalsIgnoreCase(u.getRole())) {
            throw new BusinessException(ResultCode.NOT_FOUND, "维修师傅不存在");
        }
        return u;
    }

    private RepairmanResponse toResponse(SysUser u) {
        RepairmanResponse r = new RepairmanResponse();
        r.setId(u.getId());
        r.setUsername(u.getUsername());
        r.setRealName(u.getRealName());
        r.setGender(u.getGender());
        r.setPhone(u.getPhone());
        r.setWorkType(u.getWorkType());
        r.setStatus(u.getStatus());
        return r;
    }
}
