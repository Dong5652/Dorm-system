package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 系统用户：学生 / 宿管 / 管理员 / 维修师傅 统一在此表，role 字段区分。
 * 对应表 {@code sys_user}（DATABASE.md §2.2）。
 */
@Data
@TableName("sys_user")
public class SysUser {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 登录名（学生用学号；宿管用工号）。 */
    private String username;

    /** BCrypt 加密密码。 */
    @com.fasterxml.jackson.annotation.JsonIgnore
    private String password;

    /** 真实姓名（与学生 student.name 同值）。 */
    private String realName;

    /** 角色标识：admin / dorm_manager / student / repairman。 */
    private String role;

    /** 性别：1男 2女。 */
    private Integer gender;

    private String phone;

    /** 宿管:管辖楼栋 id；其他角色 null。 */
    private Long buildingId;

    /** 维修师傅工种，如 水电/木工/综合。 */
    private String workType;

    /** 0禁用 1启用。 */
    private Integer status;

    private LocalDateTime lastLoginAt;

    private LocalDateTime createdAt;

    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
