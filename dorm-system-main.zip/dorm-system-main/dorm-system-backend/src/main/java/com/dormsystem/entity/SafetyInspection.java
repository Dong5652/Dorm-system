package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 违禁品检查表
 */
@Data
@TableName("safety_inspection")
public class SafetyInspection {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long roomId;
    private Long studentId;
    private LocalDate inspectDate;
    private Long inspectorId;
    private String itemType;
    private String itemDesc;
    private String photoUrl;
    private String disposition;
    private Integer noticeSent;
    private String remark;
    private LocalDateTime createdAt;
    
    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
