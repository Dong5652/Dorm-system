package com.dormsystem.dto.hygiene;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * 卫生检查录入 / 修改请求（API_SPEC §6.1）。
 *
 * <p>score 计算规则：{@code score = 100 + bonus − deduction}；
 * 若调用方不传 score，由 Service 自动按公式兜底计算。</p>
 */
@Data
public class HygieneSaveRequest {

    @NotNull(message = "房间ID不能为空")
    private Long roomId;

    @NotNull(message = "检查日期不能为空")
    private LocalDate checkDate;

    /** 本次得分。为空时由 Service 按 100 + bonus − deduction 计算。 */
    private BigDecimal score;

    private BigDecimal deduction;

    private BigDecimal bonus;

    private String photoUrl;

    /** 扣分/加分项明细 JSON 字符串。 */
    private String itemDetail;

    private String remark;
}
