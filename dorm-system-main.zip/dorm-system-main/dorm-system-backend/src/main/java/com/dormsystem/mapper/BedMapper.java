package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.Bed;
import org.apache.ibatis.annotations.Mapper;

/** Bed 通用 Mapper。 */
@Mapper
public interface BedMapper extends BaseMapper<Bed> {
}
