package com.dormsystem.dto.hygiene;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 卫生检查列表 / 详情响应（API_SPEC §6.1）。
 *
 * <p>冗余 buildingName / roomNo / inspectorName 便于前端直接展示。</p>
 */
@Data
public class HygieneResponse {

    private Long id;
    private Long roomId;
    private Long buildingId;
    private String buildingName;
    private String roomNo;
    private LocalDate checkDate;
    private Long inspectorId;
    private String inspectorName;
    private BigDecimal score;
    private BigDecimal deduction;
    private BigDecimal bonus;
    private String photoUrl;
    private String itemDetail;
    private String remark;
    private LocalDateTime createdAt;
}
