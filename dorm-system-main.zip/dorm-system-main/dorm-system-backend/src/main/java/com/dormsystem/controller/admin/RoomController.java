package com.dormsystem.controller.admin;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.Result;
import com.dormsystem.dto.dorm.RoomSaveRequest;
import com.dormsystem.entity.Room;
import com.dormsystem.service.RoomService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/** 房间管理（API_SPEC §3.3）。 */
@Tag(name = "Admin · Room", description = "房间 CRUD（管理员）")
@RestController
@RequestMapping("/api/v1/admin/rooms")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class RoomController {

    private final RoomService roomService;

    @Operation(summary = "房间分页列表")
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<Page<Room>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Long floorId) {
        return Result.success(roomService.page(pageNum, pageSize, buildingId, floorId));
    }

    @Operation(summary = "房间详情(刷新 capacity/occupiedCount)")
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<Room> detail(@PathVariable Long id) {
        return Result.success(roomService.getDetail(id));
    }

    @Operation(summary = "新增房间")
    @PostMapping
    public Result<Room> create(@Valid @RequestBody RoomSaveRequest req) {
        return Result.success(roomService.create(req));
    }

    @Operation(summary = "修改房间(基础字段，不含 status)")
    @PutMapping("/{id}")
    public Result<Room> update(@PathVariable Long id, @Valid @RequestBody RoomSaveRequest req) {
        return Result.success(roomService.update(id, req));
    }

    @Operation(summary = "改房间状态(联动床位状态)")
    @PutMapping("/{id}/status")
    public Result<Room> setStatus(@PathVariable Long id, @RequestBody Map<String, Integer> body) {
        Integer status = body.get("status");
        if (status == null) status = body.get("value");
        if (status == null) status = (Integer) body.values().iterator().next();
        return Result.success(roomService.setStatus(id, status));
    }

    @Operation(summary = "删除房间(占用中禁止)")
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        roomService.delete(id);
        return Result.success();
    }
}
