package com.dormsystem.dto.fee;

import lombok.Data;

@Data
public class UtilityFeeRequest {
    private String readingMonth;
}
