package com.dormsystem.controller.admin;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.Result;
import com.dormsystem.dto.dorm.BedSaveRequest;
import com.dormsystem.entity.Bed;
import com.dormsystem.service.BedService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/** 床位管理（API_SPEC §3.4）。 */
@Tag(name = "Admin · Bed", description = "床位 CRUD（管理员）")
@RestController
@RequestMapping("/api/v1/admin/beds")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class BedController {

    private final BedService bedService;

    @Operation(summary = "床位分页列表(按 room_id)")
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<Page<Bed>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) Long roomId) {
        return Result.success(bedService.page(pageNum, pageSize, roomId));
    }

    @Operation(summary = "新增床位")
    @PostMapping
    public Result<Bed> create(@Valid @RequestBody BedSaveRequest req) {
        return Result.success(bedService.create(req));
    }

    @Operation(summary = "修改床位")
    @PutMapping("/{id}")
    public Result<Bed> update(@PathVariable Long id, @Valid @RequestBody BedSaveRequest req) {
        return Result.success(bedService.update(id, req));
    }

    @Operation(summary = "改床位状态(空闲/维修/预留)")
    @PutMapping("/{id}/status")
    public Result<Bed> setStatus(@PathVariable Long id, @RequestBody java.util.Map<String, Integer> body) {
        Integer status = body.get("status");
        if (status == null) status = (Integer) body.values().iterator().next();
        return Result.success(bedService.setStatus(id, status));
    }

    @Operation(summary = "删除床位(占用中禁止)")
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        bedService.delete(id);
        return Result.success();
    }
}
