package com.dormsystem.controller;

import com.dormsystem.common.Result;
import com.dormsystem.dto.repair.RepairmanResponse;
import com.dormsystem.dto.repair.RepairmanSaveRequest;
import com.dormsystem.service.RepairmanService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 维修师傅账号管理控制层（API_SPEC §7.2）。
 *
 * <ul>
 *   <li>GET    /api/v1/admin/repairmen        列表</li>
 *   <li>GET    /api/v1/admin/repairmen/{id}   详情</li>
 *   <li>POST   /api/v1/admin/repairmen        新增（role=repairman，初始密码 123456）</li>
 *   <li>PUT    /api/v1/admin/repairmen/{id}   修改</li>
 *   <li>DELETE /api/v1/admin/repairmen/{id}   软删</li>
 * </ul>
 */
@Tag(name = "Repairman", description = "维修师傅账号管理")
@RestController
@RequestMapping("/api/v1/admin/repairmen")
@RequiredArgsConstructor
public class RepairmanController {

    private final RepairmanService repairmanService;

    @Operation(summary = "维修师傅列表")
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Result<List<RepairmanResponse>> list() {
        return Result.success(repairmanService.list());
    }

    @Operation(summary = "维修师傅详情")
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<RepairmanResponse> get(@PathVariable Long id) {
        return Result.success(repairmanService.get(id));
    }

    @Operation(summary = "新增维修师傅账号")
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Result<RepairmanResponse> create(@Valid @RequestBody RepairmanSaveRequest req) {
        return Result.success(repairmanService.create(req));
    }

    @Operation(summary = "修改维修师傅账号")
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<RepairmanResponse> update(@PathVariable Long id, @Valid @RequestBody RepairmanSaveRequest req) {
        return Result.success(repairmanService.update(id, req));
    }

    @Operation(summary = "删除维修师傅账号（软删）")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> delete(@PathVariable Long id) {
        repairmanService.delete(id);
        return Result.success();
    }
}
