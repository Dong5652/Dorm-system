package com.dormsystem.dto.student;

import com.dormsystem.entity.Student;
import lombok.Data;

import java.util.List;

/**
 * 学生档案详情响应（含基本档案、当前床位详细宿管位置及历史异动流水）。
 */
@Data
public class StudentDetailResponse {

    /** 基本学籍档案 */
    private Student student;

    /** 关联登录账号手机号（由于 phone 存在 sys_user 表，冗余至此） */
    private String phone;

    /** 当前入住床位详细信息，未分配时为 null */
    private BedDetail bedDetail;

    /** 历史异动流水 */
    private List<ChangeRecordDetail> changeRecords;

    @Data
    public static class BedDetail {
        private Long bedId;
        private String bedNo;
        private Long roomId;
        private String roomNo;
        private Long buildingId;
        private String buildingName;
        private Long floorId;
        private Integer floorNo;
    }

    @Data
    public static class ChangeRecordDetail {
        private Long id;
        private String type; // suspend/transfer/change_room/holiday_leave
        private String typeLabel; // 中文说明
        private Long fromBedId;
        private String fromBedNo;
        private String fromRoomNo;
        private Long toBedId;
        private String toBedNo;
        private String toRoomNo;
        private String reason;
        private Long operatorId;
        private String operatorName;
        private java.time.LocalDateTime happenedAt;
        private String remark;
    }
}
