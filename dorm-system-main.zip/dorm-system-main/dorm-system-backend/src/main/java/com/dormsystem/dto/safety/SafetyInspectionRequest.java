package com.dormsystem.dto.safety;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Data
public class SafetyInspectionRequest {
    @NotNull(message = "房间ID不能为空")
    private Long roomId;
    private Long studentId;
    @NotNull(message = "检查日期不能为空")
    private LocalDate inspectDate;
    @NotBlank(message = "违禁品类型不能为空")
    private String itemType;
    @NotBlank(message = "物品描述不能为空")
    private String itemDesc;
    private String photoUrl;
    @NotBlank(message = "处理方式不能为空")
    private String disposition;
    private Boolean noticeSent;
    private String remark;
}
