package com.dormsystem.dto.student;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;

/**
 * 学生新增/编辑保存请求。
 */
@Data
public class StudentSaveRequest {

    @NotBlank(message = "学号不能为空")
    private String studentNo;

    @NotBlank(message = "姓名不能为空")
    private String name;

    @NotNull(message = "性别不能为空")
    private Integer gender;

    private String college;

    private String major;

    private String className;

    private String grade;

    private String phone;

    private String emergencyContact;

    private String emergencyPhone;

    private LocalDate enrollDate;

    @NotNull(message = "在籍状态不能为空")
    private Integer status;
}
