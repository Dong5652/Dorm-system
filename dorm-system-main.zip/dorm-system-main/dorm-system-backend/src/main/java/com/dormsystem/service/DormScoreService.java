package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.score.DormScoreManualRequest;
import com.dormsystem.dto.score.DormScoreResponse;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 寝室综合评分服务（API_SPEC §6.3）。
 *
 * <p>评分公式：</p>
 * <pre>
 *   total_score = hygiene_avg × 0.6 + (100 − late_count × 5) × 0.4
 *   level: ≥90 优秀 / 75-89 合格 / 60-74 待整改 / &lt;60 不合格
 * </pre>
 *
 * <p>数据范围：</p>
 * <ul>
 *   <li>ADMIN → 全部</li>
 *   <li>DORM_MANAGER → 强制锁定为本人 buildingId</li>
 *   <li>STUDENT → 仅本人所在房间</li>
 * </ul>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DormScoreService {

    public static final BigDecimal WEIGHT_HYGIENE = new BigDecimal("0.6");
    public static final BigDecimal WEIGHT_ATTENDANCE = new BigDecimal("0.4");
    public static final BigDecimal SCORE_BASE = new BigDecimal("100");
    public static final BigDecimal LATE_PENALTY = new BigDecimal("5");

    private final DormScoreMapper dormScoreMapper;
    private final HygieneCheckMapper hygieneCheckMapper;
    private final AttendanceMapper attendanceMapper;
    private final RoomMapper roomMapper;
    private final BuildingMapper buildingMapper;
    private final StudentService studentService;
    private final OperationLogMapper operationLogMapper;

    /**
     * 生成指定月份的寝室评分（幂等：覆盖已存在的记录）。
     *
     * @param yearMonth 形如 "2026-03"
     * @return 影响的房间数
     */
    @Transactional
    public int generateMonthlyScores(String yearMonth) {
        // 解析月份
        YearMonth ym;
        try {
            ym = YearMonth.parse(yearMonth);
        } catch (Exception e) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "yearMonth 格式应为 yyyy-MM，如 2026-03");
        }
        LocalDate monthStart = ym.atDay(1);
        LocalDate monthEnd = ym.atEndOfMonth();

        // 1. 取所有房间
        List<Room> allRooms = roomMapper.selectList(null);
        if (allRooms.isEmpty()) {
            log.info("DormScore monthly: no rooms found, skip");
            return 0;
        }

        // 2. 取本月所有卫生检查
        List<HygieneCheck> hygieneList = hygieneCheckMapper.selectList(
                new LambdaQueryWrapper<HygieneCheck>()
                        .ge(HygieneCheck::getCheckDate, monthStart)
                        .le(HygieneCheck::getCheckDate, monthEnd));
        Map<Long, List<HygieneCheck>> hygieneByRoom = hygieneList.stream()
                .collect(Collectors.groupingBy(HygieneCheck::getRoomId));

        // 3. 取本月所有晚归/未归记录（type=1晚归 2未归）
        List<Attendance> attendanceList = attendanceMapper.selectList(
                new LambdaQueryWrapper<Attendance>()
                        .ge(Attendance::getRecordDate, monthStart)
                        .le(Attendance::getRecordDate, monthEnd)
                        .in(Attendance::getType, 1, 2));
        Map<Long, Long> lateCountByRoom = attendanceList.stream()
                .collect(Collectors.groupingBy(Attendance::getRoomId, Collectors.counting()));

        // 4. 清掉同月旧记录（物理删除，重新生成；避免软删行命中唯一约束）
        dormScoreMapper.physicalDeleteByMonth(yearMonth);

        int affected = 0;
        for (Room room : allRooms) {
            List<HygieneCheck> roomHygiene = hygieneByRoom.getOrDefault(room.getId(), List.of());
            BigDecimal hygieneAvg;
            if (roomHygiene.isEmpty()) {
                // 当月没有卫生检查：默认 100 满分基础（避免没检查的房间被误降级）
                hygieneAvg = SCORE_BASE;
            } else {
                BigDecimal sum = BigDecimal.ZERO;
                for (HygieneCheck h : roomHygiene) {
                    if (h.getScore() != null) {
                        sum = sum.add(h.getScore());
                    }
                }
                hygieneAvg = sum.divide(new BigDecimal(roomHygiene.size()), 2, RoundingMode.HALF_UP);
            }

            long lateCount = lateCountByRoom.getOrDefault(room.getId(), 0L);
            // 晚归扣分上限 100（避免负数）
            BigDecimal latePenalty = LATE_PENALTY.multiply(BigDecimal.valueOf(lateCount));
            BigDecimal attendanceScore = SCORE_BASE.subtract(latePenalty);
            if (attendanceScore.compareTo(BigDecimal.ZERO) < 0) {
                attendanceScore = BigDecimal.ZERO;
            }

            BigDecimal totalScore = hygieneAvg.multiply(WEIGHT_HYGIENE)
                    .add(attendanceScore.multiply(WEIGHT_ATTENDANCE))
                    .setScale(2, RoundingMode.HALF_UP);

            DormScore score = new DormScore();
            score.setRoomId(room.getId());
            score.setYearMonth(yearMonth);
            score.setHygieneAvg(hygieneAvg.setScale(2, RoundingMode.HALF_UP));
            score.setLateCount((int) lateCount);
            score.setTotalScore(totalScore);
            score.setLevel(calcLevel(totalScore));
            dormScoreMapper.insert(score);
            affected++;
        }
        log.info("DormScore monthly: generated {} scores for {}", affected, yearMonth);
        return affected;
    }

    /** 管理员手动补录 / 修正某寝室某月评分。 */
    @Transactional
    public DormScore manualOverride(DormScoreManualRequest req, Long operatorUserId) {
        Room room = roomMapper.selectById(req.getRoomId());
        if (room == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "房间不存在");
        }
        // 删除原记录（物理删除；避免软删行命中唯一约束）
        dormScoreMapper.physicalDeleteByRoomAndMonth(req.getRoomId(), req.getYearMonth());

        BigDecimal hygieneAvg = req.getHygieneAvg();
        Integer lateCount = req.getLateCount();
        BigDecimal totalScore = req.getTotalScore();
        String level = req.getLevel();

        // 未传字段按公式兜底重算
        if (hygieneAvg == null) hygieneAvg = SCORE_BASE;
        if (lateCount == null) lateCount = 0;
        if (totalScore == null) {
            BigDecimal attendanceScore = SCORE_BASE.subtract(LATE_PENALTY.multiply(BigDecimal.valueOf(lateCount)));
            if (attendanceScore.compareTo(BigDecimal.ZERO) < 0) {
                attendanceScore = BigDecimal.ZERO;
            }
            totalScore = hygieneAvg.multiply(WEIGHT_HYGIENE)
                    .add(attendanceScore.multiply(WEIGHT_ATTENDANCE))
                    .setScale(2, RoundingMode.HALF_UP);
        }
        if (level == null) {
            level = calcLevel(totalScore);
        }

        DormScore score = new DormScore();
        score.setRoomId(req.getRoomId());
        score.setYearMonth(req.getYearMonth());
        score.setHygieneAvg(hygieneAvg.setScale(2, RoundingMode.HALF_UP));
        score.setLateCount(lateCount);
        score.setTotalScore(totalScore.setScale(2, RoundingMode.HALF_UP));
        score.setLevel(level);
        score.setRemark(req.getRemark());
        dormScoreMapper.insert(score);

        // 写操作日志
        OperationLog log = new OperationLog();
        log.setOperatorId(operatorUserId);
        log.setModule("dorm_score");
        log.setAction("manual_override");
        log.setTargetTable("dorm_score");
        log.setTargetId(score.getId());
        log.setDetail(String.format(
                "{\"roomId\":%d,\"yearMonth\":\"%s\",\"hygieneAvg\":%s,\"lateCount\":%d,\"totalScore\":%s,\"level\":\"%s\"}",
                req.getRoomId(), req.getYearMonth(), hygieneAvg, lateCount, totalScore, level));
        operationLogMapper.insert(log);

        return score;
    }

    /**
     * 查询月度评分排行。
     *
     * @param yearMonth  月份；为空则取最近一条记录的月份
     * @param buildingId 楼栋筛选
     * @param roomId     房间筛选
     */
    public List<DormScoreResponse> listScores(String yearMonth, Long buildingId, Long roomId) {
        // 1. 解析 yearMonth：为空取最新
        String targetMonth = yearMonth;
        if (targetMonth == null || targetMonth.isBlank()) {
            List<DormScore> latest = dormScoreMapper.selectList(
                    new LambdaQueryWrapper<DormScore>()
                            .orderByDesc(DormScore::getYearMonth)
                            .last("LIMIT 1"));
            if (latest.isEmpty()) {
                return List.of();
            }
            targetMonth = latest.get(0).getYearMonth();
        }

        // 2. 收敛可见房间（学生只能看本人房间）
        Set<Long> visibleRoomIds = scopeRoomIds();

        LambdaQueryWrapper<DormScore> w = new LambdaQueryWrapper<DormScore>()
                .eq(DormScore::getYearMonth, targetMonth);
        if (visibleRoomIds != null) {
            if (visibleRoomIds.isEmpty()) return List.of();
            w.in(DormScore::getRoomId, visibleRoomIds);
        }
        if (roomId != null) {
            if (visibleRoomIds != null && !visibleRoomIds.contains(roomId)) {
                throw new BusinessException(ResultCode.FORBIDDEN, "无权访问该房间的评分");
            }
            w.eq(DormScore::getRoomId, roomId);
        }
        if (buildingId != null) {
            Set<Long> roomsOfBuilding = listRoomIdsOfBuilding(buildingId);
            if (roomsOfBuilding.isEmpty()) return List.of();
            w.in(DormScore::getRoomId, roomsOfBuilding);
        }
        w.orderByDesc(DormScore::getTotalScore);

        List<DormScore> scores = dormScoreMapper.selectList(w);
        if (scores.isEmpty()) return List.of();

        // 3. 批量加载 room / building 信息
        Set<Long> roomIdsInScores = scores.stream().map(DormScore::getRoomId).collect(Collectors.toSet());
        Map<Long, Room> roomMap = roomMapper.selectList(
                new LambdaQueryWrapper<Room>().in(Room::getId, roomIdsInScores))
                .stream().collect(Collectors.toMap(Room::getId, r -> r));
        Set<Long> buildingIds = roomMap.values().stream()
                .map(Room::getBuildingId).filter(Objects::nonNull).collect(Collectors.toSet());
        Map<Long, Building> buildingMap = buildingIds.isEmpty() ? Map.of()
                : buildingMapper.selectList(new LambdaQueryWrapper<Building>().in(Building::getId, buildingIds))
                .stream().collect(Collectors.toMap(Building::getId, b -> b));

        // 4. 拼装响应 + 计算排名
        List<DormScoreResponse> out = new ArrayList<>(scores.size());
        int rank = 1;
        BigDecimal prevScore = null;
        for (int i = 0; i < scores.size(); i++) {
            DormScore s = scores.get(i);
            DormScoreResponse r = new DormScoreResponse();
            r.setRoomId(s.getRoomId());
            r.setYearMonth(s.getYearMonth());
            r.setHygieneAvg(s.getHygieneAvg());
            r.setLateCount(s.getLateCount());
            r.setTotalScore(s.getTotalScore());
            r.setLevel(s.getLevel());
            r.setRemark(s.getRemark());

            Room room = roomMap.get(s.getRoomId());
            if (room != null) {
                r.setRoomNo(room.getRoomNo());
                r.setBuildingId(room.getBuildingId());
                Building b = buildingMap.get(room.getBuildingId());
                if (b != null) r.setBuildingName(b.getName());
            }

            // 同分同排名（standard competition ranking）
            if (prevScore != null && prevScore.compareTo(s.getTotalScore()) == 0) {
                // 同分共用前一个排名
            } else {
                rank = i + 1;
                prevScore = s.getTotalScore();
            }
            r.setRank(rank);
            out.add(r);
        }
        return out;
    }

    // ---- 工具方法 -------------------------------------------------------

    public static String calcLevel(BigDecimal totalScore) {
        if (totalScore == null) return "不合格";
        BigDecimal v = totalScore.setScale(2, RoundingMode.HALF_UP);
        if (v.compareTo(new BigDecimal("90")) >= 0) return "优秀";
        if (v.compareTo(new BigDecimal("75")) >= 0) return "合格";
        if (v.compareTo(new BigDecimal("60")) >= 0) return "待整改";
        return "不合格";
    }

    /** 学生返回本人房间 id 集合；ADMIN/宿管返回 null（不限）。 */
    private Set<Long> scopeRoomIds() {
        String role = com.dormsystem.security.SecurityUtils.currentRole();
        if (BuildingService.ROLE_ADMIN.equalsIgnoreCase(role)) return null;
        if (BuildingService.ROLE_DORM_MANAGER.equalsIgnoreCase(role)) {
            Long bid = com.dormsystem.security.SecurityUtils.currentUser().getBuildingId();
            if (bid == null) {
                throw new BusinessException(ResultCode.FORBIDDEN, "宿管未绑定管辖楼栋");
            }
            return listRoomIdsOfBuilding(bid);
        }
        if ("student".equalsIgnoreCase(role)) {
            Long studentUserId = com.dormsystem.security.SecurityUtils.currentUserId();
            Long roomId = studentService.currentStudentRoomId(studentUserId);
            return roomId == null ? Set.of() : Set.of(roomId);
        }
        throw new BusinessException(ResultCode.FORBIDDEN, "无评分查询权限");
    }

    private Set<Long> listRoomIdsOfBuilding(Long buildingId) {
        List<Room> rooms = roomMapper.selectList(
                new LambdaQueryWrapper<Room>().eq(Room::getBuildingId, buildingId));
        return rooms.stream().map(Room::getId).collect(Collectors.toSet());
    }
}
