package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 卫生检查表（{@code hygiene_check}，DATABASE.md §2.4）。
 * score = 100 + bonus − deduction。
 */
@Data
@TableName("hygiene_check")
public class HygieneCheck {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long roomId;

    private LocalDate checkDate;

    /** 检查人 user_id（宿管）。 */
    private Long inspectorId;

    private BigDecimal score;

    private BigDecimal deduction;

    private BigDecimal bonus;

    private String photoUrl;

    /** 扣分/加分项明细 JSON 字符串。 */
    private String itemDetail;

    private String remark;

    private LocalDateTime createdAt;

    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
