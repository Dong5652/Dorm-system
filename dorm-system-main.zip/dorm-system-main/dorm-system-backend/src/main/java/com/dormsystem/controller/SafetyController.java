package com.dormsystem.controller;

import com.dormsystem.common.Result;
import com.dormsystem.dto.safety.*;
import com.dormsystem.entity.SafetyEvent;
import com.dormsystem.entity.SafetyInspection;
import com.dormsystem.entity.Visitor;
import com.dormsystem.service.SafetyService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Tag(name = "Safety Module", description = "访客与安全模块接口")
@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class SafetyController {

    private final SafetyService safetyService;

    // ==========================================
    // 访客管理
    // ==========================================

    @Operation(summary = "访客记录列表查询")
    @GetMapping("/safety/visitor")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_MANAGER')")
    public Result<List<Visitor>> queryVisitors(
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam(required = false) Long targetStudentId) {
        return Result.success(safetyService.queryVisitors(buildingId, date, targetStudentId));
    }

    @Operation(summary = "访客登记")
    @PostMapping("/safety/visitor")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_MANAGER')")
    public Result<Void> registerVisitor(@Valid @RequestBody VisitorRequest req) {
        safetyService.registerVisitor(req);
        return Result.success();
    }

    @Operation(summary = "登记访客离开")
    @PutMapping("/safety/visitor/{id}/exit")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_MANAGER')")
    public Result<Void> exitVisitor(@PathVariable Long id) {
        safetyService.exitVisitor(id);
        return Result.success();
    }

    @Operation(summary = "删除访客记录")
    @DeleteMapping("/admin/safety/visitor/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> deleteVisitor(@PathVariable Long id) {
        safetyService.deleteVisitor(id);
        return Result.success();
    }

    // ==========================================
    // 违禁品检查
    // ==========================================

    @Operation(summary = "违禁品检查记录列表查询")
    @GetMapping("/safety/inspection")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_MANAGER')")
    public Result<List<SafetyInspection>> queryInspections(
            @RequestParam(required = false) Long roomId,
            @RequestParam(required = false) Long studentId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return Result.success(safetyService.queryInspections(roomId, studentId, startDate, endDate));
    }

    @Operation(summary = "录入违禁品检查")
    @PostMapping("/safety/inspection")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_MANAGER')")
    public Result<Void> recordInspection(@Valid @RequestBody SafetyInspectionRequest req) {
        safetyService.recordInspection(req);
        return Result.success();
    }

    @Operation(summary = "修改违禁品检查记录")
    @PutMapping("/admin/safety/inspection/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> updateInspection(@PathVariable Long id, @Valid @RequestBody SafetyInspectionRequest req) {
        safetyService.updateInspection(id, req);
        return Result.success();
    }

    @Operation(summary = "删除违禁品检查记录")
    @DeleteMapping("/admin/safety/inspection/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> deleteInspection(@PathVariable Long id) {
        safetyService.deleteInspection(id);
        return Result.success();
    }

    // ==========================================
    // 安全事件
    // ==========================================

    @Operation(summary = "安全事件列表查询")
    @GetMapping("/safety/event")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_MANAGER')")
    public Result<List<SafetyEvent>> queryEvents(
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Integer handled,
            @RequestParam(required = false) Integer severity,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return Result.success(safetyService.queryEvents(buildingId, handled, severity, startDate, endDate));
    }

    @Operation(summary = "上报安全事件")
    @PostMapping("/safety/event")
    @PreAuthorize("hasAnyRole('ADMIN', 'DORM_MANAGER')")
    public Result<Void> reportEvent(@Valid @RequestBody SafetyEventRequest req) {
        safetyService.reportEvent(req);
        return Result.success();
    }

    @Operation(summary = "处理安全事件")
    @PutMapping("/admin/safety/event/{id}/handle")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> handleEvent(@PathVariable Long id, @Valid @RequestBody SafetyEventHandleRequest req) {
        safetyService.handleEvent(id, req);
        return Result.success();
    }

    @Operation(summary = "删除安全事件")
    @DeleteMapping("/admin/safety/event/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> deleteEvent(@PathVariable Long id) {
        safetyService.deleteEvent(id);
        return Result.success();
    }
}
