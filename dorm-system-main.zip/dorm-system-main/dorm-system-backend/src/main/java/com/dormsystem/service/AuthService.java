package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.ChangePasswordRequest;
import com.dormsystem.dto.CurrentUserResponse;
import com.dormsystem.dto.LoginRequest;
import com.dormsystem.dto.LoginResponse;
import com.dormsystem.entity.SysUser;
import com.dormsystem.mapper.SysUserMapper;
import com.dormsystem.security.JwtUtil;
import com.dormsystem.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * 认证服务：登录、登出、当前用户、修改密码。
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final SysUserMapper sysUserMapper;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final com.dormsystem.mapper.BuildingMapper buildingMapper;

    public LoginResponse login(LoginRequest req) {
        SysUser user = sysUserMapper.selectOne(
                new LambdaQueryWrapper<SysUser>().eq(SysUser::getUsername, req.getUsername()));
        if (user == null) {
            throw new BusinessException(ResultCode.UNAUTHORIZED, "账号或密码错误");
        }
        if (!passwordEncoder.matches(req.getPassword(), user.getPassword())) {
            throw new BusinessException(ResultCode.UNAUTHORIZED, "账号或密码错误");
        }
        if (user.getStatus() != null && user.getStatus() == 0) {
            throw new BusinessException(ResultCode.FORBIDDEN, "账号已被禁用，请联系管理员");
        }
        String token = jwtUtil.generate(user.getId(), user.getUsername(), user.getRole());

        // 刷新最近登录时间
        user.setLastLoginAt(LocalDateTime.now());
        sysUserMapper.updateById(user);

        return new LoginResponse(token, user.getId(), user.getUsername(), user.getRealName(), user.getRole());
    }

    public CurrentUserResponse currentUser() {
        SysUser user = SecurityUtils.currentUser();
        CurrentUserResponse resp = new CurrentUserResponse();
        resp.setUserId(user.getId());
        resp.setUsername(user.getUsername());
        resp.setRealName(user.getRealName());
        resp.setRole(user.getRole());
        resp.setBuildingId(user.getBuildingId());
        
        if (user.getBuildingId() != null) {
            com.dormsystem.entity.Building building = buildingMapper.selectById(user.getBuildingId());
            if (building != null) {
                resp.setBuildingName(building.getName());
            }
        }
        
        resp.setGender(user.getGender());
        resp.setPhone(user.getPhone());
        return resp;
    }

    @Transactional
    public void changePassword(ChangePasswordRequest req) {
        SysUser user = SecurityUtils.currentUser();
        if (!passwordEncoder.matches(req.getOldPassword(), user.getPassword())) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "原密码错误");
        }
        if (Objects.equals(req.getOldPassword(), req.getNewPassword())) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "新密码不能与原密码相同");
        }
        user.setPassword(passwordEncoder.encode(req.getNewPassword()));
        sysUserMapper.updateById(user);
        log.info("用户 {} 修改密码成功", user.getUsername());
    }
}
