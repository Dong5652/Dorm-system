package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.hygiene.HygieneResponse;
import com.dormsystem.dto.hygiene.HygieneSaveRequest;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.BuildingMapper;
import com.dormsystem.mapper.HygieneCheckMapper;
import com.dormsystem.mapper.RoomMapper;
import com.dormsystem.mapper.SysUserMapper;
import com.dormsystem.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 卫生检查服务（API_SPEC §6.1）。
 *
 * <p>数据范围：</p>
 * <ul>
 *   <li>ADMIN → 全部</li>
 *   <li>DORM_MANAGER → 强制锁定为本人 buildingId 下的房间</li>
 *   <li>STUDENT → 仅本人当前入住房间的卫生记录（通过 StudentService 反查）</li>
 * </ul>
 *
 * <p>得分兜底：调用方未传 score 时按 {@code score = 100 + bonus − deduction} 自动计算。</p>
 */
@Service
@RequiredArgsConstructor
public class HygieneService {

    public static final String ROLE_STUDENT = "student";
    /** score 公式基数。 */
    public static final BigDecimal SCORE_BASE = new BigDecimal("100");

    private final HygieneCheckMapper hygieneCheckMapper;
    private final RoomMapper roomMapper;
    private final BuildingMapper buildingMapper;
    private final SysUserMapper sysUserMapper;
    private final StudentService studentService;

    @Transactional
    public HygieneCheck create(HygieneSaveRequest req) {
        Room room = mustRoomWritable(req.getRoomId());

        HygieneCheck check = new HygieneCheck();
        check.setRoomId(room.getId());
        check.setCheckDate(req.getCheckDate());
        check.setInspectorId(SecurityUtils.currentUserId());
        applyScore(check, req);
        check.setPhotoUrl(req.getPhotoUrl());
        check.setItemDetail(req.getItemDetail());
        check.setRemark(req.getRemark());
        hygieneCheckMapper.insert(check);
        return check;
    }

    @Transactional
    public HygieneCheck update(Long id, HygieneSaveRequest req) {
        HygieneCheck existed = hygieneCheckMapper.selectById(id);
        if (existed == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "卫生记录不存在");
        }
        mustRoomWritable(existed.getRoomId());
        if (!existed.getRoomId().equals(req.getRoomId())) {
            mustRoomWritable(req.getRoomId());
            existed.setRoomId(req.getRoomId());
        }
        existed.setCheckDate(req.getCheckDate());
        applyScore(existed, req);
        existed.setPhotoUrl(req.getPhotoUrl());
        existed.setItemDetail(req.getItemDetail());
        existed.setRemark(req.getRemark());
        hygieneCheckMapper.updateById(existed);
        return existed;
    }

    @Transactional
    public void delete(Long id) {
        HygieneCheck existed = hygieneCheckMapper.selectById(id);
        if (existed == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "卫生记录不存在");
        }
        // 只有 ADMIN 才能删除（API_SPEC §6.1）
        if (!BuildingService.ROLE_ADMIN.equalsIgnoreCase(SecurityUtils.currentRole())) {
            throw new BusinessException(ResultCode.FORBIDDEN, "仅管理员可删除卫生记录");
        }
        mustRoomWritable(existed.getRoomId());
        hygieneCheckMapper.deleteById(existed.getId());
    }

    public HygieneResponse get(Long id) {
        HygieneCheck check = hygieneCheckMapper.selectById(id);
        if (check == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "卫生记录不存在");
        }
        ensureRoomReadable(check.getRoomId());
        return toResponse(check);
    }

    public IPage<HygieneResponse> page(int pageNum, int pageSize,
                                       Long roomId, Long buildingId,
                                       LocalDate startDate, LocalDate endDate) {
        // 1. 收敛可见房间集合
        Set<Long> visibleRoomIds = scopeRoomIds();
        if (visibleRoomIds != null && visibleRoomIds.isEmpty()) {
            return new Page<>(pageNum, pageSize, 0);
        }

        LambdaQueryWrapper<HygieneCheck> w = new LambdaQueryWrapper<>();
        if (visibleRoomIds != null) {
            w.in(HygieneCheck::getRoomId, visibleRoomIds);
        }
        if (roomId != null) {
            if (visibleRoomIds != null && !visibleRoomIds.contains(roomId)) {
                throw new BusinessException(ResultCode.FORBIDDEN, "无权访问该房间的卫生记录");
            }
            w.eq(HygieneCheck::getRoomId, roomId);
        }
        if (buildingId != null) {
            Set<Long> roomsOfBuilding = listRoomIdsOfBuilding(buildingId);
            if (roomsOfBuilding.isEmpty()) {
                return new Page<>(pageNum, pageSize, 0);
            }
            w.in(HygieneCheck::getRoomId, roomsOfBuilding);
        }
        if (startDate != null) w.ge(HygieneCheck::getCheckDate, startDate);
        if (endDate != null) w.le(HygieneCheck::getCheckDate, endDate);
        w.orderByDesc(HygieneCheck::getCheckDate).orderByDesc(HygieneCheck::getId);

        Page<HygieneCheck> page = new Page<>(pageNum, pageSize);
        IPage<HygieneCheck> raw = hygieneCheckMapper.selectPage(page, w);
        return raw.convert(this::toResponse);
    }

    // ---- 工具方法 -------------------------------------------------------

    /** 学生返回本人房间 id 集合（含当前入住）；ADMIN/宿管返回 null（不限）。 */
    private Set<Long> scopeRoomIds() {
        String role = SecurityUtils.currentRole();
        if (BuildingService.ROLE_ADMIN.equalsIgnoreCase(role)) return null;
        if (BuildingService.ROLE_DORM_MANAGER.equalsIgnoreCase(role)) {
            Long bid = SecurityUtils.currentUser().getBuildingId();
            if (bid == null) {
                throw new BusinessException(ResultCode.FORBIDDEN, "宿管未绑定管辖楼栋");
            }
            return listRoomIdsOfBuilding(bid);
        }
        if (ROLE_STUDENT.equalsIgnoreCase(role)) {
            Long studentUserId = SecurityUtils.currentUserId();
            Long roomId = studentService.currentStudentRoomId(studentUserId);
            return roomId == null ? Set.of() : Set.of(roomId);
        }
        throw new BusinessException(ResultCode.FORBIDDEN, "无卫生数据查询权限");
    }

    private Set<Long> listRoomIdsOfBuilding(Long buildingId) {
        List<Room> rooms = roomMapper.selectList(
                new LambdaQueryWrapper<Room>().eq(Room::getBuildingId, buildingId));
        return rooms.stream().map(Room::getId).collect(Collectors.toSet());
    }

    private Room mustRoomWritable(Long roomId) {
        Room r = roomMapper.selectById(roomId);
        if (r == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "房间不存在");
        }
        String role = SecurityUtils.currentRole();
        if (BuildingService.ROLE_ADMIN.equalsIgnoreCase(role)) {
            return r;
        }
        if (BuildingService.ROLE_DORM_MANAGER.equalsIgnoreCase(role)) {
            Long bid = SecurityUtils.currentUser().getBuildingId();
            if (bid == null || !bid.equals(r.getBuildingId())) {
                throw new BusinessException(ResultCode.FORBIDDEN, "无权操作该楼栋的卫生记录");
            }
            return r;
        }
        throw new BusinessException(ResultCode.FORBIDDEN, "无卫生数据写入权限");
    }

    private void ensureRoomReadable(Long roomId) {
        String role = SecurityUtils.currentRole();
        if (BuildingService.ROLE_ADMIN.equalsIgnoreCase(role)) return;
        if (BuildingService.ROLE_DORM_MANAGER.equalsIgnoreCase(role)) {
            Long bid = SecurityUtils.currentUser().getBuildingId();
            Room r = roomMapper.selectById(roomId);
            if (r == null || bid == null || !bid.equals(r.getBuildingId())) {
                throw new BusinessException(ResultCode.FORBIDDEN, "无权查看该卫生记录");
            }
            return;
        }
        if (ROLE_STUDENT.equalsIgnoreCase(role)) {
            Long studentUserId = SecurityUtils.currentUserId();
            Long myRoom = studentService.currentStudentRoomId(studentUserId);
            if (myRoom == null || !myRoom.equals(roomId)) {
                throw new BusinessException(ResultCode.FORBIDDEN, "只能查看本人房间的卫生记录");
            }
        }
    }

    private HygieneResponse toResponse(HygieneCheck check) {
        HygieneResponse r = new HygieneResponse();
        r.setId(check.getId());
        r.setRoomId(check.getRoomId());
        r.setCheckDate(check.getCheckDate());
        r.setInspectorId(check.getInspectorId());
        r.setScore(check.getScore());
        r.setDeduction(check.getDeduction());
        r.setBonus(check.getBonus());
        r.setPhotoUrl(check.getPhotoUrl());
        r.setItemDetail(check.getItemDetail());
        r.setRemark(check.getRemark());
        r.setCreatedAt(check.getCreatedAt());

        Room room = roomMapper.selectById(check.getRoomId());
        if (room != null) {
            r.setRoomNo(room.getRoomNo());
            r.setBuildingId(room.getBuildingId());
            Building b = buildingMapper.selectById(room.getBuildingId());
            if (b != null) r.setBuildingName(b.getName());
        }
        SysUser inspector = sysUserMapper.selectById(check.getInspectorId());
        if (inspector != null) r.setInspectorName(inspector.getRealName());
        return r;
    }

    /** 把 deduction / bonus / score 同步到实体上，score 为空时按公式计算。 */
    private static void applyScore(HygieneCheck check, HygieneSaveRequest req) {
        BigDecimal deduction = req.getDeduction() == null ? BigDecimal.ZERO : req.getDeduction();
        BigDecimal bonus = req.getBonus() == null ? BigDecimal.ZERO : req.getBonus();
        check.setDeduction(deduction);
        check.setBonus(bonus);
        if (req.getScore() != null) {
            check.setScore(req.getScore());
        } else {
            check.setScore(SCORE_BASE.add(bonus).subtract(deduction));
        }
    }
}
