package com.dormsystem.controller.admin;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.Result;
import com.dormsystem.dto.dorm.BuildingSaveRequest;
import com.dormsystem.entity.Building;
import com.dormsystem.service.BuildingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 楼栋管理（API_SPEC §3.1）{@code /api/v1/admin/buildings}。
 *
 * <p>权限:GET 列表 / 详情对 admin + dorm_manager 放开(数据范围见 {@link BuildingService#scopeBuildingId()});
 * 写操作(POST/PUT/DELETE)仅 admin。</p>
 */
@Tag(name = "Admin · Building", description = "楼栋 CRUD（管理员）")
@RestController
@RequestMapping("/api/v1/admin/buildings")
@RequiredArgsConstructor
public class BuildingController {

    private final BuildingService buildingService;

    @Operation(summary = "楼栋分页列表")
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<Page<Building>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer gender) {
        return Result.success(buildingService.page(pageNum, pageSize, keyword, gender));
    }

    @Operation(summary = "全部楼栋(下拉)")
    @GetMapping("/all")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<List<Building>> all() {
        return Result.success(buildingService.listAll());
    }

    @Operation(summary = "所有宿管用户列表(用于绑定楼栋)")
    @GetMapping("/managers")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<List<com.dormsystem.entity.SysUser>> managers() {
        return Result.success(buildingService.listManagers());
    }

    @Operation(summary = "楼栋详情")
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<Building> get(@PathVariable Long id) {
        return Result.success(buildingService.get(id));
    }

    @Operation(summary = "新增楼栋")
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Building> create(@Valid @RequestBody BuildingSaveRequest req) {
        return Result.success(buildingService.create(req));
    }

    @Operation(summary = "修改楼栋")
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Building> update(@PathVariable Long id, @Valid @RequestBody BuildingSaveRequest req) {
        return Result.success(buildingService.update(id, req));
    }

    @Operation(summary = "删除楼栋(软删)")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> delete(@PathVariable Long id) {
        buildingService.delete(id);
        return Result.success();
    }
}
