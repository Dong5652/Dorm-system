package com.dormsystem.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * 修改密码请求（{@code PUT /api/v1/auth/password}，API_SPEC §2.4）。
 */
@Data
public class ChangePasswordRequest {

    @NotBlank
    private String oldPassword;

    @NotBlank
    @Size(min = 6, max = 32, message = "新密码长度需在 6–32 之间")
    private String newPassword;
}
