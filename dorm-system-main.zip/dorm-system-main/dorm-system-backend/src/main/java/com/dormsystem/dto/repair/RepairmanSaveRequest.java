package com.dormsystem.dto.repair;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 维修师傅账号新增 / 修改请求（API_SPEC §7.2）。
 *
 * <p>新增：role 自动设为 {@code repairman}，初始密码 {@code 123456}（BCrypt 加密）。
 * 修改：username 不可改；realName / phone / workType / gender 可改。</p>
 */
@Data
public class RepairmanSaveRequest {

    @NotBlank(message = "登录名不能为空")
    private String username;

    @NotBlank(message = "姓名不能为空")
    private String realName;

    @NotNull(message = "性别不能为空")
    private Integer gender;

    private String phone;

    /** 工种：水电 / 木工 / 综合。 */
    private String workType;

    /** 0禁用 1启用；新增时为空默认 1。 */
    private Integer status;
}
