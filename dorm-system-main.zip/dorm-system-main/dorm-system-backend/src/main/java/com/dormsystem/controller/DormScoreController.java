package com.dormsystem.controller;

import com.dormsystem.common.Result;
import com.dormsystem.dto.score.DormScoreManualRequest;
import com.dormsystem.dto.score.DormScoreResponse;
import com.dormsystem.dto.score.DormScoreTriggerRequest;
import com.dormsystem.entity.DormScore;
import com.dormsystem.security.SecurityUtils;
import com.dormsystem.service.DormScoreService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 寝室评分控制层（API_SPEC §6.3）。
 *
 * <ul>
 *   <li>GET  /api/v1/dorm/scores                  查询月度评分排行</li>
 *   <li>POST /api/v1/admin/dorm/scores/manual    管理员手动补录/修正</li>
 *   <li>POST /api/v1/admin/dorm/scores/trigger    手动触发月度评分任务</li>
 * </ul>
 */
@Tag(name = "Dorm Score", description = "寝室综合评分接口")
@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class DormScoreController {

    private final DormScoreService dormScoreService;

    @Operation(summary = "查询月度评分排行")
    @GetMapping("/dorm/scores")
    @PreAuthorize("isAuthenticated()")
    public Result<Map<String, Object>> list(
            @RequestParam(required = false) String yearMonth,
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Long roomId) {
        List<DormScoreResponse> list = dormScoreService.listScores(yearMonth, buildingId, roomId);
        return Result.success(Map.of("list", list));
    }

    @Operation(summary = "管理员手动补录/修正某寝室某月评分")
    @PostMapping("/admin/dorm/scores/manual")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<DormScore> manual(@Valid @RequestBody DormScoreManualRequest req) {
        return Result.success(dormScoreService.manualOverride(req, SecurityUtils.currentUserId()));
    }

    @Operation(summary = "手动触发月度评分任务（开发联调用）")
    @PostMapping("/admin/dorm/scores/trigger")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Map<String, Object>> trigger(@Valid @RequestBody DormScoreTriggerRequest req) {
        int affected = dormScoreService.generateMonthlyScores(req.getYearMonth());
        return Result.success(Map.of(
                "yearMonth", req.getYearMonth(),
                "affected", affected));
    }
}
