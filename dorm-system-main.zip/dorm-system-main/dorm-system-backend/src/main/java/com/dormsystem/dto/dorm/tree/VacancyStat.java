package com.dormsystem.dto.dorm.tree;

import lombok.Data;

/** {@code GET /api/v1/dorm/vacancy} 按楼栋返回空置统计。 */
@Data
public class VacancyStat {
    private Long buildingId;
    private String buildingName;
    private Integer totalBeds;
    private Integer occupiedBeds;
    private Integer vacantBeds;
    private Double occupancyRate;
}
