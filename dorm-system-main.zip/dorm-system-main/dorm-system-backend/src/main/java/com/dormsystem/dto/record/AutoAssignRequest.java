package com.dormsystem.dto.record;

import lombok.Data;

/**
 * 自动分配床位请求。
 */
@Data
public class AutoAssignRequest {

    private Long buildingId;

    private Integer preferredFloor;
}
