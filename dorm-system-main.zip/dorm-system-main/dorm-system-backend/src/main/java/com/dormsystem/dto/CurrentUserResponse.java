package com.dormsystem.dto;

import lombok.Data;

/**
 * 当前登录用户信息（{@code GET /api/v1/auth/me}，API_SPEC §2.3）。
 */
@Data
public class CurrentUserResponse {
    private Long userId;
    private String username;
    private String realName;
    private String role;
    private Long buildingId;
    private String buildingName;
    private Integer gender;
    private String phone;
}
