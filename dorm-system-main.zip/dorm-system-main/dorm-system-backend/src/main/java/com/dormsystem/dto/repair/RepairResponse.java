package com.dormsystem.dto.repair;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 报修单列表 / 详情响应（API_SPEC §7.1）。
 *
 * <p>冗余 buildingName / roomNo / bedNo / reporterName / repairmanName / assignedByName
 * 便于前端直接展示。</p>
 */
@Data
public class RepairResponse {

    private Long id;
    private String orderNo;
    private Long roomId;
    private Long bedId;
    private Long reporterId;
    private String title;
    private String description;
    private String photoUrl;
    private Integer status;
    private Integer priority;
    private Long repairmanId;
    private LocalDateTime assignedAt;
    private Long assignedById;
    private LocalDateTime startedAt;
    private LocalDateTime finishedAt;
    private String completionNote;
    private Integer rating;
    private String ratingComment;
    private LocalDateTime createdAt;

    // 冗余展示字段
    private Long buildingId;
    private String buildingName;
    private String roomNo;
    private String bedNo;
    private String reporterName;
    private String repairmanName;
    private String repairmanPhone;
    private String repairmanWorkType;
    private String assignedByName;
}
