package com.dormsystem.dto.dorm;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/** 新增 / 修改楼层请求。 */
@Data
public class FloorSaveRequest {

    @NotNull(message = "楼栋 id 必填")
    private Long buildingId;

    @NotNull(message = "楼层号必填")
    private Integer floorNo;

    @NotNull
    private Integer roomCount;
}
