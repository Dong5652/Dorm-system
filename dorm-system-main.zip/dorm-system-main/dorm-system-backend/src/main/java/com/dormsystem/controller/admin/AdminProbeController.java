package com.dormsystem.controller.admin;

import com.dormsystem.common.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 临时管理员鉴权示例端点：用作 Phase 2 验收「越权访问 /api/v1/admin/** 返回 403」的探针。
 * Phase 3 起被正式 admin 接口取代，可删。
 */
@Tag(name = "Admin (temp)", description = "Phase 2 鉴权探针")
@RestController
@RequestMapping("/api/v1/admin")
public class AdminProbeController {

    @Operation(summary = "管理员探针", description = "需要 ADMIN 角色；非管理员访问返回 403")
    @GetMapping("/ping")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<String> adminPing() {
        return Result.success("admin-ok");
    }
}
