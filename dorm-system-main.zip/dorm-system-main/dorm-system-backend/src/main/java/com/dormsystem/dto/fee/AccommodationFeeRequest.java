package com.dormsystem.dto.fee;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class AccommodationFeeRequest {
    private String semester;
    private BigDecimal amount;
    private LocalDate dueDate;
}
