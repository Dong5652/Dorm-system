package com.dormsystem.dto.fee;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class MeterReadingRequest {
    private Long roomId;
    private Integer meterType;
    private BigDecimal readingValue;
    private String readingMonth;
    private String remark;
}
