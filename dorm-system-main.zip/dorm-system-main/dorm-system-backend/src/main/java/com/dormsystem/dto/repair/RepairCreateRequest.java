package com.dormsystem.dto.repair;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 报修单创建请求（API_SPEC §7.1）。
 *
 * <p>学生 / 宿管都可发起；初始 status = 0 待派单。
p */
@Data
public class RepairCreateRequest {

    @NotNull(message = "房间ID不能为空")
    private Long roomId;

    /** 具体床位（可空）。 */
    private Long bedId;

    @NotBlank(message = "标题不能为空")
    private String title;

    private String description;

    private String photoUrl;

    /** 0普通 1紧急 2非常紧急；为空默认 0。 */
    private Integer priority;
}
