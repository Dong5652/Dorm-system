package com.dormsystem.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dormsystem.common.Result;
import com.dormsystem.dto.attendance.AttendanceResponse;
import com.dormsystem.dto.attendance.AttendanceSaveRequest;
import com.dormsystem.entity.Attendance;
import com.dormsystem.service.AttendanceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

/**
 * 晚归考勤控制层（API_SPEC §6.2）。
 */
@Tag(name = "Attendance", description = "晚归考勤接口")
@RestController
@RequestMapping("/api/v1/dorm/attendance")
@RequiredArgsConstructor
public class AttendanceController {

    private final AttendanceService attendanceService;

    @Operation(summary = "考勤记录分页列表")
    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public Result<IPage<AttendanceResponse>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) Long studentId,
            @RequestParam(required = false) Long roomId,
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Integer type,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return Result.success(attendanceService.page(
                pageNum, pageSize, studentId, roomId, buildingId, type, startDate, endDate));
    }

    @Operation(summary = "考勤记录详情")
    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public Result<AttendanceResponse> get(@PathVariable Long id) {
        return Result.success(attendanceService.get(id));
    }

    @Operation(summary = "登记晚归/未归/请假")
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<Attendance> create(@Valid @RequestBody AttendanceSaveRequest req) {
        return Result.success(attendanceService.create(req));
    }

    @Operation(summary = "修改考勤记录")
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<Attendance> update(@PathVariable Long id, @Valid @RequestBody AttendanceSaveRequest req) {
        return Result.success(attendanceService.update(id, req));
    }

    @Operation(summary = "删除考勤记录（仅 ADMIN）")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> delete(@PathVariable Long id) {
        attendanceService.delete(id);
        return Result.success();
    }
}
