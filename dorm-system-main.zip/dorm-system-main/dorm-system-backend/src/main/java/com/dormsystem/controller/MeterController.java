package com.dormsystem.controller;

import com.dormsystem.annotation.OperationLog;
import com.dormsystem.common.Result;
import com.dormsystem.dto.fee.MeterReadingRequest;
import com.dormsystem.security.SecurityUtils;
import com.dormsystem.service.FeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class MeterController {
    private final FeeService feeService;

    @GetMapping("/dorm/meter")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<?> getMeterReadings(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) Long roomId) {
        return Result.success(feeService.pageMeterReadings(page, size, roomId));
    }

    @PostMapping("/dorm/meter")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    @OperationLog(module = "meter", action = "create", targetTable = "meter_reading")
    public Result<?> addMeterReading(@RequestBody MeterReadingRequest req) {
        feeService.recordMeterReading(req, SecurityUtils.currentUserId());
        return Result.success();
    }

    @PutMapping("/admin/dorm/meter/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "meter", action = "update", targetTable = "meter_reading")
    public Result<?> updateMeterReading(@PathVariable Long id, @RequestBody MeterReadingRequest req) {
        feeService.updateMeterReading(id, req);
        return Result.success();
    }

    @DeleteMapping("/admin/dorm/meter/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "meter", action = "delete", targetTable = "meter_reading")
    public Result<?> deleteMeterReading(@PathVariable Long id) {
        feeService.deleteMeterReading(id);
        return Result.success();
    }
}
