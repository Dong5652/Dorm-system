package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.Building;
import org.apache.ibatis.annotations.Mapper;

/** Building 通用 Mapper。 */
@Mapper
public interface BuildingMapper extends BaseMapper<Building> {
}
