package com.dormsystem.dto.record;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 办理退宿请求。
 */
@Data
public class CheckOutRequest {

    @NotNull(message = "学生ID不能为空")
    private Long studentId;

    private Boolean keyReturned;

    private String facilityCheck;

    private String remark;
}
