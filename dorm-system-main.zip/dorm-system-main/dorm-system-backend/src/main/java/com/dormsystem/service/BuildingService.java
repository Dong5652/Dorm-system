package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.dorm.BuildingSaveRequest;
import com.dormsystem.entity.Building;
import com.dormsystem.mapper.BuildingMapper;
import com.dormsystem.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Set;

/**
 * 楼栋服务。数据范围由 {@link #scopeBuildingId()} 收敛:
 *
 * <ul>
 *   <li>{@code ADMIN} → null(全部楼栋)</li>
 *   <li>{@code DORM_MANAGER} → 强制锁定为 {@code sys_user.building_id} 本人楼栋</li>
 *   <li>其它角色 → 抛 {@link ResultCode#FORBIDDEN}</li>
 * </ul>
 *
 * <p>接口层切 {@code @PreAuthorize} 控角色，service 层用 scope 兜数据范围。</p>
 */
@Service
@RequiredArgsConstructor
public class BuildingService {

    /** DORM_MANAGER 角色标识,与 sys_user.role 一致。 */
    public static final String ROLE_DORM_MANAGER = "dorm_manager";
    public static final String ROLE_ADMIN = "admin";

    private final BuildingMapper buildingMapper;
    private final com.dormsystem.mapper.SysUserMapper sysUserMapper;
    private final com.dormsystem.mapper.FloorMapper floorMapper;
    private final com.dormsystem.mapper.RoomMapper roomMapper;

    public List<com.dormsystem.entity.SysUser> listManagers() {
        return sysUserMapper.selectList(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<com.dormsystem.entity.SysUser>()
                        .eq(com.dormsystem.entity.SysUser::getRole, "dorm_manager")
                        .orderByAsc(com.dormsystem.entity.SysUser::getUsername));
    }

    /**
     * 返回当前登录用户的可见楼栋范围:ADMIN 返回 null(不受限),
     * DORM_MANAGER 返回 {@code currentUser.buildingId}(强制锁定本人楼栋),
     * 其它角色一律 FORBIDDEN。
     */
    public static Long scopeBuildingId() {
        String role = SecurityUtils.currentRole();
        if (ROLE_ADMIN.equalsIgnoreCase(role)) return null;
        if (ROLE_DORM_MANAGER.equalsIgnoreCase(role)) {
            Long bid = SecurityUtils.currentUser().getBuildingId();
            if (bid == null) {
                throw new BusinessException(ResultCode.FORBIDDEN, "宿管未绑定管辖楼栋");
            }
            return bid;
        }
        throw new BusinessException(ResultCode.FORBIDDEN, "无楼栋查询权限");
    }

    public Page<Building> page(int pageNum, int pageSize, String keyword, Integer gender) {
        Long scope = scopeBuildingId();
        Page<Building> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Building> w = new LambdaQueryWrapper<>();
        if (scope != null) w.eq(Building::getId, scope);
        if (StringUtils.hasText(keyword)) {
            w.and(qw -> qw.like(Building::getCode, keyword).or().like(Building::getName, keyword));
        }
        if (gender != null) {
            w.eq(Building::getGender, gender);
        }
        w.orderByAsc(Building::getCode);
        return buildingMapper.selectPage(page, w);
    }

    public List<Building> listAll() {
        Long scope = scopeBuildingId();
        return buildingMapper.selectList(
                new LambdaQueryWrapper<Building>()
                        .eq(scope != null, Building::getId, scope)
                        .orderByAsc(Building::getCode));
    }

    public Building get(Long id) {
        Long scope = scopeBuildingId();
        if (scope != null && !scope.equals(id)) {
            throw new BusinessException(ResultCode.FORBIDDEN, "无权访问该楼栋");
        }
        Building b = buildingMapper.selectById(id);
        if (b == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "楼栋不存在");
        }
        return b;
    }

    @org.springframework.transaction.annotation.Transactional
    public Building create(BuildingSaveRequest req) {
        ensureCodeUnique(req.getCode());
        if (!Set.of(1, 2, 3).contains(req.getGender())) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "gender 取值 1男 2女 3混合");
        }
        Building b = new Building();
        b.setCode(req.getCode());
        b.setName(req.getName());
        b.setGender(req.getGender());
        b.setFloorCount(req.getFloorCount());
        b.setManagerId(req.getManagerId());
        b.setRemark(req.getRemark());
        buildingMapper.insert(b);

        if (b.getFloorCount() != null && b.getFloorCount() > 0) {
            for (int i = 1; i <= b.getFloorCount(); i++) {
                com.dormsystem.entity.Floor f = new com.dormsystem.entity.Floor();
                f.setBuildingId(b.getId());
                f.setFloorNo(i);
                f.setRoomCount(0);
                floorMapper.insert(f);
            }
        }
        return b;
    }

    @org.springframework.transaction.annotation.Transactional
    public Building update(Long id, BuildingSaveRequest req) {
        Building b = get(id);
        if (!b.getCode().equals(req.getCode())) {
            ensureCodeUnique(req.getCode());
        }

        int oldFloorCount = b.getFloorCount() == null ? 0 : b.getFloorCount();
        int newFloorCount = req.getFloorCount() == null ? 0 : req.getFloorCount();

        if (newFloorCount != oldFloorCount) {
            if (newFloorCount > oldFloorCount) {
                // 增量补建楼层
                for (int i = oldFloorCount + 1; i <= newFloorCount; i++) {
                    com.dormsystem.entity.Floor f = new com.dormsystem.entity.Floor();
                    f.setBuildingId(b.getId());
                    f.setFloorNo(i);
                    f.setRoomCount(0);
                    floorMapper.insert(f);
                }
            } else {
                // 缩减楼层，校验将被删除的楼层（floorNo > newFloorCount）是否有房间
                List<com.dormsystem.entity.Floor> floorsToRemove = floorMapper.selectList(
                        new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<com.dormsystem.entity.Floor>()
                                .eq(com.dormsystem.entity.Floor::getBuildingId, id)
                                .gt(com.dormsystem.entity.Floor::getFloorNo, newFloorCount));

                if (!floorsToRemove.isEmpty()) {
                    List<Long> floorIds = floorsToRemove.stream().map(com.dormsystem.entity.Floor::getId).toList();
                    Long roomCount = roomMapper.selectCount(
                            new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<com.dormsystem.entity.Room>()
                                    .in(com.dormsystem.entity.Room::getFloorId, floorIds));
                    if (roomCount != null && roomCount > 0) {
                        throw new BusinessException(ResultCode.CONFLICT, "被缩减的楼层上仍有房间存在，禁止缩减楼层");
                    }
                    // 删除无房间的楼层记录
                    floorMapper.deleteBatchIds(floorIds);
                }
            }
        }

        b.setCode(req.getCode());
        b.setName(req.getName());
        b.setGender(req.getGender());
        b.setFloorCount(newFloorCount);
        b.setManagerId(req.getManagerId());
        b.setRemark(req.getRemark());
        buildingMapper.updateById(b);
        return b;
    }

    @org.springframework.transaction.annotation.Transactional
    public void delete(Long id) {
        get(id);
        // 校验该 building 下是否还有房间
        Long roomCount = roomMapper.selectCount(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<com.dormsystem.entity.Room>()
                        .eq(com.dormsystem.entity.Room::getBuildingId, id));
        if (roomCount != null && roomCount > 0) {
            throw new BusinessException(ResultCode.CONFLICT, "该楼栋下仍有房间存在，禁止删除");
        }
        // 清理楼层数据
        floorMapper.delete(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<com.dormsystem.entity.Floor>()
                        .eq(com.dormsystem.entity.Floor::getBuildingId, id));
        buildingMapper.deleteById(id);
    }

    private void ensureCodeUnique(String code) {
        Long cnt = buildingMapper.selectCount(
                new LambdaQueryWrapper<Building>().eq(Building::getCode, code));
        if (cnt != null && cnt > 0) {
            throw new BusinessException(ResultCode.CONFLICT, "楼栋编号已存在: " + code);
        }
    }
}
