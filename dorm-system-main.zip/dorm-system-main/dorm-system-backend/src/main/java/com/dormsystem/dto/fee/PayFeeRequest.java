package com.dormsystem.dto.fee;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class PayFeeRequest {
    private Integer payType;
    private BigDecimal amount;
    private String payNo;
}
