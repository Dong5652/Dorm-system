package com.dormsystem.controller;

import com.dormsystem.common.Result;
import com.dormsystem.dto.dorm.tree.BuildingTreeNode;
import com.dormsystem.dto.dorm.tree.VacancyStat;
import com.dormsystem.service.DormQueryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** 通用查询（API_SPEC §3.5）：宿舍树 / 空置统计。 */
@Tag(name = "Dorm", description = "宿舍树 & 空置统计")
@RestController
@RequestMapping("/api/v1/dorm")
@RequiredArgsConstructor
public class DormController {

    private final DormQueryService dormQueryService;

    @Operation(summary = "宿舍树(级联 building → floor → room → bed)")
    @GetMapping("/tree")
    @PreAuthorize("isAuthenticated()")
    public Result<List<BuildingTreeNode>> tree() {
        return Result.success(dormQueryService.tree());
    }

    @Operation(summary = "空置统计(按楼栋)")
    @GetMapping("/vacancy")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<List<VacancyStat>> vacancy() {
        return Result.success(dormQueryService.vacancy());
    }
}
