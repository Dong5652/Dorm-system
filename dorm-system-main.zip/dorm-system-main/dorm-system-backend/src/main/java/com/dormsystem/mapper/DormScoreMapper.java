package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.DormScore;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/** DormScore 通用 Mapper。 */
@Mapper
public interface DormScoreMapper extends BaseMapper<DormScore> {

    /**
     * 物理删除指定月份的所有评分记录，绕开 MyBatis-Plus 逻辑删除。
     *
     * <p>用于 {@link com.dormsystem.service.DormScoreService#generateMonthlyScores} 与
     * {@link com.dormsystem.service.DormScoreService#manualOverride} 在重新生成评分前清掉旧记录，
     * 避免 {@code uk_dorm_score_room_month} 唯一约束被软删除行命中。</p>
     *
     * <p>注意 {@code year_month} 是 MySQL 保留字，必须用反引号包住列名。</p>
     */
    @Delete("DELETE FROM dorm_score WHERE `year_month` = #{yearMonth}")
    int physicalDeleteByMonth(@Param("yearMonth") String yearMonth);

    /**
     * 物理删除指定房间 + 月份的评分记录（管理员补录时使用）。
     */
    @Delete("DELETE FROM dorm_score WHERE room_id = #{roomId} AND `year_month` = #{yearMonth}")
    int physicalDeleteByRoomAndMonth(@Param("roomId") Long roomId, @Param("yearMonth") String yearMonth);
}
