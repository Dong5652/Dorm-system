package com.dormsystem.dto.dorm;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/** 新增 / 修改楼栋请求。 */
@Data
public class BuildingSaveRequest {

    @NotBlank(message = "楼栋编号不能为空")
    private String code;

    @NotBlank(message = "楼栋名称不能为空")
    private String name;

    @NotNull(message = "性别必填")
    private Integer gender;

    @NotNull(message = "楼层数必填")
    private Integer floorCount;

    private Long managerId;

    private String remark;
}
