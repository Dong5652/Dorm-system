package com.dormsystem.dto.score;

import lombok.Data;

import java.math.BigDecimal;

/**
 * 寝室评分排行响应（API_SPEC §6.3.1）。
 */
@Data
public class DormScoreResponse {

    private Long roomId;
    private Long buildingId;
    private String buildingName;
    private String roomNo;
    private String yearMonth;
    private BigDecimal hygieneAvg;
    private Integer lateCount;
    private BigDecimal totalScore;
    private String level;
    /** 排名（按 totalScore 降序，从 1 起）。 */
    private Integer rank;
    private String remark;
}
