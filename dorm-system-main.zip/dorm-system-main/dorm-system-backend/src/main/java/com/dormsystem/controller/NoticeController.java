package com.dormsystem.controller;

import com.dormsystem.annotation.OperationLog;
import com.dormsystem.common.Result;
import com.dormsystem.dto.notice.AnnouncementRequest;
import com.dormsystem.entity.SysUser;
import com.dormsystem.security.SecurityUtils;
import com.dormsystem.service.NoticeService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class NoticeController {
    private final NoticeService noticeService;

    @GetMapping("/announcement")
    @PreAuthorize("isAuthenticated()")
    public Result<?> getAnnouncements(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size) {
        SysUser user = SecurityUtils.currentUser();
        // 按 userId + buildingId + role 做 scope 四级过滤
        return Result.success(noticeService.pageAnnouncements(
                page, size, user.getId(), user.getBuildingId(), user.getRole()));
    }

    @GetMapping("/announcement/{id}")
    @PreAuthorize("isAuthenticated()")
    public Result<?> getAnnouncementDetail(@PathVariable Long id) {
        SysUser user = SecurityUtils.currentUser();
        return Result.success(noticeService.getVisibleAnnouncement(
                id, user.getId(), user.getBuildingId(), user.getRole()));
    }

    @GetMapping("/admin/announcement")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<?> getAdminAnnouncements(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size) {
        return Result.success(noticeService.pageAdminAnnouncements(page, size));
    }

    @PostMapping("/admin/announcement")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "announcement", action = "publish", targetTable = "announcement")
    public Result<?> publishAnnouncement(@RequestBody AnnouncementRequest req) {
        noticeService.publishAnnouncement(req, SecurityUtils.currentUserId());
        return Result.success();
    }

    @PutMapping("/admin/announcement/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "announcement", action = "update", targetTable = "announcement")
    public Result<?> updateAnnouncement(@PathVariable Long id, @RequestBody AnnouncementRequest req) {
        noticeService.updateAnnouncement(id, req);
        return Result.success();
    }

    @DeleteMapping("/admin/announcement/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "announcement", action = "delete", targetTable = "announcement")
    public Result<?> deleteAnnouncement(@PathVariable Long id) {
        noticeService.deleteAnnouncement(id);
        return Result.success();
    }

    @PutMapping("/admin/announcement/{id}/pin")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "announcement", action = "pin", targetTable = "announcement")
    public Result<?> pinAnnouncement(@PathVariable Long id) {
        noticeService.pinAnnouncement(id);
        return Result.success();
    }

    @PutMapping("/admin/announcement/{id}/offline")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "announcement", action = "offline", targetTable = "announcement")
    public Result<?> offlineAnnouncement(@PathVariable Long id) {
        noticeService.offlineAnnouncement(id);
        return Result.success();
    }

    @GetMapping("/notice")
    @PreAuthorize("isAuthenticated()")
    public Result<?> getNotices(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size) {
        return Result.success(noticeService.pageNotices(page, size, SecurityUtils.currentUserId()));
    }

    @GetMapping("/notice/unread-count")
    @PreAuthorize("isAuthenticated()")
    public Result<?> getUnreadCount() {
        return Result.success(noticeService.countUnreadNotices(SecurityUtils.currentUserId()));
    }

    @PutMapping("/notice/{id}/read")
    @PreAuthorize("isAuthenticated()")
    public Result<?> readNotice(@PathVariable Long id) {
        noticeService.readNotice(id, SecurityUtils.currentUserId());
        return Result.success();
    }

    @PutMapping("/notice/read-all")
    @PreAuthorize("isAuthenticated()")
    public Result<?> readAllNotices() {
        noticeService.readAllNotices(SecurityUtils.currentUserId());
        return Result.success();
    }

    @DeleteMapping("/notice/{id}")
    @PreAuthorize("isAuthenticated()")
    public Result<?> deleteNotice(@PathVariable Long id) {
        noticeService.deleteNotice(id, SecurityUtils.currentUserId());
        return Result.success();
    }
}
