package com.dormsystem.security;

import com.dormsystem.entity.SysUser;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

/**
 * Spring Security 上下文中的登录用户。
 *
 * <p>角色以 {@code ROLE_<角色>} 形式注册，配合 {@code @PreAuthorize("hasRole('ADMIN')")} 注解使用。</p>
 */
@Getter
@AllArgsConstructor
public class LoginUser implements UserDetails {

    private final SysUser user;

    public Long getUserId() {
        return user.getId();
    }

    public String getRole() {
        return user.getRole();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // role 写大写后挂 ROLE_ 前缀，hasRole('ADMIN') 即校验 ROLE_ADMIN
        return List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().toUpperCase()));
    }

    @Override
    public String getPassword() {
        return user.getPassword();
    }

    @Override
    public String getUsername() {
        return user.getUsername();
    }

    /** 状态为禁用（status=0）即视为账号锁定。 */
    @Override
    public boolean isEnabled() {
        return user.getStatus() != null && user.getStatus() == 1;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }
}
