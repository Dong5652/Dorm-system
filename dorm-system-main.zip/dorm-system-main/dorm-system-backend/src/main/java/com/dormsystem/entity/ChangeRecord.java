package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 宿舍异动记录表（{@code change_record}，DATABASE.md §2.3）。
 * type: suspend / transfer / change_room / holiday_leave.
 */
@Data
@TableName("change_record")
public class ChangeRecord {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long studentId;

    private String type;

    private Long fromBedId;

    private Long toBedId;

    private String reason;

    private Long operatorId;

    private LocalDateTime happenedAt;

    private String remark;

    private LocalDateTime createdAt;

    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
