package com.dormsystem.dto.dorm;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/** 新增 / 修改房间请求。 */
@Data
public class RoomSaveRequest {

    @NotNull(message = "楼栋 id 必填")
    private Long buildingId;

    @NotNull(message = "楼层 id 必填")
    private Long floorId;

    @NotBlank(message = "房间号不能为空")
    private String roomNo;

    @NotNull(message = "额定床位数必填")
    private Integer capacity;

    /** 修改房间状态时单字段 PUT。 */
    private Integer status;

    private String remark;
}
