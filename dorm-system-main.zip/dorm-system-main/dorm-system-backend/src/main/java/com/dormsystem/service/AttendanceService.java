package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.attendance.AttendanceResponse;
import com.dormsystem.dto.attendance.AttendanceSaveRequest;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.*;
import com.dormsystem.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 晚归考勤服务（API_SPEC §6.2）。
 *
 * <p>数据范围：</p>
 * <ul>
 *   <li>ADMIN → 全部</li>
 *   <li>DORM_MANAGER → 强制锁定为本人 buildingId 下的学生</li>
 *   <li>STUDENT → 仅本人考勤记录</li>
 * </ul>
 *
 * <p>录入时自动通过 student.current_bed_id 反查 room_id 冗余写入 attendance.room_id，便于按房间筛选。</p>
 */
@Service
@RequiredArgsConstructor
public class AttendanceService {

    public static final String ROLE_STUDENT = "student";

    private final AttendanceMapper attendanceMapper;
    private final StudentMapper studentMapper;
    private final BedMapper bedMapper;
    private final RoomMapper roomMapper;
    private final BuildingMapper buildingMapper;
    private final SysUserMapper sysUserMapper;
    private final StudentService studentService;

    @Transactional
    public Attendance create(AttendanceSaveRequest req) {
        Student s = studentMapper.selectById(req.getStudentId());
        if (s == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "学生档案不存在");
        }
        validateType(req.getType());
        // 通过 current_bed_id 反查 room_id；若未入住则不允许登记晚归
        Long roomId = resolveStudentRoomId(s);
        if (roomId == null) {
            throw new BusinessException(ResultCode.CONFLICT, "该学生当前未入住任何床位，无法登记考勤");
        }
        ensureStudentWritable(s, roomId);

        Attendance a = new Attendance();
        a.setStudentId(s.getId());
        a.setRoomId(roomId);
        a.setRecordDate(req.getRecordDate());
        a.setType(req.getType());
        a.setReturnTime(req.getReturnTime());
        a.setInspectorId(SecurityUtils.currentUserId());
        a.setRemark(req.getRemark());
        attendanceMapper.insert(a);
        return a;
    }

    @Transactional
    public Attendance update(Long id, AttendanceSaveRequest req) {
        Attendance existed = attendanceMapper.selectById(id);
        if (existed == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "考勤记录不存在");
        }
        validateType(req.getType());
        // 校验越权
        Student s = studentMapper.selectById(existed.getStudentId());
        if (s != null) {
            ensureStudentWritable(s, existed.getRoomId());
        }
        existed.setRecordDate(req.getRecordDate());
        existed.setType(req.getType());
        existed.setReturnTime(req.getReturnTime());
        existed.setRemark(req.getRemark());
        attendanceMapper.updateById(existed);
        return existed;
    }

    @Transactional
    public void delete(Long id) {
        Attendance existed = attendanceMapper.selectById(id);
        if (existed == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "考勤记录不存在");
        }
        if (!BuildingService.ROLE_ADMIN.equalsIgnoreCase(SecurityUtils.currentRole())) {
            throw new BusinessException(ResultCode.FORBIDDEN, "仅管理员可删除考勤记录");
        }
        attendanceMapper.deleteById(id);
    }

    public AttendanceResponse get(Long id) {
        Attendance a = attendanceMapper.selectById(id);
        if (a == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "考勤记录不存在");
        }
        ensureReadable(a);
        return toResponse(a);
    }

    public IPage<AttendanceResponse> page(int pageNum, int pageSize,
                                          Long studentId, Long roomId, Long buildingId,
                                          Integer type,
                                          LocalDate startDate, LocalDate endDate) {
        LambdaQueryWrapper<Attendance> w = new LambdaQueryWrapper<>();
        String role = SecurityUtils.currentRole();

        // 学生：限制为本人
        if (ROLE_STUDENT.equalsIgnoreCase(role)) {
            Student me = studentService.findByUserId(SecurityUtils.currentUserId());
            if (me == null) {
                return new Page<>(pageNum, pageSize, 0);
            }
            w.eq(Attendance::getStudentId, me.getId());
        } else if (BuildingService.ROLE_DORM_MANAGER.equalsIgnoreCase(role)) {
            Long bid = SecurityUtils.currentUser().getBuildingId();
            if (bid == null) {
                throw new BusinessException(ResultCode.FORBIDDEN, "宿管未绑定管辖楼栋");
            }
            // 限定本楼栋房间
            Set<Long> roomIds = listRoomIdsOfBuilding(bid);
            if (roomIds.isEmpty()) {
                return new Page<>(pageNum, pageSize, 0);
            }
            w.in(Attendance::getRoomId, roomIds);
        }

        if (studentId != null) w.eq(Attendance::getStudentId, studentId);
        if (roomId != null) w.eq(Attendance::getRoomId, roomId);
        if (buildingId != null) {
            Set<Long> roomIds = listRoomIdsOfBuilding(buildingId);
            if (roomIds.isEmpty()) {
                return new Page<>(pageNum, pageSize, 0);
            }
            w.in(Attendance::getRoomId, roomIds);
        }
        if (type != null) w.eq(Attendance::getType, type);
        if (startDate != null) w.ge(Attendance::getRecordDate, startDate);
        if (endDate != null) w.le(Attendance::getRecordDate, endDate);
        w.orderByDesc(Attendance::getRecordDate).orderByDesc(Attendance::getId);

        Page<Attendance> page = new Page<>(pageNum, pageSize);
        IPage<Attendance> raw = attendanceMapper.selectPage(page, w);
        return raw.convert(this::toResponse);
    }

    // ---- 工具方法 -------------------------------------------------------

    private void validateType(Integer type) {
        if (type == null || type < 1 || type > 3) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "type 取值 1晚归 2未归 3请假");
        }
    }

    private Long resolveStudentRoomId(Student s) {
        if (s.getCurrentBedId() == null) return null;
        Bed b = bedMapper.selectById(s.getCurrentBedId());
        return b == null ? null : b.getRoomId();
    }

    private void ensureStudentWritable(Student s, Long roomId) {
        String role = SecurityUtils.currentRole();
        if (BuildingService.ROLE_ADMIN.equalsIgnoreCase(role)) return;
        if (BuildingService.ROLE_DORM_MANAGER.equalsIgnoreCase(role)) {
            Long bid = SecurityUtils.currentUser().getBuildingId();
            if (bid == null) {
                throw new BusinessException(ResultCode.FORBIDDEN, "宿管未绑定管辖楼栋");
            }
            Room r = roomMapper.selectById(roomId);
            if (r == null || !bid.equals(r.getBuildingId())) {
                throw new BusinessException(ResultCode.FORBIDDEN, "无权操作该学生的考勤记录");
            }
            return;
        }
        throw new BusinessException(ResultCode.FORBIDDEN, "无考勤数据写入权限");
    }

    private void ensureReadable(Attendance a) {
        String role = SecurityUtils.currentRole();
        if (BuildingService.ROLE_ADMIN.equalsIgnoreCase(role)) return;
        if (BuildingService.ROLE_DORM_MANAGER.equalsIgnoreCase(role)) {
            Long bid = SecurityUtils.currentUser().getBuildingId();
            Room r = roomMapper.selectById(a.getRoomId());
            if (r == null || bid == null || !bid.equals(r.getBuildingId())) {
                throw new BusinessException(ResultCode.FORBIDDEN, "无权查看该考勤记录");
            }
            return;
        }
        if (ROLE_STUDENT.equalsIgnoreCase(role)) {
            Student me = studentService.findByUserId(SecurityUtils.currentUserId());
            if (me == null || !me.getId().equals(a.getStudentId())) {
                throw new BusinessException(ResultCode.FORBIDDEN, "只能查看本人考勤记录");
            }
        }
    }

    private Set<Long> listRoomIdsOfBuilding(Long buildingId) {
        List<Room> rooms = roomMapper.selectList(
                new LambdaQueryWrapper<Room>().eq(Room::getBuildingId, buildingId));
        return rooms.stream().map(Room::getId).collect(Collectors.toSet());
    }

    private AttendanceResponse toResponse(Attendance a) {
        AttendanceResponse r = new AttendanceResponse();
        r.setId(a.getId());
        r.setStudentId(a.getStudentId());
        r.setRoomId(a.getRoomId());
        r.setRecordDate(a.getRecordDate());
        r.setType(a.getType());
        r.setReturnTime(a.getReturnTime());
        r.setInspectorId(a.getInspectorId());
        r.setRemark(a.getRemark());
        r.setCreatedAt(a.getCreatedAt());

        Student s = studentMapper.selectById(a.getStudentId());
        if (s != null) {
            r.setStudentName(s.getName());
            r.setStudentNo(s.getStudentNo());
        }
        Room room = roomMapper.selectById(a.getRoomId());
        if (room != null) {
            r.setRoomNo(room.getRoomNo());
            r.setBuildingId(room.getBuildingId());
            Building b = buildingMapper.selectById(room.getBuildingId());
            if (b != null) r.setBuildingName(b.getName());
        }
        SysUser inspector = sysUserMapper.selectById(a.getInspectorId());
        if (inspector != null) r.setInspectorName(inspector.getRealName());
        return r;
    }
}
