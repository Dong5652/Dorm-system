package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@TableName("meter_reading")
public class MeterReading {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long roomId;
    private Integer meterType;
    private BigDecimal readingValue;
    private BigDecimal previousValue;
    private BigDecimal usageAmount;
    private BigDecimal unitPrice;
    private BigDecimal amount;
    private String readingMonth;
    private Long readerId;
    private String remark;
    private LocalDateTime createdAt;
    
    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
