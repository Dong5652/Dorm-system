package com.dormsystem.controller;

import com.dormsystem.common.Result;
import com.dormsystem.dto.ChangePasswordRequest;
import com.dormsystem.dto.CurrentUserResponse;
import com.dormsystem.dto.LoginRequest;
import com.dormsystem.dto.LoginResponse;
import com.dormsystem.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 认证模块（API_SPEC §2）：登录 / 登出 / 当前用户 / 修改密码。
 */
@Tag(name = "Auth", description = "认证模块：登录、当前用户、修改密码")
@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @Operation(summary = "登录", description = "校验用户名/密码（BCrypt），签发 JWT")
    @PostMapping("/login")
    public Result<LoginResponse> login(@Valid @RequestBody LoginRequest req) {
        return Result.success(authService.login(req));
    }

    @Operation(summary = "登出", description = "JWT 无状态，前端清 token 即可")
    @PostMapping("/logout")
    public Result<Void> logout() {
        // 后端无黑名单，前端清 token 即可
        return Result.success();
    }

    @Operation(summary = "当前登录用户", description = "根据 token 解出当前用户与角色")
    @GetMapping("/me")
    public Result<CurrentUserResponse> me() {
        return Result.success(authService.currentUser());
    }

    @Operation(summary = "修改密码", description = "校验原密码后写入新密码（BCrypt）")
    @PutMapping("/password")
    public Result<Void> changePassword(@Valid @RequestBody ChangePasswordRequest req) {
        authService.changePassword(req);
        return Result.success();
    }
}
