package com.dormsystem.controller;

import com.dormsystem.annotation.OperationLog;
import com.dormsystem.common.Result;
import com.dormsystem.dto.fee.AccommodationFeeRequest;
import com.dormsystem.dto.fee.PayFeeRequest;
import com.dormsystem.dto.fee.UtilityFeeRequest;
import com.dormsystem.security.SecurityUtils;
import com.dormsystem.service.FeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class FeeController {
    private final FeeService feeService;

    @GetMapping("/fee")
    @PreAuthorize("isAuthenticated()")
    public Result<?> getMyFees(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String feeType,
            @RequestParam(required = false) String yearMonth,
            @RequestParam(required = false) Integer paidStatus) {
        // fee.student_id 对应 student.id，不能直接用 sys_user.id
        return Result.success(feeService.pageMyFees(
                page, size, SecurityUtils.currentUserId(), feeType, yearMonth, paidStatus));
    }

    @GetMapping("/admin/fee")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    public Result<?> getFees(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) Long studentId,
            @RequestParam(required = false) String feeType,
            @RequestParam(required = false) String yearMonth,
            @RequestParam(required = false) Integer paidStatus) {
        return Result.success(feeService.pageFees(page, size, studentId, feeType, yearMonth, paidStatus));
    }

    @PostMapping("/admin/fee/accommodation/generate")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "fee", action = "generate_accommodation", targetTable = "fee")
    public Result<?> generateAccommodationFee(@RequestBody AccommodationFeeRequest req) {
        feeService.generateAccommodationFee(req);
        return Result.success();
    }

    @PostMapping("/admin/fee/utility/generate")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "fee", action = "generate_utility", targetTable = "fee")
    public Result<?> generateUtilityFee(@RequestBody UtilityFeeRequest req) {
        feeService.generateUtilityFee(req);
        return Result.success();
    }

    @PostMapping("/admin/fee/{id}/pay")
    @PreAuthorize("hasRole('ADMIN')")
    @OperationLog(module = "fee", action = "pay", targetTable = "fee")
    public Result<?> payFee(@PathVariable Long id, @RequestBody PayFeeRequest req) {
        feeService.payFee(id, req, SecurityUtils.currentUserId());
        return Result.success();
    }

    @PostMapping("/admin/fee/{id}/remind")
    @PreAuthorize("hasAnyRole('ADMIN','DORM_MANAGER')")
    @OperationLog(module = "fee", action = "remind", targetTable = "fee")
    public Result<?> remindFee(@PathVariable Long id) {
        feeService.remindFee(id);
        return Result.success();
    }
}
