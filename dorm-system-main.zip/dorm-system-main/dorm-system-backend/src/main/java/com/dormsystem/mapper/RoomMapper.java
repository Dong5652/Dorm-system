package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.Room;
import org.apache.ibatis.annotations.Mapper;

/** Room 通用 Mapper。 */
@Mapper
public interface RoomMapper extends BaseMapper<Room> {
}
