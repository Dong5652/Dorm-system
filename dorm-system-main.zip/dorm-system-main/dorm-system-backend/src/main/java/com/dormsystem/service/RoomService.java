package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.dorm.RoomSaveRequest;
import com.dormsystem.entity.Bed;
import com.dormsystem.entity.Building;
import com.dormsystem.entity.Floor;
import com.dormsystem.entity.Room;
import com.dormsystem.mapper.BedMapper;
import com.dormsystem.mapper.RoomMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

/**
 * 房间服务。
 *
 * <p>状态机维护:{@link #recalcRoomState} 将「房间已入住床数 / 总床数」映射到房间状态,
 * 调用场景:任何床位状态变化后都会回调此方法刷新 room.occupied_count 与 room.status。</p>
 *
 * <p>房间标记为「维修中」(status=3)时,会把房间内所有床位置为维修中(2),
 * 标记结束后会再做一次状态重算。</p>
 */
@Service
@RequiredArgsConstructor
public class RoomService {

    /** 房间状态:0空闲 1部分入住 2满员 3维修中 4锁定预留。 */
    public static final Integer ROOM_FREE = 0;
    public static final Integer ROOM_PARTIAL = 1;
    public static final Integer ROOM_FULL = 2;
    public static final Integer ROOM_REPAIR = 3;
    public static final Integer ROOM_RESERVED = 4;

    /** 床位状态:0空闲 1已占用 2维修中 3预留。 */
    public static final Integer BED_FREE = 0;
    public static final Integer BED_OCCUPIED = 1;
    public static final Integer BED_REPAIR = 2;
    public static final Integer BED_RESERVED = 3;

    private final RoomMapper roomMapper;
    private final BedMapper bedMapper;
    private final BuildingService buildingService;
    private final FloorService floorService;

    public Page<Room> page(int pageNum, int pageSize, Long buildingId, Long floorId) {
        Long scope = BuildingService.scopeBuildingId();
        Long effectiveBuildingId = scope != null ? scope : buildingId;
        if (scope != null && buildingId != null && !scope.equals(buildingId)) {
            throw new BusinessException(ResultCode.FORBIDDEN, "无权查看非本人楼栋的房间");
        }
        Page<Room> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Room> w = new LambdaQueryWrapper<>();
        if (effectiveBuildingId != null) w.eq(Room::getBuildingId, effectiveBuildingId);
        if (floorId != null) {
            // floorId 校验:必须属于 effectiveBuildingId(防宿管用别楼 floorId 套出房间)
            ensureFloorInScope(floorId, effectiveBuildingId);
            w.eq(Room::getFloorId, floorId);
        }
        w.orderByAsc(Room::getRoomNo);
        return roomMapper.selectPage(page, w);
    }

    public Room get(Long id) {
        Room r = roomMapper.selectById(id);
        if (r == null) throw new BusinessException(ResultCode.NOT_FOUND, "房间不存在");
        return r;
    }

    public Room getDetail(Long id) {
        Room r = get(id);
        Long scope = BuildingService.scopeBuildingId();
        if (scope != null && !scope.equals(r.getBuildingId())) {
            throw new BusinessException(ResultCode.FORBIDDEN, "无权查看非本人楼栋的房间");
        }
        // 含床位总数 + 入住数(从 bed 表实时拉,避免冗余字段脏读)
        Long total = bedMapper.selectCount(new LambdaQueryWrapper<Bed>().eq(Bed::getRoomId, id));
        Long occupied = bedMapper.selectCount(new LambdaQueryWrapper<Bed>()
                .eq(Bed::getRoomId, id).eq(Bed::getStatus, BED_OCCUPIED));
        r.setCapacity(total == null ? 0 : total.intValue());
        r.setOccupiedCount(occupied == null ? 0 : occupied.intValue());
        return r;
    }

    private void ensureFloorInScope(Long floorId, Long buildingId) {
        Floor f = floorService.get(floorId);
        if (buildingId != null && !buildingId.equals(f.getBuildingId())) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "楼层与所属楼栋不一致");
        }
    }

    public Room create(RoomSaveRequest req) {
        Building b = buildingService.get(req.getBuildingId());
        Floor f = floorService.get(req.getFloorId());
        if (!f.getBuildingId().equals(b.getId())) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "楼层与所属楼栋不一致");
        }
        ensureRoomNoUnique(b.getId(), req.getRoomNo(), null);
        Room r = new Room();
        r.setBuildingId(b.getId());
        r.setFloorId(f.getId());
        r.setRoomNo(req.getRoomNo());
        r.setCapacity(req.getCapacity());
        r.setOccupiedCount(0);
        r.setStatus(req.getStatus() == null ? ROOM_FREE : req.getStatus());
        r.setRemark(req.getRemark());
        roomMapper.insert(r);
        return r;
    }

    public Room update(Long id, RoomSaveRequest req) {
        Room r = get(id);
        if (req.getStatus() != null && !r.getStatus().equals(req.getStatus())) {
            // status 变更单独走 setStatusFlow,这里只允许改基础字段
            throw new BusinessException(ResultCode.PARAM_INVALID,
                    "请用 PUT /admin/rooms/{id}/status 修改房间状态");
        }
        if (!r.getBuildingId().equals(req.getBuildingId())
                || !r.getFloorId().equals(req.getFloorId())) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "不允许修改房间所属楼栋/楼层");
        }
        if (!r.getRoomNo().equals(req.getRoomNo())) {
            ensureRoomNoUnique(r.getBuildingId(), req.getRoomNo(), id);
        }
        r.setRoomNo(req.getRoomNo());
        r.setCapacity(req.getCapacity());
        r.setRemark(req.getRemark());
        roomMapper.updateById(r);
        return r;
    }

    /** 单字段流转房间状态(API_SPEC §3.3)。维修中会把全部床位置 2;恢复需消费方自行重算。 */
    @Transactional
    public Room setStatus(Long id, int newStatus) {
        if (!Set.of(ROOM_FREE, ROOM_PARTIAL, ROOM_FULL, ROOM_REPAIR, ROOM_RESERVED).contains(newStatus)) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "房间状态取值 0/1/2/3/4");
        }
        Room r = get(id);
        r.setStatus(newStatus);
        roomMapper.updateById(r);

        List<Bed> beds = bedMapper.selectList(
                new LambdaQueryWrapper<Bed>().eq(Bed::getRoomId, id));
        if (newStatus == ROOM_REPAIR && !beds.isEmpty()) {
            // 维修中:把所有床位设为维修中;已占用者不变(仍记 student_id),只改 status
            for (Bed b : beds) {
                if (!BED_OCCUPIED.equals(b.getStatus())) {
                    b.setStatus(BED_REPAIR);
                    bedMapper.updateById(b);
                }
            }
        } else if ((newStatus == ROOM_FREE || newStatus == ROOM_PARTIAL)
                && beds.stream().anyMatch(b -> BED_REPAIR.equals(b.getStatus()))) {
            // 从维修中恢复:把处于维修中的床位按当前 student_id 还原为空闲/已占用
            for (Bed b : beds) {
                if (BED_REPAIR.equals(b.getStatus())) {
                    b.setStatus(b.getStudentId() != null ? BED_OCCUPIED : BED_FREE);
                    bedMapper.updateById(b);
                }
            }
            recalcRoomState(id);
        }
        return get(id);
    }

    public void delete(Long id) {
        Room r = get(id);
        Long occupied = bedMapper.selectCount(new LambdaQueryWrapper<Bed>()
                .eq(Bed::getRoomId, id).eq(Bed::getStatus, BED_OCCUPIED));
        if (occupied != null && occupied > 0) {
            throw new BusinessException(ResultCode.CONFLICT, "房间尚有学生入住,禁止删除");
        }
        // 软删房间内床位
        List<Bed> beds = bedMapper.selectList(
                new LambdaQueryWrapper<Bed>().eq(Bed::getRoomId, id));
        for (Bed b : beds) {
            bedMapper.deleteById(b.getId());
        }
        roomMapper.deleteById(id);
        // floor.room_count 不在数据库里维护一致(种子数据已经各自计数),保持简单
    }

    public List<Room> listByBuilding(Long buildingId) {
        return roomMapper.selectList(
                new LambdaQueryWrapper<Room>()
                        .eq(Room::getBuildingId, buildingId)
                        .orderByAsc(Room::getRoomNo));
    }

    /**
     * 重算房间 occupancy + status。任意床位状态变化后由 {@link BedService} 调用。
     * 维修中(3)与锁定预留(4)是「人手指定」的状态,不在重算范围内会被覆盖。
     */
    @Transactional
    public void recalcRoomState(Long roomId) {
        Room r = roomMapper.selectById(roomId);
        if (r == null) return;
        if (r.getStatus() != null && (r.getStatus() == ROOM_REPAIR || r.getStatus() == ROOM_RESERVED)) {
            // 维修中/锁定预留:仍要刷新 occupied_count 但 status 不可被重算覆盖
            Long occ = bedMapper.selectCount(new LambdaQueryWrapper<Bed>()
                    .eq(Bed::getRoomId, roomId).eq(Bed::getStatus, BED_OCCUPIED));
            r.setOccupiedCount(occ == null ? 0 : occ.intValue());
            roomMapper.updateById(r);
            return;
        }
        Long occ = bedMapper.selectCount(new LambdaQueryWrapper<Bed>()
                .eq(Bed::getRoomId, roomId).eq(Bed::getStatus, BED_OCCUPIED));
        r.setOccupiedCount(occ == null ? 0 : occ.intValue());
        int oc = r.getOccupiedCount();
        int cap = r.getCapacity() == null ? 0 : r.getCapacity();
        r.setStatus(oc <= 0 ? ROOM_FREE : (oc >= cap ? ROOM_FULL : ROOM_PARTIAL));
        roomMapper.updateById(r);
    }

    private void ensureRoomNoUnique(Long buildingId, String roomNo, Long excludeId) {
        LambdaQueryWrapper<Room> w = new LambdaQueryWrapper<Room>()
                .eq(Room::getBuildingId, buildingId)
                .eq(Room::getRoomNo, roomNo);
        if (excludeId != null) w.ne(Room::getId, excludeId);
        Long cnt = roomMapper.selectCount(w);
        if (cnt != null && cnt > 0) {
            throw new BusinessException(ResultCode.CONFLICT, "该楼栋已存在此房间号: " + roomNo);
        }
    }
}
