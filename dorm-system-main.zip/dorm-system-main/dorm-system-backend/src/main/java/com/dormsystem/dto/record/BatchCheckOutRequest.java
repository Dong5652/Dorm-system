package com.dormsystem.dto.record;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 批量退宿请求。
 */
@Data
public class BatchCheckOutRequest {

    @NotBlank(message = "年级不能为空")
    private String grade;

    private String className;

    private String reason;

    private Boolean keyReturned;
}
