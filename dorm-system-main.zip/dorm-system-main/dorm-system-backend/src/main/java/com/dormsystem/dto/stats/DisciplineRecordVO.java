package com.dormsystem.dto.stats;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class DisciplineRecordVO {
    private String type; // hygiene, attendance, safety
    private String description;
    private LocalDateTime time;
    private Long studentId;
    private Long roomId;
    private Integer score; // optional, e.g. -5 for hygiene
}
