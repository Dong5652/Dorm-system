package com.dormsystem.dto.record;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 统一的入住/退宿/异动流水响应模型。
 */
@Data
public class DormRecordResponse {

    private Long id;

    /** check_in / change */
    private String recordType;

    private Long studentId;

    private String studentName;

    private String studentNo;

    // --- 入住/退宿流水相关字段 (check_in) ---
    private Long bedId;

    private String bedNo;

    private Long roomId;

    private String roomNo;

    private String buildingName;

    /** 1入住 2退宿 */
    private Integer type;

    private Integer keyIssued;

    private Integer keyReturned;

    private String facilityCheck;

    // --- 异动登记相关字段 (change) ---
    private String changeType;

    private String changeTypeLabel;

    private Long fromBedId;

    private String fromBedNo;

    private String fromRoomNo;

    private Long toBedId;

    private String toBedNo;

    private String toRoomNo;

    private String reason;

    // --- 通用字段 ---
    private Long operatorId;

    private String operatorName;

    private LocalDateTime happenedAt;

    private String remark;
}
