package com.dormsystem.dto.dorm.tree;

import lombok.Data;

/** 宿舍树的一个床位节点。 */
@Data
public class BedTreeNode {
    private Long id;
    private String bedNo;
    private Integer status;
    private Long studentId;
    private String studentName;
}
