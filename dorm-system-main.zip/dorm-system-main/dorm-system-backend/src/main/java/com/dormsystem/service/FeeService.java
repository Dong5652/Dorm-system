package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.fee.AccommodationFeeRequest;
import com.dormsystem.dto.fee.MeterReadingRequest;
import com.dormsystem.dto.fee.PayFeeRequest;
import com.dormsystem.dto.fee.UtilityFeeRequest;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.*;
import com.dormsystem.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FeeService {
    private final FeeMapper feeMapper;
    private final MeterReadingMapper meterReadingMapper;
    private final PaymentMapper paymentMapper;
    private final StudentMapper studentMapper;
    private final RoomMapper roomMapper;
    private final BedMapper bedMapper;
    private final NoticeMessageMapper noticeMessageMapper;

    @Value("${fee.water-unit-price:3.5}")
    private BigDecimal waterUnitPrice;

    @Value("${fee.electric-unit-price:0.6}")
    private BigDecimal electricUnitPrice;

    public IPage<Fee> pageFees(int page, int size, Long studentId, String feeType, String yearMonth, Integer paidStatus) {
        LambdaQueryWrapper<Fee> wrapper = new LambdaQueryWrapper<>();
        // 宿管仅可查自己楼栋学生账单
        if ("dorm_manager".equalsIgnoreCase(SecurityUtils.currentRole())) {
            Long buildingId = SecurityUtils.currentUser().getBuildingId();
            if (buildingId == null) {
                throw new BusinessException(ResultCode.FORBIDDEN, "宿管未绑定管辖楼栋");
            }
            if (studentId != null) {
                Student s = studentMapper.selectById(studentId);
                if (s == null) {
                    throw new BusinessException(ResultCode.NOT_FOUND, "学生不存在");
                }
                assertStudentInManagerBuilding(s);
            }
            wrapper.inSql(Fee::getStudentId,
                    "select s.id from student s "
                            + "join bed b on s.current_bed_id = b.id "
                            + "join room r on b.room_id = r.id "
                            + "where s.is_deleted = 0 and b.is_deleted = 0 and r.is_deleted = 0 "
                            + "and r.building_id = " + buildingId);
        }
        if (studentId != null) wrapper.eq(Fee::getStudentId, studentId);
        if (feeType != null && !feeType.isEmpty()) wrapper.eq(Fee::getFeeType, feeType);
        if (yearMonth != null && !yearMonth.isEmpty()) wrapper.eq(Fee::getYearMonth, yearMonth);
        if (paidStatus != null) wrapper.eq(Fee::getPaidStatus, paidStatus);
        wrapper.orderByDesc(Fee::getCreatedAt);
        return feeMapper.selectPage(new Page<>(page, size), wrapper);
    }

    /**
     * 学生查看自己的账单：sys_user.id → student.id → fee.student_id
     */
    public IPage<Fee> pageMyFees(int page, int size, Long userId, String feeType, String yearMonth, Integer paidStatus) {
        Student student = studentMapper.selectOne(new LambdaQueryWrapper<Student>()
                .eq(Student::getUserId, userId)
                .last("LIMIT 1"));
        if (student == null) {
            return new Page<>(page, size);
        }
        return pageFees(page, size, student.getId(), feeType, yearMonth, paidStatus);
    }

    @Transactional
    public void generateAccommodationFee(AccommodationFeeRequest req) {
        // Find all in-dorm students
        LambdaQueryWrapper<Student> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Student::getStatus, 0); // 0=in-dorm
        List<Student> students = studentMapper.selectList(wrapper);
        // year_month 列 varchar(7)，不能直接塞学期长字符串（否则 SQL 500）
        String yearMonth = req.getSemester();
        if (yearMonth == null || yearMonth.isBlank()) {
            yearMonth = java.time.LocalDate.now().toString().substring(0, 7);
        } else if (yearMonth.length() > 7) {
            // 优先取 yyyy-MM 形态；否则截断到 7 并回退当前月
            if (yearMonth.matches("\\d{4}-\\d{2}.*")) {
                yearMonth = yearMonth.substring(0, 7);
            } else {
                yearMonth = java.time.LocalDate.now().toString().substring(0, 7);
            }
        }
        for (Student s : students) {
            Fee fee = new Fee();
            fee.setStudentId(s.getId());
            fee.setFeeType("accommodation");
            fee.setSemester(req.getSemester());
            fee.setYearMonth(yearMonth);
            fee.setAmount(req.getAmount());
            fee.setPaidAmount(BigDecimal.ZERO);
            fee.setPaidStatus(0); // 0 un-paid
            fee.setDueDate(req.getDueDate());
            fee.setCreatedAt(LocalDateTime.now());
            feeMapper.insert(fee);
        }
    }

    @Transactional
    public void generateUtilityFee(UtilityFeeRequest req) {
        String month = req.getReadingMonth();
        // find all meter readings for this month
        LambdaQueryWrapper<MeterReading> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(MeterReading::getReadingMonth, month);
        List<MeterReading> readings = meterReadingMapper.selectList(wrapper);
        
        for (MeterReading r : readings) {
            // find students in this room
            LambdaQueryWrapper<Student> stuWrapper = new LambdaQueryWrapper<>();
            stuWrapper.eq(Student::getStatus, 0);
            stuWrapper.inSql(Student::getCurrentBedId, "select id from bed where room_id = " + r.getRoomId());
            List<Student> students = studentMapper.selectList(stuWrapper);
            if (students.isEmpty()) continue;
            
            BigDecimal perAmount = r.getAmount().divide(new BigDecimal(students.size()), 2, RoundingMode.HALF_UP);
            
            for (Student s : students) {
                Fee fee = new Fee();
                fee.setStudentId(s.getId());
                fee.setFeeType("utility");
                fee.setYearMonth(month);
                fee.setAmount(perAmount);
                fee.setPaidAmount(BigDecimal.ZERO);
                fee.setPaidStatus(0);
                LocalDate due = LocalDate.now().plusDays(15);
                fee.setDueDate(due);
                fee.setCreatedAt(LocalDateTime.now());
                feeMapper.insert(fee);
            }
        }
    }

    @Transactional
    public void payFee(Long feeId, PayFeeRequest req, Long operatorId) {
        Fee fee = feeMapper.selectById(feeId);
        if (fee == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "账单不存在");
        }
        if (fee.getPaidStatus() != null && fee.getPaidStatus() == 2) {
            throw new BusinessException(ResultCode.CONFLICT, "账单已缴清，不可重复缴费");
        }
        if (req.getAmount() == null || req.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "缴费金额必须大于 0");
        }
        BigDecimal paid = fee.getPaidAmount() == null ? BigDecimal.ZERO : fee.getPaidAmount();
        BigDecimal remain = fee.getAmount().subtract(paid);
        if (req.getAmount().compareTo(remain) > 0) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "缴费金额超过未缴余额: " + remain);
        }

        Payment payment = new Payment();
        payment.setFeeId(feeId);
        payment.setStudentId(fee.getStudentId());
        payment.setAmount(req.getAmount());
        payment.setPayType(req.getPayType());
        payment.setPayNo(req.getPayNo());
        payment.setPayTime(LocalDateTime.now());
        payment.setOperatorId(operatorId);
        payment.setCreatedAt(LocalDateTime.now());
        paymentMapper.insert(payment);

        fee.setPaidAmount(paid.add(req.getAmount()));
        if (fee.getPaidAmount().compareTo(fee.getAmount()) >= 0) {
            fee.setPaidStatus(2); // fully paid
        } else if (fee.getPaidAmount().compareTo(BigDecimal.ZERO) > 0) {
            fee.setPaidStatus(1); // partially paid
        } else {
            fee.setPaidStatus(0);
        }
        feeMapper.updateById(fee);
    }

    public void remindFee(Long feeId) {
        Fee fee = feeMapper.selectById(feeId);
        if (fee == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "账单不存在");
        }
        if (fee.getPaidStatus() != null && fee.getPaidStatus() == 2) {
            throw new BusinessException(ResultCode.CONFLICT, "账单已缴清，无需催缴");
        }
        Student student = studentMapper.selectById(fee.getStudentId());
        if (student == null || student.getUserId() == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "账单对应学生账号不存在，无法发送催缴消息");
        }
        // 宿管只能催缴自己楼栋学生
        assertStudentInManagerBuilding(student);

        BigDecimal paid = fee.getPaidAmount() == null ? BigDecimal.ZERO : fee.getPaidAmount();
        BigDecimal remain = fee.getAmount().subtract(paid);
        NoticeMessage msg = new NoticeMessage();
        msg.setToUserId(student.getUserId());
        msg.setFromUserId(null);
        msg.setMsgType("FEE_REMIND");
        msg.setTitle("欠费催缴通知");
        msg.setContent("您有一笔 " + ("utility".equals(fee.getFeeType()) ? "水电费" : "住宿费")
                + " 账单未结清，待缴金额：" + remain + "，请尽快缴费。");
        msg.setRefId(fee.getId());
        msg.setIsRead(0);
        msg.setCreatedAt(LocalDateTime.now());
        noticeMessageMapper.insert(msg);
    }
    
    public IPage<MeterReading> pageMeterReadings(int page, int size, Long roomId) {
        LambdaQueryWrapper<MeterReading> wrapper = new LambdaQueryWrapper<>();
        if ("dorm_manager".equalsIgnoreCase(SecurityUtils.currentRole())) {
            Long buildingId = SecurityUtils.currentUser().getBuildingId();
            if (buildingId == null) {
                throw new BusinessException(ResultCode.FORBIDDEN, "宿管未绑定管辖楼栋");
            }
            if (roomId != null) {
                assertRoomInManagerBuilding(roomId);
            }
            wrapper.inSql(MeterReading::getRoomId,
                    "select id from room where is_deleted = 0 and building_id = " + buildingId);
        }
        if (roomId != null) wrapper.eq(MeterReading::getRoomId, roomId);
        wrapper.orderByDesc(MeterReading::getCreatedAt);
        return meterReadingMapper.selectPage(new Page<>(page, size), wrapper);
    }

    @Transactional
    public void recordMeterReading(MeterReadingRequest req, Long readerId) {
        assertRoomInManagerBuilding(req.getRoomId());
        // find previous reading
        LambdaQueryWrapper<MeterReading> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(MeterReading::getRoomId, req.getRoomId())
               .eq(MeterReading::getMeterType, req.getMeterType())
               .orderByDesc(MeterReading::getReadingMonth)
               .last("limit 1");
        MeterReading prev = meterReadingMapper.selectOne(wrapper);
        
        BigDecimal prevVal = prev != null ? prev.getReadingValue() : BigDecimal.ZERO;
        BigDecimal usage = req.getReadingValue().subtract(prevVal);
        if (usage.compareTo(BigDecimal.ZERO) < 0) usage = BigDecimal.ZERO;
        
        BigDecimal price = req.getMeterType() == 1 ? waterUnitPrice : electricUnitPrice;
        BigDecimal amount = usage.multiply(price);
        
        MeterReading mr = new MeterReading();
        mr.setRoomId(req.getRoomId());
        mr.setMeterType(req.getMeterType());
        mr.setReadingValue(req.getReadingValue());
        mr.setPreviousValue(prevVal);
        mr.setUsageAmount(usage);
        mr.setUnitPrice(price);
        mr.setAmount(amount);
        mr.setReadingMonth(req.getReadingMonth());
        mr.setReaderId(readerId);
        mr.setRemark(req.getRemark());
        mr.setCreatedAt(LocalDateTime.now());
        meterReadingMapper.insert(mr);
    }

    public void updateMeterReading(Long id, MeterReadingRequest req) {
        MeterReading mr = meterReadingMapper.selectById(id);
        if (mr == null) return;
        
        BigDecimal usage = req.getReadingValue().subtract(mr.getPreviousValue());
        if (usage.compareTo(BigDecimal.ZERO) < 0) usage = BigDecimal.ZERO;
        BigDecimal amount = usage.multiply(mr.getUnitPrice());
        
        mr.setReadingValue(req.getReadingValue());
        mr.setUsageAmount(usage);
        mr.setAmount(amount);
        mr.setReadingMonth(req.getReadingMonth());
        mr.setRemark(req.getRemark());
        meterReadingMapper.updateById(mr);
    }

    public void deleteMeterReading(Long id) {
        meterReadingMapper.deleteById(id);
    }

    private void assertRoomInManagerBuilding(Long roomId) {
        if (!"dorm_manager".equalsIgnoreCase(SecurityUtils.currentRole())) {
            return;
        }
        Long buildingId = SecurityUtils.currentUser().getBuildingId();
        if (buildingId == null) {
            throw new BusinessException(ResultCode.FORBIDDEN, "宿管未绑定管辖楼栋");
        }
        Room room = roomMapper.selectById(roomId);
        if (room == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "房间不存在");
        }
        if (!buildingId.equals(room.getBuildingId())) {
            throw new BusinessException(ResultCode.FORBIDDEN, "无权操作其他楼栋的抄表数据");
        }
    }

    private void assertStudentInManagerBuilding(Student student) {
        if (!"dorm_manager".equalsIgnoreCase(SecurityUtils.currentRole())) {
            return;
        }
        Long buildingId = SecurityUtils.currentUser().getBuildingId();
        if (buildingId == null) {
            throw new BusinessException(ResultCode.FORBIDDEN, "宿管未绑定管辖楼栋");
        }
        if (student.getCurrentBedId() == null) {
            throw new BusinessException(ResultCode.FORBIDDEN, "该学生未入住，宿管不可催缴");
        }
        Bed bed = bedMapper.selectById(student.getCurrentBedId());
        if (bed == null) {
            throw new BusinessException(ResultCode.FORBIDDEN, "无权催缴该学生账单");
        }
        Room room = roomMapper.selectById(bed.getRoomId());
        if (room == null || !buildingId.equals(room.getBuildingId())) {
            throw new BusinessException(ResultCode.FORBIDDEN, "无权催缴其他楼栋学生账单");
        }
    }
}
