package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.MeterReading;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MeterReadingMapper extends BaseMapper<MeterReading> {
}
