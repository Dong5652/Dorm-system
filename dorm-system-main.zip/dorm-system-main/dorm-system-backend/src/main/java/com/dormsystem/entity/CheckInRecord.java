package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 入住退宿记录表（{@code check_in_record}，DATABASE.md §2.3）。
 * type: 1入住 2退宿。
 */
@Data
@TableName("check_in_record")
public class CheckInRecord {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long studentId;

    private Long bedId;

    /** 1入住 2退宿 */
    private Integer type;

    private Long operatorId;

    private Integer keyIssued;

    private Integer keyReturned;

    private String facilityCheck;

    private String remark;

    private LocalDateTime happenedAt;

    private LocalDateTime createdAt;

    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
