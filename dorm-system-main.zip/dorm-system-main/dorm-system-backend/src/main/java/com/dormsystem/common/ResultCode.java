package com.dormsystem.common;

import lombok.Getter;

/**
 * 统一错误码描述，与 {@code docs/API_SPEC.md §1.1} 对齐。
 *
 * <p>HTTP 状态码与 code 同步返回（401 / 403 / 404 / 409 / 500），前端只判 {@code code} 字段即可。</p>
 */
@Getter
public enum ResultCode {

    SUCCESS        (0,     "success"),
    PARAM_INVALID  (40001, "参数校验失败"),
    UNAUTHORIZED   (40101, "未登录或 token 已失效"),
    FORBIDDEN      (40301, "无权限"),
    NOT_FOUND      (40401, "资源不存在"),
    CONFLICT       (40901, "业务冲突"),
    INTERNAL_ERROR (50001, "服务器内部错误");

    private final int code;
    private final String message;

    ResultCode(int code, String message) {
        this.code = code;
        this.message = message;
    }
}
