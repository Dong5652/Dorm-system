package com.dormsystem.dto.safety;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class VisitorRequest {
    @NotBlank(message = "访客姓名不能为空")
    private String visitorName;
    @NotBlank(message = "身份证号不能为空")
    @Pattern(
            regexp = "^[1-9]\\d{5}(19|20)\\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\\d|3[01])\\d{3}[\\dXx]$",
            message = "身份证号格式不正确")
    private String idCard;
    private String phone;
    private Long visitTargetId;
    @NotNull(message = "楼栋ID不能为空")
    private Long buildingId;
    @NotBlank(message = "来访目的不能为空")
    private String purpose;
    @NotNull(message = "进入时间不能为空")
    private LocalDateTime enterTime;
    private String remark;
}
