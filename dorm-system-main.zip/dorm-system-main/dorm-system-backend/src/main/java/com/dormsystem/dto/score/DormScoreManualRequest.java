package com.dormsystem.dto.score;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

/**
 * 管理员手动补录 / 修正某寝室某月评分请求（API_SPEC §6.3.2）。
 *
 * <p>每项都允许为空：未传则在 Service 内按公式重算（保持公式一致性）。</p>
 */
@Data
public class DormScoreManualRequest {

    @NotNull(message = "房间ID不能为空")
    private Long roomId;

    @NotNull(message = "评分月份不能为空")
    private String yearMonth;

    private BigDecimal hygieneAvg;

    private Integer lateCount;

    private BigDecimal totalScore;

    private String level;

    private String remark;
}
