package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.safety.*;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.*;
import com.dormsystem.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class SafetyService {

    private final VisitorMapper visitorMapper;
    private final SafetyInspectionMapper safetyInspectionMapper;
    private final SafetyEventMapper safetyEventMapper;
    private final NoticeMessageMapper noticeMessageMapper;
    private final StudentMapper studentMapper;
    private final SysUserMapper sysUserMapper;
    private final RoomMapper roomMapper;

    // ==========================================
    // 访客管理
    // ==========================================
    
    @Transactional
    public void registerVisitor(VisitorRequest req) {
        checkBuildingPermission(req.getBuildingId());

        Visitor visitor = new Visitor();
        visitor.setVisitorName(req.getVisitorName());
        visitor.setIdCard(req.getIdCard());
        visitor.setPhone(req.getPhone());
        visitor.setVisitTargetId(req.getVisitTargetId());
        visitor.setBuildingId(req.getBuildingId());
        visitor.setPurpose(req.getPurpose());
        visitor.setEnterTime(req.getEnterTime());
        visitor.setRegisterBy(SecurityUtils.currentUserId());
        visitor.setRemark(req.getRemark());
        visitor.setCreatedAt(LocalDateTime.now());
        visitorMapper.insert(visitor);
    }

    @Transactional
    public void exitVisitor(Long id) {
        Visitor visitor = visitorMapper.selectById(id);
        if (visitor == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "访客记录不存在");
        }
        checkBuildingPermission(visitor.getBuildingId());
        
        if (visitor.getExitTime() != null) {
            throw new BusinessException(ResultCode.CONFLICT, "访客已离开，不可重复登记");
        }
        visitor.setExitTime(LocalDateTime.now());
        visitorMapper.updateById(visitor);
    }

    public List<Visitor> queryVisitors(Long buildingId, LocalDate date, Long targetStudentId) {
        LambdaQueryWrapper<Visitor> w = new LambdaQueryWrapper<>();
        
        // 权限隔离
        String role = SecurityUtils.currentRole();
        if ("dorm_manager".equals(role)) {
            SysUser cur = sysUserMapper.selectById(SecurityUtils.currentUserId());
            if (cur.getBuildingId() == null) {
                return List.of();
            }
            w.eq(Visitor::getBuildingId, cur.getBuildingId());
            if (buildingId != null && !buildingId.equals(cur.getBuildingId())) {
                return List.of();
            }
        } else if (buildingId != null) {
            w.eq(Visitor::getBuildingId, buildingId);
        }

        if (targetStudentId != null) {
            w.eq(Visitor::getVisitTargetId, targetStudentId);
        }
        if (date != null) {
            w.ge(Visitor::getEnterTime, date.atStartOfDay());
            w.le(Visitor::getEnterTime, date.atTime(23, 59, 59));
        }
        w.orderByDesc(Visitor::getEnterTime);
        return visitorMapper.selectList(w);
    }

    @Transactional
    public void deleteVisitor(Long id) {
        visitorMapper.deleteById(id);
    }

    // ==========================================
    // 违禁品检查
    // ==========================================

    @Transactional
    public void recordInspection(SafetyInspectionRequest req) {
        // 宿管只能录入自己楼栋房间的违禁品检查
        Room room = roomMapper.selectById(req.getRoomId());
        if (room == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "房间不存在");
        }
        checkBuildingPermission(room.getBuildingId());

        SafetyInspection inspection = new SafetyInspection();
        inspection.setRoomId(req.getRoomId());
        inspection.setStudentId(req.getStudentId());
        inspection.setInspectDate(req.getInspectDate());
        inspection.setInspectorId(SecurityUtils.currentUserId());
        inspection.setItemType(req.getItemType());
        inspection.setItemDesc(req.getItemDesc());
        inspection.setPhotoUrl(req.getPhotoUrl());
        inspection.setDisposition(req.getDisposition());
        // noticeSent 表示“是否已发送整改消息”，录入后默认自动发送
        inspection.setNoticeSent(0);
        inspection.setRemark(req.getRemark());
        inspection.setCreatedAt(LocalDateTime.now());
        
        safetyInspectionMapper.insert(inspection);

        // 录入违禁品后自动发送整改消息（关联学生且有 userId 时）
        if (inspection.getStudentId() != null) {
            Student student = studentMapper.selectById(inspection.getStudentId());
            if (student != null && student.getUserId() != null) {
                NoticeMessage msg = new NoticeMessage();
                msg.setToUserId(student.getUserId());
                msg.setFromUserId(SecurityUtils.currentUserId());
                msg.setTitle("违禁品整改通知");
                msg.setContent("在您的寝室发现违禁品: " + req.getItemType() + " (" + req.getItemDesc()
                        + ")。处理结果: " + req.getDisposition() + "。请及时整改并注意宿舍安全。");
                msg.setMsgType("rectify");
                msg.setRefId(inspection.getId());
                msg.setIsRead(0);
                msg.setCreatedAt(LocalDateTime.now());
                noticeMessageMapper.insert(msg);
                inspection.setNoticeSent(1);
                safetyInspectionMapper.updateById(inspection);
            }
        }
    }

    public List<SafetyInspection> queryInspections(Long roomId, Long studentId, LocalDate startDate, LocalDate endDate) {
        LambdaQueryWrapper<SafetyInspection> w = new LambdaQueryWrapper<>();

        // 宿管只能看自己楼栋的违禁品记录
        String role = SecurityUtils.currentRole();
        if ("dorm_manager".equals(role)) {
            SysUser cur = sysUserMapper.selectById(SecurityUtils.currentUserId());
            if (cur == null || cur.getBuildingId() == null) {
                return List.of();
            }
            w.inSql(SafetyInspection::getRoomId,
                    "select id from room where building_id = " + cur.getBuildingId() + " and is_deleted = 0");
        }

        if (roomId != null) {
            w.eq(SafetyInspection::getRoomId, roomId);
        }
        if (studentId != null) {
            w.eq(SafetyInspection::getStudentId, studentId);
        }
        if (startDate != null) {
            w.ge(SafetyInspection::getInspectDate, startDate);
        }
        if (endDate != null) {
            w.le(SafetyInspection::getInspectDate, endDate);
        }
        w.orderByDesc(SafetyInspection::getInspectDate);
        return safetyInspectionMapper.selectList(w);
    }

    @Transactional
    public void updateInspection(Long id, SafetyInspectionRequest req) {
        SafetyInspection inspection = safetyInspectionMapper.selectById(id);
        if (inspection == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "检查记录不存在");
        }
        inspection.setRoomId(req.getRoomId());
        inspection.setStudentId(req.getStudentId());
        inspection.setInspectDate(req.getInspectDate());
        inspection.setItemType(req.getItemType());
        inspection.setItemDesc(req.getItemDesc());
        inspection.setPhotoUrl(req.getPhotoUrl());
        inspection.setDisposition(req.getDisposition());
        inspection.setRemark(req.getRemark());
        safetyInspectionMapper.updateById(inspection);
    }

    @Transactional
    public void deleteInspection(Long id) {
        safetyInspectionMapper.deleteById(id);
    }

    // ==========================================
    // 安全事件
    // ==========================================

    @Transactional
    public void reportEvent(SafetyEventRequest req) {
        checkBuildingPermission(req.getBuildingId());

        SafetyEvent event = new SafetyEvent();
        event.setBuildingId(req.getBuildingId());
        event.setRoomId(req.getRoomId());
        event.setEventType(req.getEventType());
        event.setSeverity(req.getSeverity());
        event.setDescription(req.getDescription());
        event.setPhotoUrl(req.getPhotoUrl());
        event.setReportedBy(SecurityUtils.currentUserId());
        event.setHandled(0);
        event.setHappenedAt(req.getHappenedAt());
        event.setCreatedAt(LocalDateTime.now());
        
        safetyEventMapper.insert(event);
    }

    @Transactional
    public void handleEvent(Long id, SafetyEventHandleRequest req) {
        SafetyEvent event = safetyEventMapper.selectById(id);
        if (event == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "安全事件不存在");
        }
        
        event.setHandled(1);
        event.setHandleNote(req.getHandleNote());
        safetyEventMapper.updateById(event);
    }

    public List<SafetyEvent> queryEvents(Long buildingId, Integer handled, Integer severity, LocalDate startDate, LocalDate endDate) {
        LambdaQueryWrapper<SafetyEvent> w = new LambdaQueryWrapper<>();

        // 权限隔离
        String role = SecurityUtils.currentRole();
        if ("dorm_manager".equals(role)) {
            SysUser cur = sysUserMapper.selectById(SecurityUtils.currentUserId());
            if (cur.getBuildingId() == null) {
                return List.of();
            }
            w.eq(SafetyEvent::getBuildingId, cur.getBuildingId());
            if (buildingId != null && !buildingId.equals(cur.getBuildingId())) {
                return List.of();
            }
        } else if (buildingId != null) {
            w.eq(SafetyEvent::getBuildingId, buildingId);
        }

        if (handled != null) {
            w.eq(SafetyEvent::getHandled, handled);
        }
        if (severity != null) {
            w.eq(SafetyEvent::getSeverity, severity);
        }
        if (startDate != null) {
            w.ge(SafetyEvent::getHappenedAt, startDate.atStartOfDay());
        }
        if (endDate != null) {
            w.le(SafetyEvent::getHappenedAt, endDate.atTime(23, 59, 59));
        }
        // 验收要求：按 severity 排序展示（严重程度优先，时间次序）
        w.orderByDesc(SafetyEvent::getSeverity)
         .orderByDesc(SafetyEvent::getHappenedAt);
        return safetyEventMapper.selectList(w);
    }

    @Transactional
    public void deleteEvent(Long id) {
        safetyEventMapper.deleteById(id);
    }

    // ==========================================
    // 权限校验辅助方法
    // ==========================================
    private void checkBuildingPermission(Long buildingId) {
        String role = SecurityUtils.currentRole();
        if ("dorm_manager".equals(role)) {
            SysUser manager = sysUserMapper.selectById(SecurityUtils.currentUserId());
            if (manager.getBuildingId() == null || !manager.getBuildingId().equals(buildingId)) {
                throw new BusinessException(ResultCode.FORBIDDEN, "无权操作其他楼栋的数据");
            }
        }
    }
}
