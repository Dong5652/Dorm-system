package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.RepairOrder;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/** 报修单 Mapper：MyBatis-Plus 通用 CRUD。 */
@Mapper
public interface RepairOrderMapper extends BaseMapper<RepairOrder> {

    /**
     * 取当日最大单号（含软删除），避免 uk_repair_order_no 与软删除记录冲突。
     */
    @Select("SELECT MAX(order_no) FROM repair_order WHERE order_no LIKE CONCAT(#{prefix}, '%')")
    String selectMaxOrderNoIncludingDeleted(@Param("prefix") String prefix);
}
