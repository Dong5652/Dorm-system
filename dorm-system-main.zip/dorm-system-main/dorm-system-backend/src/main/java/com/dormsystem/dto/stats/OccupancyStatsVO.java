package com.dormsystem.dto.stats;

import lombok.Data;

@Data
public class OccupancyStatsVO {
    private String dimName;
    private Long totalBeds;
    private Long occupiedBeds;
    private Long vacantBeds;
    private Double occupancyRate;
}
