package com.dormsystem.common;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.stream.Collectors;

/**
 * 全局异常处理：把所有异常统一翻译为 {@code {code, message, data}} 响应体，
 * HTTP 状态码与 {@link ResultCode} 同步，前端只判 {@code code} 字段即可（API_SPEC §1.1）。
 *
 * <p>注意：Spring Security 的 {@link AccessDeniedException}（403）与
 * {@link AuthenticationException}（401）必须原样抛出，由 Security 的
 * accessDeniedHandler / authenticationEntryPoint 统一写 envelope，
 * 否则会被本类兜底 Exception handler 吃成 500。</p>
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * 鉴权类异常：原样抛回去，交给 Spring Security 的 accessDeniedHandler / entryPoint。
     * 在此显式 declared 是为了优先级高于 {@code @ExceptionHandler(Exception)} 兜底。
     */
    @ExceptionHandler({AccessDeniedException.class, AuthenticationException.class})
    public void rethrowSecurity(Exception ex) throws Exception {
        throw ex;
    }

    /** 业务异常 → CONFLICT(409)，便于前端区分 4xx。 */
    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<Result<Void>> handleBusiness(BusinessException ex, HttpServletRequest req) {
        log.warn("业务异常 [{}] {} - {}", req.getRequestURI(), ex.getCode(), ex.getMessage());
        HttpStatus status = mapHttpStatus(ex.getCode());
        return ResponseEntity.status(status).body(Result.fail(ex.getCode(), ex.getMessage()));
    }

    /** 参数校验失败 → 400。 */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Result<Void>> handleValidation(MethodArgumentNotValidException ex) {
        String msg = ex.getBindingResult().getFieldErrors().stream()
                .map(e -> e.getField() + ": " + e.getDefaultMessage())
                .collect(Collectors.joining("; "));
        log.warn("参数校验失败 - {}", msg);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Result.fail(ResultCode.PARAM_INVALID, msg));
    }

    @ExceptionHandler(BindException.class)
    public ResponseEntity<Result<Void>> handleBind(BindException ex) {
        String msg = ex.getBindingResult().getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .collect(Collectors.joining("; "));
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Result.fail(ResultCode.PARAM_INVALID, msg));
    }

    /** 兜底：未捕获异常 → 500。 */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Result<Void>> handleAny(Exception ex, HttpServletRequest req) {
        log.error("未捕获异常 [{}]", req.getRequestURI(), ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Result.fail(ResultCode.INTERNAL_ERROR));
    }

    /** 把业务码映射到 HTTP 状态码。 */
    private HttpStatus mapHttpStatus(ResultCode code) {
        return switch (code) {
            case UNAUTHORIZED   -> HttpStatus.UNAUTHORIZED;
            case FORBIDDEN       -> HttpStatus.FORBIDDEN;
            case NOT_FOUND       -> HttpStatus.NOT_FOUND;
            case CONFLICT        -> HttpStatus.CONFLICT;
            case PARAM_INVALID   -> HttpStatus.BAD_REQUEST;
            case INTERNAL_ERROR, SUCCESS -> HttpStatus.OK;
        };
    }
}
