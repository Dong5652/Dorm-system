package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.record.*;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.*;
import com.dormsystem.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 入住、退宿及异动核心业务服务（Phase 5）。
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DormRecordService {

    private final StudentMapper studentMapper;
    private final BedMapper bedMapper;
    private final RoomMapper roomMapper;
    private final BuildingMapper buildingMapper;
    private final FloorMapper floorMapper;
    private final CheckInRecordMapper checkInRecordMapper;
    private final ChangeRecordMapper changeRecordMapper;
    private final SysUserMapper sysUserMapper;

    private final BedService bedService;

    private DormRecordService self;

    @Autowired
    public void setSelf(@Lazy DormRecordService self) {
        this.self = self;
    }

    /**
     * 办理入住（API_SPEC §5.1）。
     */
    @Transactional
    public Map<String, Object> checkIn(CheckInRequest req) {
        Student student = studentMapper.selectById(req.getStudentId());
        if (student == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "学生不存在");
        }
        if (student.getCurrentBedId() != null) {
            throw new BusinessException(ResultCode.CONFLICT, "该学生已分配床位，请勿重复分配");
        }

        Bed bed = bedMapper.selectById(req.getBedId());
        if (bed == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "目标床位不存在");
        }
        if (!bed.getStatus().equals(0)) {
            throw new BusinessException(ResultCode.CONFLICT, "床位当前不可分配，状态为 " + bed.getStatus());
        }

        // 校验性别一致性
        Room room = roomMapper.selectById(bed.getRoomId());
        if (room != null) {
            Building building = buildingMapper.selectById(room.getBuildingId());
            if (building != null && building.getGender() != 3 && !building.getGender().equals(student.getGender())) {
                throw new BusinessException(ResultCode.CONFLICT, "性别不匹配，不能将" + 
                        (student.getGender() == 1 ? "男" : "女") + "生分配到" + 
                        (building.getGender() == 1 ? "男生" : "女生") + "楼栋");
            }
        }

        // 占用床位
        bedService.occupy(req.getBedId(), req.getStudentId());

        // 更新学生当前床位
        student.setCurrentBedId(req.getBedId());
        studentMapper.updateById(student);

        // 写入流水日志
        CheckInRecord record = new CheckInRecord();
        record.setStudentId(req.getStudentId());
        record.setBedId(req.getBedId());
        record.setType(1); // 入住
        record.setOperatorId(SecurityUtils.currentUserId());
        record.setKeyIssued(req.getKeyIssued() != null && req.getKeyIssued() ? 1 : 0);
        record.setKeyReturned(0);
        record.setFacilityCheck(req.getFacilityCheck());
        record.setRemark(req.getRemark());
        record.setHappenedAt(LocalDateTime.now());
        checkInRecordMapper.insert(record);

        Map<String, Object> result = new HashMap<>();
        result.put("recordId", record.getId());
        result.put("bedId", req.getBedId());
        return result;
    }

    /**
     * 自动分配床位（API_SPEC §5.2）。
     */
    @Transactional
    public Map<String, Object> autoAssign(Long studentId, AutoAssignRequest req) {
        Student student = studentMapper.selectById(studentId);
        if (student == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "学生不存在");
        }
        if (student.getCurrentBedId() != null) {
            throw new BusinessException(ResultCode.CONFLICT, "该学生已分配床位，请勿重复分配");
        }

        // 确定目标楼栋集合
        List<Long> targetBuildingIds = new ArrayList<>();
        if (req.getBuildingId() != null) {
            Building building = buildingMapper.selectById(req.getBuildingId());
            if (building == null) {
                throw new BusinessException(ResultCode.NOT_FOUND, "指定楼栋不存在");
            }
            if (building.getGender() != 3 && !building.getGender().equals(student.getGender())) {
                throw new BusinessException(ResultCode.CONFLICT, "学生性别与指定楼栋性别要求不匹配");
            }
            targetBuildingIds.add(req.getBuildingId());
        } else {
            // 根据性别搜索楼栋
            List<Building> buildings = buildingMapper.selectList(new LambdaQueryWrapper<Building>()
                    .and(w -> w.eq(Building::getGender, student.getGender()).or().eq(Building::getGender, 3)));
            for (Building b : buildings) {
                targetBuildingIds.add(b.getId());
            }
        }

        if (targetBuildingIds.isEmpty()) {
            throw new BusinessException(ResultCode.NOT_FOUND, "未找到适合该学生性别的楼栋");
        }

        // 查找空闲床位
        Bed selectedBed = null;

        // 尝试 1：优先查找偏好楼层 preferredFloor 的空闲床位
        if (req.getPreferredFloor() != null) {
            List<Floor> floors = floorMapper.selectList(new LambdaQueryWrapper<Floor>()
                    .in(Floor::getBuildingId, targetBuildingIds)
                    .eq(Floor::getFloorNo, req.getPreferredFloor()));
            List<Long> floorIds = floors.stream().map(Floor::getId).collect(Collectors.toList());

            if (!floorIds.isEmpty()) {
                List<Room> rooms = roomMapper.selectList(new LambdaQueryWrapper<Room>()
                        .in(Room::getFloorId, floorIds)
                        .ne(Room::getStatus, 3) // 排除维修中
                        .ne(Room::getStatus, 4)); // 排除锁定预留
                List<Long> roomIds = rooms.stream().map(Room::getId).collect(Collectors.toList());

                if (!roomIds.isEmpty()) {
                    List<Bed> beds = bedMapper.selectList(new LambdaQueryWrapper<Bed>()
                            .in(Bed::getRoomId, roomIds)
                            .eq(Bed::getStatus, 0) // 空闲
                            .orderByAsc(Bed::getId));
                    if (!beds.isEmpty()) {
                        selectedBed = beds.get(0);
                    }
                }
            }
        }

        // 尝试 2：若无指定 preferredFloor 或尝试 1 未找到，则跨楼层任选空闲床位
        if (selectedBed == null) {
            List<Room> rooms = roomMapper.selectList(new LambdaQueryWrapper<Room>()
                    .in(Room::getBuildingId, targetBuildingIds)
                    .ne(Room::getStatus, 3)
                    .ne(Room::getStatus, 4));
            List<Long> roomIds = rooms.stream().map(Room::getId).collect(Collectors.toList());

            if (!roomIds.isEmpty()) {
                List<Bed> beds = bedMapper.selectList(new LambdaQueryWrapper<Bed>()
                        .in(Bed::getRoomId, roomIds)
                        .eq(Bed::getStatus, 0)
                        .orderByAsc(Bed::getId));
                if (!beds.isEmpty()) {
                    selectedBed = beds.get(0);
                }
            }
        }

        if (selectedBed == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "未找到适合该学生性别且空闲的床位");
        }

        // 执行办理入住
        CheckInRequest checkInReq = new CheckInRequest();
        checkInReq.setStudentId(studentId);
        checkInReq.setBedId(selectedBed.getId());
        checkInReq.setKeyIssued(true);
        checkInReq.setFacilityCheck("系统自动分配");
        checkInReq.setRemark("自动分配床位");

        return checkIn(checkInReq);
    }

    /**
     * 办理退宿（API_SPEC §5.3）。
     */
    @Transactional
    public void checkOut(CheckOutRequest req) {
        Student student = studentMapper.selectById(req.getStudentId());
        if (student == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "学生不存在");
        }
        if (student.getCurrentBedId() == null) {
            throw new BusinessException(ResultCode.CONFLICT, "该学生目前未入住任何床位，无需退宿");
        }

        Long bedId = student.getCurrentBedId();

        // 释放床位
        bedService.release(bedId);

        // 清理学生当前床位
        student.setCurrentBedId(null);
        studentMapper.updateById(student);

        // 写入退宿流水日志
        CheckInRecord record = new CheckInRecord();
        record.setStudentId(req.getStudentId());
        record.setBedId(bedId);
        record.setType(2); // 退宿
        record.setOperatorId(SecurityUtils.currentUserId());
        record.setKeyIssued(0);
        record.setKeyReturned(req.getKeyReturned() != null && req.getKeyReturned() ? 1 : 0);
        record.setFacilityCheck(req.getFacilityCheck());
        record.setRemark(req.getRemark());
        record.setHappenedAt(LocalDateTime.now());
        checkInRecordMapper.insert(record);
    }

    /**
     * 办理调宿（API_SPEC §5.4）。
     */
    @Transactional
    public void changeRoom(ChangeRoomRequest req) {
        Student student = studentMapper.selectById(req.getStudentId());
        if (student == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "学生不存在");
        }
        if (student.getCurrentBedId() == null) {
            throw new BusinessException(ResultCode.CONFLICT, "该学生目前未分配床位，请先办理入住");
        }
        if (!student.getCurrentBedId().equals(req.getFromBedId())) {
            throw new BusinessException(ResultCode.CONFLICT, "原床位匹配失败，该学生当前未占用该床位");
        }

        Bed newBed = bedMapper.selectById(req.getToBedId());
        if (newBed == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "目标新床位不存在");
        }
        if (!newBed.getStatus().equals(0)) {
            throw new BusinessException(ResultCode.CONFLICT, "目标新床位已被占用或不可用");
        }

        // 校验目标楼栋的性别匹配情况
        Room newRoom = roomMapper.selectById(newBed.getRoomId());
        if (newRoom != null) {
            Building newBuilding = buildingMapper.selectById(newRoom.getBuildingId());
            if (newBuilding != null && newBuilding.getGender() != 3 && !newBuilding.getGender().equals(student.getGender())) {
                throw new BusinessException(ResultCode.CONFLICT, "目标新床位所属楼栋与学生性别不匹配");
            }
        }

        // 执行调宿床位互换
        bedService.swap(req.getFromBedId(), req.getToBedId(), req.getStudentId());

        // 更新学生床位信息
        student.setCurrentBedId(req.getToBedId());
        studentMapper.updateById(student);

        // 写入异动记录 change_record
        ChangeRecord record = new ChangeRecord();
        record.setStudentId(req.getStudentId());
        record.setType("change_room");
        record.setFromBedId(req.getFromBedId());
        record.setToBedId(req.getToBedId());
        record.setReason(req.getReason());
        record.setOperatorId(SecurityUtils.currentUserId());
        record.setHappenedAt(LocalDateTime.now());
        changeRecordMapper.insert(record);
    }

    /**
     * 登记异动（休学、转专业、假期离校）（API_SPEC §5.5）。
     */
    @Transactional
    public void change(StudentChangeRequest req) {
        Student student = studentMapper.selectById(req.getStudentId());
        if (student == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "学生不存在");
        }

        // 校验异动类型合法性
        String type = req.getType().toLowerCase();
        if (!Set.of("suspend", "transfer", "holiday_leave").contains(type)) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "非法的异动登记类型");
        }

        // 若是休学(suspend)，需要自动退宿回收床位，并将学生档案状态置为 1 (休学)
        if ("suspend".equals(type)) {
            if (student.getCurrentBedId() != null) {
                Long oldBedId = student.getCurrentBedId();
                // 释放床位
                bedService.release(oldBedId);
                student.setCurrentBedId(null);

                // 写入退宿流水
                CheckInRecord cir = new CheckInRecord();
                cir.setStudentId(student.getId());
                cir.setBedId(oldBedId);
                cir.setType(2); // 退宿
                cir.setOperatorId(SecurityUtils.currentUserId());
                cir.setKeyIssued(0);
                cir.setKeyReturned(1); // 默认已交回
                cir.setFacilityCheck("办理休学登记时系统自动退宿");
                cir.setRemark("因办理休学异动自动收回床位");
                cir.setHappenedAt(LocalDateTime.now());
                checkInRecordMapper.insert(cir);
            }
            student.setStatus(1); // 休学
        }

        // 写入异动记录
        ChangeRecord record = new ChangeRecord();
        record.setStudentId(req.getStudentId());
        record.setType(type);
        record.setReason(req.getReason());
        record.setRemark(req.getRemark());
        record.setOperatorId(SecurityUtils.currentUserId());
        record.setHappenedAt(LocalDateTime.now());
        changeRecordMapper.insert(record);

        studentMapper.updateById(student);
    }

    /**
     * 批量退宿操作（毕业季按年级/班级批量退宿，逐条事务隔离保证）（API_SPEC §5.6）。
     */
    public Map<String, Object> batchCheckOut(BatchCheckOutRequest req) {
        LambdaQueryWrapper<Student> w = new LambdaQueryWrapper<>();
        w.eq(Student::getGrade, req.getGrade());
        if (StringUtils.hasText(req.getClassName())) {
            w.eq(Student::getClassName, req.getClassName());
        }
        w.isNotNull(Student::getCurrentBedId);

        List<Student> students = studentMapper.selectList(w);
        int total = students.size();
        int success = 0;
        int failed = 0;

        for (Student s : students) {
            try {
                self.checkOutSingle(s.getId(), req);
                success++;
            } catch (Exception e) {
                log.error("批量退宿逐条处理失败，学生学号：{}，原因：{}", s.getStudentNo(), e.getMessage());
                failed++;
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("totalCount", total);
        result.put("successCount", success);
        result.put("failedCount", failed);
        return result;
    }

    /**
     * 批量退宿中单条退宿的事务包裹辅助方法。
     */
    @Transactional
    public void checkOutSingle(Long studentId, BatchCheckOutRequest req) {
        Student student = studentMapper.selectById(studentId);
        if (student == null || student.getCurrentBedId() == null) {
            return;
        }

        Long bedId = student.getCurrentBedId();

        // 释放床位
        bedService.release(bedId);

        // 清理学生当前床位
        student.setCurrentBedId(null);
        studentMapper.updateById(student);

        // 写入退宿流水日志
        CheckInRecord record = new CheckInRecord();
        record.setStudentId(studentId);
        record.setBedId(bedId);
        record.setType(2); // 退宿
        record.setOperatorId(SecurityUtils.currentUserId());
        record.setKeyIssued(0);
        record.setKeyReturned(req.getKeyReturned() != null && req.getKeyReturned() ? 1 : 0);
        record.setFacilityCheck("批量退宿自动核验");
        record.setRemark(req.getReason());
        record.setHappenedAt(LocalDateTime.now());
        checkInRecordMapper.insert(record);
    }

    /**
     * 流水日志合并查询（API_SPEC §5.7），带严格角色范围过滤约束。
     */
    public List<DormRecordResponse> queryRecords(Long studentId, Long roomId, Integer type, 
                                                String changeType, LocalDate startDate, LocalDate endDate) {
        
        Long filterStudentId = studentId;
        String curRole = SecurityUtils.currentRole();
        Long curUserId = SecurityUtils.currentUserId();

        // 权限隔离约束
        List<Long> managerBedIds = null;
        if ("student".equals(curRole)) {
            // 学生只能查自己
            Student curStudent = studentMapper.selectOne(new LambdaQueryWrapper<Student>().eq(Student::getUserId, curUserId));
            if (curStudent == null) {
                return new ArrayList<>();
            }
            filterStudentId = curStudent.getId();
        } else if ("dorm_manager".equals(curRole)) {
            // 宿管只能查其名下楼栋的床位数据
            SysUser manager = sysUserMapper.selectById(curUserId);
            if (manager == null || manager.getBuildingId() == null) {
                return new ArrayList<>();
            }
            List<Room> rooms = roomMapper.selectList(new LambdaQueryWrapper<Room>().eq(Room::getBuildingId, manager.getBuildingId()));
            List<Long> roomIds = rooms.stream().map(Room::getId).collect(Collectors.toList());
            if (roomIds.isEmpty()) {
                return new ArrayList<>();
            }
            List<Bed> beds = bedMapper.selectList(new LambdaQueryWrapper<Bed>().in(Bed::getRoomId, roomIds));
            managerBedIds = beds.stream().map(Bed::getId).collect(Collectors.toList());
            if (managerBedIds.isEmpty()) {
                return new ArrayList<>();
            }
        }

        List<DormRecordResponse> combinedTimeline = new ArrayList<>();

        // 1. 查询入住/退宿流水 (check_in_record)
        // 若指定了 changeType 且不是查 check_in 记录，可直接跳过该表查询
        if (changeType == null) {
            LambdaQueryWrapper<CheckInRecord> w = new LambdaQueryWrapper<>();
            if (filterStudentId != null) {
                w.eq(CheckInRecord::getStudentId, filterStudentId);
            }
            if (roomId != null) {
                List<Bed> bedsInRoom = bedMapper.selectList(new LambdaQueryWrapper<Bed>().eq(Bed::getRoomId, roomId));
                List<Long> bedIdsInRoom = bedsInRoom.stream().map(Bed::getId).collect(Collectors.toList());
                if (bedIdsInRoom.isEmpty()) {
                    return new ArrayList<>();
                }
                w.in(CheckInRecord::getBedId, bedIdsInRoom);
            }
            if (type != null) {
                w.eq(CheckInRecord::getType, type);
            }
            if (startDate != null) {
                w.ge(CheckInRecord::getHappenedAt, startDate.atStartOfDay());
            }
            if (endDate != null) {
                w.le(CheckInRecord::getHappenedAt, endDate.atTime(23, 59, 59));
            }
            if (managerBedIds != null) {
                w.in(CheckInRecord::getBedId, managerBedIds);
            }

            List<CheckInRecord> checkIns = checkInRecordMapper.selectList(w);
            for (CheckInRecord r : checkIns) {
                combinedTimeline.add(mapCheckInRecord(r));
            }
        }

        // 2. 查询异动流水 (change_record)
        // 若指定了 type (入住/退宿)，直接跳过异动表的查询
        if (type == null) {
            LambdaQueryWrapper<ChangeRecord> w = new LambdaQueryWrapper<>();
            if (filterStudentId != null) {
                w.eq(ChangeRecord::getStudentId, filterStudentId);
            }
            if (roomId != null) {
                List<Bed> bedsInRoom = bedMapper.selectList(new LambdaQueryWrapper<Bed>().eq(Bed::getRoomId, roomId));
                List<Long> bedIdsInRoom = bedsInRoom.stream().map(Bed::getId).collect(Collectors.toList());
                if (bedIdsInRoom.isEmpty()) {
                    return new ArrayList<>();
                }
                w.and(qw -> qw.in(ChangeRecord::getFromBedId, bedIdsInRoom).or().in(ChangeRecord::getToBedId, bedIdsInRoom));
            }
            if (StringUtils.hasText(changeType)) {
                w.eq(ChangeRecord::getType, changeType);
            }
            if (startDate != null) {
                w.ge(ChangeRecord::getHappenedAt, startDate.atStartOfDay());
            }
            if (endDate != null) {
                w.le(ChangeRecord::getHappenedAt, endDate.atTime(23, 59, 59));
            }
            if (managerBedIds != null) {
                List<Long> finalBeds = managerBedIds;
                w.and(qw -> qw.in(ChangeRecord::getFromBedId, finalBeds).or().in(ChangeRecord::getToBedId, finalBeds));
            }

            List<ChangeRecord> changes = changeRecordMapper.selectList(w);
            for (ChangeRecord r : changes) {
                combinedTimeline.add(mapChangeRecord(r));
            }
        }

        // 3. 对流水集合按时间降序排序
        combinedTimeline.sort((o1, o2) -> o2.getHappenedAt().compareTo(o1.getHappenedAt()));
        return combinedTimeline;
    }

    private DormRecordResponse mapCheckInRecord(CheckInRecord r) {
        DormRecordResponse resp = new DormRecordResponse();
        resp.setId(r.getId());
        resp.setRecordType("check_in");
        resp.setStudentId(r.getStudentId());
        resp.setBedId(r.getBedId());
        resp.setType(r.getType());
        resp.setKeyIssued(r.getKeyIssued());
        resp.setKeyReturned(r.getKeyReturned());
        resp.setFacilityCheck(r.getFacilityCheck());
        resp.setOperatorId(r.getOperatorId());
        resp.setHappenedAt(r.getHappenedAt());
        resp.setRemark(r.getRemark());

        // 查询详细信息
        Student student = studentMapper.selectById(r.getStudentId());
        if (student != null) {
            resp.setStudentName(student.getName());
            resp.setStudentNo(student.getStudentNo());
        }

        Bed bed = bedMapper.selectById(r.getBedId());
        if (bed != null) {
            resp.setBedNo(bed.getBedNo());
            Room room = roomMapper.selectById(bed.getRoomId());
            if (room != null) {
                resp.setRoomId(room.getId());
                resp.setRoomNo(room.getRoomNo());
                Building building = buildingMapper.selectById(room.getBuildingId());
                if (building != null) {
                    resp.setBuildingName(building.getName());
                }
            }
        }

        SysUser operator = sysUserMapper.selectById(r.getOperatorId());
        if (operator != null) {
            resp.setOperatorName(operator.getRealName());
        }

        return resp;
    }

    private DormRecordResponse mapChangeRecord(ChangeRecord r) {
        DormRecordResponse resp = new DormRecordResponse();
        resp.setId(r.getId());
        resp.setRecordType("change");
        resp.setStudentId(r.getStudentId());
        resp.setChangeType(r.getType());
        resp.setChangeTypeLabel(translateChangeType(r.getType()));
        resp.setFromBedId(r.getFromBedId());
        resp.setToBedId(r.getToBedId());
        resp.setReason(r.getReason());
        resp.setOperatorId(r.getOperatorId());
        resp.setHappenedAt(r.getHappenedAt());
        resp.setRemark(r.getRemark());

        // 查询详细信息
        Student student = studentMapper.selectById(r.getStudentId());
        if (student != null) {
            resp.setStudentName(student.getName());
            resp.setStudentNo(student.getStudentNo());
        }

        if (r.getFromBedId() != null) {
            Bed b = bedMapper.selectById(r.getFromBedId());
            if (b != null) {
                resp.setFromBedNo(b.getBedNo());
                Room room = roomMapper.selectById(b.getRoomId());
                if (room != null) {
                    resp.setFromRoomNo(room.getRoomNo());
                }
            }
        }

        if (r.getToBedId() != null) {
            Bed b = bedMapper.selectById(r.getToBedId());
            if (b != null) {
                resp.setToBedNo(b.getBedNo());
                Room room = roomMapper.selectById(b.getRoomId());
                if (room != null) {
                    resp.setToRoomNo(room.getRoomNo());
                }
            }
        }

        SysUser operator = sysUserMapper.selectById(r.getOperatorId());
        if (operator != null) {
            resp.setOperatorName(operator.getRealName());
        }

        return resp;
    }

    private String translateChangeType(String type) {
        if (!StringUtils.hasText(type)) return "-";
        return switch (type.toLowerCase()) {
            case "suspend" -> "休学";
            case "transfer" -> "转专业";
            case "change_room" -> "调宿";
            case "holiday_leave" -> "假期离校";
            default -> type;
        };
    }
}
