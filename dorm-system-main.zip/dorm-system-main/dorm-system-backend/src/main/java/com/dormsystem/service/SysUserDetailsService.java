package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.dormsystem.entity.SysUser;
import com.dormsystem.mapper.SysUserMapper;
import com.dormsystem.security.LoginUser;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * 用户详情查询：JWT 解析后用 user_id 查数据库，包成 {@link LoginUser}。
 *
 * <p>Phase 2 简化：直接按 username 查 sys_user。后续阶段可加入缓存。</p>
 */
@Service
@RequiredArgsConstructor
public class SysUserDetailsService implements UserDetailsService {

    private final SysUserMapper sysUserMapper;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        SysUser user = sysUserMapper.selectOne(
                new LambdaQueryWrapper<SysUser>().eq(SysUser::getUsername, username));
        if (user == null) {
            throw new UsernameNotFoundException("账号不存在");
        }
        return new LoginUser(user);
    }

    /** 给 JwtAuthenticationFilter 用 userId 反查。 */
    public UserDetails loadUserByUserId(Long userId) {
        SysUser user = sysUserMapper.selectById(userId);
        if (user == null) {
            throw new UsernameNotFoundException("账号不存在");
        }
        return new LoginUser(user);
    }
}
