package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.SafetyInspection;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SafetyInspectionMapper extends BaseMapper<SafetyInspection> {
}
