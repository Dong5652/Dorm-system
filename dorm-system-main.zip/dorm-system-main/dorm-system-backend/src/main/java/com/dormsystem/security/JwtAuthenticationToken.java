package com.dormsystem.security;

import com.dormsystem.entity.SysUser;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

/**
 * JWT 认证 token：承载已认证的 LoginUser。
 */
public class JwtAuthenticationToken extends AbstractAuthenticationToken {

    private final LoginUser principal;

    public JwtAuthenticationToken(LoginUser principal, Object details,
                                  Collection<? extends GrantedAuthority> authorities) {
        super(authorities);
        this.principal = principal;
        setDetails(details);
        setAuthenticated(true);
    }

    @Override
    public Object getCredentials() {
        return null;
    }

    @Override
    public LoginUser getPrincipal() {
        return principal;
    }

    @Override
    public String getName() {
        return principal != null && principal.getUser() != null
                ? principal.getUser().getUsername() : null;
    }

    public SysUser getSysUser() {
        return principal != null ? principal.getUser() : null;
    }
}
