package com.dormsystem.dto.student;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.Data;

/**
 * 学生 Excel 导入导出映射模型。
 */
@Data
public class StudentExcelModel {

    @ExcelProperty("学号")
    private String studentNo;

    @ExcelProperty("姓名")
    private String name;

    @ExcelProperty("性别")
    private String gender; // Excel 中表现为 "男" / "女"

    @ExcelProperty("学院")
    private String college;

    @ExcelProperty("专业")
    private String major;

    @ExcelProperty("班级")
    private String className;

    @ExcelProperty("年级")
    private String grade;

    @ExcelProperty("联系电话")
    private String phone;

    @ExcelProperty("紧急联系人")
    private String emergencyContact;

    @ExcelProperty("紧急联系电话")
    private String emergencyPhone;

    @ExcelProperty("入学日期")
    @DateTimeFormat("yyyy-MM-dd")
    private String enrollDate; // 格式 yyyy-MM-dd
}
