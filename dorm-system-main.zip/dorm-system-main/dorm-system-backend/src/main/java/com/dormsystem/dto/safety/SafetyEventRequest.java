package com.dormsystem.dto.safety;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class SafetyEventRequest {
    @NotNull(message = "楼栋ID不能为空")
    private Long buildingId;
    private Long roomId;
    @NotBlank(message = "事件类型不能为空")
    private String eventType;
    @NotNull(message = "严重程度不能为空")
    private Integer severity;
    @NotBlank(message = "事件描述不能为空")
    private String description;
    private String photoUrl;
    @NotNull(message = "发生时间不能为空")
    private LocalDateTime happenedAt;
}
