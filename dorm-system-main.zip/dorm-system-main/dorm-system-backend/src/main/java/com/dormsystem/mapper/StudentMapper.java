package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.Student;
import org.apache.ibatis.annotations.Mapper;

/**
 * 学生档案 Mapper。
 */
@Mapper
public interface StudentMapper extends BaseMapper<Student> {
}
