package com.dormsystem.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.repair.*;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.*;
import com.dormsystem.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 报修工单服务（API_SPEC §7.1）。
 *
 * <p>状态机：</p>
 * <pre>
 *   0 待派单 ── POST /admin/repair/{id}/assign ──▶ 1 已派单
 *   1 已派单 ── PUT  /repair/{id}/start          ──▶ 2 维修中
 *   2 维修中 ── PUT  /repair/{id}/finish         ──▶ 3 已完成
 *   0/1/2    ── PUT  /repair/{id}/cancel         ──▶ 4 已取消
 *   3 已完成 ── PUT  /repair/{id}/rate           ──▶ rating 写入（不可重复）
 * </pre>
 *
 * <p>数据范围：</p>
 * <ul>
 *   <li>ADMIN → 全部工单</li>
 *   <li>DORM_MANAGER → 仅本楼栋房间的工单</li>
 *   <li>STUDENT → 仅本人发起的工单</li>
 *   <li>REPAIRMAN → 仅派给自己（repairman_id = 当前 user_id）的工单</li>
 * </ul>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RepairService {

    public static final String ROLE_STUDENT = "student";
    public static final String ROLE_REPAIRMAN = "repairman";
    public static final Integer STATUS_PENDING = 0;
    public static final Integer STATUS_ASSIGNED = 1;
    public static final Integer STATUS_IN_PROGRESS = 2;
    public static final Integer STATUS_FINISHED = 3;
    public static final Integer STATUS_CANCELLED = 4;

    private final RepairOrderMapper repairOrderMapper;
    private final RoomMapper roomMapper;
    private final BuildingMapper buildingMapper;
    private final BedMapper bedMapper;
    private final SysUserMapper sysUserMapper;
    private final StudentService studentService;

    // ---- 创建 / 状态流转 ---------------------------------------------------

    @Transactional
    public RepairOrder create(RepairCreateRequest req) {
        Room room = mustRoomWritable(req.getRoomId());

        RepairOrder order = new RepairOrder();
        order.setOrderNo(generateOrderNo());
        order.setRoomId(room.getId());
        order.setBedId(req.getBedId());
        order.setReporterId(SecurityUtils.currentUserId());
        order.setTitle(req.getTitle());
        order.setDescription(req.getDescription());
        order.setPhotoUrl(req.getPhotoUrl());
        order.setPriority(req.getPriority() == null ? 0 : req.getPriority());
        order.setStatus(STATUS_PENDING);
        repairOrderMapper.insert(order);
        return order;
    }

    /** 管理员派单：status 0 → 1。 */
    @Transactional
    public RepairOrder assign(Long id, AssignRequest req, Long operatorUserId) {
        RepairOrder order = mustGet(id);
        ensureWritable(order);
        if (!STATUS_PENDING.equals(order.getStatus())) {
            throw new BusinessException(ResultCode.CONFLICT,
                    "当前状态[" + statusName(order.getStatus()) + "]不可派单");
        }
        SysUser repairman = sysUserMapper.selectById(req.getRepairmanId());
        if (repairman == null || !ROLE_REPAIRMAN.equalsIgnoreCase(repairman.getRole())) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "指定的用户不是维修师傅");
        }
        if (repairman.getStatus() != null && repairman.getStatus() == 0) {
            throw new BusinessException(ResultCode.CONFLICT, "该维修师傅已被禁用");
        }
        order.setRepairmanId(repairman.getId());
        order.setAssignedAt(LocalDateTime.now());
        order.setAssignedBy(operatorUserId);
        order.setStatus(STATUS_ASSIGNED);
        repairOrderMapper.updateById(order);
        return order;
    }

    /** 师傅接单：status 1 → 2。 */
    @Transactional
    public RepairOrder start(Long id, Long currentUserId) {
        RepairOrder order = mustGet(id);
        // 只能接派给自己的单
        if (order.getRepairmanId() == null || !order.getRepairmanId().equals(currentUserId)) {
            throw new BusinessException(ResultCode.FORBIDDEN, "该工单未派给你，无法接单");
        }
        if (!STATUS_ASSIGNED.equals(order.getStatus())) {
            throw new BusinessException(ResultCode.CONFLICT,
                    "当前状态[" + statusName(order.getStatus()) + "]不可接单");
        }
        order.setStartedAt(LocalDateTime.now());
        order.setStatus(STATUS_IN_PROGRESS);
        repairOrderMapper.updateById(order);
        return order;
    }

    /** 师傅完工：status 2 → 3。 */
    @Transactional
    public RepairOrder finish(Long id, FinishRequest req, Long currentUserId) {
        RepairOrder order = mustGet(id);
        if (order.getRepairmanId() == null || !order.getRepairmanId().equals(currentUserId)) {
            throw new BusinessException(ResultCode.FORBIDDEN, "该工单未派给你，无法完工");
        }
        if (!STATUS_IN_PROGRESS.equals(order.getStatus())) {
            throw new BusinessException(ResultCode.CONFLICT,
                    "当前状态[" + statusName(order.getStatus()) + "]不可完工");
        }
        order.setCompletionNote(req.getCompletionNote());
        order.setFinishedAt(LocalDateTime.now());
        order.setStatus(STATUS_FINISHED);
        repairOrderMapper.updateById(order);
        return order;
    }

    /** 学生评价：仅 status=3 时可评价一次，重复评分被拒绝。 */
    @Transactional
    public RepairOrder rate(Long id, RateRequest req, Long currentUserId) {
        RepairOrder order = mustGet(id);
        // 只有报修人能评价
        if (order.getReporterId() == null || !order.getReporterId().equals(currentUserId)) {
            throw new BusinessException(ResultCode.FORBIDDEN, "仅报修人可评价工单");
        }
        if (!STATUS_FINISHED.equals(order.getStatus())) {
            throw new BusinessException(ResultCode.CONFLICT,
                    "当前状态[" + statusName(order.getStatus()) + "]不可评价");
        }
        if (order.getRating() != null) {
            throw new BusinessException(ResultCode.CONFLICT, "该工单已评价，不可重复评分");
        }
        order.setRating(req.getRating());
        order.setRatingComment(req.getRatingComment());
        repairOrderMapper.updateById(order);
        return order;
    }

    /** 取消工单：学生取消自己的（0/1/2）；管理员取消任意（0/1/2）。 */
    @Transactional
    public RepairOrder cancel(Long id, Long currentUserId, String currentRole) {
        RepairOrder order = mustGet(id);
        if (ROLE_STUDENT.equalsIgnoreCase(currentRole)) {
            if (order.getReporterId() == null || !order.getReporterId().equals(currentUserId)) {
                throw new BusinessException(ResultCode.FORBIDDEN, "只能取消自己发起的工单");
            }
        } else if (!BuildingService.ROLE_ADMIN.equalsIgnoreCase(currentRole)) {
            // 其他角色不允许取消
            throw new BusinessException(ResultCode.FORBIDDEN, "无取消工单权限");
        }
        if (STATUS_FINISHED.equals(order.getStatus()) || STATUS_CANCELLED.equals(order.getStatus())) {
            throw new BusinessException(ResultCode.CONFLICT,
                    "当前状态[" + statusName(order.getStatus()) + "]不可取消");
        }
        order.setStatus(STATUS_CANCELLED);
        repairOrderMapper.updateById(order);
        return order;
    }

    @Transactional
    public void delete(Long id) {
        RepairOrder order = mustGet(id);
        if (!BuildingService.ROLE_ADMIN.equalsIgnoreCase(SecurityUtils.currentRole())) {
            throw new BusinessException(ResultCode.FORBIDDEN, "仅管理员可删除工单");
        }
        repairOrderMapper.deleteById(order.getId());
    }

    // ---- 查询 --------------------------------------------------------------

    public RepairResponse get(Long id) {
        RepairOrder order = mustGet(id);
        ensureReadable(order);
        return toResponse(order);
    }

    public IPage<RepairResponse> page(int pageNum, int pageSize,
                                       Integer status, Integer priority,
                                       Long repairmanId,
                                       Long roomId, Long buildingId, Long reporterId,
                                       LocalDate startDate, LocalDate endDate) {
        LambdaQueryWrapper<RepairOrder> w = new LambdaQueryWrapper<>();
        String role = SecurityUtils.currentRole();

        // 1. 角色范围收敛
        if (ROLE_STUDENT.equalsIgnoreCase(role)) {
            w.eq(RepairOrder::getReporterId, SecurityUtils.currentUserId());
        } else if (ROLE_REPAIRMAN.equalsIgnoreCase(role)) {
            w.eq(RepairOrder::getRepairmanId, SecurityUtils.currentUserId());
        } else if (BuildingService.ROLE_DORM_MANAGER.equalsIgnoreCase(role)) {
            Long bid = SecurityUtils.currentUser().getBuildingId();
            if (bid == null) {
                throw new BusinessException(ResultCode.FORBIDDEN, "宿管未绑定管辖楼栋");
            }
            Set<Long> roomIds = listRoomIdsOfBuilding(bid);
            if (roomIds.isEmpty()) {
                return new Page<>(pageNum, pageSize, 0);
            }
            w.in(RepairOrder::getRoomId, roomIds);
        }
        // ADMIN 不加额外过滤

        // 2. 业务筛选
        if (status != null) w.eq(RepairOrder::getStatus, status);
        if (priority != null) w.eq(RepairOrder::getPriority, priority);
        if (repairmanId != null) w.eq(RepairOrder::getRepairmanId, repairmanId);
        if (roomId != null) w.eq(RepairOrder::getRoomId, roomId);
        if (buildingId != null) {
            Set<Long> roomsOfBuilding = listRoomIdsOfBuilding(buildingId);
            if (roomsOfBuilding.isEmpty()) {
                return new Page<>(pageNum, pageSize, 0);
            }
            w.in(RepairOrder::getRoomId, roomsOfBuilding);
        }
        if (reporterId != null) w.eq(RepairOrder::getReporterId, reporterId);
        if (startDate != null) w.ge(RepairOrder::getCreatedAt, startDate.atStartOfDay());
        if (endDate != null) w.le(RepairOrder::getCreatedAt, endDate.atTime(23, 59, 59));
        w.orderByDesc(RepairOrder::getCreatedAt).orderByDesc(RepairOrder::getId);

        Page<RepairOrder> page = new Page<>(pageNum, pageSize);
        IPage<RepairOrder> raw = repairOrderMapper.selectPage(page, w);
        return raw.convert(this::toResponse);
    }

    // ---- 工具方法 -------------------------------------------------------

    private RepairOrder mustGet(Long id) {
        RepairOrder order = repairOrderMapper.selectById(id);
        if (order == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "工单不存在");
        }
        return order;
    }

    /** 写权限：ADMIN 全部 / 宿管本楼栋 / 学生本人发起的。 */
    private void ensureWritable(RepairOrder order) {
        String role = SecurityUtils.currentRole();
        if (BuildingService.ROLE_ADMIN.equalsIgnoreCase(role)) return;
        if (BuildingService.ROLE_DORM_MANAGER.equalsIgnoreCase(role)) {
            Long bid = SecurityUtils.currentUser().getBuildingId();
            Room r = roomMapper.selectById(order.getRoomId());
            if (r == null || bid == null || !bid.equals(r.getBuildingId())) {
                throw new BusinessException(ResultCode.FORBIDDEN, "无权操作该楼栋的工单");
            }
            return;
        }
        if (ROLE_STUDENT.equalsIgnoreCase(role)) {
            if (!order.getReporterId().equals(SecurityUtils.currentUserId())) {
                throw new BusinessException(ResultCode.FORBIDDEN, "只能操作自己发起的工单");
            }
        }
    }

    /** 读权限：ADMIN 全部 / 宿管本楼栋 / 学生本人 / 师傅派给自己的。 */
    private void ensureReadable(RepairOrder order) {
        String role = SecurityUtils.currentRole();
        if (BuildingService.ROLE_ADMIN.equalsIgnoreCase(role)) return;
        if (BuildingService.ROLE_DORM_MANAGER.equalsIgnoreCase(role)) {
            Long bid = SecurityUtils.currentUser().getBuildingId();
            Room r = roomMapper.selectById(order.getRoomId());
            if (r == null || bid == null || !bid.equals(r.getBuildingId())) {
                throw new BusinessException(ResultCode.FORBIDDEN, "无权查看该楼栋的工单");
            }
            return;
        }
        if (ROLE_STUDENT.equalsIgnoreCase(role)) {
            if (!order.getReporterId().equals(SecurityUtils.currentUserId())) {
                throw new BusinessException(ResultCode.FORBIDDEN, "只能查看自己发起的工单");
            }
            return;
        }
        if (ROLE_REPAIRMAN.equalsIgnoreCase(role)) {
            if (order.getRepairmanId() == null || !order.getRepairmanId().equals(SecurityUtils.currentUserId())) {
                throw new BusinessException(ResultCode.FORBIDDEN, "只能查看派给自己的工单");
            }
        }
    }

    /** 学生创建工单时校验房间：学生只能报修自己入住的房间；宿管/管理员可报修本楼栋任意房间。 */
    private Room mustRoomWritable(Long roomId) {
        Room r = roomMapper.selectById(roomId);
        if (r == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "房间不存在");
        }
        String role = SecurityUtils.currentRole();
        if (BuildingService.ROLE_ADMIN.equalsIgnoreCase(role)) return r;
        if (BuildingService.ROLE_DORM_MANAGER.equalsIgnoreCase(role)) {
            Long bid = SecurityUtils.currentUser().getBuildingId();
            if (bid == null || !bid.equals(r.getBuildingId())) {
                throw new BusinessException(ResultCode.FORBIDDEN, "无权为该楼栋的房间发起报修");
            }
            return r;
        }
        if (ROLE_STUDENT.equalsIgnoreCase(role)) {
            Long myRoom = studentService.currentStudentRoomId(SecurityUtils.currentUserId());
            if (myRoom == null || !myRoom.equals(roomId)) {
                throw new BusinessException(ResultCode.FORBIDDEN, "只能对自己入住的房间发起报修");
            }
            return r;
        }
        throw new BusinessException(ResultCode.FORBIDDEN, "无报修权限");
    }

    private Set<Long> listRoomIdsOfBuilding(Long buildingId) {
        List<Room> rooms = roomMapper.selectList(
                new LambdaQueryWrapper<Room>().eq(Room::getBuildingId, buildingId));
        return rooms.stream().map(Room::getId).collect(Collectors.toSet());
    }

    /**
     * 生成单号 RP + yyyyMMdd + 4 位序号。
     * 序号取当天最大序号 + 1（并发冲突由 uk_repair_order_no 兜底）。
     */
    private String generateOrderNo() {
        String dateStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String prefix = "RP" + dateStr;
        // 必须包含软删除记录：uk_repair_order_no 对 is_deleted 行仍生效
        String lastNo = repairOrderMapper.selectMaxOrderNoIncludingDeleted(prefix);
        int seq = 1;
        if (lastNo != null && lastNo.length() > prefix.length()) {
            try {
                seq = Integer.parseInt(lastNo.substring(prefix.length())) + 1;
            } catch (NumberFormatException ignored) {
                seq = 1;
            }
        }
        return prefix + String.format("%04d", seq);
    }

    public static String statusName(Integer status) {
        if (status == null) return "未知";
        return switch (status) {
            case 0 -> "待派单";
            case 1 -> "已派单";
            case 2 -> "维修中";
            case 3 -> "已完成";
            case 4 -> "已取消";
            default -> "未知";
        };
    }

    private RepairResponse toResponse(RepairOrder o) {
        RepairResponse r = new RepairResponse();
        r.setId(o.getId());
        r.setOrderNo(o.getOrderNo());
        r.setRoomId(o.getRoomId());
        r.setBedId(o.getBedId());
        r.setReporterId(o.getReporterId());
        r.setTitle(o.getTitle());
        r.setDescription(o.getDescription());
        r.setPhotoUrl(o.getPhotoUrl());
        r.setStatus(o.getStatus());
        r.setPriority(o.getPriority());
        r.setRepairmanId(o.getRepairmanId());
        r.setAssignedAt(o.getAssignedAt());
        r.setAssignedById(o.getAssignedBy());
        r.setStartedAt(o.getStartedAt());
        r.setFinishedAt(o.getFinishedAt());
        r.setCompletionNote(o.getCompletionNote());
        r.setRating(o.getRating());
        r.setRatingComment(o.getRatingComment());
        r.setCreatedAt(o.getCreatedAt());

        Room room = roomMapper.selectById(o.getRoomId());
        if (room != null) {
            r.setRoomNo(room.getRoomNo());
            r.setBuildingId(room.getBuildingId());
            Building b = buildingMapper.selectById(room.getBuildingId());
            if (b != null) r.setBuildingName(b.getName());
        }
        if (o.getBedId() != null) {
            Bed bed = bedMapper.selectById(o.getBedId());
            if (bed != null) r.setBedNo(bed.getBedNo());
        }
        SysUser reporter = sysUserMapper.selectById(o.getReporterId());
        if (reporter != null) r.setReporterName(reporter.getRealName());
        if (o.getRepairmanId() != null) {
            SysUser repairman = sysUserMapper.selectById(o.getRepairmanId());
            if (repairman != null) {
                r.setRepairmanName(repairman.getRealName());
                r.setRepairmanPhone(repairman.getPhone());
                r.setRepairmanWorkType(repairman.getWorkType());
            }
        }
        if (o.getAssignedBy() != null) {
            SysUser assigner = sysUserMapper.selectById(o.getAssignedBy());
            if (assigner != null) r.setAssignedByName(assigner.getRealName());
        }
        return r;
    }
}
