package com.dormsystem.service;

import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.stats.DisciplineRecordVO;
import com.dormsystem.dto.stats.OccupancyStatsVO;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StatsService {
    private final StudentMapper studentMapper;
    private final BedMapper bedMapper;
    private final RoomMapper roomMapper;
    private final BuildingMapper buildingMapper;
    private final HygieneCheckMapper hygieneCheckMapper;
    private final AttendanceMapper attendanceMapper;
    private final SafetyInspectionMapper safetyInspectionMapper;
    private final FeeMapper feeMapper;
    private final RepairOrderMapper repairOrderMapper;

    /**
     * 入住率统计。
     * groupBy: building | gender | major | grade；缺省按 building。
     */
    public List<OccupancyStatsVO> getOccupancyStats(String groupBy, Long buildingId) {
        String dim = StringUtils.hasText(groupBy) ? groupBy.trim().toLowerCase(Locale.ROOT) : "building";
        // 宿管强制锁定本人楼栋；管理员可查全校或指定楼栋
        Long scopedBuildingId = BuildingService.scopeBuildingId();
        if (scopedBuildingId != null) {
            buildingId = scopedBuildingId;
        }

        List<Bed> beds = bedMapper.selectList(new LambdaQueryWrapper<>());
        List<Room> rooms = roomMapper.selectList(new LambdaQueryWrapper<>());
        Map<Long, Room> roomMap = rooms.stream().collect(Collectors.toMap(Room::getId, r -> r, (a, b) -> a));

        if (buildingId != null) {
            Long bid = buildingId;
            beds = beds.stream()
                    .filter(b -> {
                        Room room = roomMap.get(b.getRoomId());
                        return room != null && bid.equals(room.getBuildingId());
                    })
                    .collect(Collectors.toList());
        }

        List<Building> buildings = buildingMapper.selectList(new LambdaQueryWrapper<>());
        Map<Long, Building> buildingMap = buildings.stream()
                .collect(Collectors.toMap(Building::getId, b -> b, (a, b) -> a));

        // 学生映射：按当前床位关联
        List<Student> students = studentMapper.selectList(new LambdaQueryWrapper<Student>()
                .eq(Student::getStatus, 0));
        Map<Long, Student> studentByBed = students.stream()
                .filter(s -> s.getCurrentBedId() != null)
                .collect(Collectors.toMap(Student::getCurrentBedId, s -> s, (a, b) -> a));

        Map<String, List<Bed>> groups = new LinkedHashMap<>();
        for (Bed bed : beds) {
            String key = resolveDimName(dim, bed, roomMap, buildingMap, studentByBed);
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(bed);
        }

        List<OccupancyStatsVO> statsList = new ArrayList<>();
        for (Map.Entry<String, List<Bed>> entry : groups.entrySet()) {
            List<Bed> groupBeds = entry.getValue();
            long total = groupBeds.size();
            long occupied = groupBeds.stream()
                    .filter(b -> b.getStatus() != null && b.getStatus() == 1)
                    .count();
            OccupancyStatsVO vo = new OccupancyStatsVO();
            vo.setDimName(entry.getKey());
            vo.setTotalBeds(total);
            vo.setOccupiedBeds(occupied);
            vo.setVacantBeds(total - occupied);
            vo.setOccupancyRate(total > 0 ? (double) occupied / total * 100 : 0.0);
            statsList.add(vo);
        }

        // 稳定排序：按维度名
        statsList.sort(Comparator.comparing(OccupancyStatsVO::getDimName, Comparator.nullsLast(String::compareTo)));
        return statsList;
    }

    private String resolveDimName(String dim,
                                  Bed bed,
                                  Map<Long, Room> roomMap,
                                  Map<Long, Building> buildingMap,
                                  Map<Long, Student> studentByBed) {
        Room room = roomMap.get(bed.getRoomId());
        Building building = room == null ? null : buildingMap.get(room.getBuildingId());
        Student student = studentByBed.get(bed.getId());

        return switch (dim) {
            case "gender" -> {
                Integer gender = building == null ? null : building.getGender();
                if (gender == null) yield "未知性别";
                yield switch (gender) {
                    case 1 -> "男";
                    case 2 -> "女";
                    case 3 -> "混合";
                    default -> "未知性别";
                };
            }
            case "major" -> student == null || !StringUtils.hasText(student.getMajor())
                    ? "未入住/未知专业"
                    : student.getMajor();
            case "grade" -> student == null || !StringUtils.hasText(student.getGrade())
                    ? "未入住/未知年级"
                    : student.getGrade();
            default -> building == null
                    ? "未知楼栋"
                    : (StringUtils.hasText(building.getName()) ? building.getName() : building.getCode());
        };
    }

    /**
     * 违纪时间线：卫生扣分 + 晚归/未归 + 违禁品。
     */
    public List<DisciplineRecordVO> getDisciplineTimeline(String studentNo, Long roomId,
                                                          String startDate, String endDate) {
        List<DisciplineRecordVO> records = new ArrayList<>();
        Long scopedBuildingId = BuildingService.scopeBuildingId();

        Student student = null;
        Long studentId = null;
        if (StringUtils.hasText(studentNo)) {
            student = studentMapper.selectOne(new LambdaQueryWrapper<Student>()
                    .eq(Student::getStudentNo, studentNo)
                    .last("LIMIT 1"));
            if (student != null) {
                studentId = student.getId();
                if (roomId == null && student.getCurrentBedId() != null) {
                    Bed bed = bedMapper.selectById(student.getCurrentBedId());
                    if (bed != null) {
                        roomId = bed.getRoomId();
                    }
                }
            }
        }

        // 宿管只能查自己楼栋的学生/房间
        if (scopedBuildingId != null) {
            if (roomId != null) {
                Room room = roomMapper.selectById(roomId);
                if (room == null || !scopedBuildingId.equals(room.getBuildingId())) {
                    throw new BusinessException(ResultCode.FORBIDDEN, "无权查看其他楼栋的违纪记录");
                }
            }
            if (student != null) {
                if (student.getCurrentBedId() == null) {
                    throw new BusinessException(ResultCode.FORBIDDEN, "该学生未入住，宿管不可查询");
                }
                Bed bed = bedMapper.selectById(student.getCurrentBedId());
                Room room = bed == null ? null : roomMapper.selectById(bed.getRoomId());
                if (room == null || !scopedBuildingId.equals(room.getBuildingId())) {
                    throw new BusinessException(ResultCode.FORBIDDEN, "无权查看其他楼栋学生的违纪记录");
                }
            }
            if (roomId == null && student == null) {
                throw new BusinessException(ResultCode.PARAM_INVALID, "宿管查询违纪记录需指定学号或房间");
            }
        }

        LocalDate start = parseDate(startDate);
        LocalDate end = parseDate(endDate);

        // 1) 卫生：按房间，score < 80 视为扣分/不达标
        if (roomId != null) {
            LambdaQueryWrapper<HygieneCheck> hw = new LambdaQueryWrapper<>();
            hw.eq(HygieneCheck::getRoomId, roomId);
            if (start != null) hw.ge(HygieneCheck::getCheckDate, start);
            if (end != null) hw.le(HygieneCheck::getCheckDate, end);
            List<HygieneCheck> checks = hygieneCheckMapper.selectList(hw);
            for (HygieneCheck c : checks) {
                if (c.getScore() != null && c.getScore().compareTo(new BigDecimal("80")) < 0) {
                    DisciplineRecordVO vo = new DisciplineRecordVO();
                    vo.setType("hygiene");
                    vo.setDescription("卫生不达标 (" + c.getScore() + "分)");
                    vo.setTime(c.getCheckDate() == null ? null : c.getCheckDate().atStartOfDay());
                    vo.setRoomId(roomId);
                    vo.setStudentId(studentId);
                    vo.setScore(c.getScore().intValue());
                    records.add(vo);
                }
            }
        }

        // 2) 考勤：type 1晚归 2未归 3请假（请假不算违纪）
        if (studentId != null) {
            LambdaQueryWrapper<Attendance> aw = new LambdaQueryWrapper<>();
            aw.eq(Attendance::getStudentId, studentId);
            if (start != null) aw.ge(Attendance::getRecordDate, start);
            if (end != null) aw.le(Attendance::getRecordDate, end);
            List<Attendance> atts = attendanceMapper.selectList(aw);
            for (Attendance a : atts) {
                if (a.getType() == null || a.getType() == 3) {
                    continue;
                }
                DisciplineRecordVO vo = new DisciplineRecordVO();
                vo.setType("attendance");
                vo.setDescription(a.getType() == 1 ? "晚归" : "未归");
                vo.setTime(a.getRecordDate() == null ? null : a.getRecordDate().atStartOfDay());
                vo.setStudentId(studentId);
                vo.setRoomId(a.getRoomId());
                records.add(vo);
            }
        }

        // 3) 违禁品
        if (studentId != null || roomId != null) {
            LambdaQueryWrapper<SafetyInspection> sw = new LambdaQueryWrapper<>();
            if (studentId != null) {
                sw.eq(SafetyInspection::getStudentId, studentId);
            }
            if (roomId != null) {
                sw.eq(SafetyInspection::getRoomId, roomId);
            }
            if (start != null) sw.ge(SafetyInspection::getInspectDate, start);
            if (end != null) sw.le(SafetyInspection::getInspectDate, end);
            List<SafetyInspection> inspections = safetyInspectionMapper.selectList(sw);
            for (SafetyInspection si : inspections) {
                DisciplineRecordVO vo = new DisciplineRecordVO();
                vo.setType("safety");
                String item = StringUtils.hasText(si.getItemType()) ? si.getItemType() : "违禁品";
                String desc = StringUtils.hasText(si.getItemDesc()) ? si.getItemDesc() : "";
                vo.setDescription("违禁品: " + item + (desc.isEmpty() ? "" : " (" + desc + ")"));
                vo.setTime(si.getInspectDate() == null ? null : si.getInspectDate().atStartOfDay());
                vo.setStudentId(si.getStudentId());
                vo.setRoomId(si.getRoomId());
                records.add(vo);
            }
        }

        records.sort((a, b) -> {
            if (a.getTime() == null && b.getTime() == null) return 0;
            if (a.getTime() == null) return 1;
            if (b.getTime() == null) return -1;
            return b.getTime().compareTo(a.getTime());
        });
        return records;
    }

    public void exportReport(String type, HttpServletResponse response) throws IOException {
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        String fileName = URLEncoder.encode(type + "_report", StandardCharsets.UTF_8).replaceAll("\\+", "%20");
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");

        switch (type) {
            case "occupancy" -> {
                List<Student> students = studentMapper.selectList(null);
                EasyExcel.write(response.getOutputStream(), Student.class).sheet("入住名单").doWrite(students);
            }
            case "fee" -> {
                List<Fee> fees = feeMapper.selectList(null);
                EasyExcel.write(response.getOutputStream(), Fee.class).sheet("缴费统计").doWrite(fees);
            }
            case "repair" -> {
                List<RepairOrder> repairs = repairOrderMapper.selectList(null);
                EasyExcel.write(response.getOutputStream(), RepairOrder.class).sheet("维修账单").doWrite(repairs);
            }
            case "score" -> {
                List<HygieneCheck> checks = hygieneCheckMapper.selectList(null);
                EasyExcel.write(response.getOutputStream(), HygieneCheck.class).sheet("卫生考评").doWrite(checks);
            }
            default -> throw new IllegalArgumentException("Unknown export type: " + type);
        }
    }

    private LocalDate parseDate(String value) {
        if (!StringUtils.hasText(value)) {
            return null;
        }
        return LocalDate.parse(value.trim());
    }
}
