package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.ChangeRecord;
import org.apache.ibatis.annotations.Mapper;

/**
 * 宿舍异动记录 Mapper。
 */
@Mapper
public interface ChangeRecordMapper extends BaseMapper<ChangeRecord> {
}
