package com.dormsystem.dto.safety;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class SafetyEventHandleRequest {
    @NotBlank(message = "处置说明不能为空")
    private String handleNote;
}
