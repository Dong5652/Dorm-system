package com.dormsystem.schedule;

import com.dormsystem.service.DormScoreService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

/**
 * 月度寝室评分定时任务（DEVELOPMENT_PLAN §6.5）。
 *
 * <p>每月 1 号凌晨 1 点跑上月评分。{@code @EnableScheduling} 由
 * {@link com.dormsystem.DormSystemApplication} 启用。</p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DormScoreScheduler {

    private final DormScoreService dormScoreService;

    /**
     * 每月 1 号 01:00 自动跑上月评分。
     * cron = 秒 分 时 日 月 周
     */
    @Scheduled(cron = "0 0 1 1 * ?")
    public void generateLastMonthScores() {
        YearMonth lastMonth = YearMonth.now().minusMonths(1);
        String yearMonth = lastMonth.format(DateTimeFormatter.ofPattern("yyyy-MM"));
        log.info("DormScoreScheduler: start generating scores for {}", yearMonth);
        try {
            int affected = dormScoreService.generateMonthlyScores(yearMonth);
            log.info("DormScoreScheduler: finished, generated {} scores for {}", affected, yearMonth);
        } catch (Exception e) {
            log.error("DormScoreScheduler: failed for {}", yearMonth, e);
        }
    }

    /** 提供给应用启动时可选的引导方法（暂不调用，留作扩展）。 */
    public void runFor(LocalDate date) {
        String ym = YearMonth.from(date).format(DateTimeFormatter.ofPattern("yyyy-MM"));
        dormScoreService.generateMonthlyScores(ym);
    }
}
