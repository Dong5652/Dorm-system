package com.dormsystem.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 报修单表（{@code repair_order}，DATABASE.md §2.4）。
 *
 * <p>状态机：</p>
 * <pre>
 *   0 待派单 ── POST /admin/repair/{id}/assign ──▶ 1 已派单
 *   1 已派单 ── PUT  /repair/{id}/start          ──▶ 2 维修中
 *   2 维修中 ── PUT  /repair/{id}/finish         ──▶ 3 已完成
 *   0/1/2    ── PUT  /repair/{id}/cancel         ──▶ 4 已取消
 *   3 已完成 ── PUT  /repair/{id}/rate           ──▶ rating 写入
 * </pre>
 *
 * <p>priority: 0普通 1紧急 2非常紧急。</p>
 */
@Data
@TableName("repair_order")
public class RepairOrder {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 单号 RP + 日期 + 4 位序号，如 RP202603150001。 */
    private String orderNo;

    private Long roomId;

    /** 具体床位（可空）。 */
    private Long bedId;

    /** 报修人 user_id。 */
    private Long reporterId;

    private String title;

    private String description;

    private String photoUrl;

    /** 0待派单 1已派单 2维修中 3已完成 4已取消。 */
    private Integer status;

    /** 0普通 1紧急 2非常紧急。 */
    private Integer priority;

    /** 派单维修师傅 user_id。 */
    private Long repairmanId;

    private LocalDateTime assignedAt;

    /** 派单人 user_id（管理员）。 */
    private Long assignedBy;

    private LocalDateTime startedAt;

    private LocalDateTime finishedAt;

    private String completionNote;

    /** 学生评价 1-5 星。 */
    private Integer rating;

    private String ratingComment;

    private LocalDateTime createdAt;

    @TableLogic
    @TableField("is_deleted")
    private Integer isDeleted;
}
