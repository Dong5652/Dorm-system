package com.dormsystem.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.Result;
import com.dormsystem.entity.OperationLog;
import com.dormsystem.mapper.OperationLogMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/logs")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class OperationLogController {

    private final OperationLogMapper operationLogMapper;

    @GetMapping
    public Result<?> getLogs(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) Long operatorId,
            @RequestParam(required = false) String module,
            @RequestParam(required = false) String action) {
        
        LambdaQueryWrapper<OperationLog> wrapper = new LambdaQueryWrapper<>();
        if (operatorId != null) wrapper.eq(OperationLog::getOperatorId, operatorId);
        if (module != null && !module.isEmpty()) wrapper.like(OperationLog::getModule, module);
        if (action != null && !action.isEmpty()) wrapper.like(OperationLog::getAction, action);
        wrapper.orderByDesc(OperationLog::getCreatedAt);
        
        return Result.success(operationLogMapper.selectPage(new Page<>(page, size), wrapper));
    }
}
