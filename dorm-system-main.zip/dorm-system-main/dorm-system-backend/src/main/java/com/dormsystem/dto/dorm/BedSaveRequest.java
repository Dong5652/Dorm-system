package com.dormsystem.dto.dorm;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/** 新增 / 修改床位请求。 */
@Data
public class BedSaveRequest {

    @NotNull(message = "房间 id 必填")
    private Long roomId;

    @NotBlank(message = "床位号不能为空")
    private String bedNo;

    private Integer status;
}
