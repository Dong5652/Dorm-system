package com.dormsystem.dto.record;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 调宿申请请求。
 */
@Data
public class ChangeRoomRequest {

    @NotNull(message = "学生ID不能为空")
    private Long studentId;

    @NotNull(message = "原床位ID不能为空")
    private Long fromBedId;

    @NotNull(message = "目标床位ID不能为空")
    private Long toBedId;

    private String reason;
}
