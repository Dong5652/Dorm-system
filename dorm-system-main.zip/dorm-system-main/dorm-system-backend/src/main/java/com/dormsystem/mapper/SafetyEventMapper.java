package com.dormsystem.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dormsystem.entity.SafetyEvent;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SafetyEventMapper extends BaseMapper<SafetyEvent> {
}
