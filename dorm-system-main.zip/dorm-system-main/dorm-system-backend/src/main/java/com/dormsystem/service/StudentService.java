package com.dormsystem.service;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.read.listener.ReadListener;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dormsystem.common.BusinessException;
import com.dormsystem.common.ResultCode;
import com.dormsystem.dto.student.StudentDetailResponse;
import com.dormsystem.dto.student.StudentExcelModel;
import com.dormsystem.dto.student.StudentSaveRequest;
import com.dormsystem.entity.*;
import com.dormsystem.mapper.*;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 学生档案服务。
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentMapper studentMapper;
    private final SysUserMapper sysUserMapper;
    private final BedMapper bedMapper;
    private final RoomMapper roomMapper;
    private final FloorMapper floorMapper;
    private final BuildingMapper buildingMapper;
    private final ChangeRecordMapper changeRecordMapper;
    private final PasswordEncoder passwordEncoder;

    public Page<Student> page(int pageNum, int pageSize, String keyword, String className, String college, Integer status) {
        Page<Student> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Student> w = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            w.and(qw -> qw.like(Student::getStudentNo, keyword).or().like(Student::getName, keyword));
        }
        if (StringUtils.hasText(className)) {
            w.eq(Student::getClassName, className);
        }
        if (StringUtils.hasText(college)) {
            w.eq(Student::getCollege, college);
        }
        if (status != null) {
            w.eq(Student::getStatus, status);
        }
        w.orderByDesc(Student::getId);
        return studentMapper.selectPage(page, w);
    }

    public Student get(Long id) {
        Student s = studentMapper.selectById(id);
        if (s == null) {
            throw new BusinessException(ResultCode.NOT_FOUND, "学生档案不存在");
        }
        return s;
    }

    /**
     * 根据 sys_user.id 反查学生当前入住的房间 ID（student.current_bed_id → bed.room_id）。
     *
     * <p>未找到学生 / 未分配床位 / 床位不存在时返回 null。供卫生检查、考勤等模块做数据范围收敛用。</p>
     */
    public Long currentStudentRoomId(Long studentUserId) {
        if (studentUserId == null) return null;
        Student s = studentMapper.selectOne(
                new LambdaQueryWrapper<Student>().eq(Student::getUserId, studentUserId));
        if (s == null || s.getCurrentBedId() == null) return null;
        Bed b = bedMapper.selectById(s.getCurrentBedId());
        return b == null ? null : b.getRoomId();
    }

    /**
     * 根据 sys_user.id 反查学生档案；不存在返回 null（不抛异常）。
     */
    public Student findByUserId(Long studentUserId) {
        if (studentUserId == null) return null;
        return studentMapper.selectOne(
                new LambdaQueryWrapper<Student>().eq(Student::getUserId, studentUserId));
    }

    public StudentDetailResponse getDetail(Long id) {
        Student s = get(id);
        SysUser user = sysUserMapper.selectById(s.getUserId());
        String phone = user != null ? user.getPhone() : null;

        StudentDetailResponse resp = new StudentDetailResponse();
        resp.setStudent(s);
        resp.setPhone(phone);

        // 获取当前床位信息
        if (s.getCurrentBedId() != null) {
            Bed bed = bedMapper.selectById(s.getCurrentBedId());
            if (bed != null) {
                StudentDetailResponse.BedDetail bedDetail = new StudentDetailResponse.BedDetail();
                bedDetail.setBedId(bed.getId());
                bedDetail.setBedNo(bed.getBedNo());

                Room room = roomMapper.selectById(bed.getRoomId());
                if (room != null) {
                    bedDetail.setRoomId(room.getId());
                    bedDetail.setRoomNo(room.getRoomNo());

                    Floor floor = floorMapper.selectById(room.getFloorId());
                    if (floor != null) {
                        bedDetail.setFloorId(floor.getId());
                        bedDetail.setFloorNo(floor.getFloorNo());
                    }

                    Building building = buildingMapper.selectById(room.getBuildingId());
                    if (building != null) {
                        bedDetail.setBuildingId(building.getId());
                        bedDetail.setBuildingName(building.getName());
                    }
                }
                resp.setBedDetail(bedDetail);
            }
        }

        // 获取历史异动流水
        List<ChangeRecord> records = changeRecordMapper.selectList(
                new LambdaQueryWrapper<ChangeRecord>()
                        .eq(ChangeRecord::getStudentId, s.getId())
                        .orderByDesc(ChangeRecord::getHappenedAt));

        List<StudentDetailResponse.ChangeRecordDetail> recordDetails = new ArrayList<>();
        // 获取所有经办人名称
        Map<Long, String> operatorNameMap = new HashMap<>();
        for (ChangeRecord r : records) {
            StudentDetailResponse.ChangeRecordDetail rd = new StudentDetailResponse.ChangeRecordDetail();
            rd.setId(r.getId());
            rd.setType(r.getType());
            rd.setTypeLabel(translateChangeType(r.getType()));
            rd.setFromBedId(r.getFromBedId());
            rd.setToBedId(r.getToBedId());
            rd.setReason(r.getReason());
            rd.setOperatorId(r.getOperatorId());
            rd.setHappenedAt(r.getHappenedAt());
            rd.setRemark(r.getRemark());

            // 经办人姓名查询
            if (r.getOperatorId() != null) {
                String opName = operatorNameMap.computeIfAbsent(r.getOperatorId(), opId -> {
                    SysUser opUser = sysUserMapper.selectById(opId);
                    return opUser != null ? opUser.getRealName() : "管理员";
                });
                rd.setOperatorName(opName);
            }

            // 原床位与房间查询
            if (r.getFromBedId() != null) {
                Bed b = bedMapper.selectById(r.getFromBedId());
                if (b != null) {
                    rd.setFromBedNo(b.getBedNo());
                    Room rm = roomMapper.selectById(b.getRoomId());
                    if (rm != null) rd.setFromRoomNo(rm.getRoomNo());
                }
            }

            // 新床位与房间查询
            if (r.getToBedId() != null) {
                Bed b = bedMapper.selectById(r.getToBedId());
                if (b != null) {
                    rd.setToBedNo(b.getBedNo());
                    Room rm = roomMapper.selectById(b.getRoomId());
                    if (rm != null) rd.setToRoomNo(rm.getRoomNo());
                }
            }

            recordDetails.add(rd);
        }
        resp.setChangeRecords(recordDetails);

        return resp;
    }

    private String translateChangeType(String type) {
        if (!StringUtils.hasText(type)) return "-";
        return switch (type.toLowerCase()) {
            case "suspend" -> "休学";
            case "transfer" -> "转专业";
            case "change_room" -> "调宿";
            case "holiday_leave" -> "假期离校";
            default -> type;
        };
    }

    @Transactional
    public Student create(StudentSaveRequest req) {
        checkStudentNoUnique(req.getStudentNo());

        // 1. 新增 sys_user 账号
        SysUser user = new SysUser();
        user.setUsername(req.getStudentNo());
        // 默认密码为 123456
        user.setPassword(passwordEncoder.encode("123456"));
        user.setRealName(req.getName());
        user.setRole("student");
        user.setGender(req.getGender());
        user.setPhone(req.getPhone());
        user.setStatus(1); // 启用
        sysUserMapper.insert(user);

        // 2. 新增 student 档案
        Student s = new Student();
        s.setUserId(user.getId());
        s.setStudentNo(req.getStudentNo());
        s.setName(req.getName());
        s.setGender(req.getGender());
        s.setCollege(req.getCollege());
        s.setMajor(req.getMajor());
        s.setClassName(req.getClassName());
        s.setGrade(req.getGrade());
        s.setEmergencyContact(req.getEmergencyContact());
        s.setEmergencyPhone(req.getEmergencyPhone());
        s.setEnrollDate(req.getEnrollDate());
        s.setStatus(req.getStatus());
        studentMapper.insert(s);

        return s;
    }

    @Transactional
    public Student update(Long id, StudentSaveRequest req) {
        Student s = get(id);
        if (!s.getStudentNo().equals(req.getStudentNo())) {
            checkStudentNoUnique(req.getStudentNo());
        }

        // 1. 同步修改 sys_user 账户基本信息
        SysUser user = sysUserMapper.selectById(s.getUserId());
        if (user != null) {
            user.setUsername(req.getStudentNo());
            user.setRealName(req.getName());
            user.setGender(req.getGender());
            user.setPhone(req.getPhone());
            // 如果学生状态是毕业(2)或退学(3)，禁用其账号
            if (req.getStatus() == 2 || req.getStatus() == 3) {
                user.setStatus(0);
            } else {
                user.setStatus(1);
            }
            sysUserMapper.updateById(user);
        }

        // 2. 修改 student 档案
        s.setStudentNo(req.getStudentNo());
        s.setName(req.getName());
        s.setGender(req.getGender());
        s.setCollege(req.getCollege());
        s.setMajor(req.getMajor());
        s.setClassName(req.getClassName());
        s.setGrade(req.getGrade());
        s.setEmergencyContact(req.getEmergencyContact());
        s.setEmergencyPhone(req.getEmergencyPhone());
        s.setEnrollDate(req.getEnrollDate());
        s.setStatus(req.getStatus());
        studentMapper.updateById(s);

        return s;
    }

    @Transactional
    public void delete(Long id) {
        Student s = get(id);
        // 校验是否已分配床位，避免悬挂脏数据
        if (s.getCurrentBedId() != null) {
            throw new BusinessException(ResultCode.CONFLICT, "该学生目前已分配床位，请先办理退宿再删除档案");
        }

        // 软删除 sys_user 账号
        sysUserMapper.deleteById(s.getUserId());
        // 软删除 student 档案
        studentMapper.deleteById(id);
    }

    private void checkStudentNoUnique(String studentNo) {
        Long cntUser = sysUserMapper.selectCount(new LambdaQueryWrapper<SysUser>().eq(SysUser::getUsername, studentNo));
        Long cntStudent = studentMapper.selectCount(new LambdaQueryWrapper<Student>().eq(Student::getStudentNo, studentNo));
        if ((cntUser != null && cntUser > 0) || (cntStudent != null && cntStudent > 0)) {
            throw new BusinessException(ResultCode.CONFLICT, "学号已存在: " + studentNo);
        }
    }

    /**
     * Excel 批量导入学生档案。
     */
    @Transactional
    public Map<String, Object> importExcel(MultipartFile file) {
        List<String> errorList = new ArrayList<>();
        List<StudentExcelModel> validRows = new ArrayList<>();

        try {
            EasyExcel.read(file.getInputStream(), StudentExcelModel.class, new ReadListener<StudentExcelModel>() {
                private int rowNum = 1; // 1-indexed

                @Override
                public void invoke(StudentExcelModel data, AnalysisContext context) {
                    rowNum++;
                    // 校验基本必填字段
                    if (!StringUtils.hasText(data.getStudentNo())) {
                        errorList.add("第 " + rowNum + " 行：学号为空，已忽略");
                        return;
                    }
                    if (!StringUtils.hasText(data.getName())) {
                        errorList.add("第 " + rowNum + " 行：姓名为空，已忽略");
                        return;
                    }
                    if (!StringUtils.hasText(data.getGender())) {
                        errorList.add("第 " + rowNum + " 行：性别为空，已忽略");
                        return;
                    }
                    String gStr = data.getGender().trim();
                    if (!"男".equals(gStr) && !"女".equals(gStr)) {
                        errorList.add("第 " + rowNum + " 行：性别必须为'男'或'女'，已忽略");
                        return;
                    }

                    // 检查学号是否已存在
                    Long cntUser = sysUserMapper.selectCount(new LambdaQueryWrapper<SysUser>().eq(SysUser::getUsername, data.getStudentNo()));
                    Long cntStudent = studentMapper.selectCount(new LambdaQueryWrapper<Student>().eq(Student::getStudentNo, data.getStudentNo()));
                    if ((cntUser != null && cntUser > 0) || (cntStudent != null && cntStudent > 0)) {
                        errorList.add("第 " + rowNum + " 行：学号 [" + data.getStudentNo() + "] 已存在，已忽略");
                        return;
                    }

                    // 校验是否在 validRows 中有重复学号
                    if (validRows.stream().anyMatch(r -> r.getStudentNo().equals(data.getStudentNo()))) {
                        errorList.add("第 " + rowNum + " 行：文件中存在重复学号 [" + data.getStudentNo() + "]，已忽略");
                        return;
                    }

                    validRows.add(data);
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {
                    log.info("Excel 学生导入解析完成，有效条数：{}", validRows.size());
                }
            }).sheet().doRead();
        } catch (IOException e) {
            throw new BusinessException(ResultCode.PARAM_INVALID, "文件读取失败: " + e.getMessage());
        }

        // 执行批量保存
        int successCount = 0;
        for (StudentExcelModel model : validRows) {
            try {
                StudentSaveRequest req = new StudentSaveRequest();
                req.setStudentNo(model.getStudentNo());
                req.setName(model.getName());
                req.setGender("男".equals(model.getGender().trim()) ? 1 : 2);
                req.setCollege(model.getCollege());
                req.setMajor(model.getMajor());
                req.setClassName(model.getClassName());
                req.setGrade(model.getGrade());
                req.setPhone(model.getPhone());
                req.setEmergencyContact(model.getEmergencyContact());
                req.setEmergencyPhone(model.getEmergencyPhone());
                req.setStatus(0); // 默认在籍

                // 入学日期解析
                if (StringUtils.hasText(model.getEnrollDate())) {
                    try {
                        req.setEnrollDate(LocalDate.parse(model.getEnrollDate().trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd")));
                    } catch (Exception ex) {
                        // 无法解析时设为今天并警告
                        req.setEnrollDate(LocalDate.now());
                    }
                } else {
                    req.setEnrollDate(LocalDate.now());
                }

                create(req);
                successCount++;
            } catch (Exception e) {
                errorList.add("保存学生 [" + model.getName() + " (" + model.getStudentNo() + ")] 发生错误: " + e.getMessage());
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("successCount", successCount);
        result.put("errorList", errorList);
        return result;
    }

    /**
     * 导出符合条件的学生档案到 Excel。
     */
    public void exportExcel(String keyword, String className, String college, Integer status, HttpServletResponse response) throws IOException {
        LambdaQueryWrapper<Student> w = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            w.and(qw -> qw.like(Student::getStudentNo, keyword).or().like(Student::getName, keyword));
        }
        if (StringUtils.hasText(className)) {
            w.eq(Student::getClassName, className);
        }
        if (StringUtils.hasText(college)) {
            w.eq(Student::getCollege, college);
        }
        if (status != null) {
            w.eq(Student::getStatus, status);
        }
        w.orderByDesc(Student::getId);
        List<Student> list = studentMapper.selectList(w);

        List<StudentExcelModel> excelModels = new ArrayList<>(list.size());
        for (Student s : list) {
            StudentExcelModel m = new StudentExcelModel();
            m.setStudentNo(s.getStudentNo());
            m.setName(s.getName());
            m.setGender(s.getGender() == 1 ? "男" : "女");
            m.setCollege(s.getCollege());
            m.setMajor(s.getMajor());
            m.setClassName(s.getClassName());
            m.setGrade(s.getGrade());
            m.setEmergencyContact(s.getEmergencyContact());
            m.setEmergencyPhone(s.getEmergencyPhone());
            m.setEnrollDate(s.getEnrollDate() != null ? s.getEnrollDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) : null);

            // 查 sys_user 拿学生本人的手机号
            SysUser u = sysUserMapper.selectById(s.getUserId());
            m.setPhone(u != null ? u.getPhone() : null);

            excelModels.add(m);
        }

        // 写入 HttpServletResponse
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        String fileName = URLEncoder.encode("学生档案列表", StandardCharsets.UTF_8).replaceAll("\\+", "%20");
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");

        EasyExcel.write(response.getOutputStream(), StudentExcelModel.class)
                .sheet("学生档案数据")
                .doWrite(excelModels);
    }
}
