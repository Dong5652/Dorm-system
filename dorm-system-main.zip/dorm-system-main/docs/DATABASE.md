# 学校宿舍管理系统 — 数据库 ER 设计

> 版本: v1.0
> 技术栈: Spring Boot 3 (JDK 17) + MySQL 8 + MyBatis-Plus
> 约定: 表名小写下划线、字段小写下划线,主键统一 `id` BIGINT 自增,时间统一 `DATETIME` 默认 `CURRENT_TIMESTAMP`,软删除用 `is_deleted` TINYINT (0未删/1已删)

---

## 一、ER 总览图

```
┌──────────────┐       ┌──────────────┐       ┌──────────────┐
│  building    │◀──────│    floor     │◀──────│    room      │
│  楼栋         │  1:N  │   楼层        │  1:N  │   房间        │
└──────┬───────┘       └──────────────┘       └──────┬───────┘
       │                                              │ 1:N
       │ gender 字段做性别                             │
       │ 硬约束                                        ▼
       │                                      ┌──────────────┐
       │                                      │    bed       │
       │                                      │   床位        │
       │                                      └──────┬───────┘
       │                                             │ 1:1 (当前入住)
       │                                             ▼
       │  ┌──────────────────────────────────────────────────┐
       │  │                  student                        │
       │  │  学号、姓名、性别、专业、班级、当前床位号          │
       │  └────────────┬─────────────────────────────────────┘
       │               │
       │               │ 1:N
       │               ▼
       │       ┌──────────────────┐     ┌──────────────────┐
       │       │ check_in_record  │     │  change_record   │
       │       │  入住/退宿流水    │     │  异动记录         │
       │       └──────────────────┘     └──────────────────┘
       │
       │ (宿管和管理员也挂在 sys_user,通过 building_id 限定管辖楼栋)
       │
       ▼
┌──────────────┐
│  sys_user    │ 学生/宿管/管理员/维修师傅统一在这里
│  系统用户     │ role 枚举区分
└──────┬───────┘
       │
       ├─────► announcement       公告
       ├─────► notice_message     站内消息
       ├─────► repair_order       报修单 (含维修师傅分配)
       ├─────► visitor            访客登记
       ├─────► safety_inspection  违禁品检查
       ├─────► safety_event       安全事件
       └─────► operation_log      操作日志

┌──────────────┐      ┌──────────────┐      ┌──────────────┐
│ hygiene_check│      │ attendance   │      │ dorm_score   │
│ 卫生检查      │      │ 晚归考勤      │      │  寝室评分     │
└──────┬───────┘      └──────┬───────┘      └──────────────┘
       │ 多对一 room         │ 多对一 student
       └────────────────────┘
            月度汇总到 dorm_score

┌──────────────┐      ┌──────────────┐      ┌──────────────┐
│meter_reading │─────►│    fee       │─────►│   payment    │
│ 每月抄表      │ 1:N  │  费用账单      │ 1:N  │  缴费记录     │
└──────────────┘      └──────────────┘      └──────────────┘
```

---

## 二、核心实体表

### 2.1 组织与宿舍结构

#### building 楼栋表
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| code | VARCHAR(20) | 楼栋编号,如 `7B`,唯一 |
| name | VARCHAR(50) | 楼栋名称,如 `7号B楼` |
| gender | TINYINT | 1男 2女 3混合(混合仅管理员允许,分配算法默认拒绝跨性别) |
| floor_count | INT | 楼层数 |
| manager_id | BIGINT NULL | 管理该楼栋的宿管 user_id(FK sys_user) |
| remark | VARCHAR(200) | 备注 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| UNIQUE | (code) |  |

#### floor 楼层表
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| building_id | BIGINT | FK building |
| floor_no | INT | 楼层号,如 `3` |
| room_count | INT | 该层房间数 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| UNIQUE | (building_id, floor_no) |  |

#### room 房间表
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| building_id | BIGINT | FK building |
| floor_id | BIGINT | FK floor |
| room_no | VARCHAR(10) | 房间号,如 `302` |
| capacity | INT | 额定床位数 |
| occupied_count | INT | 已入住数(冗余字段,便于查询空置率) |
| status | TINYINT | 0空闲 1部分入住 2满员 3维修中 4锁定预留 |
| remark | VARCHAR(200) | 备注 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| UNIQUE | (building_id, room_no) |  |

#### bed 床位表
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| room_id | BIGINT | FK room |
| bed_no | VARCHAR(10) | 床位号,如 `1` `2` |
| student_id | BIGINT NULL | 当前入住学生(FK student),空表示空闲 |
| status | TINYINT | 0空闲 1已占用 2维修中 3预留 |
| check_in_time | DATETIME NULL | 当前入住开始时间 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| UNIQUE | (room_id, bed_no) |  |

### 2.2 学生与系统用户

#### sys_user 系统用户表
> 学生 / 宿管 / 管理员 / 维修师傅 都在这张表,通过 `role` 区分

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| username | VARCHAR(50) | 登录账号(学生用学号,宿管用工号) |
| password | VARCHAR(100) | BCrypt 加密密码 |
| real_name | VARCHAR(50) | 真实姓名 |
| role | VARCHAR(20) | `student` / `dorm_manager` / `admin` / `repairman` |
| gender | TINYINT | 1男 2女 |
| phone | VARCHAR(20) NULL | 联系电话 |
| building_id | BIGINT NULL | 宿管:管辖楼栋;维修师傅:无;学生:无 |
| work_type | VARCHAR(50) NULL | 维修师傅工种,如 `水电` `木工` `综合` |
| status | TINYINT | 0禁用 1启用 |
| last_login_at | DATETIME NULL | 最近登录时间 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| UNIQUE | (username) |  |

#### student 学生档案表
> 学生除学籍信息外的扩展字段,登录账号仍在 sys_user

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| user_id | BIGINT | FK sys_user.id |
| student_no | VARCHAR(20) | 学号,唯一(与 username 同值,冗余便于查询) |
| name | VARCHAR(50) | 姓名(冗余 sys_user.real_name) |
| gender | TINYINT | 性别(冗余,与 sys_user 一致) |
| college | VARCHAR(50) | 学院 |
| major | VARCHAR(50) | 专业 |
| class_name | VARCHAR(50) | 班级 |
| grade | VARCHAR(10) | 年级,如 `2024` |
| current_bed_id | BIGINT NULL | 当前床位号(FK bed),空表示未分配 |
| emergency_contact | VARCHAR(50) | 紧急联系人 |
| emergency_phone | VARCHAR(20) | 紧急联系电话 |
| enroll_date | DATE | 入学日期 |
| status | TINYINT | 0在籍 1休学 2毕业 3退学 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| UNIQUE | (student_no) |  |

### 2.3 入住与异动

#### check_in_record 入住/退宿流水
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| student_id | BIGINT | FK student |
| bed_id | BIGINT | FK bed |
| type | TINYINT | 1入住 2退宿 |
| operator_id | BIGINT | 经办人(FK sys_user,通常为宿管) |
| key_issued | TINYINT | 是否发放钥匙 0否1是 |
| key_returned | TINYINT | 是否收回钥匙 0否1是(退宿时) |
| facility_check | VARCHAR(500) | 设施清点备注 |
| remark | VARCHAR(500) | 备注 |
| happened_at | DATETIME | 发生时间 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |

#### change_record 异动记录
> 休学、转专业调宿、假期离校等位置/状态变更

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| student_id | BIGINT | FK student |
| type | VARCHAR(20) | `suspend`(休学) / `transfer`(转专业) / `change_room`(调宿) / `holiday_leave`(假期离校) |
| from_bed_id | BIGINT NULL | 原床位(调宿时) |
| to_bed_id | BIGINT NULL | 新床位(调宿时) |
| reason | VARCHAR(500) | 异动原因 |
| operator_id | BIGINT | 经办人(FK sys_user) |
| happened_at | DATETIME | 发生时间 |
| remark | VARCHAR(500) | 备注 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |

### 2.4 卫生与考勤

#### hygiene_check 卫生检查
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| room_id | BIGINT | FK room |
| check_date | DATE | 检查日期 |
| inspector_id | BIGINT | 检查人(FK sys_user,宿管) |
| score | DECIMAL(5,2) | 本次得分(0–100) |
| deduction | DECIMAL(5,2) | 扣分合计 |
| bonus | DECIMAL(5,2) | 加分合计 |
| photo_url | VARCHAR(500) NULL | 现场照片 |
| item_detail | TEXT NULL | 扣分/加分项明细(JSON,如 `[{"item":"地面","type":"deduct","value":2}]`) |
| remark | VARCHAR(500) | 备注 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| INDEX | (room_id, check_date) |  |

#### attendance 晚归考勤
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| student_id | BIGINT | FK student |
| room_id | BIGINT | FK room(冗余,通过 bed 反查) |
| record_date | DATE | 记录日期 |
| type | TINYINT | 1晚归 2未归 3请假 |
| return_time | DATETIME NULL | 实际归寝时间(晚归时) |
| inspector_id | BIGINT | 记录人(FK sys_user) |
| remark | VARCHAR(500) | 备注 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| INDEX | (student_id, record_date) |  |

#### dorm_score 寝室综合评分
> 按月汇总,管理员或系统定时任务生成

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| room_id | BIGINT | FK room |
| year_month | VARCHAR(7) | 评分月份,如 `2026-03` |
| hygiene_avg | DECIMAL(5,2) | 该月卫生平均分 |
| late_count | INT | 该月晚归/未归次数 |
| total_score | DECIMAL(6,2) | 综合评分(卫生×0.6 + (100–晚归次数×5)×0.4) |
| level | VARCHAR(10) | `优秀` / `合格` / `待整改` / `不合格` |
| remark | VARCHAR(500) | 评语 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| UNIQUE | (room_id, year_month) |  |

### 2.5 维修管理

#### repair_order 报修单
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| order_no | VARCHAR(30) | 单号,如 `RP202603050001`,唯一 |
| room_id | BIGINT | FK room |
| bed_id | BIGINT NULL | 具体床位(可空) |
| reporter_id | BIGINT | 报修人(FK sys_user,学生或宿管) |
| title | VARCHAR(100) | 报修标题 |
| description | TEXT | 故障描述 |
| photo_url | VARCHAR(500) NULL | 现场照片 |
| status | TINYINT | 0待派单 1已派单 2维修中 3已完成 4已取消 |
| priority | TINYINT | 0普通 1紧急 2非常紧急 |
| repairman_id | BIGINT NULL | 分派维修师傅(FK sys_user) |
| assigned_at | DATETIME NULL | 派单时间 |
| assigned_by | BIGINT NULL | 派单人(FK sys_user,管理员) |
| started_at | DATETIME NULL | 开始维修时间 |
| finished_at | DATETIME NULL | 完成时间 |
| completion_note | TEXT NULL | 维修说明 |
| rating | TINYINT NULL | 学生评价 1–5 星 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| INDEX | (status, repairman_id) |  |

### 2.6 访客与安全

#### visitor 访客登记
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| visitor_name | VARCHAR(50) | 访客姓名 |
| id_card | VARCHAR(20) | 身份证号 |
| phone | VARCHAR(20) NULL | 联系电话 |
| visit_target_id | BIGINT NULL | 被访学生(FK student) |
| building_id | BIGINT | 进入楼栋(FK building) |
| purpose | VARCHAR(200) | 来访目的 |
| enter_time | DATETIME | 进入时间 |
| exit_time | DATETIME NULL | 离开时间(未登记表示仍在内) |
| register_by | BIGINT | 登记人(FK sys_user,宿管) |
| remark | VARCHAR(500) | 备注 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| INDEX | (building_id, enter_time) |  |

#### safety_inspection 违禁品检查
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| room_id | BIGINT | FK room |
| student_id | BIGINT NULL | 相关学生(可空,只针对寝室) |
| inspect_date | DATE | 检查日期 |
| inspector_id | BIGINT | 检查人(FK sys_user) |
| item_type | VARCHAR(50) | 违禁类型,如 `大功率电器` `管制刀具` |
| item_desc | VARCHAR(200) | 物品描述 |
| photo_url | VARCHAR(500) NULL | 查获照片 |
| disposition | VARCHAR(20) | `没收保管` / `限期带离` / `通报批评` |
| notice_sent | TINYINT | 是否已发整改通知 0否1是 |
| remark | VARCHAR(500) | 备注 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |

#### safety_event 安全事件
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| building_id | BIGINT | FK building |
| room_id | BIGINT NULL | FK room(可空,楼栋公共事件) |
| event_type | VARCHAR(30) | `火情` `设施失控` `人员异常` `其它` |
| severity | TINYINT | 0一般 1较重 2严重 |
| description | TEXT | 事件描述 |
| photo_url | VARCHAR(500) NULL | 现场照片 |
| reported_by | BIGINT | 上报人(FK sys_user) |
| handled | TINYINT | 0待处理 1已处理 |
| handle_note | TEXT NULL | 处置说明 |
| happened_at | DATETIME | 事件发生时间 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| INDEX | (building_id, happened_at) |  |

### 2.7 费用与公告

#### fee 费用账单表
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| student_id | BIGINT | FK student |
| fee_type | VARCHAR(20) | `accommodation`(住宿费) / `utility`(水电费) |
| year_month | VARCHAR(7) NULL | 账期,水电费按月如 `2026-03`;住宿费按学期留空 |
| semester | VARCHAR(20) NULL | 住宿费归口学期,如 `2025-2026-1` |
| amount | DECIMAL(10,2) | 应缴金额 |
| paid_amount | DECIMAL(10,2) | 已缴金额,冗余字段 |
| paid_status | TINYINT | 0未缴 1部分缴费 2已缴清 |
| due_date | DATE | 缴费截止日 |
| remark | VARCHAR(200) | 备注 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| INDEX | (student_id, fee_type, year_month) |  |

#### meter_reading 每月抄表记录
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| room_id | BIGINT | FK room |
| meter_type | TINYINT | 1水表 2电表 |
| reading_value | DECIMAL(12,2) | 本次抄表读数 |
| previous_value | DECIMAL(12,2) | 上次读数,冗余便于直接算差值 |
| usage_amount | DECIMAL(12,2) | 本月用量 = reading − previous |
| unit_price | DECIMAL(8,4) | 单价,冗余(费率可调时保留历史) |
| amount | DECIMAL(10,2) | 本月费用 = usage × unit_price |
| reading_month | VARCHAR(7) | 抄表月份,如 `2026-03` |
| reader_id | BIGINT | 抄表人(FK sys_user,宿管或管理员) |
| remark | VARCHAR(200) | 备注 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| UNIQUE | (room_id, meter_type, reading_month) |  |

> 设计说明:抄表后由系统/管理员根据 `meter_reading` 汇总生成 `fee`(utility 类型)。`fee` 与 `meter_reading` 是 1:N(一笔水电费账单对应当月水表+电表两条抄表记录,可在 fee 增设 `water_reading_id` `electric_reading_id` 两列建立关联,这里用 N 端聚合,不建反向外键以简化模型)。

#### payment 缴费记录
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| fee_id | BIGINT | FK fee |
| student_id | BIGINT | FK student |
| amount | DECIMAL(10,2) | 本次实缴金额 |
| pay_type | TINYINT | 1现金 2微信 3支付宝 4银行转账 |
| pay_time | DATETIME | 缴费时间 |
| operator_id | BIGINT | 收款人(FK sys_user) |
| pay_no | VARCHAR(50) NULL | 第三方流水号 |
| remark | VARCHAR(200) | 备注 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| INDEX | (fee_id) |  |

#### announcement 公告表
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| title | VARCHAR(200) | 公告标题 |
| content | TEXT | 公告正文 |
| scope | TINYINT | 0全校 1指定楼栋 2指定寝室 3指定学生 |
| building_id | BIGINT NULL | scope=1 时生效 |
| target_room_id | BIGINT NULL | scope=2 时生效：目标寝室 |
| target_student_id | BIGINT NULL | scope=3 时生效：目标学生 |
| publish_by | BIGINT | 发布人(FK sys_user) |
| publish_time | DATETIME | 发布时间 |
| is_pinned | TINYINT | 0否 1置顶 |
| expire_time | DATETIME NULL | 过期时间(可空) |
| status | TINYINT | 0草稿 1已发布 2已下架 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |

#### notice_message 站内消息
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| to_user_id | BIGINT | 接收人(FK sys_user) |
| from_user_id | BIGINT NULL | 发送人(FK sys_user),空表示系统消息 |
| title | VARCHAR(200) | 消息标题 |
| content | TEXT | 消息内容 |
| msg_type | VARCHAR(20) | `fee`(催缴) `rectify`(整改) `notice`(通知) `system` |
| ref_id | BIGINT NULL | 关联业务对象 ID(如相关 fee / safety_inspection) |
| is_read | TINYINT | 0未读 1已读 |
| read_time | DATETIME NULL | 阅读时间 |
| created_at | DATETIME | 创建时间 |
| is_deleted | TINYINT | 软删除 |
| INDEX | (to_user_id, is_read) |  |

#### operation_log 操作日志
> 全局记录敏感操作(改卫生分、改缴费状态、删学生等),便于审计

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 主键 |
| operator_id | BIGINT | 操作人(FK sys_user) |
| module | VARCHAR(30) | 模块名,如 `student` `fee` `hygiene` |
| action | VARCHAR(30) | 操作类型,如 `insert` `update` `delete` `login` |
| target_table | VARCHAR(50) | 操作表名 |
| target_id | BIGINT NULL | 操作记录主键 |
| detail | TEXT NULL | 变更明细(JSON,如旧值/新值对比) |
| ip | VARCHAR(50) | 操作 IP |
| created_at | DATETIME | 创建时间 |
| INDEX | (operator_id, created_at) |  |

---

## 三、实体关系总览

| 主表 | 关联表 | 关系 | 关键外键 |
|------|--------|------|----------|
| sys_user | building | N:1 | building.manager_id → sys_user(宿管) |
| building | floor | 1:N | floor.building_id |
| floor | room | 1:N | room.floor_id |
| room | bed | 1:N | bed.room_id |
| bed | student | 1:1 | bed.student_id(当前入住) |
| sys_user | student | 1:1 | student.user_id |
| student | check_in_record | 1:N | check_in_record.student_id |
| room | hygiene_check | 1:N | hygiene_check.room_id |
| student | attendance | 1:N | attendance.student_id |
| room | dorm_score | 1:N | dorm_score.room_id |
| room | repair_order | 1:N | repair_order.room_id |
| sys_user(repairman) | repair_order | 1:N | repair_order.repairman_id |
| building | visitor | 1:N | visitor.building_id |
| room | safety_inspection | 1:N | safety_inspection.room_id |
| student | fee | 1:N | fee.student_id |
| room | meter_reading | 1:N | meter_reading.room_id |
| fee | payment | 1:N | payment.fee_id |

---

## 四、关键索引清单

| 表 | 索引 | 用途 |
|------|------|------|
| student | UNIQUE(student_no) | 学号唯一 |
| sys_user | UNIQUE(username) | 登录名唯一 |
| bed | UNIQUE(room_id, bed_no) | 同房间床位号唯一 |
| room | UNIQUE(building_id, room_no) | 同楼栋房间号唯一 |
| floor | UNIQUE(building_id, floor_no) | 同楼栋楼层号唯一 |
| meter_reading | UNIQUE(room_id, meter_type, reading_month) | 防止同月重复抄表 |
| dorm_score | UNIQUE(room_id, year_month) | 每月每寝室一条评分 |
| attendance | INDEX(student_id, record_date) | 按学生查考勤 |
| repair_order | INDEX(status, repairman_id) | 师傅查看自己派单 |
| notice_message | INDEX(to_user_id, is_read) | 拉取未读消息 |
| operation_log | INDEX(operator_id, created_at) | 审计按人查 |

---

## 五、关键业务规则

1. **床位分配算法硬约束**:从 `building.gender` 出发,学生性别必须等于该楼栋 gender(混合楼栋放开但默认禁止跨性别同寝),`bed.status` 必须为「空闲」。分配成功后 `bed.student_id` 写入、`bed.status=1`、`room.occupied_count++`,满员时 `room.status=2`。

2. **退宿释放床位**:`check_in_record` 增一条 type=2,`bed.student_id` 清空、`bed.status=0`、`room.occupied_count--`、`student.current_bed_id` 置空。床位可用后下次批量退宿/分配才能复用。

3. **水电费闭环**:宿管每月抄表 → `meter_reading` 写入 → 系统按楼栋费率生成 `fee`(type=utility) → 学生缴费写 `payment` → 后台任务回写 `fee.paid_status`。

4. **寝室评分**:`dorm_score` 由定时任务每月 1 号生成,读 `hygiene_check`(当月该房所有检查取平均) + `attendance`(统计当月晚归/未归次数) → 算 `total_score` → 映射 `level`。

5. **维修工单流转**:学生报修 → status=0 → 管理员派单到 `sys_user.role=repairman` → status=1 → 师傅接单修 → status=2 → 师傅完工填 `completion_note` → status=3 → 学生评分 `rating`。

6. **角色权限边界**:宿管(`dorm_manager`)只能看/操作自己 `building_id` 范围内的学生、考勤、维修、访客;管理员(`admin`)全权;学生(`student`)仅看本人;师傅(`repairman`)仅看自己 `repairman_id` 的工单。

7. **软删除**:所有业务表带 `is_deleted`,查询统一过滤 `is_deleted=0`,避免误删数据丢失。

---

## 六、数据字典(枚举汇总)

| 字段 | 取值 |
|------|------|
| sys_user.role | student / dorm_manager / admin / repairman |
| sys_user.gender | 1男 2女 |
| building.gender | 1男 2女 3混合 |
| room.status | 0空闲 1部分入住 2满员 3维修中 4锁定预留 |
| bed.status | 0空闲 1已占用 2维修中 3预留 |
| student.status | 0在籍 1休学 2毕业 3退学 |
| check_in_record.type | 1入住 2退宿 |
| attendance.type | 1晚归 2未归 3请假 |
| repair_order.status | 0待派单 1已派单 2维修中 3已完成 4已取消 |
| repair_order.priority | 0普通 1紧急 2非常紧急 |
| fee.fee_type | accommodation / utility |
| fee.paid_status | 0未缴 1部分缴费 2已缴清 |
| safety_event.severity | 0一般 1较重 2严重 |
| announcement.scope | 0全校 1楼栋 2寝室 3学生 |
| announcement.status | 0草稿 1已发布 2已下架 |
| notice_message.msg_type | fee / rectify / notice / system |

---

## 七、初始数据(开发用)

```sql
-- 管理员
INSERT INTO sys_user (username, password, real_name, role, gender, status)
VALUES ('admin', '$2a$10$...BCrypt...', '超管', 'admin', 1, 1);

-- 一栋男生楼 + 一栋女生楼
INSERT INTO building (code, name, gender, floor_count) VALUES
  ('7B', '7号B楼', 1, 6),
  ('8A', '8号A楼', 2, 6);

-- 一个维修师傅
INSERT INTO sys_user (username, password, real_name, role, work_type, status)
VALUES ('repair001', '$2a$10$...', '王师傅', 'repairman', '水电', 1);

-- 一个月度水电抄表(示例)
INSERT INTO meter_reading
  (room_id, meter_type, reading_value, previous_value, usage_amount, unit_price, amount, reading_month, reader_id)
VALUES
  (1, 1, 120.50, 100.00, 20.50, 3.5000, 71.75, '2026-03', 1);
```

> 完整建表 DDL 与种子数据生成脚本(楼栋/楼层/房间/床位批量插入)放在 `db/init.sql`,导入 MySQL 即可起跑。

---

## 八、后续衔接

这份文档定下来后,下一步可以直接产出:

1. **`docs/DEVELOPMENT_PLAN.md`** —— 9 个阶段开发计划,每阶段附验收 checkbox。
2. **`docs/API_SPEC.md`** —— REST 接口清单,按 8 大模块分组,统一 `/api/v1/...` 前缀。
3. **`db/init.sql`** —— 建表 DDL + 索引 + 初始数据。
