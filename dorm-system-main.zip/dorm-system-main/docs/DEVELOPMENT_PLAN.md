# 学校宿舍管理系统 — 开发阶段规划

> 基于 [DATABASE.md](./DATABASE.md) 制定
> 技术栈: Vue 3 + Spring Boot 3 (JDK 17) + MySQL 8 + MyBatis-Plus + Spring Security + JWT
> 每个阶段完成并验收通过后,必须立即进行 Git 本地存档

---

## 开发规则

1. **每阶段验收通过后立即 `git add . && git commit`**,确保每个阶段都是独立的、可回滚的存档点
2. 严格按照本文档中各阶段的验收标准进行验证,全部通过后才算完成
3. 开发过程中如遇到需要调整数据库设计的地方,及时更新 `docs/DATABASE.md`
4. Git 提交信息使用 Conventional Commits 格式(`feat:` / `fix:` / `chore:` / `test:` / `docs:` / `refactor:`)
5. 提交前确保 `mvn clean compile` 编译通过且单元测试无报错

---

## 阶段依赖关系

```
阶段1 (脚手架+数据库)
  └→ 阶段2 (用户与权限)
       ├→ 阶段3 (宿舍基础数据) ──┐
       │                          ├→ 阶段5 (入住退宿)
       │                          │
       └→ 阶段4 (学生档案)   ─────┘
                                    └→ 阶段6 (卫生考勤)
                                         │
                                         ├→ 阶段7 (维修)
                                         │
                                         ├→ 阶段8 (访客安全)
                                         │
                                         ├→ 阶段9 (费用公告)
                                         │
                                         └→ 阶段10 (统计+日志+收尾)
```

**并行可能性:**
- 阶段 3、4 在阶段 2 完成后可并行开发
- 阶段 6、7、8、9 在阶段 5 完成后可并行开发

---

## 阶段 1:项目脚手架与数据库初始化

**目标:** 搭建前后端骨架,数据库表结构就绪,Hello World 跑通。

| 任务 | 具体内容 |
|------|---------|
| 1.1 后端脚手架 | Spring Initializr 生成 `dorm-system-backend/`,JDK 17,引入 spring-boot-starter-web / mybatis-plus / mysql / spring-security / jjwt / lombok / validation |
| 1.2 前端脚手架 | `npm create vue@latest` 生成 `dorm-system-frontend/`,Vue 3 + TS + Vite + Vue Router + Pinia + Element Plus + axios + ECharts |
| 1.3 数据库初始化 | 按 `DATABASE.md` 编写 `db/init.sql`,建 17 张表 + 索引 + 初始管理员账号,导入 MySQL 跑通 |
| 1.4 配置文件 | 后端 `application.yml`(数据源、MyBatis-Plus、JWT 密钥)、前端 `.env`(VITE_API_BASE_URL)、跨域配置 |
| 1.5 全局异常处理 | 后端 `GlobalExceptionHandler` 统一封装 `{code, message, data}` 响应体 |
| 1.6 联调验证 | 前端 axios 请求后端 `/api/v1/ping` 返回 `pong`,前后端通 |

### 验收标准

- [ ] `mvn clean compile` 编译通过
- [ ] `mvn spring-boot:run` 启动成功,监听 8080 端口
- [ ] `npm run dev` 启动 Vite 开发服务器,访问 `localhost:5174` 显示首页
- [ ] MySQL 中执行 `db/init.sql` 无报错,17 张表全部建成
- [ ] `curl http://localhost:8080/api/v1/ping` 返回 `{"code":0,"data":"pong"}`
- [ ] Git 提交:`chore: init scaffold and database schema`

---

## 阶段 2:用户认证与权限模块

**目标:** 实现登录登出、JWT 鉴权、基于角色的接口权限控制。

| 任务 | 具体内容 |
|------|---------|
| 2.1 SysUser 实体与 Mapper | `SysUser` 实体 + `SysUserMapper extends BaseMapper` |
| 2.2 登录接口 | `POST /api/v1/auth/login`,校验 username/password(BCrypt),签发 JWT |
| 2.3 登出接口 | `POST /api/v1/auth/logout`,前端清 token 即可(JWT 无状态,后端可选维护黑名单) |
| 2.4 当前用户 | `GET /api/v1/auth/me`,根据 token 返回当前登录用户信息与角色 |
| 2.5 JWT 拦截器 | `JwtAuthenticationFilter` 解析 Bearer token,注入 `SecurityContext` |
| 2.6 角色权限 | `@PreAuthorize("hasRole('ADMIN')")` 注解或自定义 `@HasRole` 切面控制接口访问 |
| 2.7 密码加密 | `BCryptPasswordEncoder` 配置为 Bean |
| 2.8 前端登录页 | `LoginView.vue` 用户名密码表单,登录后存 token 到 Pinia + localStorage |
| 2.9 axios 拦截器 | 请求自动带 `Authorization`,401 自动跳登录页 |
| 2.10 路由守卫 | Vue Router `beforeEach` 校验 token,未登录跳 `/login` |

### 验收标准

- [x] 用初始 admin 账号登录返回有效 JWT
- [x] 错误密码返回 401 + 友好错误信息
- [x] 带 token 请求 `/api/v1/auth/me` 返回当前用户
- [x] 不带 token 访问受保护接口返回 401
- [x] 学生角色 token 访问 `/api/v1/admin/**` 接口返回 403
- [x] 前端登录流程跑通,token 存 localStorage,F5 刷新仍保持登录
- [x] Git 提交:`feat: auth module with JWT`

---

## 阶段 3:宿舍基础数据模块

**目标:** 楼栋 / 楼层 / 房间 / 床位四层结构的 CRUD 与树形查询,床位状态机就绪。

| 任务 | 具体内容 |
|------|---------|
| 3.1 实体与 Mapper | `Building` / `Floor` / `Room` / `Bed` 四个实体 + Mapper |
| 3.2 楼栋管理 | `GET/POST/PUT/DELETE /api/v1/admin/buildings`,含按性别分楼、绑定宿管 |
| 3.3 楼层管理 | `GET/POST/PUT/DELETE /api/v1/admin/floors` |
| 3.4 房间管理 | `GET/POST/PUT/DELETE /api/v1/admin/rooms`,含状态修改(维修中 / 锁定预留) |
| 3.5 床位管理 | `GET/POST/PUT/DELETE /api/v1/admin/beds`,改动时联动维护 `room.occupied_count` 与 `room.status` |
| 3.6 树形查询 | `GET /api/v1/dorm/tree` 返回楼栋→楼层→房间→床位的级联数据,供前端 Selector |
| 3.7 空置统计 | `GET /api/v1/dorm/vacancy` 按楼栋返回空闲床位数 / 入住率 |
| 3.8 前端页面 | `BuildingManagerView.vue`:楼栋 CRUD + 楼层/房间/床位级联管理界面 |
| 3.9 级联选择器 | 封装 `DormSelector.vue`(楼栋→楼层→房间→床位)供后续模块复用 |

### 验收标准

- [x] 新增楼栋后楼层数自动写入
- [x] 床位状态变更后房间 `occupied_count` 与 `status` 同步刷新
- [x] 满员房间 `status` 自动变为 2(满员),释放一张床位后变回 1(部分入住)
- [x] 树形查询接口返回完整级联 JSON
- [x] 前端级联选择器工作正常
- [x] 仅管理员可调用上述接口(宿管只能查本人楼栋)
- [x] Git 提交:`feat: dorm structure module`

---

## 阶段 4:学生档案模块

**目标:** 学生档案 CRUD,新生批量导入,与 sys_user 联动建账号。

| 任务 | 具体内容 |
|------|---------|
| 4.1 实体与 Mapper | `Student` 实体 + `StudentMapper` |
| 4.2 学生 CRUD | `GET/POST/PUT/DELETE /api/v1/admin/students`,支持按学号/姓名/班级/学院多条件分页查询 |
| 4.3 账号联动 | 新增学生时自动创建 `sys_user(role=student, username=学号, password=默认)`,删除学生时同步删除账号(软删除) |
| 4.4 批量导入 | `POST /api/v1/admin/students/import`,上传 Excel(Alibaba EasyExcel),逐行建学生账号 |
| 4.5 导出 | `GET /api/v1/admin/students/export`,导出当前查询结果为 Excel |
| 4.6 前端页面 | `StudentManagerView.vue`:列表 + 筛选 + 增改弹窗 + 批量导入按钮 + 导出按钮 |
| 4.7 学生详情 | `GET /api/v1/admin/students/{id}` 返回学生档案 + 当前床位 + 历史异动 |

### 验收标准

- [x] 新增学生后 sys_user 同步生成一条 role=student 记录
- [x] Excel 批量导入 100 条学生数据无报错,失败行有错误提示
- [x] 分页查询支持按学号模糊检索
- [x] 导出 Excel 列完整(学号/姓名/性别/学院/专业/班级/年级/联系电话/紧急联系人)
- [x] 删除学生触发 sys_user 软删除
- [x] Git 提交:`feat: student profile module with batch import`

---

## 阶段 5:入住退宿与异动模块

**目标:** 床位分配的核心业务闭环——入住、调宿、退宿全流程打通。

| 任务 | 具体内容 |
|------|---------|
| 5.1 入住流程 | `POST /api/v1/dorm/check-in`:选空闲床位 → 写 bed.student_id → bed.status=1 → room.occupied_count++ → 触发 room.status 流转 → 写 check_in_record(type=1) → 更新 student.current_bed_id |
| 5.2 批量分配 | `POST /api/v1/admin/students/{id}/auto-assign`:按楼栋性别硬约束,从空闲床位中选一张分配给学生 |
| 5.3 退宿流程 | `POST /api/v1/dorm/check-out`:校验 bed.student_id 一致 → 清空 bed → room.occupied_count-- → 写 check_in_record(type=2) → student.current_bed_id 置空 |
| 5.4 调宿流程 | `POST /api/v1/dorm/change-room`:旧床位释放 + 新床位占用,写 change_record(type=change_room),同时维护 from_bed_id / to_bed_id |
| 5.5 异动登记 | `POST /api/v1/dorm/change`:登记休学/转专业/假期离校,写 change_record,休学/退学同时把学生状态置位 |
| 5.6 批量退宿 | `POST /api/v1/admin/check-out/batch`:毕业季按年级/班级批量退宿,逐条事务保证 |
| 5.7 流水查询 | `GET /api/v1/dorm/records`:入住/退宿/异动流水,按学生或房间或时间范围检索 |
| 5.8 前端页面 | `CheckInOutView.vue`:入住登记表单、退宿按钮、调宿向导、异动流水查询 |
| 5.9 床位可视化 | `RoomBedView.vue`:点选房间后可视化显示 4 个床位状态(空闲/已占/维修/预留),点击空闲床位直接办理入住 |

### 验收标准

- [x] 入住一张床位后,bed.status=1,room.occupied_count 准确,check_in_record 写入一条 type=1
- [x] 男生分配到女生楼栋被拒绝,返回明确错误
- [x] 分配到已占用床位被拒绝
- [x] 退宿后床位变为空闲,可被再次分配
- [x] 调宿后 old bed 与 new bed 状态分别正确,change_record 含 from/to
- [x] 批量退宿 N 个学生,数据一致性检查通过(每张床都被释放,无悬挂 student.current_bed_id)
- [x] 前端床位可视化页面直观显示状态与入住操作入口
- [x] Git 提交:`feat: check-in/check-out and change-record flow`

---

## 阶段 6:卫生与考勤模块

**目标:** 宿管日常录入卫生检查、晚归考勤,系统按月汇总寝室评分。

| 任务 | 具体内容 |
|------|---------|
| 6.1 卫生检查 | `POST /api/v1/dorm/hygiene`:宿管录入卫生得分,扣分/加分项以 JSON 存 item_detail |
| 6.2 卫生查询 | `GET /api/v1/dorm/hygiene`:按房间/日期范围查询历史检查记录 |
| 6.3 晚归登记 | `POST /api/v1/dorm/attendance`:宿管登记晚归/未归/请假 |
| 6.4 考勤查询 | `GET /api/v1/dorm/attendance`:按学生/日期查询 |
| 6.5 月度评分 | `@Scheduled` 定时任务每月 1 凌晨 1 点跑,生成上月的 `dorm_score` |
| 6.6 评分查看 | `GET /api/v1/dorm/scores`:按月/楼栋/寝室查询寝室综合评分及排名 |
| 6.7 评分补录 | `POST /api/v1/admin/dorm/scores/manual`:允许管理员手动调整某寝室某月评分(留操作日志) |
| 6.8 前端页面 | `HygieneView.vue`(卫生检查录入 + 历史)、`AttendanceView.vue`(晚归登记 + 查询)、`DormScoreView.vue`(评分排行榜) |

### 验收标准

- [x] 宿管只能录入/查询自己 building_id 范围内的记录
- [x] 学生查询自己寝室的卫生历史记录正常
- [x] 卫生得分 SUM 计算正确(score = 100 + bonus − deduction)
- [x] 月度评分任务手动触发一次,生成的 dorm_score 含 hygiene_avg / late_count / total_score / level
- [x] 评分公式按 `total_score = hygiene_avg × 0.6 + (100 − late_count × 5) × 0.4`
- [x] level 映射正确(≥90 优秀 / 75–89 合格 / 60–74 待整改 / <60 不合格)
- [x] Git 提交:`feat: hygiene attendance and dorm score module`

---

## 阶段 7:维修管理模块

**目标:** 学生报修 → 管理员派单 → 师傅维修 → 完工 → 学生评价闭环。

| 任务 | 具体内容 |
|------|---------|
| 7.1 报修单生成 | 学生/宿管 `POST /api/v1/repair`,生成 repair_order,order_no 按日期+序号生成,初始 status=0 |
| 7.2 派单接口 | `POST /api/v1/admin/repair/{id}/assign`:指定 repairman_id,status=0→1,写 assigned_at / assigned_by |
| 7.3 师傅接单 | `PUT /api/v1/repair/{id}/start`:师傅自己接单,status=1→2,写 started_at |
| 7.4 师傅完工 | `PUT /api/v1/repair/{id}/finish`:填 completion_note,status=2→3,写 finished_at |
| 7.5 学生评价 | `PUT /api/v1/repair/{id}/rate`:学生 1–5 星评分 |
| 7.6 取消工单 | `PUT /api/v1/repair/{id}/cancel`:学生或管理员取消,status=4 |
| 7.7 列表查询 | `GET /api/v1/repair`:学生看自己的、宿管看本楼栋的、师傅看自己派单、管理员全权;按状态/优先级/时间筛选 |
| 7.8 师傅管理 | `GET/POST/PUT/DELETE /api/v1/admin/repairmen`:维修师傅账号 CRUD(就是 sys_user.role=repairman),含工种 |
| 7.9 前端页面 | `RepairListView.vue`(工单列表分角色视图)、`RepairDetailView.vue`(详情 + 状态流转按钮)、`RepairmanManagerView.vue`(师傅账号管理) |

### 验收标准

- [x] 学生报修后看到自己工单 status=0
- [x] 管理员派单后工单流转到 status=1,assigned_at 写入
- [x] 维修师傅只能看到分配给自己的工单,无法看到其他师傅工单
- [x] 师傅接单后 status=2,完工后 status=3 + finished_at
- [x] 学生评价后 rating 写入,repeated rating 被拒绝
- [x] 各角色看到的列表范围符合权限规则
- [x] Git 提交:`feat: repair order workflow`

---

## 阶段 8:访客与安全模块

**目标:** 访客登记、违禁品检查、安全事件上报。

| 任务 | 具体内容 |
|------|---------|
| 8.1 访客登记 | `POST /api/v1/safety/visitor`:宿管录入访客姓名/身份证/被访学生/进入时间,生成 visitor 记录 |
| 8.2 访客离开 | `PUT /api/v1/safety/visitor/{id}/exit`:登记离开时间 |
| 8.3 访客查询 | `GET /api/v1/safety/visitor`:按楼栋/日期/被访学生查询,支持之久未离开提醒 |
| 8.4 违禁品检查 | `POST /api/v1/safety/inspection`:宿管录入违禁品检查记录,关联房间与学生 |
| 8.5 违禁查询 | `GET /api/v1/safety/inspection`:按学生/房间/日期查历史 |
| 8.6 整改通知 | 检查录入后系统自动写一条 notice_message(msg_type=rectify)给相关学生 |
| 8.7 安全事件 | `POST /api/v1/safety/event`:宿管/管理员上报安全事件,severity 描述 |
| 8.8 事件处理 | `PUT /api/v1/admin/safety/event/{id}/handle`:管理员填 handle_note,标记 handled=1 |
| 8.9 前端页面 | `VisitorView.vue`、`SafetyInspectionView.vue`、`SafetyEventView.vue` |

### 验收标准

> 2026-07-24 代码层复验通过；API 联调与跨楼栋隔离已验证（详见 `docs/PHASE_8_9_10_VERIFICATION_REPORT.md`）。

- [x] 访客登记写入正常,身份证格式校验
- [x] 访客离开时间补登成功,不可重复离开
- [x] 违禁品检查记录关联到正确房间与学生
- [x] 录入违禁品后相关学生自动收到站内整改消息(notice_message)
- [x] 安全事件按 severity 排序展示,管理员可处理
- [x] 宿管只看自己楼栋,管理员全权
- [x] Git 提交:`5d60dd2` fix: complete phase 8-10 verification and harden fee/notice/stats

---

## 阶段 9:费用与公告模块

**目标:** 抄表 → 出账 → 缴费 → 公告 → 站内消息全链路。

| 任务 | 具体内容 |
|------|---------|
| 9.1 住宿费出账 | `POST /api/v1/admin/fee/accommodation/generate`:按学期批量生成住宿费 fee 记录 |
| 9.2 水电抄表 | `POST /api/v1/dorm/meter`:宿管录入每月水表/电表读数,系统自动算 usage_amount / amount |
| 9.3 水电出账 | `POST /api/v1/admin/fee/utility/generate`:按当月 meter_reading 汇总每个房间生成 fee |
| 9.4 缴费 | `POST /api/v1/admin/fee/{id}/pay`:管理员代收,写 payment,累计 fee.paid_amount,更新 paid_status |
| 9.5 缴费查询 | `GET /api/v1/fee`:学生看自己账单,管理员看任意学生或按缴费状态筛选 |
| 9.6 催缴消息 | `POST /api/v1/admin/fee/{id}/remind`:给欠费学生发 notice_message(msg_type=fee) |
| 9.7 公告发布 | `POST /api/v1/admin/announcement`:管理员发布,scope 控制定向(全校/楼栋/寝室/学生) |
| 9.8 公告查看 | `GET /api/v1/announcement`:按 scope 过滤当前用户可见公告 |
| 9.9 站内消息 | `GET /api/v1/notice`:用户查自己的站内消息,`PUT /api/v1/notice/{id}/read` 标记已读 |
| 9.10 消息未读数 | `GET /api/v1/notice/unread-count`:前端导航栏轮询显示红点 |
| 9.11 前端页面 | `MeterReadingView.vue`(抄表)、`FeeListView.vue`(账单 + 缴费)、`AnnouncementView.vue`(公告发布+浏览)、`NoticeView.vue`(站内消息列表) |

### 验收标准

> 2026-07-24 后端代码层 + API 联调通过；前端已实现导航栏红点轮询（浏览器视觉点验可选）。

- [x] 住宿费按学期批量出账后每个学生一条 fee
- [x] 抄表记录自动算出 usage_amount 与 amount,previous_value 取上次同房间同表读数
- [x] 缴费后 fee.paid_amount 累加,paid_status 正确流转(未缴→部分→已缴清)
- [x] 缴清后无法重复缴费
- [x] 公告按 scope 过滤正确(学生只能看到全校/自己楼栋/自己寝室/个人)
- [x] 站内消息未读数 API + 前端导航栏红点轮询已实现（催缴后 0→1，已读后 1→0 已 API 验证）
- [x] 催缴消息真实送达指定学生
- [x] Git 提交:`5d60dd2`

---

## 阶段 10:统计查询、操作日志与收尾

**目标:** 跨模块统计可视化、审计日志、文档完善、答辩就绪。

| 任务 | 具体内容 |
|------|---------|
| 10.1 入住率统计 | `GET /api/v1/stats/occupancy`:按楼栋/性别/专业/年级返回入住率与空置率,配合 ECharts 柱状图饼图 |
| 10.2 违纪记录查询 | `GET /api/v1/stats/discipline`:按学生学号或寝室检索历史卫生扣分、晚归、违禁品记录,支持时间范围筛选 |
| 10.3 报表导出 | `GET /api/v1/stats/export?type=occupancy|fee|repair|score`:一键导出对应 Excel,统一 EasyExcel 实现 |
| 10.4 操作日志 AOP | `@OperationLog` 注解 + AOP 切面,自动捕获敏感操作(modify/delete/import/pay 等)写入 operation_log |
| 10.5 日志查询 | `GET /api/v1/admin/logs`:管理员按操作人/模块/时间查询审计日志 |
| 10.6 Dashboard 仪表盘 | `DashboardView.vue`:总览卡片(学生总数/入住率/待派单维修/未读公告) + 图表区(入住率饼图 / 维修状态柱状图 / 缴费进度) |
| 10.7 README | 项目根 `README.md`,含项目介绍、技术栈、本地启动步骤、默认账号、目录结构 |
| 10.8 接口文档 | 用 SpringDoc OpenAPI 生成 Swagger UI,或导出 `docs/API_SPEC.md` |
| 10.9 全量联调 | 用初始 admin + 学生 + 宿管 + 师傅四个角色走一遍核心业务流程 |
| 10.10 安全核查 | 日志不输出明文密码与身份证、跨楼层越权接口全部返回 403、SQL 注入通过 MyBatis 参数化杜绝 |

### 验收标准

> 2026-07-24/25 后端代码层 + 核心 API 联调通过；浏览器视觉点验与更深业务链可继续补。

- [x] 入住率统计接口按楼栋/性别/专业/年级返回（图表前端联调另验）
- [x] 按学号查违纪记录返回该学生所有卫生扣分、晚归、违禁记录
- [x] 4 种报表(入住名单 / 缴费统计 / 维修账单 / 卫生考评)可一键导出 Excel
- [x] 修改/删除学生、改缴费状态、批量退宿、删除维修工单等敏感操作均产生 operation_log 记录
- [x] 管理员可查询任意操作人的操作日志
- [x] Dashboard 数据源(occupancy/repair/fee/unread) API 已通，前端 ECharts 三图已接入
- [x] README 含一键启动步骤(后端 + 前端 + MySQL)
- [x] Swagger UI 在 `http://localhost:8080/swagger-ui.html` 可访问（代码层依赖+放行已就位）
- [x] 用四个角色账号走完整业务流程无报错（含维修闭环 create→assign→start→finish→rate；缴费部分/缴清/重复拒绝）
- [x] Git 提交:`5d60dd2`（后续 nit/文档续提交）

---

## 后续可选优化方向

如下非毕设必做,留作进阶或论文"未来工作"章节:

1. **微信小程序端**:学生报修、查公告、缴费的移动端
2. **门禁卡联动**:访客登记与门禁数据打通
3. **大屏可视化**:宿舍楼分布的 3D 大屏
4. **AI 卫生检查**:摄像头识别地面整洁度
5. **多校多租户**:支持多个独立学校管理员上线

---

## 阶段进度跟踪表

| 阶段 | 状态 | 完成日期 | Commit |
|------|------|---------|--------|
| 1. 脚手架+数据库 | ☑ 完成 | 2026-07-05 | `53f83f8` chore: init scaffold and database schema（端口改动 `69d73ec`） |
| 2. 用户与权限 | ☑ 完成 | 2026-07-05 | 见本次 `feat: auth module with JWT` |
| 3. 宿舍基础数据 | ☑ 完成 | 2026-07-06 | `feat: dorm structure module` |
| 4. 学生档案 | ☑ 完成 | 2026-07-06 | `feat: student profile module with batch import` |
| 5. 入住退宿异动 | ☑ 完成 | 2026-07-19 | 后端 `c6722b0` feat: backend check-in/out and change-record flow；前端 `feat: check-in/check-out and change-record flow` |
| 6. 卫生考勤 | ☑ 完成 | 2026-07-19 | `feat: hygiene attendance and dorm score module` |
| 7. 维修管理 | ☑ 完成 | 2026-07-19 | `ae64ba5` feat: repair order workflow |
| 8. 访客安全 | ☑ 后端复验通过 | 2026-07-24 | 初标 `665f5c2`；修复见 `docs/PHASE_8_9_10_VERIFICATION_REPORT.md` |
| 9. 费用公告 | ☑ 后端复验通过（前端未读红点待联调） | 2026-07-24 | 初标 `21707d3`；修复见验收报告 |
| 10. 统计日志收尾 | ⚠ 后端代码层通过 / 运行时未完 | 2026-07-24 | Dashboard/全量联调/安全核查待运行时；修复见验收报告 |
