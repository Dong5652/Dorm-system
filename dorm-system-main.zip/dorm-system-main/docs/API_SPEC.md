# 学校宿舍管理系统 — REST 接口规范

> 版本: v1.0
> 基于 [DATABASE.md](./DATABASE.md) 与 [DEVELOPMENT_PLAN.md](./DEVELOPMENT_PLAN.md) 制定
> 后端: Spring Boot 3.2 (JDK 17) + MyBatis-Plus + Spring Security
> 前端: Vue 3 + TypeScript + axios
> 所有接口统一前缀 `/api/v1`,响应体统一封装

---

## 一、通用规范

### 1.1 统一响应体

```json
{
  "code": 0,
  "message": "success",
  "data": {}
}
```

| code | 含义 |
|------|------|
| 0 | 成功 |
| 40001 | 参数校验失败 |
| 40101 | 未登录(token 缺失/失效) |
| 40301 | 无权限(角色越权) |
| 40401 | 资源不存在 |
| 40901 | 业务冲突(如床位已占用) |
| 50001 | 服务器内部错误 |

> HTTP 状态码与 code 同步返回(401/403/404/409/500),前端只判 `code` 字段即可。

### 1.2 统一请求头

```http
Authorization: Bearer <jwt_token>
Content-Type: application/json
```

> 除登录、公告浏览等公开接口外,所有接口必须携带 `Authorization` 头。

### 1.3 分页参数

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| pageNum | int | 1 | 页码,从 1 开始 |
| pageSize | int | 20 | 每页条数,最大 200 |

分页响应:

```json
{
  "code": 0,
  "data": {
    "list": [],
    "total": 100,
    "pageNum": 1,
    "pageSize": 20,
    "pages": 5
  }
}
```

### 1.4 时间格式

- 日期: `yyyy-MM-dd`
- 月份: `yyyy-MM`
- 时间戳: `yyyy-MM-dd HH:mm:ss`
- 查询参数中时间范围统一用 `startDate` / `endDate`

### 1.5 角色权限标识

| 角色 | 标识 | 接口前缀范围 |
|------|------|------------|
| 管理员 | `admin` | `/admin/**` 全权 + 通用 |
| 宿管 | `dorm_manager` | `/dorm/**` 本人楼栋范围 + 通用 |
| 学生 | `student` | `/student/**` 本人范围 + 通用 |
| 维修师傅 | `repairman` | `/repair/**` 本人派单 |

---

## 二、认证模块 `/auth`

### 2.1 登录

`POST /api/v1/auth/login`

**权限**: 公开

**Request**:
```json
{
  "username": "admin",
  "password": "123456"
}
```

**Response**:
```json
{
  "code": 0,
  "data": {
    "token": "eyJhbGciOiJIUzI1...",
    "userId": 1,
    "username": "admin",
    "realName": "超管",
    "role": "admin"
  }
}
```

### 2.2 登出

`POST /api/v1/auth/logout`

**权限**: 已登录

**Response**: `{ "code": 0, "message": "success" }`

### 2.3 当前用户信息

`GET /api/v1/auth/me`

**权限**: 已登录

**Response**:
```json
{
  "code": 0,
  "data": {
    "userId": 1,
    "username": "admin",
    "realName": "超管",
    "role": "admin",
    "buildingId": null,
    "buildingName": null,
    "gender": 1,
    "phone": "13800138000"
  }
}
```

### 2.4 修改密码

`PUT /api/v1/auth/password`

**权限**: 已登录

**Request**:
```json
{
  "oldPassword": "123456",
  "newPassword": "newpass"
}
```

---

## 三、宿舍基础数据模块

### 3.1 楼栋管理 `/admin/buildings`(管理员 CRUD)

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/admin/buildings` | 楼栋分页列表 | admin |
| GET | `/api/v1/admin/buildings/all` | 全部楼栋(下拉) | admin / dorm_manager |
| GET | `/api/v1/admin/buildings/{id}` | 楼栋详情 | admin |
| POST | `/api/v1/admin/buildings` | 新增楼栋 | admin |
| PUT | `/api/v1/admin/buildings/{id}` | 修改楼栋 | admin |
| DELETE | `/api/v1/admin/buildings/{id}` | 删除楼栋(软删) | admin |

**新增/修改 Request**:
```json
{
  "code": "7B",
  "name": "7号B楼",
  "gender": 1,
  "floorCount": 6,
  "managerId": 5,
  "remark": "男生楼"
}
```

**列表查询参数**:
| 参数 | 类型 | 说明 |
|------|------|------|
| keyword | string | 模糊匹配 code/name |
| gender | int | 1男 2女 3混合 |

### 3.2 楼层管理 `/admin/floors`

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/admin/floors` | 楼层分页列表(按 building_id) | admin |
| POST | `/api/v1/admin/floors` | 新增楼层 | admin |
| PUT | `/api/v1/admin/floors/{id}` | 修改楼层 | admin |
| DELETE | `/api/v1/admin/floors/{id}` | 删除楼层 | admin |

**Request**: `{ "buildingId": 1, "floorNo": 3, "roomCount": 20 }`

### 3.3 房间管理 `/admin/rooms`

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/admin/rooms` | 房间分页列表 | admin |
| GET | `/api/v1/admin/rooms/{id}` | 房间详情(含床位) | admin / dorm_manager |
| POST | `/api/v1/admin/rooms` | 新增房间 | admin |
| PUT | `/api/v1/admin/rooms/{id}` | 修改房间(支持修改 status) | admin |
| DELETE | `/api/v1/admin/rooms/{id}` | 删除房间 | admin |

**Request**: `{ "buildingId": 1, "floorId": 1, "roomNo": "302", "capacity": 4 }`

**status 修改**: PUT 单字段 `{"status": 3}` 即可标记维修中,系统自动联动该房间所有 bed.status=2。

### 3.4 床位管理 `/admin/beds`

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/admin/beds` | 床位分页列表(按 room_id) | admin / dorm_manager |
| POST | `/api/v1/admin/beds` | 新增床位 | admin |
| PUT | `/api/v1/admin/beds/{id}` | 修改床位 | admin |
| DELETE | `/api/v1/admin/beds/{id}` | 删除床位(占用中禁止) | admin |

**Request**: `{ "roomId": 1, "bedNo": "1" }`

### 3.5 通用查询

#### 3.5.1 宿舍树(级联数据)

`GET /api/v1/dorm/tree`

**权限**: 已登录

**Response**:
```json
{
  "code": 0,
  "data": [
    {
      "id": 1, "code": "7B", "name": "7号B楼", "gender": 1,
      "floors": [
        { "id": 1, "floorNo": 1, "rooms": [
          { "id": 1, "roomNo": "102", "capacity": 4, "occupiedCount": 2,
            "beds": [
              { "id": 1, "bedNo": "1", "status": 1, "studentId": 1001, "studentName": "张三" },
              { "id": 2, "bedNo": "2", "status": 0, "studentId": null, "studentName": null }
            ] }
          ]
        }]
      ]
    }
  ]
}
```

#### 3.5.2 空置统计

`GET /api/v1/dorm/vacancy`

**权限**: admin / dorm_manager

**Response**:
```json
{
  "code": 0,
  "data": [
    { "buildingId": 1, "buildingName": "7号B楼", "totalBeds": 240, "occupiedBeds": 180, "vacantBeds": 60, "occupancyRate": 75.0 }
  ]
}
```

---

## 四、学生档案模块

### 4.1 学生 CRUD `/admin/students`

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/admin/students` | 分页查询(多条件) | admin |
| GET | `/api/v1/admin/students/{id}` | 学生详情(含床位+异动) | admin / dorm_manager(本人楼栋) / student(本人) |
| POST | `/api/v1/admin/students` | 新增学生(自动建 sys_user) | admin |
| PUT | `/api/v1/admin/students/{id}` | 修改学生 | admin |
| DELETE | `/api/v1/admin/students/{id}` | 删除学生(软删+联动账号) | admin |

**新增/修改 Request**:
```json
{
  "studentNo": "2024010001",
  "name": "张三",
  "gender": 1,
  "college": "计算机学院",
  "major": "软件工程",
  "className": "软件2301",
  "grade": "2024",
  "phone": "13800138000",
  "emergencyContact": "张父",
  "emergencyPhone": "13900139000",
  "enrollDate": "2024-09-01"
}
```

**列表查询参数**:
| 参数 | 类型 | 说明 |
|------|------|------|
| keyword | string | 学号/姓名模糊匹配 |
| college | string | 学院精确 |
| major | string | 专业精确 |
| className | string | 班级精确 |
| grade | string | 年级精确 |
| gender | int | 性别 |

### 4.2 批量导入导出

#### 4.2.1 批量导入

`POST /api/v1/admin/students/import`

**权限**: admin

**Request**: `multipart/form-data`,字段名 `file`,Excel 文件(.xlsx)

**Response**:
```json
{
  "code": 0,
  "data": {
    "totalCount": 100,
    "successCount": 98,
    "failedCount": 2,
    "failedRows": [
      { "rowNum": 15, "reason": "学号 2024010015 已存在" }
    ]
  }
}
```

#### 4.2.2 导出

`GET /api/v1/admin/students/export`

**权限**: admin

**参数**: 同 4.1 列表查询参数

**Response**: 直接返回 `application/vnd.ms-excel` 二进制流,前端触发下载

---

## 五、入住退宿与异动模块

### 5.1 入住

`POST /api/v1/dorm/check-in`

**权限**: dorm_manager / admin

**Request**:
```json
{
  "studentId": 1001,
  "bedId": 5,
  "keyIssued": true,
  "facilityCheck": "电风扇/桌椅齐全",
  "remark": "新生入住"
}
```

**校验**:
- 床位必须空闲(`bed.status=0`)
- 学生性别必须等于床位所属楼栋 gender(混合楼栋放行)
- 学生当前 `current_bed_id` 必须为空(不能重复入住)

**Response**: `{ "code": 0, "data": { "recordId": 1, "bedId": 5 } }`

### 5.2 自动分配

`POST /api/v1/admin/students/{id}/auto-assign`

**权限**: admin

**Request**:
```json
{
  "buildingId": 1,
  "preferredFloor": 3
}
```

> 算法: 按 gender 筛选楼栋 → 优先选 preferredFloor 的空闲床位 → 无指定则跨楼层任选空闲床位

### 5.3 退宿

`POST /api/v1/dorm/check-out`

**Request**:
```json
{
  "studentId": 1001,
  "keyReturned": true,
  "facilityCheck": "设施完好",
  "remark": "毕业退宿"
}
```

### 5.4 调宿

`POST /api/v1/dorm/change-room`

**Request**:
```json
{
  "studentId": 1001,
  "fromBedId": 5,
  "toBedId": 12,
  "reason": "同寝矛盾"
}
```

### 5.5 异动登记

`POST /api/v1/dorm/change`

**Request**:
```json
{
  "studentId": 1001,
  "type": "suspend",
  "reason": "身体原因休学一年",
  "operatorId": 3,
  "remark": ""
}
```

> type 取值 `suspend`(休学,同时置学生 status=1) / `transfer`(转专业) / `change_room`(若用 5.4 调宿接口不走这里) / `holiday_leave`(假期离校)

### 5.6 批量退宿

`POST /api/v1/admin/check-out/batch`

**Request**:
```json
{
  "grade": "2022",
  "className": null,
  "reason": "毕业退宿",
  "keyReturned": true
}
```

**Response**: `{ "code": 0, "data": { "totalCount": 200, "successCount": 200, "failedCount": 0 } }`

### 5.7 流水查询

`GET /api/v1/dorm/records`

**权限**: admin(全) / dorm_manager(本人楼栋) / student(本人)

**参数**:
| 参数 | 类型 | 说明 |
|------|------|------|
| studentId | long | 学生 ID |
| roomId | long | 房间 ID |
| type | int | 1入住 2退宿(只查 check_in_record) |
| changeType | string | 仅查异动记录时用,如 `suspend` |
| startDate | date | 起始日期 |
| endDate | date | 结束日期 |

**Response**: 返回 `check_in_record` 与 `change_record` 合并后的时间线列表,每条带 `recordType`(`check_in` / `change`)区分来源。

---

## 六、卫生与考勤模块

### 6.1 卫生检查

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/dorm/hygiene` | 卫生检查分页列表 | admin / dorm_manager / student(本人房间) |
| POST | `/api/v1/dorm/hygiene` | 录入卫生检查 | dorm_manager |
| PUT | `/api/v1/dorm/hygiene/{id}` | 修改卫生记录 | dorm_manager / admin |
| DELETE | `/api/v1/dorm/hygiene/{id}` | 删除 | admin |

**录入 Request**:
```json
{
  "roomId": 1,
  "checkDate": "2026-03-15",
  "score": 92.0,
  "deduction": 8.0,
  "bonus": 0.0,
  "photoUrl": "/upload/hygiene/20260315-302.jpg",
  "itemDetail": "[{\"item\":\"地面有尘\",\"type\":\"deduct\",\"value\":3},{\"item\":\"桌面整洁\",\"type\":\"bonus\",\"value\":0}]",
  "remark": "整体尚可"
}
```

### 6.2 考勤

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/dorm/attendance` | 晚归考勤查询 | admin / dorm_manager / student(本人) |
| POST | `/api/v1/dorm/attendance` | 登记晚归/未归/请假 | dorm_manager |
| PUT | `/api/v1/dorm/attendance/{id}` | 修改 | dorm_manager / admin |
| DELETE | `/api/v1/dorm/attendance/{id}` | 删除 | admin |

**录入 Request**:
```json
{
  "studentId": 1001,
  "recordDate": "2026-03-15",
  "type": 1,
  "returnTime": "2026-03-16T01:30:00",
  "remark": "校外兼职晚归"
}
```

### 6.3 寝室评分

#### 6.3.1 查询评分

`GET /api/v1/dorm/scores`

**参数**:
| 参数 | 类型 | 说明 |
|------|------|------|
| yearMonth | string | 如 `2026-03`,缺省返回最近一个月 |
| buildingId | long | 楼栋筛选 |
| roomId | long | 房间筛选 |

**Response**:
```json
{
  "code": 0,
  "data": {
    "list": [
      { "roomId": 1, "buildingName": "7号B楼", "roomNo": "302",
        "yearMonth": "2026-03", "hygieneAvg": 92.5, "lateCount": 2,
        "totalScore": 88.5, "level": "合格", "rank": 1 }
    ]
  }
}
```

#### 6.3.2 手动补录

`POST /api/v1/admin/dorm/scores/manual`

**权限**: admin

**Request**: `{ "roomId": 1, "yearMonth": "2026-03", "hygieneAvg": 95, "lateCount": 0, "totalScore": 95.0, "level": "优秀", "remark": "管理员修正" }`

#### 6.3.3 触发月度评分任务

`POST /api/v1/admin/dorm/scores/trigger`

**权限**: admin

**Request**: `{ "yearMonth": "2026-03" }`

> 用于手动触发定时任务跑评分(开发联调用)。

---

## 七、维修管理模块 `/repair`

### 7.1 工单 CRUD 与流转

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/repair` | 工单列表(按角色过滤) | 全部 |
| GET | `/api/v1/repair/{id}` | 工单详情 | 全部(本人范围) |
| POST | `/api/v1/repair` | 学生/宿管报修 | student / dorm_manager |
| POST | `/api/v1/admin/repair/{id}/assign` | 管理员派单 | admin |
| PUT | `/api/v1/repair/{id}/start` | 师傅接单 | repairman |
| PUT | `/api/v1/repair/{id}/finish` | 师傅完工 | repairman |
| PUT | `/api/v1/repair/{id}/rate` | 学生评价 | student |
| PUT | `/api/v1/repair/{id}/cancel` | 取消工单 | student / admin |
| DELETE | `/api/v1/admin/repair/{id}` | 删除工单 | admin |

**报修 Request**:
```json
{
  "roomId": 1,
  "bedId": 5,
  "title": "水龙头漏水",
  "description": "302房1号床水龙头持续滴水",
  "photoUrl": "/upload/repair/20260315-leak.jpg",
  "priority": 1
}
```

**派单 Request**: `{ "repairmanId": 8 }`

**完工 Request**: `{ "completionNote": "更换水龙头芯,已正常使用" }`

**评价 Request**: `{ "rating": 5, "ratingComment": "响应及时" }`

**列表查询参数**:
| 参数 | 类型 | 说明 |
|------|------|------|
| status | int | 0待派单 1已派单 2维修中 3已完成 4已取消 |
| priority | int | 优先级 |
| repairmanId | long | 师傅 ID |
| startDate | date | 报修起始 |
| endDate | date | 报修结束 |

> 列表接口按角色自动过滤:学生只看自己报修的、师傅只看自己派单的、宿管只看本楼栋的、管理员全权。

### 7.2 维修师傅账号管理 `/admin/repairmen`

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/admin/repairmen` | 师傅列表 | admin |
| POST | `/api/v1/admin/repairmen` | 新增师傅账号 | admin |
| PUT | `/api/v1/admin/repairmen/{id}` | 修改(含工种) | admin |
| DELETE | `/api/v1/admin/repairmen/{id}` | 删除(软删) | admin |

**Request**: `{ "username": "repair001", "realName": "王师傅", "phone": "13800138001", "workType": "水电", "gender": 1 }`

> role 自动设为 `repairman`,初始密码默认 `123456`(BCrypt 加密)。

---

## 八、访客与安全模块 `/safety`

### 8.1 访客管理

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/safety/visitor` | 访客列表 | admin / dorm_manager |
| POST | `/api/v1/safety/visitor` | 访客登记 | dorm_manager |
| PUT | `/api/v1/safety/visitor/{id}/exit` | 登记访客离开 | dorm_manager |
| DELETE | `/api/v1/admin/safety/visitor/{id}` | 删除访客记录 | admin |

**登记 Request**:
```json
{
  "visitorName": "李四",
  "idCard": "110101199001011234",
  "phone": "13900139001",
  "visitTargetId": 1001,
  "buildingId": 1,
  "purpose": "看望学生张三",
  "enterTime": "2026-03-15T19:00:00",
  "remark": ""
}
```

### 8.2 违禁品检查

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/safety/inspection` | 违禁品检查记录 | admin / dorm_manager |
| POST | `/api/v1/safety/inspection` | 录入违禁品检查 | dorm_manager |
| PUT | `/api/v1/admin/safety/inspection/{id}` | 修改 | admin |
| DELETE | `/api/v1/admin/safety/inspection/{id}` | 删除 | admin |

**录入 Request**:
```json
{
  "roomId": 1,
  "studentId": 1001,
  "inspectDate": "2026-03-15",
  "itemType": "大功率电器",
  "itemDesc": "违规使用大功率电热水壶",
  "photoUrl": "/upload/inspection/20260315-kettle.jpg",
  "disposition": "没收保管",
  "noticeSent": true,
  "remark": "已告知学生签字"
}
```

> 录入后系统自动给该 student 写 `notice_message(msg_type=rectify)` 整改通知。

### 8.3 安全事件

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/safety/event` | 事件列表 | admin / dorm_manager |
| POST | `/api/v1/safety/event` | 上报事件 | dorm_manager / admin |
| PUT | `/api/v1/admin/safety/event/{id}/handle` | 处理事件 | admin |
| DELETE | `/api/v1/admin/safety/event/{id}` | 删除 | admin |

**上报 Request**:
```json
{
  "buildingId": 1,
  "roomId": 1,
  "eventType": "火情",
  "severity": 2,
  "description": "学生违规用电导致插座冒烟",
  "photoUrl": "/upload/safety/20260315-smoke.jpg",
  "happenedAt": "2026-03-15T22:30:00"
}
```

**处理 Request**: `{ "handleNote": "已切断电源,通报批评,要求整改" }`

---

## 九、费用与公告模块

### 9.1 费用管理 `/fee`、`/admin/fee`

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/fee` | 当前用户账单(学生看自己,管理员可指定 studentId) | 全部 |
| GET | `/api/v1/admin/fee` | 任意查询 | admin |
| POST | `/api/v1/admin/fee/accommodation/generate` | 批量出住宿费 | admin |
| POST | `/api/v1/admin/fee/utility/generate` | 按月出水电费 | admin |
| POST | `/api/v1/admin/fee/{id}/pay` | 缴费 | admin |
| POST | `/api/v1/admin/fee/{id}/remind` | 催缴(发站内消息) | admin |

**住宿费出账 Request**: `{ "semester": "2025-2026-2", "amount": 1200.00, "dueDate": "2026-04-15" }`

**水电费出账 Request**: `{ "readingMonth": "2026-03" }`

**缴费 Request**: `{ "payType": 2, "amount": 71.75, "payNo": "WX202603150001" }`

**账单查询参数**:
| 参数 | 类型 | 说明 |
|------|------|------|
| studentId | long | 学生 ID(管理员用) |
| feeType | string | accommodation / utility |
| yearMonth | string | 账期 |
| paidStatus | int | 0未缴 1部分 2已缴清 |

### 9.2 水电抄表 `/dorm/meter`

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/dorm/meter` | 抄表记录查询 | admin / dorm_manager |
| POST | `/api/v1/dorm/meter` | 录入抄表读数 | dorm_manager |
| PUT | `/api/v1/admin/dorm/meter/{id}` | 修改 | admin |
| DELETE | `/api/v1/admin/dorm/meter/{id}` | 删除 | admin |

**录入 Request**:
```json
{
  "roomId": 1,
  "meterType": 1,
  "readingValue": 120.50,
  "readingMonth": "2026-03",
  "remark": "例行抄表"
}
```

> 系统自动取上次同房间同表 `reading_value` 作为 `previous_value`,算 `usage_amount` 与 `amount`(单位价格由后端配置文件 `fee.water-unit-price` / `fee.electric-unit-price` 读取,冗余写入 meter_reading)。

### 9.3 公告管理 `/announcement`

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/announcement` | 当前用户可见公告列表 | 全部(按 scope 过滤) |
| GET | `/api/v1/announcement/{id}` | 公告详情 | 全部(scope 校验) |
| GET | `/api/v1/admin/announcement` | 全部公告列表(含草稿) | admin |
| POST | `/api/v1/admin/announcement` | 发布公告 | admin |
| PUT | `/api/v1/admin/announcement/{id}` | 修改 | admin |
| DELETE | `/api/v1/admin/announcement/{id}` | 删除 | admin |
| PUT | `/api/v1/admin/announcement/{id}/pin` | 置顶/取消置顶 | admin |
| PUT | `/api/v1/admin/announcement/{id}/offline` | 下架 | admin |

**发布公告 Request**:
```json
{
  "title": "3月20日 7B 楼停水通知",
  "content": "因市政检修...",
  "scope": 1,
  "buildingId": 1,
  "isPinned": true,
  "publishTime": "2026-03-18T09:00:00",
  "expireTime": "2026-03-21T06:00:00"
}
```

### 9.4 站内消息 `/notice`

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/notice` | 当前用户站内消息分页 | 全部 |
| GET | `/api/v1/notice/unread-count` | 未读消息数(导航栏轮询) | 全部 |
| PUT | `/api/v1/notice/{id}/read` | 标记已读 | 全部 |
| PUT | `/api/v1/notice/read-all` | 全部标记已读 | 全部 |
| DELETE | `/api/v1/notice/{id}` | 删除 | 全部 |

---

## 十、统计查询与日志模块

### 10.1 统计接口 `/stats`

#### 10.1.1 入住率统计

`GET /api/v1/stats/occupancy`

**参数**:
| 参数 | 类型 | 说明 |
|------|------|------|
| groupBy | string | `building` / `gender` / `major` / `grade`,可多选逗号分隔 |
| buildingId | long | 楼栋筛选 |

**Response**:
```json
{
  "code": 0,
  "data": [
    { "dimName": "7号B楼", "totalBeds": 240, "occupiedBeds": 180, "vacantBeds": 60, "occupancyRate": 75.0 }
  ]
}
```

#### 10.1.2 违纪记录查询

`GET /api/v1/stats/discipline`

**参数**:
| 参数 | 类型 | 说明 |
|------|------|------|
| studentNo | string | 学号 |
| roomId | long | 房间 ID |
| startDate | date | 起始 |
| endDate | date | 结束 |

**Response**: 返回该学生(或房间)的卫生扣分、晚归、违禁品三类记录合并时间线。

#### 10.1.3 报表导出

`GET /api/v1/stats/export`

**参数**: `type` (occupancy / fee / repair / score)

**Response**: 直接返回 Excel 二进制流(统一 EasyExcel 模板实现),前端下载:
- `occupancy`: 入住名单
- `fee`: 缴费统计
- `repair`: 维修账单
- `score`: 卫生考评

### 10.2 操作日志 `/admin/logs`

| 方法 | 路径 | 说明 | 角色 |
|------|------|------|------|
| GET | `/api/v1/admin/logs` | 操作日志分页查询 | admin |

**参数**:
| 参数 | 类型 | 说明 |
|------|------|------|
| operatorId | long | 操作人 ID |
| module | string | 模块名 |
| action | string | 操作类型 |
| startDate | date | 起始 |
| endDate | date | 结束 |

---

## 十一、文件上传

### 11.1 上传文件

`POST /api/v1/upload`

**权限**: 已登录(按业务场景限制类型)

**Request**: `multipart/form-data`,字段名 `file`

**Response**:
```json
{
  "code": 0,
  "data": {
    "url": "/upload/hygiene/20260315-302.jpg",
    "fileName": "20260315-302.jpg",
    "size": 102400
  }
}
```

> 上传路径按业务自动归档:`/upload/hygiene/*` `/upload/repair/*` `/upload/inspection/*` `/upload/safety/*` `/upload/avatar/*`,通过 `type` 参数控制:
> `POST /api/v1/upload?type=hygiene`

### 11.2 文件访问

`GET /upload/{path}`

> 静态资源服务路径,放在 `application.yml` 中配置 `spring.web.resources.static-locations` 或独立 Nginx。

---

## 十二、接口清单速查表

| 模块 | 接口前缀 | 数量 | 主要角色 |
|------|---------|------|---------|
| 认证 | `/auth` | 4 | 全部 |
| 楼栋楼层房间床位 | `/admin/buildings` `/admin/floors` `/admin/rooms` `/admin/beds` `/dorm` | 25 | admin / dorm_manager |
| 学生档案 | `/admin/students` | 8 | admin |
| 入住退宿异动 | `/dorm/check-in` `/dorm/check-out` `/dorm/change` `/admin/check-out` | 7 | admin / dorm_manager |
| 卫生考勤 | `/dorm/hygiene` `/dorm/attendance` `/dorm/scores` | 11 | dorm_manager / admin |
| 维修 | `/repair` `/admin/repair` `/admin/repairmen` | 13 | 全部 |
| 访客安全 | `/safety` `/admin/safety` | 12 | dorm_manager / admin |
| 费用公告 | `/fee` `/admin/fee` `/dorm/meter` `/announcement` `/admin/announcement` `/notice` | 18 | 全部 |
| 统计日志 | `/stats` `/admin/logs` | 4 | admin |
| 文件上传 | `/upload` | 2 | 全部 |
| **合计** | | **约 104** | |

---

## 十三、接口规约补充

### 13.1 命名规范

- 路径: 全小写中划线分隔,如 `/check-in` `/change-room`
- 查询参数: 驼峰命名,如 `pageNum` `studentId` `buildingId`
- Request/Response 字段: 驼峰,与数据库小写下划线字段一一对应(后端 MyBatis-Plus `map-underscore-to-camel-case: true` 自动转换)

### 13.2 列表查询统一分页

凡是返回集合的接口,默认走分页(除 `all` 后缀的全量下拉接口),`pageNum` `pageSize` 作为 Query 参数。`/all` 后缀接口返回不分页的精简列表,用于下拉选择器。

### 13.3 软删除约定

DELETE 接口均做软删除(`is_deleted=1`),不真正删库。占用中(如学生已入住的床位)禁止删除,返回 409 业务冲突。

### 13.4 事务边界

涉及多表联动的接口(`check-in` / `check-out` / `change-room` / 批量退宿 / 缴费)必须在 Service 层加 `@Transactional`,任一步失败整体回滚。

### 13.5 操作日志切面

下列接口需 `@OperationLog` 注解自动写入 `operation_log`:
- 修改/删除学生、修改缴费状态、批量退宿
- 修改/删除卫生评分、补录 dorm_score
- 派维修单、改维修状态、删除工单
- 录入违禁品、上报安全事件
- 发布/下架/删除公告、催缴消息

### 13.6 前端 axios 调用约定

```typescript
// api/index.ts
const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api/v1',
  timeout: 15000,
})

// 请求拦截:自动带 token
api.interceptors.request.use(config => {
  const token = useUserStore().token
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// 响应拦截:统一拆 code
api.interceptors.response.use(
  res => {
    if (res.data.code !== 0) {
      ElMessage.error(res.data.message)
      return Promise.reject(res.data)
    }
    return res.data.data
  },
  err => {
    if (err.response?.status === 401) {
      useUserStore().logout()
      router.push('/login')
    }
    return Promise.reject(err)
  }
)
```
