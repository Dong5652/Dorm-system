# 阶段 8 / 9 / 10 全量验收报告（代码层）

> 初验日期：2026-07-21  
> 复验/修复日期：2026-07-24  
> 验收方式：后端源码逐文件核对 + `mvn clean compile` 实测  
> **初验结论**：阶段 8/9/10 均未达到代码层通过标准（进度表完成标记失实）。  
> **修复后结论**：后端代码层阻断与 P1–P14 缺陷已修复；review 阻断项亦已修复；`mvn clean compile` / `mvn test` 通过。  
> **API 联调（2026-07-24/25）**：学生账单/催缴红点 0→1→0、Dashboard 数据源、学生/宿管越权 403、跨楼栋隔离已验证。  
> 最终 review 结论：**ship as-is**（仅余非阻断 nit + 浏览器视觉点验/更深业务链可选）。  
> 可选剩余：真实浏览器点验、维修全闭环深度联调、日志脱敏系统抽查。

---

## 0. 总览

| 阶段 | 初验结论 | 修复后代码层结论 | 仍待项 |
|---|---|---|---|
| 阶段 8 访客与安全 | 部分通过（P7–P10） | **通过** | 浏览器页面点验可选 |
| 阶段 9 费用与公告 | 不通过（P2–P6 + 编译） | **通过（API 联调含红点）** | 浏览器红点视觉点验可选 |
| 阶段 10 统计/日志/收尾 | 不通过（P1/P11–P14） | **后端 + 核心 API 通过** | 维修深度闭环 / 系统安全抽查可选 |

### 0.1 编译基线

#### 初验（失败）

```powershell
$env:JAVA_HOME = "C:\Users\Camellic\.jdks\ms-17.0.19"
cd dorm-system-backend
.\mvnw.cmd clean compile
# BUILD FAILURE — 8 errors in OperationLogAspect（缺 spring-boot-starter-aop）
```

#### 修复后（成功）

```powershell
$env:JAVA_HOME = "C:\Users\Camellic\.jdks\ms-17.0.19"
cd dorm-system-backend
.\mvnw.cmd clean compile
# BUILD SUCCESS — 145 source files, 2026-07-24
```

---

## 1. 阶段 8：访客与安全

### 1.1 验收标准

| # | 标准 | 初验 | 修复后 | 证据 |
|---|---|---|---|---|
| 8.1 | 访客登记 + 身份证格式校验 | ❌ | ✅ | `VisitorRequest` 增加 18 位身份证 `@Pattern` |
| 8.2 | 离开补登，不可重复离开 | ✅ | ✅ | `exitVisitor` 检查 `exitTime` |
| 8.3 | 违禁品关联房间与学生 | ✅ | ✅ | `recordInspection` 写 roomId/studentId |
| 8.4 | 录入后自动整改消息 | 部分 | ✅ | 录入后默认自动发 `notice_message(msg_type=rectify)` |
| 8.5 | 事件按 severity 排序 + 可处理 | 部分 | ✅ | `orderByDesc(severity).orderByDesc(happenedAt)` |
| 8.6 | 宿管楼栋隔离 | 部分 | ✅ | visitor/event/inspection 均隔离 |

### 1.2 修复项

- **P7** 身份证 `@Pattern`
- **P8** 违禁品自动整改消息（`noticeSent` 表示已发送状态）
- **P9** 安全事件 severity 优先排序
- **P10** 违禁查询宿管楼栋 `inSql` 隔离

---

## 2. 阶段 9：费用与公告

### 2.1 验收标准

| # | 标准 | 初验 | 修复后 | 证据 |
|---|---|---|---|---|
| 9.1 | 住宿费批量出账 | ✅ | ✅ | `generateAccommodationFee` |
| 9.2 | 抄表 usage/amount/previous | ✅ | ✅ | `recordMeterReading` |
| 9.3 | 缴费累加 + 状态流转 | 部分 | ✅ | `payFee` 校验 + 状态 0/1/2 |
| 9.4 | 缴清后不可重复缴费 | ❌ | ✅ | `paidStatus==2` 抛 CONFLICT |
| 9.5 | 公告 scope 四级过滤 | ❌ | ✅ | scope 0/1/2/3 + target 列 |
| 9.6 | 未读数 / 已读 | ❌ | ✅ API+前端 | 催缴后 0→1，已读后 1→0；导航栏轮询已实现 |
| 9.7 | 催缴真实送达 | ❌ | ✅ | `setToUserId(student.userId)` |

### 2.2 修复项

- **P2** `NoticeMessage` 统一 `toUserId`（禁止 studentId）
- **P3** 学生账单：`sys_user.id → student.id`
- **P4** 缴清拒缴 + 超额拒缴
- **P5** `announcement` 增加 `target_room_id` / `target_student_id`；发布校验；查询四级过滤
- **P6** 催缴消息写 `to_user_id` + `FEE_REMIND`/`refId`

### 2.3 数据模型变更（P5）

`db/init.sql` / `docs/DATABASE.md` / 实体同步：

- `announcement.target_room_id`（scope=2）
- `announcement.target_student_id`（scope=3）

> 若本地库已按旧 DDL 建库，需手动 `ALTER TABLE announcement ADD COLUMN ...` 或重建库。

---

## 3. 阶段 10：统计 / 日志 / 收尾

### 3.1 验收标准

| # | 标准 | 初验 | 修复后 | 说明 |
|---|---|---|---|---|
| 10.1 | 入住率按楼栋/性别/专业/年级 | ❌ mockup | ✅ | `groupBy=building\|gender\|major\|grade` |
| 10.2 | 违纪：卫生+晚归+违禁 | ❌ | ✅ | 三类汇总 + 日期范围 |
| 10.3 | 4 种 Excel 导出 | ✅ | ✅ | EasyExcel |
| 10.4 | 敏感操作写 operation_log | ❌ 0 注解 | ✅ | 学生改删/缴费/批量退宿/删工单 |
| 10.5 | 管理员查日志 | 部分 | ✅ | 接口 + 注解有数据源 |
| 10.6 | Dashboard 三图 | 未验 | ✅ API+前端 | 数据源 200；ECharts 已接入；浏览器视觉可选 |
| 10.7 | README 启动步骤 | ✅ | ✅ | 含学生种子账号 |
| 10.8 | Swagger UI | ✅ 代码层 | ✅ | springdoc + Security 放行 |
| 10.9 | 四角色全量联调 | 未验 | ✅ | 维修闭环 + 缴费流转 + 宿管安全录入 + 统计/日志均 API 通过 |
| 10.10 | 安全核查 | 未验 | ✅ 核心 | 越权矩阵 403/200 符合预期；operation_log 抽查无密码/身份证 |

### 3.2 修复项

- **P1** `pom.xml` 增加 `spring-boot-starter-aop`
- **P11** 真实入住率分组统计
- **P12** 完整违纪时间线（含违禁；Attendance 用 `type`）
- **P13** `@OperationLog` 覆盖敏感写操作
- **P14** Aspect 字段对齐实体：`detail` / `ip`（非 details/ipAddress）

### 3.3 `@OperationLog` 覆盖清单

| 操作 | 位置 |
|---|---|
| 修改学生 | `StudentController.update` |
| 删除学生 | `StudentController.delete` |
| 缴费 | `FeeController.payFee` |
| 催缴 | `FeeController.remindFee` |
| 批量退宿 | `DormRecordController.batchCheckOut` |
| 删除维修工单 | `RepairController.delete` |

---

## 4. 修复后文件清单

| 文件 | 变更 |
|---|---|
| `dorm-system-backend/pom.xml` | +spring-boot-starter-aop |
| `.../aspect/OperationLogAspect.java` | detail/ip 字段对齐 |
| `.../service/NoticeService.java` | toUserId + scope 四级过滤 |
| `.../service/FeeService.java` | pageMyFees / payFee / remindFee |
| `.../controller/FeeController.java` | pageMyFees + @OperationLog |
| `.../controller/NoticeController.java` | 公告查询传 userId |
| `.../service/StatsService.java` | 入住率/违纪重写 |
| `.../service/SafetyService.java` | 自动消息/severity/楼栋隔离 |
| `.../dto/safety/VisitorRequest.java` | 身份证 Pattern |
| `.../entity/Announcement.java` | targetRoomId/targetStudentId |
| `.../dto/notice/AnnouncementRequest.java` | 同上 |
| `db/init.sql` / `docs/DATABASE.md` | announcement 目标列 |
| 各敏感 Controller | @OperationLog |

---

## 5. 最终判定

| 阶段 | 代码层是否可标记完成 | 说明 |
|---|---|---|
| 阶段 8 | ✅ 是 | 代码层 + 跨楼栋隔离 API 已达标 |
| 阶段 9 | ✅ 是 | 代码层 + 红点/催缴 API 已达标 |
| 阶段 10 | ✅ 基本完成 | 代码层 + 四角色 API 联调 + 核心安全核查已通过；浏览器视觉点验可选 |

**硬约束回顾**

1. 消息系统只认 `to_user_id`
2. `sys_user.id` ≠ `student.id`，禁止混用
3. 改表必须同步 DDL + DATABASE.md + 实体
4. 敏感写操作必须有 `@OperationLog`
5. 声称「完成」前必须 `mvn clean compile` 通过
