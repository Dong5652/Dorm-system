﻿# Four-role E2E Report

> time: 20260727042157
> source: docs/ROLE_PERMISSION_MATRIX.md
> base: http://localhost:8080

## Summary

| Metric | Value |
|---|---|
| Total | 96 |
| Pass | 96 |
| Fail | 0 |
| Pass rate | 100% |

## Data flow checks

| Flow | Result |
|---|---|
| Admin announce scope0 -> student sees | PASS |
| Building1 announce -> stu1 sees / stu2 not | stu1=PASS stu2_hidden=PASS |
| Manager inspection/remind -> student notices | PASS |
| Fee generate -> student fee list | PASS |
| Repair create->assign->start->finish->rate | PASS |
| Pay updates student paidAmount | PASS |

## Failed cases

None

## All cases

| Result | Role | Module | Case | Expect | Actual | Detail |
|---|---|---|---|---|---|---|
| PASS | system | connectivity | ping | true | true | data=pong |
| PASS | admin | auth | login | true | true | admin |
| PASS | dorm_manager | auth | login_dm001 | true | true | dm001 |
| PASS | dorm_manager | auth | login_dm002 | true | true | dm002 |
| PASS | student | auth | login_stu001 | true | true | stu001 |
| PASS | student | auth | login_stu002 | true | true | stu002 |
| PASS | repairman | auth | login_repair001 | true | true | repair001 |
| PASS | repairman | auth | login_repair002 | true | true | repair002 |
| PASS | admin | auth | me | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | auth | me_username | true | true | user=admin role=admin |
| PASS | dorm_manager | auth | me | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | dorm_manager | auth | me_username | true | true | user=dm002 role=dorm_manager |
| PASS | student | auth | me | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | student | auth | me_username | true | true | user=stu001 role=student |
| PASS | repairman | auth | me | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | repairman | auth | me_username | true | true | user=repair001 role=repairman |
| PASS | admin | dorm | list_buildings | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | dorm | buildings_has_data | true | true | count=2 |
| PASS | admin | student | list_students | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | student | students_has_data | true | true | count=2 |
| PASS | admin | repairman | list_repairmen | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | repairman | repairmen_has_data | true | true | count=2 |
| PASS | admin | announcement | publish_scope0 | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | announcement | publish_scope1_b1 | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | logs | list_logs | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | stats | occupancy | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | stats | occupancy_has_rows | true | true | rows=2 |
| PASS | admin | stats | discipline_stu001 | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | stats | export_occupancy | true | true | HTTP=200 |
| PASS | admin | fee | generate_accommodation | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | fee | generated_fee_exists | true | true | feeId=7 studentId=594 |
| PASS | dorm_manager | visitor | register_own_building | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | dorm_manager | visitor | register_cross_building_forbidden | HTTP=403 | HTTP=403 code=40301 | dm1_to_b1 |
| PASS | dorm_manager | inspection | record_and_notify | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | dorm_manager | hygiene | create | HTTP=200 | HTTP=200 code=0 |  |
| PASS | dorm_manager | attendance | create_late | HTTP=200 | HTTP=200 code=0 |  |
| PASS | dorm_manager | meter | create | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | dorm_manager | event | report | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | dorm_manager | fee | remind | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | dorm_manager | fee | pay_forbidden | HTTP=403 | HTTP=403 code= |  |
| PASS | dorm_manager | logs | list_forbidden | HTTP=403 | HTTP=403 code= |  |
| PASS | dorm_manager | repairman | list_forbidden | HTTP=403 | HTTP=403 code= |  |
| PASS | dorm_manager | visitor | list | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | dorm_manager | visitor | list_sees_created | true | true | count=7 |
| PASS | dorm_manager | stats | occupancy | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | dorm_manager | student | list | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | student | fee | my_fees | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | student | fee | sees_own_fee | true | true | count=3 feeId=7 |
| PASS | student | notice | unread_count | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | student | notice | has_unread_after_produce | true | true | unread=4 |
| PASS | student | notice | list | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | student | notice | sees_produced_notice | true | true | notices=7 rectify=True remind=True |
| PASS | student | notice | mark_read | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | student | notice | unread_decreased_or_zero | true | true | before=4 after=3 |
| PASS | student | announcement | list | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | student | announcement | sees_scope0 | true | true | total=7 |
| PASS | student | announcement | sees_scope1_own_building | true | true | total=7 |
| PASS | student | announcement | stu2_sees_scope0 | true | true | stu2total=4 |
| PASS | student | announcement | stu2_not_sees_scope1_b1 | true | true | stu2SeeB1=False |
| PASS | student | hygiene | list | HTTP=200 | HTTP=200 code=0 |  |
| PASS | student | attendance | list | HTTP=200 | HTTP=200 code=0 |  |
| PASS | student | repair | create | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | student | repair | created_id | true | true | id=239 |
| PASS | student | repair | status_pending | true | true | status=0 |
| PASS | student | logs | admin_logs_forbidden | HTTP=403 | HTTP=403 code= |  |
| PASS | student | fee | pay_forbidden | HTTP=403 | HTTP=403 code= |  |
| PASS | student | stats | export_forbidden | HTTP=403 | HTTP=403 code= |  |
| PASS | student | student | create_forbidden | HTTP=403 | HTTP=403 code= | student cannot create |
| PASS | admin | repair | list_sees_new | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | repair | admin_sees_student_order | true | true | id=239 |
| PASS | dorm_manager | repair | list_own_building | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | dorm_manager | repair | dm_sees_building_order | true | true | count=3 |
| PASS | repairman | repair | list_before_assign | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | repairman | repair | not_see_before_assign | true | true | see=False |
| PASS | admin | repair | assign | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | repair | assign_status_1 | true | true | status=1 |
| PASS | repairman | repair | list_after_assign | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | repairman | repair | sees_after_assign | true | true | count=3 |
| PASS | repairman | repair | other_not_see | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | repairman | repair | other_repairman_not_see | true | true | rep2see=False |
| PASS | repairman | repair | start | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | repairman | repair | status_2 | true | true | status=2 |
| PASS | repairman | repair | finish | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | repairman | repair | status_3 | true | true | status=3 |
| PASS | student | repair | rate | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | student | repair | rated | true | true | rating=5 |
| PASS | repairman | logs | admin_forbidden | HTTP=403 | HTTP=403 code= |  |
| PASS | repairman | fee | pay_forbidden | HTTP=403 | HTTP=403 code= |  |
| PASS | repairman | repair | assign_forbidden | HTTP=403 | HTTP=403 code= |  |
| PASS | admin | event | handle | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | fee | pay_partial | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | fee | partial_status | true | true | paidStatus=1 paid=100.00 |
| PASS | student | fee | sees_updated_paid_amount | true | true | paid=100.00 |
| PASS | admin | stats | discipline_after_produce | HTTP=200 code=0 | HTTP=200 code=0 |  |
| PASS | admin | stats | discipline_has_safety | true | true | count=10 safety=True |
| PASS | dorm_manager | visitor | dm1_query_b1 | HTTP=200 code=0 | HTTP=200 code=0 |  |
