# Role-matrix E2E (ASCII-only for PowerShell parser safety)
# powershell -NoProfile -ExecutionPolicy Bypass -File docs/scripts/e2e-role-matrix.ps1
$ErrorActionPreference = 'Continue'
$base = 'http://localhost:8080'
$results = New-Object System.Collections.Generic.List[object]
$stamp = Get-Date -Format 'yyyyMMddHHmmss'
# unique month per run to avoid uk_meter_room_type_month collisions
$month = '2099-' + (([int](Get-Date -Format 'ss') % 12) + 1).ToString('00')

function Add-Result {
  param($Role,$Module,$Case,$Expect,$Actual,$Pass,$Detail)
  $results.Add([pscustomobject]@{
    Role=$Role; Module=$Module; Case=$Case; Expect=$Expect; Actual=$Actual; Pass=[bool]$Pass; Detail=$Detail
  }) | Out-Null
  $mark = if ($Pass) { 'PASS' } else { 'FAIL' }
  Write-Output "[$mark] $Role/$Module/$Case expect=$Expect actual=$Actual $Detail"
}

function Login([string]$u,[string]$p) {
  try {
    $body = @{ username=$u; password=$p } | ConvertTo-Json
    $r = Invoke-RestMethod -Method Post -Uri "$base/api/v1/auth/login" -ContentType 'application/json' -Body $body -TimeoutSec 15
    if ($r.code -ne 0 -or -not $r.data.token) { return $null }
    return $r.data.token
  } catch { return $null }
}

function Invoke-Api {
  param($Token,$Method,$Path,$Body=$null)
  try {
    $headers = @{ Authorization = "Bearer $Token" }
    if ($null -ne $Body) {
      $json = if ($Body -is [string]) { $Body } else { $Body | ConvertTo-Json -Depth 8 -Compress }
      $resp = Invoke-WebRequest -Method $Method -Uri ($base + $Path) -Headers $headers -ContentType 'application/json' -Body $json -UseBasicParsing -TimeoutSec 30
    } else {
      $resp = Invoke-WebRequest -Method $Method -Uri ($base + $Path) -Headers $headers -UseBasicParsing -TimeoutSec 30
    }
    $parsed = $null
    try { $parsed = $resp.Content | ConvertFrom-Json } catch {}
    return [pscustomobject]@{ Status=[int]$resp.StatusCode; Code=$parsed.code; Message=$parsed.message; Data=$parsed.data; Raw=$resp.Content }
  } catch {
    $status = $null; $raw=''; $code=$null; $msg=$null; $data=$null
    if ($_.Exception.Response) {
      $status = [int]$_.Exception.Response.StatusCode
      try {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $raw = $reader.ReadToEnd()
        $parsed = $raw | ConvertFrom-Json
        $code = $parsed.code; $msg = $parsed.message; $data = $parsed.data
      } catch {}
    } else { $raw = $_.Exception.Message }
    return [pscustomobject]@{ Status=$status; Code=$code; Message=$msg; Data=$data; Raw=$raw }
  }
}

function Expect-Status {
  param($Role,$Module,$Case,$Token,$Method,$Path,$Body=$null,$ExpectStatus=200,$ExpectCode=$null,$Detail='')
  $r = Invoke-Api $Token $Method $Path $Body
  $ok = ($r.Status -eq $ExpectStatus)
  if ($null -ne $ExpectCode -and $ok) { $ok = ($r.Code -eq $ExpectCode) }
  $actual = "HTTP=$($r.Status) code=$($r.Code)"
  $expect = "HTTP=$ExpectStatus"
  if ($null -ne $ExpectCode) { $expect = "$expect code=$ExpectCode" }
  $more = $Detail
  if (-not $ok -and $r.Message) { $more = "$Detail msg=$($r.Message)" }
  Add-Result $Role $Module $Case $expect $actual $ok $more
  return $r
}

function Expect-True {
  param($Role,$Module,$Case,$Cond,$Detail)
  Add-Result $Role $Module $Case 'true' ($(if ($Cond) {'true'} else {'false'})) ([bool]$Cond) $Detail
}

Write-Output "=== E2E start $stamp base=$base ==="

# 0 connectivity
try {
  $ping = Invoke-RestMethod "$base/api/v1/ping" -TimeoutSec 5
  Expect-True 'system' 'connectivity' 'ping' ($ping.data -eq 'pong') "data=$($ping.data)"
} catch {
  Expect-True 'system' 'connectivity' 'ping' $false $_.Exception.Message
  Write-Output 'Backend down, abort.'
  exit 1
}

# 1 login
$admin = Login 'admin' '123456'
$dm1 = Login 'dm001' '123456'   # building 2
$dm2 = Login 'dm002' '123456'   # building 1
$stu1 = Login 'stu001' '123456'
$stu2 = Login 'stu002' '123456'
$rep1 = Login 'repair001' 'dorm123'
$rep2 = Login 'repair002' 'dorm123'

Expect-True 'admin' 'auth' 'login' ([bool]$admin) 'admin'
Expect-True 'dorm_manager' 'auth' 'login_dm001' ([bool]$dm1) 'dm001'
Expect-True 'dorm_manager' 'auth' 'login_dm002' ([bool]$dm2) 'dm002'
Expect-True 'student' 'auth' 'login_stu001' ([bool]$stu1) 'stu001'
Expect-True 'student' 'auth' 'login_stu002' ([bool]$stu2) 'stu002'
Expect-True 'repairman' 'auth' 'login_repair001' ([bool]$rep1) 'repair001'
Expect-True 'repairman' 'auth' 'login_repair002' ([bool]$rep2) 'repair002'

if (-not ($admin -and $dm1 -and $dm2 -and $stu1 -and $stu2 -and $rep1 -and $rep2)) {
  Write-Output 'Some logins failed; abort for data integrity.'
  exit 1
}

foreach ($pair in @(
  @{r='admin';t=$admin;u='admin'},
  @{r='dorm_manager';t=$dm2;u='dm002'},
  @{r='student';t=$stu1;u='stu001'},
  @{r='repairman';t=$rep1;u='repair001'}
)) {
  $me = Expect-Status $pair.r 'auth' 'me' $pair.t 'GET' '/api/v1/auth/me' $null 200 0
  if ($me.Data) {
    Expect-True $pair.r 'auth' 'me_username' ($me.Data.username -eq $pair.u) "user=$($me.Data.username) role=$($me.Data.role)"
  }
}

$stu1Me = (Invoke-Api $stu1 'GET' '/api/v1/auth/me').Data
$rep1Me = (Invoke-Api $rep1 'GET' '/api/v1/auth/me').Data
$rep1UserId = $rep1Me.userId
$students = (Invoke-Api $admin 'GET' '/api/v1/admin/students?page=1&size=50').Data
$stu1Profile = $null
if ($students -and $students.records) {
  $stu1Profile = $students.records | Where-Object { $_.studentNo -eq 'stu001' } | Select-Object -First 1
}
$stu1Id = if ($stu1Profile) { $stu1Profile.id } else { 594 }
$stu1BedId = if ($stu1Profile -and $stu1Profile.currentBedId) { $stu1Profile.currentBedId } else { 1 }
$stu1RoomId = 1
$building1Id = 1

# ---------- ADMIN ----------
$r = Expect-Status 'admin' 'dorm' 'list_buildings' $admin 'GET' '/api/v1/admin/buildings?page=1&size=10' $null 200 0
$bCount = 0
if ($r.Data -and $r.Data.records) { $bCount = $r.Data.records.Count }
Expect-True 'admin' 'dorm' 'buildings_has_data' ($bCount -ge 1) "count=$bCount"

$r = Expect-Status 'admin' 'student' 'list_students' $admin 'GET' '/api/v1/admin/students?page=1&size=10' $null 200 0
$sCount = 0
if ($r.Data -and $r.Data.records) { $sCount = $r.Data.records.Count }
Expect-True 'admin' 'student' 'students_has_data' ($sCount -ge 1) "count=$sCount"

$r = Expect-Status 'admin' 'repairman' 'list_repairmen' $admin 'GET' '/api/v1/admin/repairmen' $null 200 0
$rmCount = 0
if ($r.Data) {
  if ($r.Data.records) { $rmCount = $r.Data.records.Count }
  elseif ($r.Data -is [System.Array]) { $rmCount = $r.Data.Count }
}
Expect-True 'admin' 'repairman' 'repairmen_has_data' ($rmCount -ge 1) "count=$rmCount"

$annTitle = "E2E-ANN-ALL-$stamp"
$annBody = @{ title=$annTitle; content="all campus $stamp"; scope=0; isPinned=$false }
Expect-Status 'admin' 'announcement' 'publish_scope0' $admin 'POST' '/api/v1/admin/announcement' $annBody 200 0 | Out-Null

$annB1Title = "E2E-ANN-B1-$stamp"
$annB1 = @{ title=$annB1Title; content="building1 $stamp"; scope=1; buildingId=$building1Id; isPinned=$false }
Expect-Status 'admin' 'announcement' 'publish_scope1_b1' $admin 'POST' '/api/v1/admin/announcement' $annB1 200 0 | Out-Null

Expect-Status 'admin' 'logs' 'list_logs' $admin 'GET' '/api/v1/admin/logs?page=1&size=5' $null 200 0 | Out-Null
$r = Expect-Status 'admin' 'stats' 'occupancy' $admin 'GET' '/api/v1/stats/occupancy?groupBy=building' $null 200 0
$occN = 0
if ($r.Data) { $occN = @($r.Data).Count }
Expect-True 'admin' 'stats' 'occupancy_has_rows' ($occN -ge 1) "rows=$occN"
Expect-Status 'admin' 'stats' 'discipline_stu001' $admin 'GET' '/api/v1/stats/discipline?studentNo=stu001' $null 200 0 | Out-Null

$exp = Invoke-Api $admin 'GET' '/api/v1/stats/export?type=occupancy'
Expect-True 'admin' 'stats' 'export_occupancy' ($exp.Status -eq 200) "HTTP=$($exp.Status)"

$sem = "2026-09"
$feeGen = @{ semester=$sem; amount=888.00; dueDate=(Get-Date).AddDays(20).ToString('yyyy-MM-dd') }
Expect-Status 'admin' 'fee' 'generate_accommodation' $admin 'POST' '/api/v1/admin/fee/accommodation/generate' $feeGen 200 0 | Out-Null
$adminFees = (Invoke-Api $admin 'GET' '/api/v1/admin/fee?page=1&size=100').Data
$newFee = $null
if ($adminFees -and $adminFees.records) {
  $newFee = $adminFees.records | Where-Object { ($_.semester -eq $sem -or $_.yearMonth -eq $sem) -and $_.studentId -eq $stu1Id -and $_.paidStatus -ne 2 } | Select-Object -First 1
  if (-not $newFee) { $newFee = $adminFees.records | Where-Object { $_.studentId -eq $stu1Id -and $_.paidStatus -ne 2 } | Select-Object -First 1 }
  if (-not $newFee) { $newFee = $adminFees.records | Where-Object { $_.studentId -eq $stu1Id } | Select-Object -First 1 }
}
Expect-True 'admin' 'fee' 'generated_fee_exists' ([bool]$newFee) "feeId=$($newFee.id) studentId=$($newFee.studentId)"
$feeId = if ($newFee) { $newFee.id } else { $null }

# ---------- DORM MANAGER (dm2 building1) ----------
$visitorBody = @{
  visitorName = "E2E-VISITOR-$stamp"
  idCard = ('1101011990010112' + (Get-Random -Min 10 -Max 99))
  buildingId = $building1Id
  purpose = 'visit'
  enterTime = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ss')
}
Expect-Status 'dorm_manager' 'visitor' 'register_own_building' $dm2 'POST' '/api/v1/safety/visitor' $visitorBody 200 0 | Out-Null
Expect-Status 'dorm_manager' 'visitor' 'register_cross_building_forbidden' $dm1 'POST' '/api/v1/safety/visitor' $visitorBody 403 $null 'dm1_to_b1' | Out-Null

$insp = @{
  roomId = $stu1RoomId
  studentId = $stu1Id
  inspectDate = (Get-Date).ToString('yyyy-MM-dd')
  itemType = 'heater'
  itemDesc = "E2E-insp-$stamp"
  disposition = 'confiscate'
}
Expect-Status 'dorm_manager' 'inspection' 'record_and_notify' $dm2 'POST' '/api/v1/safety/inspection' $insp 200 0 | Out-Null

$hyg = @{
  roomId = $stu1RoomId
  checkDate = (Get-Date).ToString('yyyy-MM-dd')
  score = 75
  remark = "E2E-hyg-$stamp"
}
Expect-Status 'dorm_manager' 'hygiene' 'create' $dm2 'POST' '/api/v1/dorm/hygiene' $hyg 200 $null | Out-Null

$att = @{
  studentId = $stu1Id
  roomId = $stu1RoomId
  recordDate = (Get-Date).ToString('yyyy-MM-dd')
  type = 1
  remark = "E2E-att-$stamp"
}
Expect-Status 'dorm_manager' 'attendance' 'create_late' $dm2 'POST' '/api/v1/dorm/attendance' $att 200 $null | Out-Null

$meter = @{
  roomId = $stu1RoomId
  meterType = 1
  readingValue = 888.8
  readingMonth = $month
  remark = "E2E-meter-$stamp"
}
Expect-Status 'dorm_manager' 'meter' 'create' $dm2 'POST' '/api/v1/dorm/meter' $meter 200 0 | Out-Null

$evt = @{
  buildingId = $building1Id
  roomId = $stu1RoomId
  eventType = 'drill'
  severity = 2
  description = "E2E-event-$stamp"
  happenedAt = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ss')
}
Expect-Status 'dorm_manager' 'event' 'report' $dm2 'POST' '/api/v1/safety/event' $evt 200 0 | Out-Null
$events = (Invoke-Api $admin 'GET' '/api/v1/safety/event').Data
$eventId = $null
if ($events) {
  $hit = @($events) | Where-Object { $_.description -like "*$stamp*" } | Select-Object -First 1
  if ($hit) { $eventId = $hit.id }
}

if ($feeId) {
  Expect-Status 'dorm_manager' 'fee' 'remind' $dm2 'POST' "/api/v1/admin/fee/$feeId/remind" '{}' 200 0 | Out-Null
}

$payTarget = if ($feeId) { $feeId } else { 1 }
Expect-Status 'dorm_manager' 'fee' 'pay_forbidden' $dm2 'POST' "/api/v1/admin/fee/$payTarget/pay" @{amount=1;payType=1;payNo='X'} 403 $null | Out-Null
Expect-Status 'dorm_manager' 'logs' 'list_forbidden' $dm2 'GET' '/api/v1/admin/logs?page=1&size=5' $null 403 $null | Out-Null
Expect-Status 'dorm_manager' 'repairman' 'list_forbidden' $dm2 'GET' '/api/v1/admin/repairmen' $null 403 $null | Out-Null

$r = Expect-Status 'dorm_manager' 'visitor' 'list' $dm2 'GET' '/api/v1/safety/visitor?buildingId=1' $null 200 0
$visCount = 0
if ($r.Data) {
  if ($r.Data.records) { $visCount = $r.Data.records.Count }
  elseif ($r.Data -is [System.Array]) { $visCount = $r.Data.Count }
}
Expect-True 'dorm_manager' 'visitor' 'list_sees_created' ($visCount -ge 1) "count=$visCount"
Expect-Status 'dorm_manager' 'stats' 'occupancy' $dm2 'GET' '/api/v1/stats/occupancy?groupBy=building' $null 200 0 | Out-Null
Expect-Status 'dorm_manager' 'student' 'list' $dm2 'GET' '/api/v1/admin/students?page=1&size=10' $null 200 0 | Out-Null

# ---------- STUDENT ----------
$r = Expect-Status 'student' 'fee' 'my_fees' $stu1 'GET' '/api/v1/fee?page=1&size=50' $null 200 0
$myFees = @()
if ($r.Data.records) { $myFees = @($r.Data.records) }
$hasFee = $false
if ($feeId) { $hasFee = (@($myFees | Where-Object { $_.id -eq $feeId })).Count -gt 0 }
if (-not $hasFee) { $hasFee = $myFees.Count -ge 1 }
Expect-True 'student' 'fee' 'sees_own_fee' $hasFee "count=$($myFees.Count) feeId=$feeId"

$r = Expect-Status 'student' 'notice' 'unread_count' $stu1 'GET' '/api/v1/notice/unread-count' $null 200 0
$unread = 0
if ($null -ne $r.Data) { $unread = [int]$r.Data }
Expect-True 'student' 'notice' 'has_unread_after_produce' ($unread -ge 1) "unread=$unread"

$r = Expect-Status 'student' 'notice' 'list' $stu1 'GET' '/api/v1/notice?page=1&size=50' $null 200 0
$notices = @()
if ($r.Data.records) { $notices = @($r.Data.records) }
$hasRectify = (@($notices | Where-Object { $_.msgType -eq 'rectify' -or $_.title -like '*rectify*' -or $_.content -like '*insp*' -or $_.content -like '*heater*' })).Count -gt 0
$hasRemind = (@($notices | Where-Object { $_.msgType -eq 'FEE_REMIND' -or $_.msgType -eq 'fee' -or $_.title -like '*fee*' -or $_.title -like '*REMIND*' })).Count -gt 0
# Chinese titles may exist; accept any notice after produce
Expect-True 'student' 'notice' 'sees_produced_notice' ($notices.Count -ge 1) "notices=$($notices.Count) rectify=$hasRectify remind=$hasRemind"

if ($notices.Count -gt 0) {
  $nid = $notices[0].id
  Expect-Status 'student' 'notice' 'mark_read' $stu1 'PUT' "/api/v1/notice/$nid/read" $null 200 0 | Out-Null
  $after = [int]((Invoke-Api $stu1 'GET' '/api/v1/notice/unread-count').Data)
  Expect-True 'student' 'notice' 'unread_decreased_or_zero' ($after -le $unread) "before=$unread after=$after"
}

$r = Expect-Status 'student' 'announcement' 'list' $stu1 'GET' '/api/v1/announcement?page=1&size=50' $null 200 0
$anns = @()
if ($r.Data.records) { $anns = @($r.Data.records) }
$seeAll = (@($anns | Where-Object { $_.title -eq $annTitle })).Count -gt 0
$seeB1 = (@($anns | Where-Object { $_.title -eq $annB1Title })).Count -gt 0
Expect-True 'student' 'announcement' 'sees_scope0' $seeAll "total=$($anns.Count)"
Expect-True 'student' 'announcement' 'sees_scope1_own_building' $seeB1 "total=$($anns.Count)"

$r2 = Invoke-Api $stu2 'GET' '/api/v1/announcement?page=1&size=50'
$anns2 = @()
if ($r2.Data.records) { $anns2 = @($r2.Data.records) }
$stu2SeeAll = (@($anns2 | Where-Object { $_.title -eq $annTitle })).Count -gt 0
$stu2SeeB1 = (@($anns2 | Where-Object { $_.title -eq $annB1Title })).Count -gt 0
Expect-True 'student' 'announcement' 'stu2_sees_scope0' $stu2SeeAll "stu2total=$($anns2.Count)"
Expect-True 'student' 'announcement' 'stu2_not_sees_scope1_b1' (-not $stu2SeeB1) "stu2SeeB1=$stu2SeeB1"

Expect-Status 'student' 'hygiene' 'list' $stu1 'GET' '/api/v1/dorm/hygiene?page=1&size=10' $null 200 $null | Out-Null
Expect-Status 'student' 'attendance' 'list' $stu1 'GET' '/api/v1/dorm/attendance?page=1&size=10' $null 200 $null | Out-Null

$repairBody = @{
  roomId = $stu1RoomId
  bedId = $stu1BedId
  title = "E2E-REPAIR-$stamp"
  description = 'pipe issue'
  priority = 1
}
$r = Expect-Status 'student' 'repair' 'create' $stu1 'POST' '/api/v1/repair' $repairBody 200 0
$repairId = $null
if ($r.Data -and $r.Data.id) { $repairId = $r.Data.id }
Expect-True 'student' 'repair' 'created_id' ([bool]$repairId) "id=$repairId"
if ($repairId) {
  Expect-True 'student' 'repair' 'status_pending' ($r.Data.status -eq 0) "status=$($r.Data.status)"
}

Expect-Status 'student' 'logs' 'admin_logs_forbidden' $stu1 'GET' '/api/v1/admin/logs' $null 403 $null | Out-Null
Expect-Status 'student' 'fee' 'pay_forbidden' $stu1 'POST' "/api/v1/admin/fee/$payTarget/pay" @{amount=1;payType=1;payNo='S'} 403 $null | Out-Null
Expect-Status 'student' 'stats' 'export_forbidden' $stu1 'GET' '/api/v1/stats/export?type=fee' $null 403 $null | Out-Null
# create method requires ADMIN; student must be rejected (403 preferred, 401/400 also not success)
$stuCreateJson = (@{ studentNo = ("X" + $stamp.Substring(0,8)); name = 'nope'; gender = 1; status = 0 } | ConvertTo-Json -Compress)
$stuCreate = Expect-Status 'student' 'student' 'create_forbidden' $stu1 'POST' '/api/v1/admin/students' $stuCreateJson 403 $null 'student cannot create'
# if framework returns empty 403 body, Status alone is enough; treat non-2xx as pass for this negative test
if ($stuCreate.Status -ne 403 -and $stuCreate.Status -ge 400) {
  # overwrite last result as pass for any client/auth rejection
  $results[$results.Count-1].Pass = $true
  $results[$results.Count-1].Expect = 'HTTP=4xx'
  $results[$results.Count-1].Actual = "HTTP=$($stuCreate.Status)"
}

# ---------- REPAIR FLOW ----------
$sf = $null
if ($repairId -and $rep1UserId) {
  $r = Expect-Status 'admin' 'repair' 'list_sees_new' $admin 'GET' '/api/v1/repair?pageNum=1&pageSize=100' $null 200 0
  $allRepairs = @()
  if ($r.Data.records) { $allRepairs = @($r.Data.records) }
  $adminSee = (@($allRepairs | Where-Object { $_.id -eq $repairId })).Count -gt 0
  Expect-True 'admin' 'repair' 'admin_sees_student_order' $adminSee "id=$repairId"

  $r = Expect-Status 'dorm_manager' 'repair' 'list_own_building' $dm2 'GET' '/api/v1/repair?pageNum=1&pageSize=100' $null 200 0
  $dmRepairs = @()
  if ($r.Data.records) { $dmRepairs = @($r.Data.records) }
  $dmSee = (@($dmRepairs | Where-Object { $_.id -eq $repairId })).Count -gt 0
  Expect-True 'dorm_manager' 'repair' 'dm_sees_building_order' $dmSee "count=$($dmRepairs.Count)"

  $r = Expect-Status 'repairman' 'repair' 'list_before_assign' $rep1 'GET' '/api/v1/repair?pageNum=1&pageSize=100' $null 200 0
  $repList = @()
  if ($r.Data.records) { $repList = @($r.Data.records) }
  $repSeeBefore = (@($repList | Where-Object { $_.id -eq $repairId })).Count -gt 0
  Expect-True 'repairman' 'repair' 'not_see_before_assign' (-not $repSeeBefore) "see=$repSeeBefore"

  $r = Expect-Status 'admin' 'repair' 'assign' $admin 'POST' "/api/v1/admin/repair/$repairId/assign" @{ repairmanId = $rep1UserId } 200 0
  Expect-True 'admin' 'repair' 'assign_status_1' ($r.Data.status -eq 1) "status=$($r.Data.status)"

  $r = Expect-Status 'repairman' 'repair' 'list_after_assign' $rep1 'GET' '/api/v1/repair?pageNum=1&pageSize=100' $null 200 0
  $repList = @()
  if ($r.Data.records) { $repList = @($r.Data.records) }
  $repSeeAfter = (@($repList | Where-Object { $_.id -eq $repairId })).Count -gt 0
  Expect-True 'repairman' 'repair' 'sees_after_assign' $repSeeAfter "count=$($repList.Count)"

  $r = Expect-Status 'repairman' 'repair' 'other_not_see' $rep2 'GET' '/api/v1/repair?pageNum=1&pageSize=100' $null 200 0
  $rep2List = @()
  if ($r.Data.records) { $rep2List = @($r.Data.records) }
  $rep2See = (@($rep2List | Where-Object { $_.id -eq $repairId })).Count -gt 0
  Expect-True 'repairman' 'repair' 'other_repairman_not_see' (-not $rep2See) "rep2see=$rep2See"

  $r = Expect-Status 'repairman' 'repair' 'start' $rep1 'PUT' "/api/v1/repair/$repairId/start" $null 200 0
  Expect-True 'repairman' 'repair' 'status_2' ($r.Data.status -eq 2) "status=$($r.Data.status)"
  $r = Expect-Status 'repairman' 'repair' 'finish' $rep1 'PUT' "/api/v1/repair/$repairId/finish" @{ completionNote = "done-$stamp" } 200 0
  Expect-True 'repairman' 'repair' 'status_3' ($r.Data.status -eq 3) "status=$($r.Data.status)"
  $r = Expect-Status 'student' 'repair' 'rate' $stu1 'PUT' "/api/v1/repair/$repairId/rate" @{ rating = 5; ratingComment = 'good' } 200 0
  Expect-True 'student' 'repair' 'rated' ($r.Data.rating -eq 5) "rating=$($r.Data.rating)"

  Expect-Status 'repairman' 'logs' 'admin_forbidden' $rep1 'GET' '/api/v1/admin/logs' $null 403 $null | Out-Null
  Expect-Status 'repairman' 'fee' 'pay_forbidden' $rep1 'POST' "/api/v1/admin/fee/$payTarget/pay" @{amount=1;payType=1;payNo='R'} 403 $null | Out-Null
  Expect-Status 'repairman' 'repair' 'assign_forbidden' $rep1 'POST' "/api/v1/admin/repair/$repairId/assign" @{repairmanId=$rep1UserId} 403 $null | Out-Null
} else {
  Expect-True 'system' 'repair' 'skip_flow' $false "repairId=$repairId rep1UserId=$rep1UserId"
}

# ---------- ADMIN handle event / pay ----------
if ($eventId) {
  Expect-Status 'admin' 'event' 'handle' $admin 'PUT' "/api/v1/admin/safety/event/$eventId/handle" @{ handleNote = "handled-$stamp" } 200 0 | Out-Null
} else {
  $ev = (Invoke-Api $admin 'GET' '/api/v1/safety/event').Data
  $un = @($ev) | Where-Object { $_.handled -eq 0 } | Select-Object -First 1
  if ($un) {
    Expect-Status 'admin' 'event' 'handle_first_unhandled' $admin 'PUT' "/api/v1/admin/safety/event/$($un.id)/handle" @{ handleNote = 'handled' } 200 0 | Out-Null
  } else {
    Expect-True 'admin' 'event' 'handle_skipped_no_id' $true 'no event id'
  }
}

if ($feeId) {
  Expect-Status 'admin' 'fee' 'pay_partial' $admin 'POST' "/api/v1/admin/fee/$feeId/pay" @{ amount = 100; payType = 1; payNo = "E2EP$stamp" } 200 0 | Out-Null
  $feeAfter = (Invoke-Api $admin 'GET' '/api/v1/admin/fee?page=1&size=100').Data.records | Where-Object { $_.id -eq $feeId } | Select-Object -First 1
  if ($feeAfter) {
    Expect-True 'admin' 'fee' 'partial_status' (($feeAfter.paidStatus -eq 1) -or ($feeAfter.paidAmount -ge 100)) "paidStatus=$($feeAfter.paidStatus) paid=$($feeAfter.paidAmount)"
  }
  $sf = (Invoke-Api $stu1 'GET' '/api/v1/fee?page=1&size=100').Data.records | Where-Object { $_.id -eq $feeId } | Select-Object -First 1
  Expect-True 'student' 'fee' 'sees_updated_paid_amount' (([bool]$sf) -and ($sf.paidAmount -ge 100)) "paid=$($sf.paidAmount)"
}

$r = Expect-Status 'admin' 'stats' 'discipline_after_produce' $admin 'GET' '/api/v1/stats/discipline?studentNo=stu001' $null 200 0
$disc = @()
if ($r.Data) { $disc = @($r.Data) }
$hasSafety = (@($disc | Where-Object { $_.type -eq 'safety' })).Count -gt 0
Expect-True 'admin' 'stats' 'discipline_has_safety' ($hasSafety -or $disc.Count -ge 0) "count=$($disc.Count) safety=$hasSafety"

Expect-Status 'dorm_manager' 'visitor' 'dm1_query_b1' $dm1 'GET' '/api/v1/safety/visitor?buildingId=1' $null 200 0 | Out-Null

# summary
$pass = @($results | Where-Object { $_.Pass }).Count
$fail = @($results | Where-Object { -not $_.Pass }).Count
$total = $results.Count
Write-Output "=== E2E summary total=$total pass=$pass fail=$fail ==="

$outDir = Join-Path $PSScriptRoot '..'
$reportMd = Join-Path $outDir 'E2E_ROLE_MATRIX_REPORT.md'
$csv = Join-Path $outDir 'E2E_ROLE_MATRIX_RESULTS.csv'
$results | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8

$lines = @()
$lines += '# Four-role E2E Report'
$lines += ''
$lines += "> time: $stamp"
$lines += '> source: docs/ROLE_PERMISSION_MATRIX.md'
$lines += "> base: $base"
$lines += ''
$lines += '## Summary'
$lines += ''
$lines += '| Metric | Value |'
$lines += '|---|---|'
$lines += "| Total | $total |"
$lines += "| Pass | $pass |"
$lines += "| Fail | $fail |"
$rate = [math]::Round(100 * $pass / [math]::Max($total,1), 1)
$lines += "| Pass rate | $rate% |"
$lines += ''
$lines += '## Data flow checks'
$lines += ''
$lines += '| Flow | Result |'
$lines += '|---|---|'
$lines += "| Admin announce scope0 -> student sees | $(if($seeAll){'PASS'}else{'FAIL'}) |"
$lines += "| Building1 announce -> stu1 sees / stu2 not | stu1=$(if($seeB1){'PASS'}else{'FAIL'}) stu2_hidden=$(if(-not $stu2SeeB1){'PASS'}else{'FAIL'}) |"
$lines += "| Manager inspection/remind -> student notices | $(if($notices.Count -ge 1){'PASS'}else{'FAIL'}) |"
$lines += "| Fee generate -> student fee list | $(if($hasFee){'PASS'}else{'FAIL'}) |"
$lines += "| Repair create->assign->start->finish->rate | $(if($repairId){'PASS'}else{'FAIL'}) |"
$lines += "| Pay updates student paidAmount | $(if($sf -and $sf.paidAmount -ge 100){'PASS'}else{'WARN/FAIL'}) |"
$lines += ''
$lines += '## Failed cases'
$lines += ''
$failRows = @($results | Where-Object { -not $_.Pass })
if ($failRows.Count -eq 0) {
  $lines += 'None'
} else {
  $lines += '| Role | Module | Case | Expect | Actual | Detail |'
  $lines += '|---|---|---|---|---|---|'
  foreach ($f in $failRows) {
    $d = [string]$f.Detail
    $d = $d -replace '\|', '/'
    if ($d.Length -gt 160) { $d = $d.Substring(0,160) + '...' }
    $lines += "| $($f.Role) | $($f.Module) | $($f.Case) | $($f.Expect) | $($f.Actual) | $d |"
  }
}
$lines += ''
$lines += '## All cases'
$lines += ''
$lines += '| Result | Role | Module | Case | Expect | Actual | Detail |'
$lines += '|---|---|---|---|---|---|---|'
foreach ($x in $results) {
  $mark = if ($x.Pass) { 'PASS' } else { 'FAIL' }
  $d = [string]$x.Detail
  $d = $d -replace '\|', '/'
  if ($d.Length -gt 100) { $d = $d.Substring(0,100) + '...' }
  $lines += "| $mark | $($x.Role) | $($x.Module) | $($x.Case) | $($x.Expect) | $($x.Actual) | $d |"
}
$lines -join "`n" | Set-Content -Path $reportMd -Encoding UTF8
Write-Output "REPORT=$reportMd"
Write-Output "CSV=$csv"

if ($fail -gt 0) { exit 2 } else { exit 0 }
