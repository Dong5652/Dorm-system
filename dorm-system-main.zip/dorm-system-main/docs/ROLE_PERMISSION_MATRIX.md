# 角色权限矩阵（Role Permission Matrix）

> 依据：后端 `@PreAuthorize` + Service 数据范围过滤 + 前端菜单/路由  
> 更新日期：2026-07-27  
> 关联：`docs/API_SPEC.md` §1.5、`docs/PHASE_8_9_10_VERIFICATION_REPORT.md`

---

## 1. 角色定义

| 角色 | `sys_user.role` | Spring 权限码 | 数据范围 | 种子账号 |
|---|---|---|---|---|
| 管理员 | `admin` | `ROLE_ADMIN` | 全校 | `admin / 123456` |
| 宿管 | `dorm_manager` | `ROLE_DORM_MANAGER` | 绑定 `building_id` 的楼栋 | `dm001`、`dm002 / 123456` |
| 学生 | `student` | `ROLE_STUDENT` | 本人（及本寝室相关只读） | `stu001`、`stu002 / 123456` |
| 维修师傅 | `repairman` | `ROLE_REPAIRMAN` | 派给自己的工单 | `repair001`、`repair002 / dorm123` |

说明：
- 鉴权真源在**后端**；前端菜单只做可见性收敛，不能替代接口鉴权。
- 宿管跨楼栋写操作应返回 `403` / `40301`。
- 学生/师傅访问 `/admin/**` 管理写接口应返回 `403`。

---

## 2. 图例

| 符号 | 含义 |
|---|---|
| ✅ | 完整可用（读+写，或该模块主流程） |
| 👁 | 只读 / 有限查看 |
| ✍️ | 可写但范围受限（本楼/本人） |
| 📩 | 被动接收（消息/通知） |
| ❌ | 无权限 |

---

## 3. 模块权限矩阵

| 功能模块 | admin | dorm_manager | student | repairman | 备注 |
|---|---|---|---|---|---|
| 登录 / 改密 / me | ✅ | ✅ | ✅ | ✅ | `/api/v1/auth/**` |
| Dashboard 首页 | ✅ | ✅ | ✅ | ✅ | 卡片/图按角色数据不同 |
| 宿舍结构（楼栋/层/房/床） | ✅ CRUD | 👁 本楼 | ❌ | ❌ | 结构写操作仅 admin |
| 学生档案 | ✅ CRUD/导入导出 | 👁 本楼 | 👁 本人相关 | ❌ | 导入导出仅 admin |
| 入住 / 退宿 / 调宿 | ✅ | ✍️ 本楼 | 👁 本人记录 | ❌ | 批量退宿仅 admin |
| 卫生检查 | ✅ | ✍️ 本楼 | 👁 本寝室 | ❌ | 删除通常 admin |
| 晚归考勤 | ✅ | ✍️ 本楼 | 👁 本人 | ❌ | |
| 寝室评分 | ✅ 触发/手工 | 👁 | 👁 | ❌ | |
| 维修工单 | ✅ 全权+派单 | ✍️ 代报修+本楼看 | ✍️ 报修/评价/取消 | ✍️ 接单/完工 | 列表按角色过滤 |
| 师傅账号管理 | ✅ | ❌ | ❌ | ❌ | `/admin/repairmen` |
| 访客登记 | ✅ | ✍️ 本楼 | ❌ | ❌ | 跨楼栋 403 |
| 违禁品检查 | ✅ | ✍️ 本楼 | 📩 整改消息 | ❌ | 录入后自动通知学生 |
| 安全事件 | ✅ 处理 | ✍️ 上报本楼 | ❌ | ❌ | |
| 水电抄表 | ✅ | ✍️ 本楼 | ❌ | ❌ | |
| 费用账单 | ✅ 出账/缴费/催缴 | 👁/催缴 | 👁 本人账单 | ❌ | `pay` 仅 admin |
| 公告 | ✅ 发布管理 | 👁 可见 scope | 👁 可见 scope | 👁 可见 scope | scope 0/1/2/3 |
| 站内消息 | ✅ 自己的 | ✅ 自己的 | ✅ 自己的 | ✅ 自己的 | `to_user_id` |
| 入住率/违纪统计 | ✅ | ✅ | ❌ | ❌ | |
| 报表导出 | ✅ | ❌ | ❌ | ❌ | EasyExcel |
| 操作日志 | ✅ | ❌ | ❌ | ❌ | `/admin/logs` |

---

## 4. 前端菜单可见性矩阵

> 落地文件：`dorm-system-frontend/src/layouts/MainLayout.vue`  
> 路由守卫：`dorm-system-frontend/src/router/index.ts`（`meta.roles`）

| 菜单 | 路径 | admin | dorm_manager | student | repairman |
|---|---|---|---|---|---|
| 首页 | `/` | ✅ | ✅ | ✅ | ✅ |
| 宿舍管理 | `/dorm/buildings` | ✅ | ✅ | ❌ | ❌ |
| 床位可视化 | `/dorm/room-beds` | ✅ | ✅ | ❌ | ❌ |
| 入住退宿 | `/dorm/check-in-out` | ✅ | ✅ | ❌ | ❌ |
| 卫生检查 | `/dorm/hygiene` | ✅ | ✅ | ✅（只读页） | ❌ |
| 晚归考勤 | `/dorm/attendance` | ✅ | ✅ | ✅（只读页） | ❌ |
| 寝室评分 | `/dorm/scores` | ✅ | ✅ | ✅（只读页） | ❌ |
| 维修工单 | `/repair` | ✅ | ✅ | ✅ | ✅ |
| 师傅管理 | `/admin/repairmen` | ✅ | ❌ | ❌ | ❌ |
| 学生档案 | `/student/archive` | ✅ | ✅ | ❌ | ❌ |
| 访客登记 | `/safety/visitor` | ✅ | ✅ | ❌ | ❌ |
| 违禁品检查 | `/safety/inspection` | ✅ | ✅ | ❌ | ❌ |
| 安全事件 | `/safety/event` | ✅ | ✅ | ❌ | ❌ |
| 费用管理 | `/fee/list` | ✅ | ✅ | ✅（本人） | ❌ |
| 水电抄表 | `/fee/meter` | ✅ | ✅ | ❌ | ❌ |
| 公告 | `/notice/announcement` | ✅ | ✅ | ✅ | ✅ |
| 我的消息 | `/notice/my` | ✅ | ✅ | ✅ | ✅ |
| 入住率统计 | `/stats/occupancy` | ✅ | ✅ | ❌ | ❌ |
| 违纪记录查询 | `/stats/discipline` | ✅ | ✅ | ❌ | ❌ |
| 报表导出 | `/stats/export` | ✅ | ❌ | ❌ | ❌ |
| 操作日志 | `/admin/logs` | ✅ | ❌ | ❌ | ❌ |

---

## 5. 后端接口权限摘要（按角色）

### 5.1 admin
- 全部业务模块读写
- 专属：学生导入导出、批量退宿、出账缴费、派单、师傅管理、报表导出、操作日志、事件处理

### 5.2 dorm_manager
- 允许：本楼栋入住/卫生/考勤/访客/违禁/事件上报/抄表/代报修/催缴/统计查询
- 禁止：`/admin/logs`、学生写删、结构 CRUD、缴费 pay、师傅管理、跨楼栋写

### 5.3 student
- 允许：本人账单、消息、公告（scope 内）、报修/评价/取消、部分只读查询
- 禁止：几乎全部 `/admin/**` 管理写接口

### 5.4 repairman
- 允许：`GET /repair`（自己的）、`PUT /repair/{id}/start|finish`
- 禁止：派单、删单、费用/安全/学生/统计管理接口

---

## 6. 维修状态机（跨角色协作）

```
学生/宿管 create → status=0 待派单
admin assign     → status=1 已派单
repairman start  → status=2 维修中
repairman finish → status=3 已完成
student rate     → 写入评分
student/admin cancel → status=4 已取消（约束内）
```

---

## 7. 安全验收要点

| 场景 | 期望 |
|---|---|
| 学生访问 `/admin/logs` `/admin/fee/{id}/pay` | 403 |
| 师傅访问 admin 管理接口 | 403 |
| 宿管跨楼栋访客登记 | 403 |
| 宿管本楼栋访客登记 | 200 |
| 操作日志 detail | 不落明文密码/完整身份证 |

---

## 8. 前端改造清单（已执行 / 约定）

详见同目录下文「前端菜单可见性改造清单」或提交说明。核心原则：

1. 菜单按角色 `v-if` 收敛，避免学生/师傅看到大量无效入口  
2. 路由 `meta.roles` + `beforeEach` 拦截直链  
3. 后端鉴权保持不变，前端仅 UX 层  
4. 页面内按钮级权限（如缴费按钮仅 admin）继续由各 View 的 `isAdmin/isManager` 控制  

---

## 9. 变更记录

| 日期 | 说明 |
|---|---|
| 2026-07-27 | 首版矩阵；同步 MainLayout 菜单可见性与路由 roles 守卫 |
| 2026-07-27 | 增加全角色 E2E：`docs/scripts/e2e-role-matrix.ps1`，报告 `docs/E2E_ROLE_MATRIX_REPORT.md`（96/96 通过） |
