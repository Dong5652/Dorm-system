# 前端菜单可见性改造清单

> 目标：侧栏菜单与路由直链与后端角色权限对齐，减少“看得见点不了/一点就 403”的体验。  
> 落地：`MainLayout.vue` + `router/index.ts`  
> 对照：`docs/ROLE_PERMISSION_MATRIX.md` §4

---

## 1. 改造前问题

| 问题 | 影响 |
|---|---|
| 侧栏几乎对所有登录角色展示全量菜单 | 学生/师傅看到宿舍管理、抄表、统计等无效入口 |
| 仅 `师傅管理`、`操作日志` 做了 `v-if=admin` | 权限收敛不完整 |
| 路由无 `meta.roles` | 可手工改 URL 进入无权限页面（虽后端 403，但 UX 差） |

---

## 2. 目标菜单可见性

| 菜单 | admin | dorm_manager | student | repairman |
|---|---|---|---|---|
| 首页 | ✅ | ✅ | ✅ | ✅ |
| 宿舍管理 | ✅ | ✅ | ❌ | ❌ |
| 床位可视化 | ✅ | ✅ | ❌ | ❌ |
| 入住退宿 | ✅ | ✅ | ❌ | ❌ |
| 卫生检查 | ✅ | ✅ | ✅ | ❌ |
| 晚归考勤 | ✅ | ✅ | ✅ | ❌ |
| 寝室评分 | ✅ | ✅ | ✅ | ❌ |
| 维修工单 | ✅ | ✅ | ✅ | ✅ |
| 师傅管理 | ✅ | ❌ | ❌ | ❌ |
| 学生档案 | ✅ | ✅ | ❌ | ❌ |
| 访客登记 | ✅ | ✅ | ❌ | ❌ |
| 违禁品检查 | ✅ | ✅ | ❌ | ❌ |
| 安全事件 | ✅ | ✅ | ❌ | ❌ |
| 费用管理 | ✅ | ✅ | ✅ | ❌ |
| 水电抄表 | ✅ | ✅ | ❌ | ❌ |
| 公告 | ✅ | ✅ | ✅ | ✅ |
| 我的消息 | ✅ | ✅ | ✅ | ✅ |
| 入住率统计 | ✅ | ✅ | ❌ | ❌ |
| 违纪记录查询 | ✅ | ✅ | ❌ | ❌ |
| 报表导出 | ✅ | ❌ | ❌ | ❌ |
| 操作日志 | ✅ | ❌ | ❌ | ❌ |

---

## 3. 实现方案

### 3.1 MainLayout 角色计算

```ts
const role = computed(() => store.role || '')
const isAdmin = computed(() => role.value === 'admin')
const isManager = computed(() => role.value === 'admin' || role.value === 'dorm_manager')
const isStudent = computed(() => role.value === 'student')
const isRepairman = computed(() => role.value === 'repairman')
```

菜单用组合条件控制，例如：

- 管理运营类：`v-if="isManager"`
- 学生可读业务：`v-if="isManager || isStudent"`
- 全员：无 `v-if` 或 `isAuthenticated`
- 仅 admin：`v-if="isAdmin"`
- 维修：四角色都可见（师傅核心入口）

### 3.2 路由 meta.roles

为子路由增加：

```ts
meta: { title: '...', roles: ['admin', 'dorm_manager'] }
```

`beforeEach` 中：

1. 未登录 → `/login`
2. 已登录但 `meta.roles` 不包含当前 role → 跳首页并提示无权限
3. 允许访问

### 3.3 不在本次范围

- 页面内按钮级权限（各 View 已有 `isAdmin/isManager`）保持
- 后端 `@PreAuthorize` 不改（真源）
- 不引入独立 ACL 框架

---

## 4. 验收清单

- [x] 代码已落地：`MainLayout.vue` 角色 `v-if` + `router` `meta.roles` 守卫
- [x] `vue-tsc --noEmit` 通过（TYPECHECK_OK）
- [ ] 浏览器：admin 登录看到全部菜单（含师傅管理/操作日志/报表导出）
- [ ] 浏览器：dm001 无师傅管理/操作日志/报表导出；有宿舍/安全/抄表
- [ ] 浏览器：stu001 仅首页、卫生/考勤/评分、维修、费用、公告、消息
- [ ] 浏览器：repair001 仅首页、维修、公告、消息
- [ ] 浏览器：学生直链 `/admin/logs` 被拦回首页
- [x] API：学生 `/admin/logs` 仍 403（后端不变，此前已验）

---

## 5. 变更文件

| 文件 | 变更 |
|---|---|
| `docs/ROLE_PERMISSION_MATRIX.md` | 权限总表 |
| `docs/FRONTEND_MENU_VISIBILITY.md` | 本清单 |
| `src/layouts/MainLayout.vue` | 菜单 `v-if` 按角色 |
| `src/router/index.ts` | `meta.roles` + 守卫 |

---

## 6. 后续可选

1. 将菜单配置抽成 `menu.ts` 数据驱动，避免模板里堆条件  
2. 学生卫生/考勤页若无“本人过滤”UI，可再做学生专用只读视图  
3. 路由守卫可改为跳转 `/403` 页而非静默回首页  
