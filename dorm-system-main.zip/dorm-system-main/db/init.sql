-- =============================================================================
-- 学校宿舍管理系统 — 数据库初始化脚本
-- MySQL 8.0 + utf8mb4
-- 用法： mysql -u root -p < db/init.sql
--       或使用 dorm/dorm123 账号连上 dorm_system 后导入
-- 注意： 脚本幂等，重复执行不会报错；软删除统一 is_deleted TINYINT 0/1
-- =============================================================================

CREATE DATABASE IF NOT EXISTS dorm_system
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_general_ci;

USE dorm_system;

-- 关闭外键检查便于重建
SET FOREIGN_KEY_CHECKS = 0;

-- -----------------------------------------------------------------------------
-- 1. building  楼栋表
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS building;
CREATE TABLE building (
    id            BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    code          VARCHAR(20)  NOT NULL COMMENT '楼栋编号，如 7B',
    name          VARCHAR(50)  NOT NULL COMMENT '楼栋名称，如 7号B楼',
    gender        TINYINT      NOT NULL COMMENT '1男 2女 3混合',
    floor_count   INT          NOT NULL DEFAULT 6 COMMENT '楼层数',
    manager_id    BIGINT       NULL COMMENT '管理该楼栋的宿管 user_id',
    remark        VARCHAR(200) NULL COMMENT '备注',
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted    TINYINT      NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    UNIQUE KEY uk_building_code (code)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '楼栋表';

-- -----------------------------------------------------------------------------
-- 2. floor  楼层表
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS floor;
CREATE TABLE floor (
    id            BIGINT  NOT NULL AUTO_INCREMENT COMMENT '主键',
    building_id   BIGINT  NOT NULL COMMENT 'FK building',
    floor_no      INT     NOT NULL COMMENT '楼层号，如 3',
    room_count    INT     NOT NULL DEFAULT 0 COMMENT '该层房间数',
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted    TINYINT NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    UNIQUE KEY uk_floor_building_no (building_id, floor_no)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '楼层表';

-- -----------------------------------------------------------------------------
-- 3. room  房间表
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS room;
CREATE TABLE room (
    id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    building_id     BIGINT       NOT NULL COMMENT 'FK building',
    floor_id        BIGINT       NOT NULL COMMENT 'FK floor',
    room_no         VARCHAR(10)  NOT NULL COMMENT '房间号，如 302',
    capacity        INT          NOT NULL DEFAULT 4 COMMENT '额定床位数',
    occupied_count  INT          NOT NULL DEFAULT 0 COMMENT '已入住数',
    status          TINYINT      NOT NULL DEFAULT 0 COMMENT '0空闲 1部分入住 2满员 3维修中 4锁定预留',
    remark          VARCHAR(200) NULL COMMENT '备注',
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted      TINYINT      NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    UNIQUE KEY uk_room_building_no (building_id, room_no)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '房间表';

-- -----------------------------------------------------------------------------
-- 4. bed  床位表
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS bed;
CREATE TABLE bed (
    id             BIGINT      NOT NULL AUTO_INCREMENT COMMENT '主键',
    room_id        BIGINT      NOT NULL COMMENT 'FK room',
    bed_no         VARCHAR(10) NOT NULL COMMENT '床位号，如 1 2',
    student_id     BIGINT      NULL COMMENT '当前入住学生 id，空表示空闲',
    status         TINYINT     NOT NULL DEFAULT 0 COMMENT '0空闲 1已占用 2维修中 3预留',
    check_in_time  DATETIME    NULL COMMENT '当前入住开始时间',
    created_at     DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted     TINYINT     NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    UNIQUE KEY uk_bed_room_no (room_id, bed_no)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '床位表';

-- -----------------------------------------------------------------------------
-- 5. sys_user  系统用户表（学生/宿管/管理员/维修师傅 统一）
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS sys_user;
CREATE TABLE sys_user (
    id            BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    username      VARCHAR(50)  NOT NULL COMMENT '登录账号（学生用学号，宿管用工号）',
    password      VARCHAR(100) NOT NULL COMMENT 'BCrypt 加密密码',
    real_name     VARCHAR(50)  NOT NULL COMMENT '真实姓名',
    role          VARCHAR(20)  NOT NULL COMMENT 'student / dorm_manager / admin / repairman',
    gender        TINYINT      NOT NULL DEFAULT 1 COMMENT '1男 2女',
    phone         VARCHAR(20) NULL COMMENT '联系电话',
    building_id   BIGINT       NULL COMMENT '宿管:管辖楼栋;维修师傅:无;学生:无',
    work_type     VARCHAR(50)  NULL COMMENT '维修师傅工种，如 水电/木工/综合',
    status        TINYINT      NOT NULL DEFAULT 1 COMMENT '0禁用 1启用',
    last_login_at DATETIME     NULL COMMENT '最近登录时间',
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted    TINYINT      NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    UNIQUE KEY uk_sys_user_username (username)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '系统用户表';

-- -----------------------------------------------------------------------------
-- 6. student  学生档案表（学生除学籍信息外的扩展字段）
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS student;
CREATE TABLE student (
    id               BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    user_id          BIGINT       NOT NULL COMMENT 'FK sys_user.id',
    student_no       VARCHAR(20)  NOT NULL COMMENT '学号，唯一（与 username 同值，冗余便于查询）',
    name             VARCHAR(50)  NOT NULL COMMENT '姓名（冗余 sys_user.real_name）',
    gender           TINYINT      NOT NULL COMMENT '性别（冗余，与 sys_user 一致）',
    college          VARCHAR(50)  NULL COMMENT '学院',
    major            VARCHAR(50)  NULL COMMENT '专业',
    class_name       VARCHAR(50)  NULL COMMENT '班级',
    grade            VARCHAR(10)  NULL COMMENT '年级，如 2024',
    current_bed_id   BIGINT       NULL COMMENT '当前床位 id，空表示未分配',
    emergency_contact VARCHAR(50) NULL COMMENT '紧急联系人',
    emergency_phone  VARCHAR(20)  NULL COMMENT '紧急联系电话',
    enroll_date      DATE         NULL COMMENT '入学日期',
    status           TINYINT      NOT NULL DEFAULT 0 COMMENT '0在籍 1休学 2毕业 3退学',
    created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted       TINYINT      NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    UNIQUE KEY uk_student_no (student_no)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '学生档案表';

-- -----------------------------------------------------------------------------
-- 7. check_in_record  入住/退宿流水
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS check_in_record;
CREATE TABLE check_in_record (
    id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    student_id      BIGINT       NOT NULL COMMENT 'FK student',
    bed_id          BIGINT       NOT NULL COMMENT 'FK bed',
    type            TINYINT      NOT NULL COMMENT '1入住 2退宿',
    operator_id     BIGINT       NOT NULL COMMENT '经办人 user_id',
    key_issued      TINYINT      NOT NULL DEFAULT 0 COMMENT '是否发放钥匙 0否1是',
    key_returned    TINYINT      NOT NULL DEFAULT 0 COMMENT '是否收回钥匙 0否1是（退宿时）',
    facility_check  VARCHAR(500) NULL COMMENT '设施清点备注',
    remark          VARCHAR(500) NULL COMMENT '备注',
    happened_at     DATETIME     NOT NULL COMMENT '发生时间',
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted      TINYINT      NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    KEY idx_check_in_student (student_id, happened_at)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '入住/退宿流水';

-- -----------------------------------------------------------------------------
-- 8. change_record  异动记录
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS change_record;
CREATE TABLE change_record (
    id           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    student_id   BIGINT       NOT NULL COMMENT 'FK student',
    type         VARCHAR(20)  NOT NULL COMMENT 'suspend/transfer/change_room/holiday_leave',
    from_bed_id  BIGINT       NULL COMMENT '原床位（调宿时）',
    to_bed_id    BIGINT       NULL COMMENT '新床位（调宿时）',
    reason       VARCHAR(500) NULL COMMENT '异动原因',
    operator_id  BIGINT       NOT NULL COMMENT '经办人 user_id',
    happened_at  DATETIME     NOT NULL COMMENT '发生时间',
    remark       VARCHAR(500) NULL COMMENT '备注',
    created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted   TINYINT      NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    KEY idx_change_student (student_id, happened_at)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '异动记录';

-- -----------------------------------------------------------------------------
-- 9. hygiene_check  卫生检查
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS hygiene_check;
CREATE TABLE hygiene_check (
    id           BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键',
    room_id      BIGINT        NOT NULL COMMENT 'FK room',
    check_date   DATE          NOT NULL COMMENT '检查日期',
    inspector_id BIGINT        NOT NULL COMMENT '检查人 user_id（宿管）',
    score        DECIMAL(5,2)  NOT NULL COMMENT '本次得分(0-100)',
    deduction    DECIMAL(5,2)  NOT NULL DEFAULT 0 COMMENT '扣分合计',
    bonus        DECIMAL(5,2)  NOT NULL DEFAULT 0 COMMENT '加分合计',
    photo_url    VARCHAR(500)  NULL COMMENT '现场照片',
    item_detail  TEXT          NULL COMMENT '扣分/加分项明细 JSON',
    remark       VARCHAR(500)  NULL COMMENT '备注',
    created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted   TINYINT       NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    KEY idx_hygiene_room_date (room_id, check_date)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '卫生检查';

-- -----------------------------------------------------------------------------
-- 10. attendance  晚归考勤
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS attendance;
CREATE TABLE attendance (
    id           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    student_id   BIGINT       NOT NULL COMMENT 'FK student',
    room_id      BIGINT       NOT NULL COMMENT 'FK room（冗余，通过 bed 反查）',
    record_date  DATE         NOT NULL COMMENT '记录日期',
    type         TINYINT      NOT NULL COMMENT '1晚归 2未归 3请假',
    return_time  DATETIME     NULL COMMENT '实际归寝时间（晚归时）',
    inspector_id BIGINT       NOT NULL COMMENT '记录人 user_id',
    remark       VARCHAR(500) NULL COMMENT '备注',
    created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted   TINYINT      NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    KEY idx_attendance_student_date (student_id, record_date)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '晚归考勤';

-- -----------------------------------------------------------------------------
-- 11. dorm_score  寝室综合评分
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS dorm_score;
CREATE TABLE dorm_score (
    id          BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键',
    room_id     BIGINT        NOT NULL COMMENT 'FK room',
    `year_month` VARCHAR(7)    NOT NULL COMMENT '评分月份，如 2026-03',
    hygiene_avg DECIMAL(5,2)  NOT NULL DEFAULT 0 COMMENT '该月卫生平均分',
    late_count  INT           NOT NULL DEFAULT 0 COMMENT '该月晚归/未归次数',
    total_score DECIMAL(6,2)  NOT NULL DEFAULT 0 COMMENT '综合评分 = hygieneAvg*0.6 + (100-late*5)*0.4',
    level       VARCHAR(10)   NOT NULL DEFAULT '合格' COMMENT '优秀/合格/待整改/不合格',
    remark      VARCHAR(500)  NULL COMMENT '评语',
    created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted  TINYINT       NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    UNIQUE KEY uk_dorm_score_room_month (room_id, `year_month`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '寝室综合评分';

-- -----------------------------------------------------------------------------
-- 12. repair_order  报修单
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS repair_order;
CREATE TABLE repair_order (
    id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    order_no        VARCHAR(30)  NOT NULL COMMENT '单号 RP + 日期 + 4位序号',
    room_id         BIGINT       NOT NULL COMMENT 'FK room',
    bed_id          BIGINT       NULL COMMENT '具体床位（可空）',
    reporter_id     BIGINT       NOT NULL COMMENT '报修人 user_id',
    title           VARCHAR(100) NOT NULL COMMENT '报修标题',
    description     TEXT         NULL COMMENT '故障描述',
    photo_url       VARCHAR(500) NULL COMMENT '现场照片',
    status          TINYINT      NOT NULL DEFAULT 0 COMMENT '0待派单 1已派单 2维修中 3已完成 4已取消',
    priority        TINYINT      NOT NULL DEFAULT 0 COMMENT '0普通 1紧急 2非常紧急',
    repairman_id    BIGINT       NULL COMMENT '派单维修师傅 user_id',
    assigned_at     DATETIME     NULL COMMENT '派单时间',
    assigned_by     BIGINT       NULL COMMENT '派单人 user_id',
    started_at      DATETIME     NULL COMMENT '开始维修时间',
    finished_at     DATETIME     NULL COMMENT '完成时间',
    completion_note TEXT         NULL COMMENT '维修说明',
    rating          TINYINT      NULL COMMENT '学生评价 1-5 星',
    rating_comment  VARCHAR(500) NULL COMMENT '学生评价备注',
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted      TINYINT      NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    UNIQUE KEY uk_repair_order_no (order_no),
    KEY idx_repair_status_repairman (status, repairman_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '报修单';

-- -----------------------------------------------------------------------------
-- 13. visitor  访客登记
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS visitor;
CREATE TABLE visitor (
    id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    visitor_name    VARCHAR(50)  NOT NULL COMMENT '访客姓名',
    id_card         VARCHAR(20)  NOT NULL COMMENT '身份证号',
    phone           VARCHAR(20)  NULL COMMENT '联系电话',
    visit_target_id BIGINT       NULL COMMENT '被访学生 id',
    building_id     BIGINT       NOT NULL COMMENT '进入楼栋 id',
    purpose         VARCHAR(200) NULL COMMENT '来访目的',
    enter_time      DATETIME     NOT NULL COMMENT '进入时间',
    exit_time       DATETIME     NULL COMMENT '离开时间（未登记表示仍在内）',
    register_by     BIGINT       NOT NULL COMMENT '登记人 user_id',
    remark          VARCHAR(500) NULL COMMENT '备注',
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted      TINYINT      NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    KEY idx_visitor_building_enter (building_id, enter_time)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '访客登记';

-- -----------------------------------------------------------------------------
-- 14. safety_inspection  违禁品检查
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS safety_inspection;
CREATE TABLE safety_inspection (
    id           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    room_id      BIGINT       NOT NULL COMMENT 'FK room',
    student_id   BIGINT       NULL COMMENT '相关学生（可空，只针对寝室）',
    inspect_date DATE         NOT NULL COMMENT '检查日期',
    inspector_id BIGINT       NOT NULL COMMENT '检查人 user_id',
    item_type    VARCHAR(50)  NOT NULL COMMENT '违禁类型，如 大功率电器',
    item_desc    VARCHAR(200) NULL COMMENT '物品描述',
    photo_url    VARCHAR(500) NULL COMMENT '查获照片',
    disposition  VARCHAR(20)  NULL COMMENT '没收保管 / 限期带离 / 通报批评',
    notice_sent  TINYINT      NOT NULL DEFAULT 0 COMMENT '是否已发整改通知 0否1是',
    remark       VARCHAR(500) NULL COMMENT '备注',
    created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted   TINYINT      NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    KEY idx_inspection_room_date (room_id, inspect_date)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '违禁品检查';

-- -----------------------------------------------------------------------------
-- 15. safety_event  安全事件
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS safety_event;
CREATE TABLE safety_event (
    id           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    building_id  BIGINT       NOT NULL COMMENT 'FK building',
    room_id      BIGINT       NULL COMMENT 'FK room（可空，楼栋公共事件）',
    event_type   VARCHAR(30)  NOT NULL COMMENT '火情/设施失控/人员异常/其它',
    severity     TINYINT      NOT NULL DEFAULT 0 COMMENT '0一般 1较重 2严重',
    description  TEXT         NULL COMMENT '事件描述',
    photo_url    VARCHAR(500) NULL COMMENT '现场照片',
    reported_by  BIGINT       NOT NULL COMMENT '上报人 user_id',
    handled      TINYINT      NOT NULL DEFAULT 0 COMMENT '0待处理 1已处理',
    handle_note  TEXT         NULL COMMENT '处置说明',
    happened_at  DATETIME     NOT NULL COMMENT '事件发生时间',
    created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted   TINYINT      NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    KEY idx_event_building_happened (building_id, happened_at)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '安全事件';

-- -----------------------------------------------------------------------------
-- 16. fee  费用账单表
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS fee;
CREATE TABLE fee (
    id           BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键',
    student_id   BIGINT        NOT NULL COMMENT 'FK student',
    fee_type     VARCHAR(20)   NOT NULL COMMENT 'accommodation（住宿费） / utility（水电费）',
    `year_month`  VARCHAR(7)    NULL COMMENT '账期，水电费按月如 2026-03；住宿费按学期留空',
    semester     VARCHAR(20)   NULL COMMENT '住宿费归口学期，如 2025-2026-1',
    amount       DECIMAL(10,2) NOT NULL COMMENT '应缴金额',
    paid_amount  DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT '已缴金额',
    paid_status  TINYINT       NOT NULL DEFAULT 0 COMMENT '0未缴 1部分缴费 2已缴清',
    due_date     DATE          NULL COMMENT '缴费截止日',
    remark       VARCHAR(200)  NULL COMMENT '备注',
    created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted   TINYINT       NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    KEY idx_fee_student (student_id, fee_type, `year_month`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '费用账单表';

-- -----------------------------------------------------------------------------
-- 17. meter_reading  每月抄表记录
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS meter_reading;
CREATE TABLE meter_reading (
    id             BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键',
    room_id        BIGINT        NOT NULL COMMENT 'FK room',
    meter_type     TINYINT       NOT NULL COMMENT '1水表 2电表',
    reading_value  DECIMAL(12,2) NOT NULL COMMENT '本次抄表读数',
    previous_value DECIMAL(12,2) NOT NULL DEFAULT 0 COMMENT '上次读数',
    usage_amount   DECIMAL(12,2) NOT NULL DEFAULT 0 COMMENT '本月用量 = reading - previous',
    unit_price     DECIMAL(8,4)  NOT NULL DEFAULT 0 COMMENT '单价',
    amount         DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT '本月费用 = usage * unit_price',
    reading_month  VARCHAR(7)    NOT NULL COMMENT '抄表月份，如 2026-03',
    reader_id      BIGINT        NOT NULL COMMENT '抄表人 user_id',
    remark         VARCHAR(200)  NULL COMMENT '备注',
    created_at     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted     TINYINT       NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    UNIQUE KEY uk_meter_room_type_month (room_id, meter_type, reading_month)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '每月抄表记录';

-- -----------------------------------------------------------------------------
-- 18. payment  缴费记录
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS payment;
CREATE TABLE payment (
    id           BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键',
    fee_id       BIGINT        NOT NULL COMMENT 'FK fee',
    student_id   BIGINT        NOT NULL COMMENT 'FK student',
    amount       DECIMAL(10,2) NOT NULL COMMENT '本次实缴金额',
    pay_type     TINYINT       NOT NULL COMMENT '1现金 2微信 3支付宝 4银行转账',
    pay_time     DATETIME       NOT NULL COMMENT '缴费时间',
    operator_id  BIGINT        NOT NULL COMMENT '收款人 user_id',
    pay_no       VARCHAR(50)   NULL COMMENT '第三方流水号',
    remark       VARCHAR(200)  NULL COMMENT '备注',
    created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted   TINYINT       NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    KEY idx_payment_fee (fee_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '缴费记录';

-- -----------------------------------------------------------------------------
-- 19. announcement  公告表
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS announcement;
CREATE TABLE announcement (
    id            BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    title         VARCHAR(200) NOT NULL COMMENT '公告标题',
    content       TEXT         NOT NULL COMMENT '公告正文',
    scope         TINYINT      NOT NULL DEFAULT 0 COMMENT '0全校 1指定楼栋 2指定寝室 3指定学生',
    building_id   BIGINT       NULL COMMENT 'scope=1 时生效',
    target_room_id BIGINT      NULL COMMENT 'scope=2 时生效：目标寝室 room_id',
    target_student_id BIGINT   NULL COMMENT 'scope=3 时生效：目标学生 student.id',
    publish_by    BIGINT       NOT NULL COMMENT '发布人 user_id',
    publish_time  DATETIME     NOT NULL COMMENT '发布时间',
    is_pinned     TINYINT      NOT NULL DEFAULT 0 COMMENT '0否 1置顶',
    expire_time   DATETIME     NULL COMMENT '过期时间（可空）',
    status        TINYINT      NOT NULL DEFAULT 1 COMMENT '0草稿 1已发布 2已下架',
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted    TINYINT      NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    KEY idx_announcement_publish (status, publish_time)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '公告表';

-- -----------------------------------------------------------------------------
-- 20. notice_message  站内消息
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS notice_message;
CREATE TABLE notice_message (
    id            BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    to_user_id    BIGINT       NOT NULL COMMENT '接收人 user_id',
    from_user_id  BIGINT       NULL COMMENT '发送人 user_id，空表示系统消息',
    title         VARCHAR(200) NOT NULL COMMENT '消息标题',
    content       TEXT         NULL COMMENT '消息内容',
    msg_type      VARCHAR(20)  NOT NULL COMMENT 'fee/rectify/notice/system',
    ref_id        BIGINT       NULL COMMENT '关联业务对象 ID',
    is_read       TINYINT      NOT NULL DEFAULT 0 COMMENT '0未读 1已读',
    read_time     DATETIME     NULL COMMENT '阅读时间',
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    is_deleted    TINYINT      NOT NULL DEFAULT 0 COMMENT '0未删 1已删',
    PRIMARY KEY (id),
    KEY idx_notice_user_read (to_user_id, is_read)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '站内消息';

-- -----------------------------------------------------------------------------
-- 21. operation_log  操作日志
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS operation_log;
CREATE TABLE operation_log (
    id           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    operator_id  BIGINT       NOT NULL COMMENT '操作人 user_id',
    module       VARCHAR(30)  NOT NULL COMMENT '模块名，如 student/fee/hygiene',
    action       VARCHAR(30)  NOT NULL COMMENT '操作类型，如 insert/update/delete/login',
    target_table VARCHAR(50)  NOT NULL COMMENT '操作表名',
    target_id    BIGINT       NULL COMMENT '操作记录主键',
    detail       TEXT         NULL COMMENT '变更明细 JSON',
    ip           VARCHAR(50)  NULL COMMENT '操作 IP',
    created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (id),
    KEY idx_log_operator_created (operator_id, created_at)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '操作日志';

SET FOREIGN_KEY_CHECKS = 1;

-- =============================================================================
-- 初始数据（开发期种子数据）
-- 密码说明：
--   admin / dorm_manager 默认密码 "123456"
--     BCrypt(10) = $2a$10$NdYofFJ.iXuW1g/U.AL8xuCoDjDnPv7nbeBlM61iBRqSfF6Nz.VXy
--   repairman 默认密码 "dorm123"
--     BCrypt(10) = $2a$10$JwcM5lpKSLAkV8361BMdve3OXg2EZ17SpKqKy51madFGcRMCq0DjW
-- =============================================================================

-- 系统账号
INSERT INTO sys_user (username, password, real_name, role, gender, phone, building_id, work_type, status) VALUES
    ('admin',     '$2a$10$NdYofFJ.iXuW1g/U.AL8xuCoDjDnPv7nbeBlM61iBRqSfF6Nz.VXy', '超管',    'admin',        1, '13800138000', NULL, NULL,    1),
    ('dm001',     '$2a$10$NdYofFJ.iXuW1g/U.AL8xuCoDjDnPv7nbeBlM61iBRqSfF6Nz.VXy', '李宿管',  'dorm_manager', 2, '13800138001', NULL, NULL,    1),
    ('dm002',     '$2a$10$NdYofFJ.iXuW1g/U.AL8xuCoDjDnPv7nbeBlM61iBRqSfF6Nz.VXy', '王宿管',  'dorm_manager', 1, '13800138002', NULL, NULL,    1),
    ('repair001', '$2a$10$JwcM5lpKSLAkV8361BMdve3OXg2EZ17SpKqKy51madFGcRMCq0DjW', '张师傅',  'repairman',    1, '13800138003', NULL, '水电',  1),
    ('repair002', '$2a$10$JwcM5lpKSLAkV8361BMdve3OXg2EZ17SpKqKy51madFGcRMCq0DjW', '刘师傅',  'repairman',    1, '13800138004', NULL, '综合',  1);

-- 楼栋（一栋男生楼 + 一栋女生楼）+ 绑定宿管
INSERT INTO building (code, name, gender, floor_count, manager_id, remark) VALUES
    ('7B', '7号B楼', 1, 6, 3, '男生楼'),
    ('8A', '8号A楼', 2, 6, 2, '女生楼');

-- 给宿管绑定管辖楼栋
UPDATE sys_user SET building_id = 1 WHERE username = 'dm002';
UPDATE sys_user SET building_id = 2 WHERE username = 'dm001';

-- 楼层（每栋 6 层）
INSERT INTO floor (building_id, floor_no, room_count) VALUES
    (1, 1, 10), (1, 2, 10), (1, 3, 10), (1, 4, 10), (1, 5, 10), (1, 6, 10),
    (2, 1, 10), (2, 2, 10), (2, 3, 10), (2, 4, 10), (2, 5, 10), (2, 6, 10);

-- 房间示例（每栋楼 1-3 层各一个房间，每房 4 床位）
INSERT INTO room (building_id, floor_id, room_no, capacity, occupied_count, status) VALUES
    (1, 1, '101', 4, 0, 0),
    (1, 2, '201', 4, 0, 0),
    (1, 3, '301', 4, 0, 0),
    (2, 1, '101', 4, 0, 0),
    (2, 2, '201', 4, 0, 0),
    (2, 3, '301', 4, 0, 0);

-- 床位示例（每个示例房间 4 张床位）
INSERT INTO bed (room_id, bed_no, status) VALUES
    (1, '1', 0), (1, '2', 0), (1, '3', 0), (1, '4', 0),
    (2, '1', 0), (2, '2', 0), (2, '3', 0), (2, '4', 0),
    (3, '1', 0), (3, '2', 0), (3, '3', 0), (3, '4', 0),
    (4, '1', 0), (4, '2', 0), (4, '3', 0), (4, '4', 0),
    (5, '1', 0), (5, '2', 0), (5, '3', 0), (5, '4', 0),
    (6, '1', 0), (6, '2', 0), (6, '3', 0), (6, '4', 0);

-- 一条示例水电抄表（room_id=1 fifo 水表）
INSERT INTO meter_reading
    (room_id, meter_type, reading_value, previous_value, usage_amount, unit_price, amount, reading_month, reader_id, remark)
VALUES
    (1, 1, 120.50, 100.00, 20.50, 3.5000, 71.75, '2026-03', 3, '例行抄表');

-- 示例学生账号（密码 123456）+ 档案 + 床位占用 + 未缴账单
INSERT INTO sys_user (username, password, real_name, role, gender, phone, building_id, status) VALUES
    ('stu001', '$2a$10$NdYofFJ.iXuW1g/U.AL8xuCoDjDnPv7nbeBlM61iBRqSfF6Nz.VXy', '张三', 'student', 1, '13900000001', 1, 1),
    ('stu002', '$2a$10$NdYofFJ.iXuW1g/U.AL8xuCoDjDnPv7nbeBlM61iBRqSfF6Nz.VXy', '李四', 'student', 2, '13900000002', 2, 1);

INSERT INTO student (user_id, student_no, name, gender, college, major, class_name, grade, current_bed_id, status)
SELECT id, 'stu001', '张三', 1, '信息学院', '软件工程', '软工2401', '2024', 1, 0
FROM sys_user WHERE username = 'stu001';
INSERT INTO student (user_id, student_no, name, gender, college, major, class_name, grade, current_bed_id, status)
SELECT id, 'stu002', '李四', 2, '信息学院', '计算机', '计科2401', '2024', 13, 0
FROM sys_user WHERE username = 'stu002';

UPDATE bed b
JOIN student s ON s.student_no = 'stu001'
SET b.student_id = s.id, b.status = 1, b.check_in_time = NOW()
WHERE b.id = 1;
UPDATE bed b
JOIN student s ON s.student_no = 'stu002'
SET b.student_id = s.id, b.status = 1, b.check_in_time = NOW()
WHERE b.id = 13;
UPDATE room SET occupied_count = 1, status = 1 WHERE id IN (1, 4);

INSERT INTO fee (student_id, fee_type, `year_month`, semester, amount, paid_amount, paid_status, due_date)
SELECT s.id, 'accommodation', '2026-03', '2026S1', 1200.00, 0.00, 0, DATE_ADD(CURDATE(), INTERVAL 30 DAY)
FROM student s WHERE s.student_no = 'stu001';

-- 完成提示
SELECT CONCAT('dorm_system 初始化完成，共 ',
              (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'dorm_system'),
              ' 张表') AS msg;
